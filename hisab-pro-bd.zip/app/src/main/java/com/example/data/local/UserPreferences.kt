package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "hisab_pro_prefs")

data class AppSettingsState(
    val onboardingCompleted: Boolean = false,
    val activeBusinessId: String = "",
    val languageCode: String = "en",
    val darkModePreference: String = "SYSTEM", // SYSTEM, LIGHT, DARK
    val useBanglaDigits: Boolean = false,
    val pinHash: String = "",
    val pinSalt: String = "",
    val biometricEnabled: Boolean = false,
    val activeEmployeeId: String = "",
    val dueReminderEnabled: Boolean = true,
    val lowStockAlertEnabled: Boolean = true,
    val dailySummaryEnabled: Boolean = true,
    val autoBackupEnabled: Boolean = true,
    val lastCloudSyncMillis: Long = 0L,
    val lastLocalBackupMillis: Long = 0L
) {
    val hasPin: Boolean get() = pinHash.isNotBlank() && pinSalt.isNotBlank()
}

class UserPreferences(private val context: Context) {
    private object Keys {
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val ACTIVE_BUSINESS_ID = stringPreferencesKey("active_business_id")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val DARK_MODE = stringPreferencesKey("dark_mode")
        val BANGLA_DIGITS = booleanPreferencesKey("bangla_digits")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val ACTIVE_EMPLOYEE_ID = stringPreferencesKey("active_employee_id")
        val DUE_REMINDER = booleanPreferencesKey("due_reminder")
        val LOW_STOCK_ALERT = booleanPreferencesKey("low_stock_alert")
        val DAILY_SUMMARY = booleanPreferencesKey("daily_summary")
        val AUTO_BACKUP = booleanPreferencesKey("auto_backup")
        val LAST_CLOUD_SYNC = longPreferencesKey("last_cloud_sync")
        val LAST_LOCAL_BACKUP = longPreferencesKey("last_local_backup")
    }

    val settingsFlow: Flow<AppSettingsState> = context.dataStore.data.map { prefs ->
        val lang = prefs[Keys.LANGUAGE_CODE] ?: "en"
        AppSettingsState(
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            activeBusinessId = prefs[Keys.ACTIVE_BUSINESS_ID] ?: "",
            languageCode = lang,
            darkModePreference = prefs[Keys.DARK_MODE] ?: "SYSTEM",
            useBanglaDigits = prefs[Keys.BANGLA_DIGITS] ?: (lang == "bn"),
            pinHash = prefs[Keys.PIN_HASH] ?: "",
            pinSalt = prefs[Keys.PIN_SALT] ?: "",
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            activeEmployeeId = prefs[Keys.ACTIVE_EMPLOYEE_ID] ?: "",
            dueReminderEnabled = prefs[Keys.DUE_REMINDER] ?: true,
            lowStockAlertEnabled = prefs[Keys.LOW_STOCK_ALERT] ?: true,
            dailySummaryEnabled = prefs[Keys.DAILY_SUMMARY] ?: true,
            autoBackupEnabled = prefs[Keys.AUTO_BACKUP] ?: true,
            lastCloudSyncMillis = prefs[Keys.LAST_CLOUD_SYNC] ?: 0L,
            lastLocalBackupMillis = prefs[Keys.LAST_LOCAL_BACKUP] ?: 0L
        )
    }

    suspend fun completeOnboarding(businessId: String, languageCode: String) {
        context.dataStore.edit {
            it[Keys.ONBOARDING_DONE] = true
            it[Keys.ACTIVE_BUSINESS_ID] = businessId
            it[Keys.LANGUAGE_CODE] = languageCode
            it[Keys.BANGLA_DIGITS] = (languageCode == "bn")
        }
    }

    suspend fun setActiveBusinessId(businessId: String) {
        context.dataStore.edit { it[Keys.ACTIVE_BUSINESS_ID] = businessId }
    }

    suspend fun setLanguage(languageCode: String) {
        context.dataStore.edit {
            it[Keys.LANGUAGE_CODE] = languageCode
            it[Keys.BANGLA_DIGITS] = (languageCode == "bn")
        }
    }

    suspend fun setBanglaDigits(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BANGLA_DIGITS] = enabled }
    }

    suspend fun setDarkMode(mode: String) {
        context.dataStore.edit { it[Keys.DARK_MODE] = mode }
    }

    suspend fun setPin(hash: String, salt: String) {
        context.dataStore.edit {
            it[Keys.PIN_HASH] = hash
            it[Keys.PIN_SALT] = salt
        }
    }

    suspend fun clearPin() {
        context.dataStore.edit {
            it.remove(Keys.PIN_HASH)
            it.remove(Keys.PIN_SALT)
            it[Keys.BIOMETRIC_ENABLED] = false
        }
    }

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BIOMETRIC_ENABLED] = enabled }
    }

    suspend fun setActiveEmployeeId(employeeId: String) {
        context.dataStore.edit { it[Keys.ACTIVE_EMPLOYEE_ID] = employeeId }
    }

    suspend fun updateNotificationSettings(
        dueReminder: Boolean,
        lowStock: Boolean,
        dailySummary: Boolean,
        autoBackup: Boolean
    ) {
        context.dataStore.edit {
            it[Keys.DUE_REMINDER] = dueReminder
            it[Keys.LOW_STOCK_ALERT] = lowStock
            it[Keys.DAILY_SUMMARY] = dailySummary
            it[Keys.AUTO_BACKUP] = autoBackup
        }
    }

    suspend fun updateLastCloudSync(millis: Long) {
        context.dataStore.edit { it[Keys.LAST_CLOUD_SYNC] = millis }
    }

    suspend fun updateLastLocalBackup(millis: Long) {
        context.dataStore.edit { it[Keys.LAST_LOCAL_BACKUP] = millis }
    }
}
