package com.example.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.core.util.AppLanguage
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.*
import com.example.data.remote.FirebaseAuthHelper
import com.example.ui.BusinessWorkspaceState
import com.example.ui.theme.*
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    state: BusinessWorkspaceState,
    isSyncing: Boolean,
    onUpdateBusiness: (BusinessEntity) -> Unit,
    onSaveProduct: (
        existingId: String?,
        name: String,
        sku: String,
        barcode: String,
        category: String,
        buyPaisa: Long,
        sellPaisa: Long,
        stockMilli: Long,
        unit: String,
        lowStockMilli: Long,
        imageUri: String?
    ) -> Unit,
    onAdjustStock: (productId: String, type: String, deltaMilli: Long, notes: String) -> Unit,
    onSaveEmployee: (name: String, phone: String, role: String) -> Unit,
    onRemoveEmployee: (String) -> Unit,
    onSetActiveEmployee: (String) -> Unit,
    onSetPin: (String) -> Unit,
    onRemovePin: () -> Unit,
    onSetBiometric: (Boolean) -> Unit,
    onSetLanguage: (String) -> Unit,
    onSetBanglaDigits: (Boolean) -> Unit,
    onSetDarkMode: (String) -> Unit,
    onUpdateNotifications: (Boolean, Boolean, Boolean, Boolean) -> Unit,
    onExportBackupUri: (Uri) -> Unit,
    onRestoreBackupUri: (Uri) -> Unit,
    onSyncToCloud: (String) -> Unit,
    onRestoreFromCloud: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { currentUser = it.currentUser }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }
    var authError by remember { mutableStateOf<String?>(null) }
    var authLoading by remember { mutableStateOf(false) }

    var showInventorySheet by remember { mutableStateOf(false) }
    var showEmployeesSheet by remember { mutableStateOf(false) }
    var showBusinessEditDialog by remember { mutableStateOf(false) }
    var showSetPinDialog by remember { mutableStateOf(false) }

    val createBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) onExportBackupUri(uri) }

    val openBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) onRestoreBackupUri(uri) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(strings.tabSettings, style = MaterialTheme.typography.headlineSmall)
        }

        // 1. Business Profile & Inventory Toggle
        item {
            val biz = state.activeBusiness
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(biz?.name ?: strings.appTitle, style = MaterialTheme.typography.titleMedium)
                            Text("${biz?.category ?: ""} • ${biz?.phone ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { showBusinessEditDialog = true }) { Text("Edit") }
                    }
                    if (biz != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(strings.enableInventory, style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = biz.inventoryEnabled,
                                onCheckedChange = { onUpdateBusiness(biz.copy(inventoryEnabled = it)) }
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Enable VAT / Tax Billing", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = biz.taxEnabled,
                                onCheckedChange = { onUpdateBusiness(biz.copy(taxEnabled = it)) }
                            )
                        }
                    }
                }
            }
        }

        // 2. Products & Inventory Hub
        if (state.activeBusiness?.inventoryEnabled == true) {
            item {
                SettingsActionTile(
                    icon = Icons.Default.Inventory2,
                    title = strings.inventoryProducts,
                    subtitle = "${state.products.size} products • Stock adjustments & movement log",
                    onClick = { showInventorySheet = true },
                    modifier = Modifier.testTag("settings_inventory_button")
                )
            }
        }

        // 3. Employees & Access Management
        item {
            SettingsActionTile(
                icon = Icons.Default.Badge,
                title = strings.employeesAccess,
                subtitle = "Active: ${state.activeEmployee?.name ?: "Owner"} (${state.activeEmployee?.role ?: "OWNER"})",
                onClick = { showEmployeesSheet = true },
                modifier = Modifier.testTag("settings_employees_button")
            )
        }

        // 4. Optional Google Account & Firebase Cloud Sync (Strictly auth-gated with Credential Manager)
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.cloudSyncAccount, style = MaterialTheme.typography.titleMedium)
                    val user = currentUser
                    if (user == null) {
                        Text(
                            "Optional: Sign in with Google to sync businesses and ledgers securely to Firebase Firestore.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = {
                                authLoading = true
                                authError = null
                                FirebaseAuthHelper.onGoogleSignInClicked(
                                    context = context,
                                    credentialManager = credentialManager,
                                    onAuthSuccess = { authLoading = false },
                                    onAuthError = { msg -> authLoading = false; authError = msg },
                                    scope = scope,
                                    onAuthCancelled = { authLoading = false }
                                )
                            },
                            enabled = !authLoading,
                            modifier = Modifier.fillMaxWidth().testTag("google_signin_button")
                        ) {
                            if (authLoading) {
                                CircularProgressIndicator(Modifier.size(20.dp), color = PureWhite, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(strings.signInWithGoogle)
                            }
                        }
                        authError?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = ExpenseRed)
                        }
                    } else {
                        key(user.uid) {
                            Text("Signed in: ${user.displayName ?: user.email ?: user.uid}", style = MaterialTheme.typography.bodyMedium, color = EmeraldPrimary)
                            if (state.settings.lastCloudSyncMillis > 0L) {
                                Text(
                                    "Last synced: ${MoneyUtils.formatDhakaDateTime(state.settings.lastCloudSyncMillis, useBn)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onSyncToCloud(user.uid) },
                                    enabled = !isSyncing,
                                    modifier = Modifier.weight(1f).testTag("cloud_sync_now_button")
                                ) {
                                    Text(if (isSyncing) "Syncing..." else strings.syncNow)
                                }
                                OutlinedButton(
                                    onClick = { onRestoreFromCloud(user.uid) },
                                    enabled = !isSyncing,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Pull Cloud")
                                }
                            }
                            TextButton(
                                onClick = { FirebaseAuthHelper.signOut(credentialManager, scope) },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text(strings.signOut, color = ExpenseRed)
                            }
                        }
                    }
                }
            }
        }

        // 5. Security & Local Backup
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.securityBackup, style = MaterialTheme.typography.titleMedium)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (state.settings.hasPin) "PIN Lock Active" else "Set Security PIN", style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { showSetPinDialog = true }) {
                                Text(if (state.settings.hasPin) "Change" else "Set PIN")
                            }
                            if (state.settings.hasPin) {
                                TextButton(onClick = onRemovePin) { Text("Remove", color = ExpenseRed) }
                            }
                        }
                    }
                    if (state.settings.hasPin) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Biometric Fingerprint Unlock", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = state.settings.biometricEnabled, onCheckedChange = onSetBiometric)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { createBackupLauncher.launch("hisab_pro_backup_${System.currentTimeMillis()}.json") },
                            modifier = Modifier.weight(1f)
                        ) { Text(strings.exportLocalBackup) }
                        OutlinedButton(
                            onClick = { openBackupLauncher.launch(arrayOf("application/json", "*/*")) },
                            modifier = Modifier.weight(1f)
                        ) { Text(strings.restoreLocalBackup) }
                    }
                }
            }
        }

        // 6. Notifications Preferences
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(strings.notificationsTitle, style = MaterialTheme.typography.titleMedium)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            TextButton(onClick = { notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                                Text("Enable Alerts")
                            }
                        }
                    }
                    ToggleRow("Customer & Supplier Reminders", state.settings.dueReminderEnabled) {
                        onUpdateNotifications(it, state.settings.lowStockAlertEnabled, state.settings.dailySummaryEnabled, state.settings.autoBackupEnabled)
                    }
                    ToggleRow("Low Stock Alerts", state.settings.lowStockAlertEnabled) {
                        onUpdateNotifications(state.settings.dueReminderEnabled, it, state.settings.dailySummaryEnabled, state.settings.autoBackupEnabled)
                    }
                    ToggleRow("Daily & Monthly Summary", state.settings.dailySummaryEnabled) {
                        onUpdateNotifications(state.settings.dueReminderEnabled, state.settings.lowStockAlertEnabled, it, state.settings.autoBackupEnabled)
                    }
                    ToggleRow("Automatic Scheduled Backup", state.settings.autoBackupEnabled) {
                        onUpdateNotifications(state.settings.dueReminderEnabled, state.settings.lowStockAlertEnabled, state.settings.dailySummaryEnabled, it)
                    }
                }
            }
        }

        // 7. Language & Appearance
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.appearanceLanguage, style = MaterialTheme.typography.titleMedium)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        listOf(AppLanguage.ENGLISH, AppLanguage.BANGLA).forEachIndexed { i, lang ->
                            SegmentedButton(
                                selected = state.settings.languageCode == lang.code,
                                onClick = { onSetLanguage(lang.code) },
                                shape = SegmentedButtonDefaults.itemShape(i, 2),
                                modifier = Modifier.testTag("lang_button_${lang.code}")
                            ) { Text(lang.displayName) }
                        }
                    }
                    ToggleRow("Bangla Numerals (১২৩)", state.settings.useBanglaDigits, onSetBanglaDigits)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        listOf("SYSTEM", "LIGHT", "DARK").forEachIndexed { i, mode ->
                            SegmentedButton(
                                selected = state.settings.darkModePreference == mode,
                                onClick = { onSetDarkMode(mode) },
                                shape = SegmentedButtonDefaults.itemShape(i, 3)
                            ) { Text(mode) }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }

    // Inventory & Product Management Sheet
    if (showInventorySheet) {
        InventoryManagementSheet(
            state = state,
            useBn = useBn,
            onDismiss = { showInventorySheet = false },
            onSaveProduct = onSaveProduct,
            onAdjustStock = onAdjustStock
        )
    }

    // Employees & Access Management Sheet
    if (showEmployeesSheet) {
        EmployeesManagementSheet(
            state = state,
            onDismiss = { showEmployeesSheet = false },
            onSaveEmployee = onSaveEmployee,
            onRemoveEmployee = onRemoveEmployee,
            onSetActiveEmployee = onSetActiveEmployee
        )
    }

    // Business Profile Edit Dialog
    if (showBusinessEditDialog && state.activeBusiness != null) {
        val biz = state.activeBusiness
        var name by remember { mutableStateOf(biz.name) }
        var phone by remember { mutableStateOf(biz.phone) }
        var address by remember { mutableStateOf(biz.address) }
        var taxRate by remember { mutableStateOf((biz.defaultTaxRateBps / 100.0).toString()) }
        var logoUri by remember { mutableStateOf(biz.logoUri) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) logoUri = uri.toString()
        }

        AlertDialog(
            onDismissRequest = { showBusinessEditDialog = false },
            title = { Text("Edit Business Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text("Update Logo") }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Business Name") })
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") })
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") })
                    OutlinedTextField(value = taxRate, onValueChange = { taxRate = it }, label = { Text("Default VAT/Tax (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            },
            confirmButton = {
                Button(onClick = {
                    val bps = ((taxRate.toDoubleOrNull() ?: 0.0) * 100).toInt().coerceIn(0, 10000)
                    onUpdateBusiness(
                        biz.copy(
                            name = name.trim().ifBlank { biz.name },
                            phone = MoneyUtils.formatBdPhone(phone),
                            address = address.trim(),
                            logoUri = logoUri,
                            defaultTaxRateBps = bps
                        )
                    )
                    showBusinessEditDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showBusinessEditDialog = false }) { Text("Cancel") } }
        )
    }

    if (showSetPinDialog) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSetPinDialog = false },
            title = { Text("Set Security PIN (4-6 digits)") },
            text = {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pin = it },
                    label = { Text("New PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (pin.length in 4..6) {
                        onSetPin(pin)
                        showSetPinDialog = false
                    }
                }) { Text("Save PIN") }
            },
            dismissButton = { TextButton(onClick = { showSetPinDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SettingsActionTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = title, tint = EmeraldPrimary)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun InventoryManagementSheet(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    onDismiss: () -> Unit,
    onSaveProduct: (String?, String, String, String, String, Long, Long, Long, String, Long, String?) -> Unit,
    onAdjustStock: (String, String, Long, String) -> Unit
) {
    var showAddProduct by remember { mutableStateOf(false) }
    var adjustTarget by remember { mutableStateOf<ProductEntity?>(null) }
    var showMovements by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Products & Inventory", style = MaterialTheme.typography.titleLarge)
                Row {
                    TextButton(onClick = { showMovements = !showMovements }) {
                        Text(if (showMovements) "Products" else "Movements")
                    }
                    Button(onClick = { showAddProduct = true }) { Text("+ Add") }
                }
            }

            if (showMovements) {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.stockMovements, key = { it.id }) { m ->
                        ListItem(
                            headlineContent = { Text("${m.productName} (${m.movementType})") },
                            supportingContent = { Text("${MoneyUtils.formatDhakaDateTime(m.occurredAt, useBn)} • ${m.notes}") },
                            trailingContent = {
                                val sign = if (m.deltaMilliUnits >= 0) "+" else ""
                                Text("$sign${MoneyUtils.milliUnitsToString(m.deltaMilliUnits, useBn)}")
                            }
                        )
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.products, key = { it.id }) { p ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(p.name, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "Buy ${MoneyUtils.formatTaka(p.purchasePricePaisa, useBn)} • Sell ${MoneyUtils.formatTaka(p.sellingPricePaisa, useBn)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${MoneyUtils.milliUnitsToString(p.stockMilliUnits, useBn)} ${p.unit}", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                    TextButton(onClick = { adjustTarget = p }) { Text("Adjust") }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (showAddProduct) {
        var name by remember { mutableStateOf("") }
        var sku by remember { mutableStateOf("") }
        var barcode by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("General") }
        var buyPrice by remember { mutableStateOf("") }
        var sellPrice by remember { mutableStateOf("") }
        var stock by remember { mutableStateOf("") }
        var unit by remember { mutableStateOf("Piece") }
        var lowThreshold by remember { mutableStateOf("5") }
        var imgUri by remember { mutableStateOf<String?>(null) }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) imgUri = uri.toString()
        }

        AlertDialog(
            onDismissRequest = { showAddProduct = false },
            title = { Text("Add Product") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text(if (imgUri == null) "Product Image (Optional)" else "Image Selected") }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name *") })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = barcode, onValueChange = { barcode = it }, label = { Text("Barcode") }, modifier = Modifier.weight(1f))
                    }
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = buyPrice, onValueChange = { buyPrice = it }, label = { Text("Buy Price (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = sellPrice, onValueChange = { sellPrice = it }, label = { Text("Sell Price (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Initial Stock") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = lowThreshold, onValueChange = { lowThreshold = it }, label = { Text("Low Alert") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                    Text("Unit", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Piece", "KG", "Gram", "Liter", "Meter", "Box", "Packet").forEach { u ->
                            FilterChip(selected = unit == u, onClick = { unit = u }, label = { Text(u) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        onSaveProduct(
                            null, name, sku, barcode, category,
                            MoneyUtils.parseTakaToPaisa(buyPrice),
                            MoneyUtils.parseTakaToPaisa(sellPrice),
                            MoneyUtils.parseQtyToMilliUnits(stock),
                            unit,
                            MoneyUtils.parseQtyToMilliUnits(lowThreshold).coerceAtLeast(1000L),
                            imgUri
                        )
                        showAddProduct = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddProduct = false }) { Text("Cancel") } }
        )
    }

    adjustTarget?.let { prod ->
        var adjType by remember { mutableStateOf("ADJUSTMENT") }
        var qty by remember { mutableStateOf("") }
        var isDecrease by remember { mutableStateOf(true) }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adjustTarget = null },
            title = { Text("Adjust ${prod.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf("ADJUSTMENT", "DAMAGE")) { t ->
                            FilterChip(selected = adjType == t, onClick = { adjType = t; if (t == "DAMAGE") isDecrease = true }, label = { Text(t) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Decrease Stock (Out/Damage)")
                        Switch(checked = isDecrease, onCheckedChange = { isDecrease = it })
                    }
                    OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Quantity (${prod.unit})") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Reason / Notes") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    val m = MoneyUtils.parseQtyToMilliUnits(qty)
                    if (m > 0L) {
                        onAdjustStock(prod.id, adjType, if (isDecrease) -m else m, notes)
                        adjustTarget = null
                    }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { adjustTarget = null }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EmployeesManagementSheet(
    state: BusinessWorkspaceState,
    onDismiss: () -> Unit,
    onSaveEmployee: (String, String, String) -> Unit,
    onRemoveEmployee: (String) -> Unit,
    onSetActiveEmployee: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(EmployeeRoles.CASHIER) }
    val canManage = state.activeEmployee?.canManageEmployees ?: true

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Employees & Role Access", style = MaterialTheme.typography.titleLarge)
            state.employees.forEach { emp ->
                val isActive = emp.id == state.activeEmployee?.id
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable { onSetActiveEmployee(emp.id) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isActive) SoftGreenAccent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${emp.name} (${emp.role})", style = MaterialTheme.typography.titleSmall, color = if (isActive) DarkNavy else MaterialTheme.colorScheme.onSurface)
                            Text("Reports: ${emp.canViewReports} • Reversal: ${emp.canDeleteOrReverse}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (isActive) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Active Operator", tint = EmeraldPrimary)
                        } else if (canManage && emp.role != EmployeeRoles.OWNER) {
                            IconButton(onClick = { onRemoveEmployee(emp.id) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = ExpenseRed)
                            }
                        }
                    }
                }
            }

            if (canManage) {
                HorizontalDivider()
                Text("Add Employee", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf(EmployeeRoles.MANAGER, EmployeeRoles.CASHIER, EmployeeRoles.ACCOUNTANT, EmployeeRoles.OWNER)) { r ->
                        FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r) })
                    }
                }
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onSaveEmployee(name, MoneyUtils.formatBdPhone(phone), role)
                            name = ""; phone = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Add Employee") }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
