const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write any sync data", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const past = new Date(Date.now() - 1000);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("businesses").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("businesses").doc("biz_1").set({
      userId: ALICE_UID,
      name: "Dhaka Mart",
      category: "Grocery",
      languageCode: "bn",
      openingCashPaisa: 500000,
      inventoryEnabled: true,
      taxEnabled: false,
      defaultTaxRateBps: 0,
      archived: false,
      createdAt: past,
      updatedAt: past,
    })
  );
});

test("Authenticated owner can create, update, and list own profile, businesses, and ledger records", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 5000);
  const updated = new Date(Date.now() - 1000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Rahim Uddin",
      email: "rahim@example.com",
      businessCount: 1,
      lastSyncAtMillis: Date.now() - 5000,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      businessCount: 2,
      lastSyncAtMillis: Date.now() - 1000,
      updatedAt: updated,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("businesses").doc("biz_001").set({
      userId: ALICE_UID,
      name: "Rahim Traders",
      category: "Grocery",
      phone: "+8801711000000",
      address: "Mirpur 10, Dhaka",
      languageCode: "bn",
      openingCashPaisa: 1000000,
      inventoryEnabled: true,
      taxEnabled: true,
      defaultTaxRateBps: 500,
      archived: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("businesses").get()
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("ledger_records").doc("rec_001").set({
      userId: ALICE_UID,
      businessId: "biz_001",
      entityType: "CUSTOMER",
      title: "Karim Mia",
      subtitle: "Regular",
      amountPaisa: 1000000,
      balancePaisa: 600000,
      status: "ACTIVE",
      phone: "+8801811000000",
      notes: "Due from rice purchase",
      occurredAtMillis: Date.now() - 5000,
      archived: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("ledger_records")
      .where("businessId", "==", "biz_001")
      .get()
  );
});

test("Cross-user access, ghost fields, future timestamps, and immutable field edits are rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 5000);

  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).collection("businesses").doc("bob_biz").set({
      userId: BOB_UID,
      name: "Bob Fashion",
      category: "Clothing",
      languageCode: "en",
      openingCashPaisa: 0,
      inventoryEnabled: true,
      taxEnabled: false,
      defaultTaxRateBps: 0,
      archived: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Cross-user read & write denied
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("businesses").doc("bob_biz").get());
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("businesses").get());
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("businesses").doc("bob_biz").update({
      name: "Hijacked",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Ghost field & id field rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("businesses").doc("biz_ghost").set({
      id: "biz_ghost",
      userId: ALICE_UID,
      name: "Ghost Biz",
      category: "Retail",
      languageCode: "en",
      openingCashPaisa: 0,
      inventoryEnabled: false,
      taxEnabled: false,
      defaultTaxRateBps: 0,
      archived: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Future timestamp rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("businesses").doc("biz_future").set({
      userId: ALICE_UID,
      name: "Future Biz",
      category: "Retail",
      languageCode: "en",
      openingCashPaisa: 0,
      inventoryEnabled: false,
      taxEnabled: false,
      defaultTaxRateBps: 0,
      archived: false,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: created,
    })
  );

  // List on /users denied
  await assertFails(aliceDb.collection("users").get());
});
