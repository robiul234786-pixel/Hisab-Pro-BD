package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.core.util.*
import com.example.data.local.BusinessEntity
import com.example.data.local.ProductEntity
import com.example.ui.OnlineShopUiState
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalCatalogHubBottomSheet(
    state: OnlineShopUiState,
    useBanglaDigits: Boolean,
    onSelectProductForQr: (ProductEntity) -> Unit,
    onPreviewWebCatalog: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val business = state.activeBusiness
    val businessName = business?.name ?: strings.appTitle
    val shopOrderUrl = state.effectiveCustomerShopUrl.ifBlank {
        WebStorefrontGenerator.resolveCustomerShopEntryUrl(business, state.customWebShopUrl)
    }

    var includeAllInventory by remember { mutableStateOf(false) }
    val catalogProducts = remember(state.allProducts, includeAllInventory) {
        val active = state.allProducts.filter { !it.archived }
        if (includeAllInventory) active else active.filter { it.onlineListed }.ifEmpty { active }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 680.dp)
        ) {
            // Hero Header Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(DarkNavy, DarkNavyLight, ShopOrangeDark)))
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.digitalCatalogTitle,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = PureWhite
                                )
                                Text(
                                    text = strings.digitalCatalogSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PureWhite.copy(alpha = 0.85f)
                                )
                            }
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = strings.cancel, tint = PureWhite)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val visualItems = catalogProducts.take(6).map { p ->
                                        val hasDisc = p.onlineComparePricePaisa > p.sellingPricePaisa && p.sellingPricePaisa > 0L
                                        val pct = if (hasDisc) {
                                            (((p.onlineComparePricePaisa - p.sellingPricePaisa) * 100L) / p.onlineComparePricePaisa).toInt()
                                        } else 0
                                        QrCodeGenerator.CatalogVisualItem(
                                            productName = p.name,
                                            category = p.category,
                                            priceText = MoneyUtils.formatTaka(p.sellingPricePaisa, false),
                                            comparePriceText = if (hasDisc) MoneyUtils.formatTaka(p.onlineComparePricePaisa, false) else null,
                                            discountPct = pct,
                                            isFlashDeal = p.isFlashDeal,
                                            productOrderUrl = WebStorefrontGenerator.buildProductOrderUrl(
                                                business = business,
                                                product = p,
                                                customWebShopUrl = state.customWebShopUrl
                                            )
                                        )
                                    }
                                    val poster = QrCodeGenerator.generateVisualCatalogPosterFile(
                                        context = context,
                                        businessName = businessName,
                                        businessCategory = business?.category ?: "Online Store",
                                        phone = business?.phone.orEmpty(),
                                        shopOrderUrl = shopOrderUrl,
                                        items = visualItems
                                    )
                                    ExportUtils.shareFile(context, poster, "image/png", strings.shareVisualCatalogLabel)
                                },
                                enabled = catalogProducts.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(containerColor = ShopOrange, contentColor = PureWhite),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("share_visual_catalog_png_button")
                            ) {
                                Icon(Icons.Default.AutoAwesomeMosaic, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.shareVisualCatalogLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }

                            OutlinedButton(
                                onClick = {
                                    onDismiss()
                                    onPreviewWebCatalog()
                                },
                                border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.6f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("preview_catalog_web_button")
                            ) {
                                Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (strings.isBangla) "ওয়েব" else "Web", maxLines = 1)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val htmlFile = WebStorefrontGenerator.exportWebStorefrontHtmlFile(
                                        context = context,
                                        business = business,
                                        products = catalogProducts,
                                        isBanglaDefault = strings.isBangla,
                                        accounts = state.accounts
                                    )
                                    ExportUtils.shareFile(context, htmlFile, "text/html", strings.shareWebShopFileLabel)
                                },
                                border = BorderStroke(1.dp, EmeraldLight.copy(alpha = 0.7f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = EmeraldLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 44.dp)
                                    .testTag("share_web_catalog_html_button")
                            ) {
                                Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.shareWebShopFileLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }

                            FilterChip(
                                selected = includeAllInventory,
                                onClick = { includeAllInventory = !includeAllInventory },
                                label = {
                                    Text(
                                        if (includeAllInventory) {
                                            if (strings.isBangla) "সব পণ্য" else "All Items"
                                        } else {
                                            if (strings.isBangla) "অনলাইন পণ্য" else "Listed Only"
                                        },
                                        color = PureWhite
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldPrimary,
                                    containerColor = PureWhite.copy(alpha = 0.14f)
                                )
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            if (catalogProducts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (strings.isBangla) "ক্যাটালগের জন্য কোনো পণ্য পাওয়া যায়নি।" else "Add or list products to generate shareable QR catalog cards.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(catalogProducts, key = { it.id }) { prod ->
                        CatalogProductQrCard(
                            business = business,
                            product = prod,
                            customWebShopUrl = state.customWebShopUrl,
                            useBanglaDigits = useBanglaDigits,
                            onOpenProductQr = { onSelectProductForQr(prod) }
                        )
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}

@Composable
private fun CatalogProductQrCard(
    business: BusinessEntity?,
    product: ProductEntity,
    customWebShopUrl: String,
    useBanglaDigits: Boolean,
    onOpenProductQr: () -> Unit
) {
    val strings = LocalAppStrings.current
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val productUrl = remember(business?.id, business?.phone, product.id, product.sellingPricePaisa, customWebShopUrl) {
        WebStorefrontGenerator.buildProductOrderUrl(business, product, customWebShopUrl)
    }
    val qrBitmap by produceState<android.graphics.Bitmap?>(initialValue = null, productUrl) {
        value = withContext(Dispatchers.Default) {
            QrCodeGenerator.generateQrBitmap(productUrl, sizePx = 220, quietModules = 2)
        }
    }

    val hasDiscount = product.onlineComparePricePaisa > product.sellingPricePaisa && product.sellingPricePaisa > 0L
    val discountPct = if (hasDiscount) {
        (((product.onlineComparePricePaisa - product.sellingPricePaisa) * 100L) / product.onlineComparePricePaisa).toInt()
    } else 0
    var copied by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenProductQr)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Product photo or category visual
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ShopOrangeSoft),
                contentAlignment = Alignment.Center
            ) {
                if (!product.imageUri.isNullOrBlank()) {
                    AsyncImage(
                        model = product.imageUri,
                        contentDescription = product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Default.ShoppingBag, contentDescription = product.name, tint = ShopOrange, modifier = Modifier.size(30.dp))
                }
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (hasDiscount) {
                        Surface(color = ShopOrange, shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "-$discountPct%",
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = MoneyUtils.formatTaka(product.sellingPricePaisa, useBanglaDigits),
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                        color = ShopOrange
                    )
                    if (hasDiscount) {
                        Text(
                            text = MoneyUtils.formatTaka(product.onlineComparePricePaisa, useBanglaDigits),
                            style = MaterialTheme.typography.labelSmall.copy(textDecoration = TextDecoration.LineThrough),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(productUrl))
                            copied = true
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.heightIn(min = 36.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (copied) (if (strings.isBangla) "কপি হয়েছে" else "Copied") else strings.copyProductLinkLabel,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    TextButton(
                        onClick = {
                            val flyer = QrCodeGenerator.generateProductQrPosterFile(
                                context = context,
                                businessName = business?.name ?: strings.appTitle,
                                phone = business?.phone.orEmpty(),
                                productName = product.name,
                                category = product.category,
                                priceText = MoneyUtils.formatTaka(product.sellingPricePaisa, false),
                                comparePriceText = if (hasDiscount) MoneyUtils.formatTaka(product.onlineComparePricePaisa, false) else null,
                                discountPct = discountPct,
                                productOrderUrl = productUrl
                            )
                            ExportUtils.shareFile(context, flyer, "image/png", strings.shareProductQrCardLabel)
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier
                            .heightIn(min = 36.dp)
                            .testTag("product_qr_share_btn_${product.id}")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp), tint = EmeraldPrimary)
                        Spacer(Modifier.width(4.dp))
                        Text(strings.productQrCodeLabel, style = MaterialTheme.typography.labelSmall, color = EmeraldPrimary)
                    }
                }
            }

            // Live mini scannable QR code
            Box(
                modifier = Modifier
                    .size(74.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PureWhite)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                val bmp = qrBitmap
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "${product.name} QR Code",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = ShopOrange)
                }
            }
        }
    }
}

@Composable
fun ProductQrCodeDialog(
    business: BusinessEntity?,
    product: ProductEntity,
    customWebShopUrl: String,
    useBanglaDigits: Boolean,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val businessName = business?.name ?: strings.appTitle

    val productOrderUrl = remember(business?.id, business?.phone, product.id, product.sellingPricePaisa, customWebShopUrl) {
        WebStorefrontGenerator.buildProductOrderUrl(business, product, customWebShopUrl)
    }
    val qrBitmap by produceState<android.graphics.Bitmap?>(initialValue = null, productOrderUrl) {
        value = withContext(Dispatchers.Default) {
            QrCodeGenerator.generateQrBitmap(productOrderUrl, sizePx = 560, quietModules = 3)
        }
    }

    val hasDiscount = product.onlineComparePricePaisa > product.sellingPricePaisa && product.sellingPricePaisa > 0L
    val discountPct = if (hasDiscount) {
        (((product.onlineComparePricePaisa - product.sellingPricePaisa) * 100L) / product.onlineComparePricePaisa).toInt()
    } else 0
    var copied by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = "${MoneyUtils.formatTaka(product.sellingPricePaisa, useBanglaDigits)} / ${product.unit}",
                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                            color = ShopOrange
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = strings.cancel)
                    }
                }

                Box(
                    modifier = Modifier
                        .size(224.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(PureWhite)
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val bmp = qrBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "${product.name} QR Code",
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("single_product_qr_image"),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        CircularProgressIndicator(color = ShopOrange)
                    }
                }

                Text(
                    text = if (strings.isBangla) {
                        "ক্রেতা এই QR কোড স্ক্যান করলেই অ্যাপ ছাড়াই সরাসরি এই পণ্যটি অর্ডার করতে পারবে।"
                    } else {
                        "Customers scan this QR code to order ${product.name} directly without installing the app."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(productOrderUrl))
                            copied = true
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("copy_single_product_link_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (copied) (if (strings.isBangla) "কপি হয়েছে" else "Copied") else strings.copyProductLinkLabel, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(productOrderUrl)))
                            } catch (_: Exception) {
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (strings.isBangla) "ওপেন" else "Open", maxLines = 1)
                    }
                }

                Button(
                    onClick = {
                        val flyer = QrCodeGenerator.generateProductQrPosterFile(
                            context = context,
                            businessName = businessName,
                            phone = business?.phone.orEmpty(),
                            productName = product.name,
                            category = product.category,
                            priceText = MoneyUtils.formatTaka(product.sellingPricePaisa, false),
                            comparePriceText = if (hasDiscount) MoneyUtils.formatTaka(product.onlineComparePricePaisa, false) else null,
                            discountPct = discountPct,
                            productOrderUrl = productOrderUrl
                        )
                        ExportUtils.shareFile(context, flyer, "image/png", strings.shareProductQrCardLabel)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ShopOrange),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 50.dp)
                        .testTag("share_product_qr_poster_button")
                ) {
                    Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.shareProductQrCardLabel, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
