package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

object BusinessCategories {
    val ALL = listOf(
        "Grocery Shop",
        "Retail Store",
        "Clothing & Fashion",
        "Wholesale",
        "Distributor",
        "Restaurant & Cafe",
        "Service Business",
        "Small Company"
    )
}

object CustomerCategories {
    val ALL = listOf("Regular", "VIP", "Wholesale", "Credit", "Corporate")
}

object AccountTypes {
    const val CASH = "CASH"
    const val BANK = "BANK"
    const val BKASH = "BKASH"
    const val NAGAD = "NAGAD"
    const val ROCKET = "ROCKET"
    const val CUSTOM = "CUSTOM"
}

object TxTypes {
    const val OPENING_BALANCE = "OPENING_BALANCE"
    const val SALE = "SALE"
    const val CREDIT_SALE = "CREDIT_SALE"
    const val CUSTOMER_PAYMENT = "CUSTOMER_PAYMENT"
    const val CUSTOMER_CREDIT_ADVANCE = "CUSTOMER_CREDIT_ADVANCE"
    const val CUSTOMER_REFUND = "CUSTOMER_REFUND"
    const val PURCHASE = "PURCHASE"
    const val SUPPLIER_PAYMENT = "SUPPLIER_PAYMENT"
    const val INCOME = "INCOME"
    const val EXPENSE = "EXPENSE"
    const val ACCOUNT_TRANSFER = "ACCOUNT_TRANSFER"
    const val SALE_RETURN = "SALE_RETURN"
    const val PURCHASE_RETURN = "PURCHASE_RETURN"
    const val PAYMENT_CORRECTION = "PAYMENT_CORRECTION"
    const val REVERSAL = "REVERSAL"
}

object EmployeeRoles {
    const val OWNER = "OWNER"
    const val MANAGER = "MANAGER"
    const val CASHIER = "CASHIER"
    const val ACCOUNTANT = "ACCOUNTANT"
}

@Entity(tableName = "businesses")
data class BusinessEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String,
    val phone: String = "",
    val address: String = "",
    val logoUri: String? = null,
    val languageCode: String = "en",
    val openingCashPaisa: Long = 0L,
    val inventoryEnabled: Boolean = true,
    val taxEnabled: Boolean = false,
    val defaultTaxRateBps: Int = 0,
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "accounts",
    indices = [Index("businessId")]
)
data class AccountEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val name: String,
    val type: String, // CASH, BANK, BKASH, NAGAD, ROCKET, CUSTOM
    val accountNumber: String = "",
    val openingBalancePaisa: Long = 0L,
    val currentBalancePaisa: Long = 0L,
    val isDefault: Boolean = false,
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "customers",
    indices = [Index("businessId"), Index(value = ["businessId", "customerCode"], unique = true)]
)
data class CustomerEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val customerCode: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val photoUri: String? = null,
    val category: String = "Regular",
    val openingDuePaisa: Long = 0L,
    val currentDuePaisa: Long = 0L,
    val totalPurchasesPaisa: Long = 0L,
    val totalPaymentsPaisa: Long = 0L,
    val overdueSinceMillis: Long? = null,
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "suppliers",
    indices = [Index("businessId"), Index(value = ["businessId", "supplierCode"], unique = true)]
)
data class SupplierEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val supplierCode: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val openingPayablePaisa: Long = 0L,
    val currentPayablePaisa: Long = 0L,
    val totalPurchasesPaisa: Long = 0L,
    val totalPaymentsPaisa: Long = 0L,
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "products",
    indices = [Index("businessId")]
)
data class ProductEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val name: String,
    val sku: String = "",
    val barcode: String = "",
    val category: String = "General",
    val purchasePricePaisa: Long = 0L,
    val sellingPricePaisa: Long = 0L,
    val stockMilliUnits: Long = 0L,
    val unit: String = "Piece",
    val lowStockThresholdMilliUnits: Long = 5000L,
    val imageUri: String? = null,
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "stock_movements",
    indices = [Index("businessId"), Index("productId")]
)
data class StockMovementEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val productId: String,
    val productName: String,
    val movementType: String, // OPENING, PURCHASE, SALE, SALE_RETURN, PURCHASE_RETURN, DAMAGE, ADJUSTMENT
    val deltaMilliUnits: Long,
    val balanceAfterMilliUnits: Long,
    val unitCostPaisa: Long = 0L,
    val referenceId: String? = null,
    val notes: String = "",
    val occurredAt: Long = System.currentTimeMillis(),
    val createdBy: String = "Owner"
)

@Entity(
    tableName = "categories",
    indices = [Index("businessId")]
)
data class CategoryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val name: String,
    val nameBn: String,
    val type: String, // INCOME or EXPENSE
    val isSystem: Boolean = false
)

@Entity(
    tableName = "accounting_transactions",
    indices = [
        Index("businessId"),
        Index("customerId"),
        Index("supplierId"),
        Index("accountId"),
        Index("occurredAt"),
        Index(value = ["idempotencyKey"], unique = true)
    ]
)
data class AccountingTransactionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val businessId: String,
    val type: String,
    val customerId: String? = null,
    val supplierId: String? = null,
    val partyName: String = "",
    val accountId: String? = null,
    val accountName: String = "",
    val toAccountId: String? = null,
    val toAccountName: String = "",
    val referenceId: String? = null,
    val categoryId: String? = null,
    val categoryName: String = "",
    val subtotalPaisa: Long = 0L,
    val discountPaisa: Long = 0L,
    val taxPaisa: Long = 0L,
    val totalAmountPaisa: Long = 0L,
    val paidAmountPaisa: Long = 0L,
    val dueDeltaPaisa: Long = 0L,
    val cogsPaisa: Long = 0L,
    val hasEstimatedCost: Boolean = false,
    val cashFlowDeltaPaisa: Long = 0L,
    val accountBalanceAfterPaisa: Long = 0L,
    val isReversed: Boolean = false,
    val reversedTransactionId: String? = null,
    val notes: String = "",
    val attachmentUri: String? = null,
    val occurredAt: Long = System.currentTimeMillis(),
    val dueDateMillis: Long? = null,
    val createdBy: String = "Owner",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "invoices",
    indices = [Index("businessId"), Index("occurredAt")]
)
data class InvoiceEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val invoiceNumber: String,
    val invoiceType: String, // SALE or PURCHASE
    val partyId: String? = null,
    val partyName: String,
    val subtotalPaisa: Long,
    val discountPaisa: Long,
    val taxRateBps: Int,
    val taxPaisa: Long,
    val totalPaisa: Long,
    val paidPaisa: Long,
    val duePaisa: Long,
    val cogsPaisa: Long,
    val accountId: String?,
    val notes: String = "",
    val occurredAt: Long = System.currentTimeMillis(),
    val createdBy: String = "Owner"
)

@Entity(
    tableName = "invoice_items",
    indices = [Index("invoiceId")]
)
data class InvoiceItemEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val invoiceId: String,
    val productId: String? = null,
    val itemName: String,
    val unit: String = "Piece",
    val quantityMilliUnits: Long,
    val unitPricePaisa: Long,
    val costPricePaisa: Long = 0L,
    val lineTotalPaisa: Long,
    val returnedMilliUnits: Long = 0L
)

@Entity(
    tableName = "employees",
    indices = [Index("businessId")]
)
data class EmployeeEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val name: String,
    val phone: String = "",
    val role: String = EmployeeRoles.CASHIER,
    val canViewReports: Boolean = false,
    val canDeleteOrReverse: Boolean = false,
    val canManageEmployees: Boolean = false,
    val canManageSettings: Boolean = false,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "app_notifications",
    indices = [Index("businessId"), Index("createdAt")]
)
data class AppNotificationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val businessId: String,
    val type: String, // DUE_REMINDER, SUPPLIER_REMINDER, LOW_STOCK, DAILY_SUMMARY, MONTHLY_SUMMARY, BACKUP_REMINDER
    val title: String,
    val message: String,
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
