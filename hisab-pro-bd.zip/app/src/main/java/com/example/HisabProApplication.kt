package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.Configuration
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.workers.ScheduledBackupWorker
import java.util.concurrent.TimeUnit

class HisabProApplication : Application(), Configuration.Provider {

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        scheduleDailyBackupWorker()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hisab Pro Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Business due reminders, low stock alerts, and backup notices"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun scheduleDailyBackupWorker() {
        val work = PeriodicWorkRequestBuilder<ScheduledBackupWorker>(24, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "hisab_daily_backup_and_alerts",
            ExistingPeriodicWorkPolicy.KEEP,
            work
        )
    }

    companion object {
        const val CHANNEL_ID = "hisab_pro_reminders"
    }
}
