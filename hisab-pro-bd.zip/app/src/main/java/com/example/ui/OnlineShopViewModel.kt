package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.util.MoneyUtils
import com.example.core.util.OnlineOrderMessageParser
import com.example.core.util.ParsedIncomingOrder
import com.example.core.util.WebStorefrontGenerator
import com.example.data.local.*
import com.example.data.repository.AccountingRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class OnlineCartLineItem(
    val product: ProductEntity,
    val quantityMilliUnits: Long,
    val lineTotalPaisa: Long
)

data class OnlineShopUiState(
    val activeBusinessId: String = "",
    val activeBusiness: BusinessEntity? = null,
    val allProducts: List<ProductEntity> = emptyList(),
    val storefrontProducts: List<ProductEntity> = emptyList(),
    val flashDealProducts: List<ProductEntity> = emptyList(),
    val categories: List<String> = emptyList(),
    val wishlistIds: Set<String> = emptySet(),
    val cartQuantities: Map<String, Long> = emptyMap(),
    val cartItems: List<OnlineCartLineItem> = emptyList(),
    val cartItemCount: Int = 0,
    val cartSubtotalPaisa: Long = 0L,
    val searchQuery: String = "",
    val selectedCategory: String = "All",
    val orders: List<OnlineOrderEntity> = emptyList(),
    val orderItemsByOrderId: Map<String, List<OnlineOrderItemEntity>> = emptyMap(),
    val pendingOrdersCount: Int = 0,
    val accounts: List<AccountEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val customWebShopUrl: String = "",
    val effectiveCustomerShopUrl: String = "",
    val isLoading: Boolean = false,
    val statusMessage: String? = null,
    val lastPlacedOrder: OnlineOrderEntity? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class OnlineShopViewModel(
    application: Application,
    private val db: HisabDatabase,
    private val prefs: UserPreferences
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application = application,
        db = HisabDatabase.getInstance(application),
        prefs = UserPreferences(application)
    )

    val repo = AccountingRepository(db)

    private val _explicitBusinessId = MutableStateFlow<String?>(null)
    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow("All")
    private val _wishlistIds = MutableStateFlow<Set<String>>(emptySet())
    private val _cartQuantities = MutableStateFlow<Map<String, Long>>(emptyMap())
    private val _isLoading = MutableStateFlow(false)
    private val _statusMessage = MutableStateFlow<String?>(null)
    private val _lastPlacedOrder = MutableStateFlow<OnlineOrderEntity?>(null)

    private val activeBusinessFlow: Flow<BusinessEntity?> = combine(
        _explicitBusinessId,
        prefs.settingsFlow,
        repo.observeBusinesses()
    ) { explicitId, settings, businesses ->
        val id = explicitId?.takeIf { it.isNotBlank() }
            ?: businesses.firstOrNull { it.id == settings.activeBusinessId }?.id
            ?: businesses.firstOrNull()?.id
        businesses.firstOrNull { it.id == id }
    }.distinctUntilChanged()

    private val businessDataFlow: Flow<ShopBundle> = activeBusinessFlow.flatMapLatest { biz ->
        if (biz == null) {
            flowOf(ShopBundle())
        } else {
            combine(
                repo.observeProducts(biz.id),
                repo.observeOnlineOrders(biz.id),
                repo.observeAllOnlineOrderItems(biz.id),
                repo.observeAccounts(biz.id),
                repo.observeCustomers(biz.id)
            ) { products, orders, orderItems, accounts, customers ->
                ShopBundle(
                    business = biz,
                    products = products,
                    orders = orders,
                    orderItems = orderItems,
                    accounts = accounts,
                    customers = customers
                )
            }
        }
    }

    private val interactionFlow: Flow<InteractionState> = combine(
        _searchQuery,
        _selectedCategory,
        _wishlistIds,
        _cartQuantities,
        _isLoading,
        _statusMessage,
        _lastPlacedOrder
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        InteractionState(
            searchQuery = arr[0] as String,
            selectedCategory = arr[1] as String,
            wishlistIds = arr[2] as Set<String>,
            cartQuantities = arr[3] as Map<String, Long>,
            isLoading = arr[4] as Boolean,
            statusMessage = arr[5] as String?,
            lastPlacedOrder = arr[6] as OnlineOrderEntity?
        )
    }

    val uiState: StateFlow<OnlineShopUiState> = combine(
        businessDataFlow,
        interactionFlow,
        prefs.settingsFlow
    ) { data, ui, settings ->
        val listedProducts = data.products.filter { !it.archived && it.onlineListed }
        val flashDeals = listedProducts.filter { p ->
            p.isFlashDeal || (p.onlineComparePricePaisa > p.sellingPricePaisa && p.sellingPricePaisa > 0L)
        }
        val distinctCategories = listedProducts
            .map { it.category.trim().ifBlank { "General" } }
            .distinct()
            .sorted()

        val query = ui.searchQuery.trim()
        val filtered = listedProducts.filter { p ->
            val matchesQuery = query.isBlank() ||
                p.name.contains(query, ignoreCase = true) ||
                p.category.contains(query, ignoreCase = true) ||
                p.sku.contains(query, ignoreCase = true) ||
                p.onlineDescription.contains(query, ignoreCase = true)
            val matchesCat = when (ui.selectedCategory) {
                "All" -> true
                "Flash Deals" -> p.isFlashDeal || p.onlineComparePricePaisa > p.sellingPricePaisa
                "Wishlist" -> p.id in ui.wishlistIds
                else -> p.category.equals(ui.selectedCategory, ignoreCase = true)
            }
            matchesQuery && matchesCat
        }

        val productById = data.products.associateBy { it.id }
        val cartItems = ui.cartQuantities.mapNotNull { (prodId, qty) ->
            val p = productById[prodId] ?: return@mapNotNull null
            if (qty <= 0L) return@mapNotNull null
            OnlineCartLineItem(
                product = p,
                quantityMilliUnits = qty,
                lineTotalPaisa = MoneyUtils.calculateLineTotalPaisa(qty, p.sellingPricePaisa)
            )
        }
        val subtotal = cartItems.sumOf { it.lineTotalPaisa }
        val itemsByOrder = data.orderItems.groupBy { it.orderId }
        val pendingCount = data.orders.count {
            it.orderStatus != OnlineOrderStatuses.DELIVERED &&
                it.orderStatus != OnlineOrderStatuses.CANCELLED
        }
        val bizId = data.business?.id.orEmpty()
        val customUrl = settings.webShopUrls[bizId].orEmpty()
        val effectiveUrl = WebStorefrontGenerator.resolveCustomerShopEntryUrl(data.business, customUrl)

        OnlineShopUiState(
            activeBusinessId = bizId,
            activeBusiness = data.business,
            allProducts = data.products,
            storefrontProducts = filtered,
            flashDealProducts = flashDeals,
            categories = distinctCategories,
            wishlistIds = ui.wishlistIds,
            cartQuantities = ui.cartQuantities,
            cartItems = cartItems,
            cartItemCount = cartItems.size,
            cartSubtotalPaisa = subtotal,
            searchQuery = ui.searchQuery,
            selectedCategory = ui.selectedCategory,
            orders = data.orders,
            orderItemsByOrderId = itemsByOrder,
            pendingOrdersCount = pendingCount,
            accounts = data.accounts,
            customers = data.customers,
            customWebShopUrl = customUrl,
            effectiveCustomerShopUrl = effectiveUrl,
            isLoading = ui.isLoading,
            statusMessage = ui.statusMessage,
            lastPlacedOrder = ui.lastPlacedOrder
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, OnlineShopUiState())

    fun setBusinessId(businessId: String) {
        _explicitBusinessId.value = businessId
    }

    private suspend fun resolveBusinessId(): String {
        val current = uiState.value.activeBusinessId.ifBlank { _explicitBusinessId.value.orEmpty() }
        if (current.isNotBlank()) return current
        return db.businessDao().getAllBusinessesSync().firstOrNull()?.id.orEmpty()
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun toggleWishlist(productId: String) {
        val current = _wishlistIds.value
        _wishlistIds.value = if (productId in current) current - productId else current + productId
    }

    fun addToCart(productId: String, deltaMilliUnits: Long = 1_000L) {
        val current = _cartQuantities.value.toMutableMap()
        val updatedQty = ((current[productId] ?: 0L) + deltaMilliUnits).coerceAtLeast(0L)
        if (updatedQty <= 0L) {
            current.remove(productId)
        } else {
            current[productId] = updatedQty
        }
        _cartQuantities.value = current
    }

    fun setCartQuantity(productId: String, qtyMilliUnits: Long) {
        val current = _cartQuantities.value.toMutableMap()
        if (qtyMilliUnits <= 0L) {
            current.remove(productId)
        } else {
            current[productId] = qtyMilliUnits
        }
        _cartQuantities.value = current
    }

    fun clearCart() {
        _cartQuantities.value = emptyMap()
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun clearLastPlacedOrder() {
        _lastPlacedOrder.value = null
    }

    fun previewPromoDiscount(subtotalPaisa: Long, promoCode: String): Long =
        repo.computeOnlinePromoDiscount(subtotalPaisa, promoCode)

    fun setCustomWebShopUrl(url: String) {
        viewModelScope.launch {
            val bizId = resolveBusinessId()
            if (bizId.isBlank()) return@launch
            val cleaned = url.trim()
            val normalized = when {
                cleaned.isBlank() -> ""
                cleaned.startsWith("http://", ignoreCase = true) || cleaned.startsWith("https://", ignoreCase = true) -> cleaned
                else -> "https://$cleaned"
            }
            prefs.setWebShopUrl(bizId, normalized)
            _statusMessage.value = if (normalized.isBlank()) {
                "Custom shop URL cleared (using WhatsApp catalog link)"
            } else {
                "Web shop link saved for QR & sharing"
            }
        }
    }

    fun parseIncomingOrder(rawText: String): ParsedIncomingOrder =
        OnlineOrderMessageParser.parse(rawText, uiState.value.allProducts)

    fun placeOrder(
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        deliveryDistrict: String,
        deliveryFeePaisa: Long,
        promoCode: String,
        paymentMethod: String,
        accountId: String?,
        customerId: String? = null,
        notes: String = "",
        mfsTrxId: String = "",
        mfsSenderPhone: String = "",
        directSingleItem: Pair<String, Long>? = null,
        customLines: List<AccountingRepository.OnlineCheckoutLine>? = null,
        onPlaced: (OnlineOrderEntity) -> Unit = {}
    ) {
        val lines = when {
            !customLines.isNullOrEmpty() -> customLines
            directSingleItem != null -> listOf(AccountingRepository.OnlineCheckoutLine(directSingleItem.first, directSingleItem.second))
            else -> _cartQuantities.value.entries
                .filter { it.value > 0L }
                .map { AccountingRepository.OnlineCheckoutLine(it.key, it.value) }
        }
        if (lines.isEmpty()) {
            _statusMessage.value = "Cart is empty"
            return
        }
        if (customerName.isBlank()) {
            _statusMessage.value = "Customer name is required"
            return
        }
        viewModelScope.launch {
            val bizId = resolveBusinessId()
            if (bizId.isBlank()) {
                _statusMessage.value = "No active business selected"
                return@launch
            }
            _isLoading.value = true
            try {
                val order = repo.placeOnlineOrder(
                    businessId = bizId,
                    lines = lines,
                    customerName = customerName,
                    customerPhone = customerPhone,
                    deliveryAddress = deliveryAddress,
                    deliveryDistrict = deliveryDistrict,
                    deliveryFeePaisa = deliveryFeePaisa,
                    promoCode = promoCode,
                    paymentMethod = paymentMethod,
                    accountId = accountId,
                    customerId = customerId,
                    notes = notes,
                    mfsTrxId = mfsTrxId,
                    mfsSenderPhone = mfsSenderPhone
                )
                if (directSingleItem == null && customLines.isNullOrEmpty()) {
                    _cartQuantities.value = emptyMap()
                }
                _lastPlacedOrder.value = order
                _statusMessage.value = "Order ${order.orderNumber} placed!"
                onPlaced(order)
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Failed to place order"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun saveMfsWallet(
        accountType: String,
        displayName: String,
        walletNumber: String
    ) {
        viewModelScope.launch {
            val bizId = resolveBusinessId()
            if (bizId.isBlank()) return@launch
            try {
                repo.upsertMfsWallet(
                    businessId = bizId,
                    accountType = accountType,
                    displayName = displayName,
                    walletNumber = walletNumber
                )
                _statusMessage.value = "$displayName wallet saved"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Failed to save MFS wallet"
            }
        }
    }

    fun collectOrderMfsPayment(
        orderId: String,
        paymentMethod: String,
        trxId: String,
        senderPhone: String,
        accountIdOverride: String? = null
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val updated = repo.collectOnlineOrderMfsPayment(
                    orderId = orderId,
                    paymentMethod = paymentMethod,
                    trxId = trxId,
                    senderPhone = senderPhone,
                    accountIdOverride = accountIdOverride
                )
                _statusMessage.value = "${updated.orderNumber} paid via $paymentMethod (${updated.mfsTrxId})"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Could not verify MFS payment"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun advanceOrderStatus(orderId: String, newStatus: String, accountIdOverride: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val updated = repo.advanceOnlineOrderStatus(orderId, newStatus, accountIdOverride)
                if (updated != null) {
                    _statusMessage.value = "${updated.orderNumber} -> $newStatus"
                }
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Could not update order"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun updateProductListing(
        productId: String,
        onlineListed: Boolean,
        comparePricePaisa: Long,
        description: String,
        isFlashDeal: Boolean
    ) {
        viewModelScope.launch {
            try {
                repo.updateProductOnlineListing(
                    productId = productId,
                    onlineListed = onlineListed,
                    comparePricePaisa = comparePricePaisa,
                    description = description,
                    isFlashDeal = isFlashDeal
                )
                _statusMessage.value = "Shop listing updated"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Failed to update listing"
            }
        }
    }

    private data class ShopBundle(
        val business: BusinessEntity? = null,
        val products: List<ProductEntity> = emptyList(),
        val orders: List<OnlineOrderEntity> = emptyList(),
        val orderItems: List<OnlineOrderItemEntity> = emptyList(),
        val accounts: List<AccountEntity> = emptyList(),
        val customers: List<CustomerEntity> = emptyList()
    )

    private data class InteractionState(
        val searchQuery: String = "",
        val selectedCategory: String = "All",
        val wishlistIds: Set<String> = emptySet(),
        val cartQuantities: Map<String, Long> = emptyMap(),
        val isLoading: Boolean = false,
        val statusMessage: String? = null,
        val lastPlacedOrder: OnlineOrderEntity? = null
    )
}
