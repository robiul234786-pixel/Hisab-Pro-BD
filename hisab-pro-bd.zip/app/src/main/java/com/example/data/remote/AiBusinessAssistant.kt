package com.example.data.remote

import android.util.Log
import com.example.core.util.MoneyUtils
import com.example.data.local.*
import com.example.data.repository.AccountingCalculator
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.time.Instant

data class AiChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val dateRangeLabel: String? = null,
    val proposedAction: AiProposedAction? = null,
    val actionExecuted: Boolean = false,
    val timestampMillis: Long = System.currentTimeMillis()
)

data class AiProposedAction(
    val actionType: String, // ADD_EXPENSE, RECEIVE_PAYMENT, CREDIT_SALE, ADD_SALE
    val partyOrCategory: String,
    val amountPaisa: Long,
    val notes: String
)

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Streaming(val partialText: String) : AiUiState
    data class Success(val text: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

object AiBusinessAssistant {
    private const val TAG = "AiBusinessAssistant"

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    """
                    You are Hisab Pro BD Business AI Assistant, an expert financial & retail advisor for Bangladeshi businesses (grocery, wholesale, retail, clothing, restaurant, services).
                    RULES:
                    1. Answer naturally in the language the user asked (Bangla if asked in Bangla, English if asked in English, or mixed if helpful).
                    2. Use ONLY the exact verified database figures provided in the [BUSINESS_LEDGER_CONTEXT] block. NEVER invent, estimate silently, or fabricate any Taka amount, customer name, or product figure.
                    3. Clearly state the exact Date Range used for every sales, expense, or profit calculation.
                    4. If cost/purchase price data is missing or marked as unavailable/estimated, explicitly state that cost data is unavailable for those items rather than claiming 0 cost. Distinguish unavailable data from zero values.
                    5. NEVER claim you already saved, modified, or deleted a transaction. If the user explicitly asks you to record an expense, payment, due/credit, or sale, explain the details and append ONE structured block at the very end so the user can review and tap Confirm:
                    [PROPOSED_ACTION]{"actionType":"ADD_EXPENSE|RECEIVE_PAYMENT|CREDIT_SALE|ADD_SALE","partyOrCategory":"name or category","amountTaka":1234,"notes":"short note"}[/PROPOSED_ACTION]
                    6. Keep sensitive details protected and concise; use Bangladeshi Taka (৳) and clear bullet points with actionable business advice.
                    """.trimIndent()
                )
            }
        )
    }

    fun buildDatabaseContext(
        business: BusinessEntity,
        accounts: List<AccountEntity>,
        customers: List<CustomerEntity>,
        suppliers: List<SupplierEntity>,
        products: List<ProductEntity>,
        transactions: List<AccountingTransactionEntity>,
        invoices: List<InvoiceEntity>,
        invoiceItems: List<InvoiceItemEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): Pair<String, String> {
        val (todayStart, todayEnd) = MoneyUtils.dhakaTodayBounds(nowMillis)
        val (weekStart, weekEnd) = MoneyUtils.dhakaWeekBounds(nowMillis)
        val (monthStart, monthEnd) = MoneyUtils.dhakaMonthBounds(nowMillis)
        val (yearStart, yearEnd) = MoneyUtils.dhakaYearBounds(nowMillis)

        val dash = AccountingCalculator.computeDashboard(accounts, customers, suppliers, transactions, nowMillis)
        val todayPnl = AccountingCalculator.computeProfitAndLoss(transactions, todayStart, todayEnd)
        val weekPnl = AccountingCalculator.computeProfitAndLoss(transactions, weekStart, weekEnd)
        val monthPnl = AccountingCalculator.computeProfitAndLoss(transactions, monthStart, monthEnd)
        val yearPnl = AccountingCalculator.computeProfitAndLoss(transactions, yearStart, yearEnd)
        val advanced = AccountingCalculator.computeAdvancedAnalytics(
            accounts, customers, products, transactions, invoices, invoiceItems, nowMillis
        )

        val todayStr = MoneyUtils.formatDhakaDate(nowMillis)
        val monthStartStr = MoneyUtils.formatDhakaDate(monthStart)
        val yearStartStr = MoneyUtils.formatDhakaDate(yearStart)
        val dateRangeSummary = "All-time up to $todayStr | Month: $monthStartStr – $todayStr"

        val topDebtors = customers
            .filter { it.currentDuePaisa > 0L }
            .sortedByDescending { it.currentDuePaisa }
            .take(8)
            .joinToString("; ") { "${it.name}: ${MoneyUtils.formatTaka(it.currentDuePaisa)}" }
            .ifBlank { "No outstanding customer dues (৳0)" }

        val topSuppliersPayable = suppliers
            .filter { it.currentPayablePaisa > 0L }
            .sortedByDescending { it.currentPayablePaisa }
            .take(5)
            .joinToString("; ") { "${it.name}: ${MoneyUtils.formatTaka(it.currentPayablePaisa)}" }
            .ifBlank { "No supplier payables (৳0)" }

        val topProducts = advanced.bestSellingProducts.take(8).joinToString("; ") { row ->
            val costNote = if (row.hasMissingCost) "cost unavailable for some units" else "profit ${MoneyUtils.formatTaka(row.profitPaisa)}"
            "${row.itemName}: qty ${MoneyUtils.milliUnitsToString(row.quantitySoldMilliUnits)} ${row.unit}, rev ${MoneyUtils.formatTaka(row.revenuePaisa)} ($costNote)"
        }.ifBlank { "No product sales recorded yet" }

        val lowStockList = products
            .filter { !it.archived && it.stockMilliUnits <= it.lowStockThresholdMilliUnits }
            .take(8)
            .joinToString("; ") { "${it.name} (${MoneyUtils.milliUnitsToString(it.stockMilliUnits)} ${it.unit})" }
            .ifBlank { "None" }

        val expenseCats = advanced.expenseBreakdown.take(6).joinToString("; ") {
            "${it.categoryName}: ${MoneyUtils.formatTaka(it.amountPaisa)} (${"%.1f".format(it.sharePercent)}%)"
        }.ifBlank { "No expenses recorded" }

        val growthLine = advanced.salesGrowthPercent?.let {
            "${"%.1f".format(it)}% vs previous month (${MoneyUtils.formatTaka(advanced.previousMonthSalesPaisa)} -> ${MoneyUtils.formatTaka(advanced.currentMonthSalesPaisa)})"
        } ?: "Previous month sales data unavailable for growth % comparison (Current month: ${MoneyUtils.formatTaka(advanced.currentMonthSalesPaisa)})"

        val costFlagNote = if (dash.isEstimatedProfit) {
            "IMPORTANT: Some sales/credit entries lack purchase cost data (cost data unavailable, NOT zero cost); profit is marked Estimated."
        } else {
            "All recorded item costs are available."
        }

        val contextBlock = buildString {
            appendLine("[BUSINESS_LEDGER_CONTEXT]")
            appendLine("Business: ${business.name} (${business.category})")
            appendLine("Analysis Date (Asia/Dhaka): $todayStr")
            appendLine("Transactions Count: ${transactions.count { !it.isReversed }}, Customers: ${customers.size}, Suppliers: ${suppliers.size}, Products: ${products.size}")
            appendLine("Balances -> Cash: ${MoneyUtils.formatTaka(dash.cashBalancePaisa)}, Bank: ${MoneyUtils.formatTaka(dash.bankBalancePaisa)}, MFS: ${MoneyUtils.formatTaka(dash.mfsBalancePaisa)}")
            appendLine("Receivables: ${MoneyUtils.formatTaka(dash.totalReceivablesPaisa)} (Overdue: ${MoneyUtils.formatTaka(dash.overdueDuesPaisa)}) | Supplier Payables: ${MoneyUtils.formatTaka(dash.totalPayablesPaisa)}")
            appendLine("Today ($todayStr) -> Sales: ${MoneyUtils.formatTaka(todayPnl.netSalesPaisa)}, Expenses: ${MoneyUtils.formatTaka(todayPnl.operatingExpensesPaisa)}, Net Profit: ${MoneyUtils.formatTaka(todayPnl.netProfitPaisa)} (Estimated=${todayPnl.isEstimated})")
            appendLine("Last 7 Days (${MoneyUtils.formatDhakaDate(weekStart)} - $todayStr) -> Sales: ${MoneyUtils.formatTaka(weekPnl.netSalesPaisa)}, Expenses: ${MoneyUtils.formatTaka(weekPnl.operatingExpensesPaisa)}, Net Profit: ${MoneyUtils.formatTaka(weekPnl.netProfitPaisa)}")
            appendLine("This Month ($monthStartStr - $todayStr) -> Sales: ${MoneyUtils.formatTaka(monthPnl.netSalesPaisa)}, Expenses: ${MoneyUtils.formatTaka(monthPnl.operatingExpensesPaisa)}, Net Profit: ${MoneyUtils.formatTaka(monthPnl.netProfitPaisa)} (Estimated=${monthPnl.isEstimated})")
            appendLine("This Year ($yearStartStr - $todayStr) -> Sales: ${MoneyUtils.formatTaka(yearPnl.netSalesPaisa)}, Expenses: ${MoneyUtils.formatTaka(yearPnl.operatingExpensesPaisa)}, Net Profit: ${MoneyUtils.formatTaka(yearPnl.netProfitPaisa)}")
            appendLine("All-Time Net Sales: ${MoneyUtils.formatTaka(dash.totalSalesPaisa)}, Total Expenses: ${MoneyUtils.formatTaka(dash.totalExpensesPaisa)}, Net Profit: ${MoneyUtils.formatTaka(dash.netProfitPaisa)}")
            appendLine("Monthly Sales Growth: $growthLine")
            appendLine("Cost Availability: $costFlagNote")
            appendLine("Top Customer Dues: $topDebtors")
            appendLine("Top Supplier Payables: $topSuppliersPayable")
            appendLine("Top Products Performance: $topProducts")
            appendLine("Expense Breakdown: $expenseCats")
            appendLine("Low Stock Alerts: $lowStockList")
            appendLine("Business Health Score: ${advanced.healthReport.score}/100 (${advanced.healthReport.grade})")
            appendLine("[/BUSINESS_LEDGER_CONTEXT]")
        }
        return contextBlock to dateRangeSummary
    }

    fun streamQuery(
        question: String,
        history: List<AiChatMessage>,
        contextBlock: String
    ): Flow<String> = flow {
        val recentTurns = history.takeLast(6).joinToString("\n") { msg ->
            if (msg.isUser) "User: ${msg.text}" else "Assistant: ${msg.text}"
        }
        val prompt = buildString {
            appendLine(contextBlock)
            if (recentTurns.isNotBlank()) {
                appendLine("Recent conversation:")
                appendLine(recentTurns)
            }
            appendLine("Current User Question: $question")
        }

        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                model.generateContentStream(prompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("AI assistant returned an empty response.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI assistant request timed out", e)
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI inference failed", e)
            throw e
        }
    }

    fun extractProposedAction(rawResponse: String): Pair<String, AiProposedAction?> {
        val regex = Regex("\\[PROPOSED_ACTION\\](.*?)\\[/PROPOSED_ACTION\\]", RegexOption.DOT_MATCHES_ALL)
        val match = regex.find(rawResponse) ?: return rawResponse.trim() to null
        val display = rawResponse.replace(regex, "").trim()
        return try {
            val json = JSONObject(match.groupValues[1].trim())
            val taka = json.optDouble("amountTaka", 0.0)
            val paisa = (taka * 100.0).toLong().coerceAtLeast(0L)
            if (paisa <= 0L) return display to null
            val action = AiProposedAction(
                actionType = json.optString("actionType", "ADD_EXPENSE"),
                partyOrCategory = json.optString("partyOrCategory", "General"),
                amountPaisa = paisa,
                notes = json.optString("notes", "")
            )
            display to action
        } catch (_: Exception) {
            display to null
        }
    }
}
