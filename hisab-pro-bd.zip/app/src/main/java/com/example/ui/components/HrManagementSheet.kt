package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.*
import com.example.ui.BusinessWorkspaceState
import com.example.ui.theme.*
import java.time.Instant
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HrManagementSheet(
    state: BusinessWorkspaceState,
    onDismiss: () -> Unit,
    onSaveEmployee: (name: String, phone: String, email: String, role: String, salaryPaisa: Long, existingId: String?) -> Unit,
    onRemoveEmployee: (String) -> Unit,
    onSetActiveEmployee: (String) -> Unit,
    onRecordAttendance: (employeeId: String, dateKey: String, status: String, notes: String) -> Unit,
    onSubmitLeave: (employeeId: String, startDateKey: String, endDateKey: String, leaveType: String, reason: String) -> Unit,
    onDecideLeave: (requestId: String, approved: Boolean) -> Unit,
    onRecordSalary: (employeeId: String, monthKey: String, paymentType: String, amountPaisa: Long, accountId: String, notes: String) -> Unit,
    onUpdateRolePermission: (RolePermissionEntity) -> Unit
) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var subTab by remember { mutableIntStateOf(0) } // 0 Staff, 1 Attendance, 2 Leave, 3 Salary, 4 Roles RBAC, 5 Audit Log

    val canManageEmp = state.activeEmployee?.canManageEmployees ?: true
    val isOwner = (state.activeEmployee?.role ?: EmployeeRoles.OWNER) == EmployeeRoles.OWNER
    val todayDateKey = remember {
        Instant.now().atZone(MoneyUtils.DHAKA_ZONE).toLocalDate().format(DateTimeFormatter.ISO_LOCAL_DATE)
    }
    val currentMonthKey = remember(todayDateKey) { todayDateKey.take(7) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .padding(horizontal = 16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(strings.hrPayrollTitle, style = MaterialTheme.typography.titleLarge)

            ScrollableTabRow(selectedTabIndex = subTab, edgePadding = 0.dp) {
                listOf(
                    "Staff",
                    strings.attendanceTab,
                    strings.leaveTab,
                    strings.salaryTab,
                    strings.rolesPermissionsTab,
                    strings.activityLogTab
                ).forEachIndexed { idx, label ->
                    Tab(
                        selected = subTab == idx,
                        onClick = { subTab = idx },
                        text = { Text(label, maxLines = 1) },
                        modifier = Modifier.testTag("hr_tab_$idx")
                    )
                }
            }

            when (subTab) {
                0 -> StaffSubTab(
                    state = state,
                    useBn = useBn,
                    canManageEmp = canManageEmp,
                    onSaveEmployee = onSaveEmployee,
                    onRemoveEmployee = onRemoveEmployee,
                    onSetActiveEmployee = onSetActiveEmployee
                )
                1 -> AttendanceSubTab(
                    state = state,
                    todayDateKey = todayDateKey,
                    onRecordAttendance = onRecordAttendance
                )
                2 -> LeaveSubTab(
                    state = state,
                    todayDateKey = todayDateKey,
                    canApprove = canManageEmp,
                    onSubmitLeave = onSubmitLeave,
                    onDecideLeave = onDecideLeave
                )
                3 -> SalarySubTab(
                    state = state,
                    useBn = useBn,
                    currentMonthKey = currentMonthKey,
                    canPay = canManageEmp,
                    onRecordSalary = onRecordSalary
                )
                4 -> RolesRbacSubTab(
                    rolePermissions = state.rolePermissions,
                    canEditRbac = isOwner || (state.activeEmployee?.canManageSettings ?: false),
                    onUpdatePermission = onUpdateRolePermission
                )
                else -> AuditLogSubTab(logs = state.activityLogs, useBn = useBn)
            }
        }
    }
}

@Composable
private fun StaffSubTab(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    canManageEmp: Boolean,
    onSaveEmployee: (String, String, String, String, Long, String?) -> Unit,
    onRemoveEmployee: (String) -> Unit,
    onSetActiveEmployee: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var salaryText by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(EmployeeRoles.CASHIER) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        items(state.employees, key = { it.id }) { emp ->
            val isActive = emp.id == state.activeEmployee?.id
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSetActiveEmployee(emp.id) },
                shape = RoundedCornerShape(14.dp),
                color = if (isActive) SoftGreenAccent else MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, if (isActive) EmeraldPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "${emp.name} (${emp.role})",
                            style = MaterialTheme.typography.titleSmall,
                            color = if (isActive) DarkNavy else MaterialTheme.colorScheme.onSurface
                        )
                        val salStr = if (emp.salaryPaisa > 0L) " • Salary: ${MoneyUtils.formatTaka(emp.salaryPaisa, useBn)}" else ""
                        Text(
                            "${emp.phone.ifBlank { "No phone" }}$salStr",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isActive) TextSecondaryLight else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Reports: ${emp.canViewReports} • Inventory: ${emp.canManageInventory} • Reversal: ${emp.canDeleteOrReverse}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary
                        )
                    }
                    if (isActive) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "Active Operator", tint = EmeraldPrimary)
                    } else if (canManageEmp && emp.role != EmployeeRoles.OWNER) {
                        IconButton(onClick = { onRemoveEmployee(emp.id) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = ExpenseRed)
                        }
                    }
                }
            }
        }

        if (canManageEmp) {
            item {
                HorizontalDivider()
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Add Employee", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(
                            value = salaryText,
                            onValueChange = { salaryText = it },
                            label = { Text("Salary (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(EmployeeRoles.ALL) { r ->
                            FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r) })
                        }
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                onSaveEmployee(
                                    name,
                                    MoneyUtils.formatBdPhone(phone),
                                    email,
                                    role,
                                    MoneyUtils.parseTakaToPaisa(salaryText),
                                    null
                                )
                                name = ""; phone = ""; email = ""; salaryText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) { Text("Add Employee") }
                }
            }
        }
    }
}

@Composable
private fun AttendanceSubTab(
    state: BusinessWorkspaceState,
    todayDateKey: String,
    onRecordAttendance: (String, String, String, String) -> Unit
) {
    val todayMap = remember(state.attendance, todayDateKey) {
        state.attendance.filter { it.dateKey == todayDateKey }.associateBy { it.employeeId }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item {
            Text("Today's Attendance ($todayDateKey)", style = MaterialTheme.typography.titleSmall, color = EmeraldPrimary)
        }
        items(state.employees, key = { it.id }) { emp ->
            val currentStatus = todayMap[emp.id]?.status ?: "UNMARKED"
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${emp.name} (${emp.role})", style = MaterialTheme.typography.titleSmall)
                        Text(currentStatus, style = MaterialTheme.typography.labelMedium, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(AttendanceStatuses.ALL) { st ->
                            FilterChip(
                                selected = currentStatus == st,
                                onClick = { onRecordAttendance(emp.id, todayDateKey, st, "") },
                                label = { Text(st) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LeaveSubTab(
    state: BusinessWorkspaceState,
    todayDateKey: String,
    canApprove: Boolean,
    onSubmitLeave: (String, String, String, String, String) -> Unit,
    onDecideLeave: (String, Boolean) -> Unit
) {
    var selectedEmp by remember(state.employees) { mutableStateOf(state.activeEmployee ?: state.employees.firstOrNull()) }
    var leaveType by remember { mutableStateOf("Casual") }
    var reason by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Submit Leave Request", style = MaterialTheme.typography.titleSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(state.employees, key = { it.id }) { e ->
                            FilterChip(selected = selectedEmp?.id == e.id, onClick = { selectedEmp = e }, label = { Text(e.name) })
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf("Casual", "Sick", "Annual", "Emergency")) { lt ->
                            FilterChip(selected = leaveType == lt, onClick = { leaveType = lt }, label = { Text(lt) })
                        }
                    }
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            val emp = selectedEmp ?: return@Button
                            if (reason.isNotBlank()) {
                                onSubmitLeave(emp.id, todayDateKey, todayDateKey, leaveType, reason)
                                reason = ""
                            }
                        },
                        enabled = selectedEmp != null && reason.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                    ) { Text("Request Leave") }
                }
            }
        }

        items(state.leaves, key = { it.id }) { req ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${req.employeeName} • ${req.leaveType}", style = MaterialTheme.typography.titleSmall)
                        Text(
                            req.status,
                            style = MaterialTheme.typography.labelMedium,
                            color = when (req.status) {
                                LeaveStatuses.APPROVED -> EmeraldPrimary
                                LeaveStatuses.REJECTED -> ExpenseRed
                                else -> WarningAmber
                            }
                        )
                    }
                    Text("${req.startDateKey} • ${req.reason}", style = MaterialTheme.typography.bodySmall)
                    if (canApprove && req.status == LeaveStatuses.PENDING) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onDecideLeave(req.id, true) }, modifier = Modifier.weight(1f)) { Text("Approve") }
                            OutlinedButton(onClick = { onDecideLeave(req.id, false) }, modifier = Modifier.weight(1f)) { Text("Reject") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SalarySubTab(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    currentMonthKey: String,
    canPay: Boolean,
    onRecordSalary: (String, String, String, Long, String, String) -> Unit
) {
    var selectedEmp by remember(state.employees) { mutableStateOf(state.employees.firstOrNull()) }
    var payType by remember { mutableStateOf(SalaryPaymentTypes.SALARY) }
    var amountText by remember(selectedEmp) {
        val sal = selectedEmp?.salaryPaisa ?: 0L
        mutableStateOf(if (sal > 0L) MoneyUtils.paisaToInputString(sal) else "")
    }
    var selectedAcc by remember(state.accounts) { mutableStateOf(state.accounts.firstOrNull()) }
    var notes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        if (canPay) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pay Salary / Advance / Bonus ($currentMonthKey)", style = MaterialTheme.typography.titleSmall)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(state.employees, key = { it.id }) { e ->
                                FilterChip(selected = selectedEmp?.id == e.id, onClick = { selectedEmp = e }, label = { Text(e.name) })
                            }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(SalaryPaymentTypes.ALL) { pt ->
                                FilterChip(selected = payType == pt, onClick = { payType = pt }, label = { Text(pt) })
                            }
                        }
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Amount (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth()
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(state.accounts, key = { it.id }) { a ->
                                FilterChip(selected = selectedAcc?.id == a.id, onClick = { selectedAcc = a }, label = { Text(a.name) })
                            }
                        }
                        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                val emp = selectedEmp ?: return@Button
                                val acc = selectedAcc ?: return@Button
                                val amt = MoneyUtils.parseTakaToPaisa(amountText)
                                if (amt > 0L) {
                                    onRecordSalary(emp.id, currentMonthKey, payType, amt, acc.id, notes)
                                    notes = ""
                                }
                            },
                            enabled = selectedEmp != null && selectedAcc != null && MoneyUtils.parseTakaToPaisa(amountText) > 0L,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        ) { Text("Record Payroll Payout") }
                    }
                }
            }
        }

        items(state.salaryPayments, key = { it.id }) { sp ->
            ListItem(
                headlineContent = { Text("${sp.employeeName} (${sp.paymentType})") },
                supportingContent = { Text("${sp.monthKey} • ${MoneyUtils.formatDhakaDateTime(sp.occurredAt, useBn)}") },
                trailingContent = {
                    Text(
                        MoneyUtils.formatTaka(sp.amountPaisa, useBn),
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        color = ExpenseRed
                    )
                }
            )
        }
    }
}

@Composable
private fun RolesRbacSubTab(
    rolePermissions: List<RolePermissionEntity>,
    canEditRbac: Boolean,
    onUpdatePermission: (RolePermissionEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        if (!canEditRbac) {
            item {
                Text(
                    "Only Business Owner can modify role permission templates.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarningAmber
                )
            }
        }
        items(rolePermissions, key = { it.id }) { rp ->
            val lockedOwner = rp.roleName == EmployeeRoles.OWNER
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(rp.roleName, style = MaterialTheme.typography.titleSmall, color = EmeraldPrimary)
                    RbacToggle("View Reports", rp.canViewReports, canEditRbac && !lockedOwner) {
                        onUpdatePermission(rp.copy(canViewReports = it))
                    }
                    RbacToggle("Record Sales & Billing", rp.canRecordSales, canEditRbac && !lockedOwner) {
                        onUpdatePermission(rp.copy(canRecordSales = it))
                    }
                    RbacToggle("Edit Customers & Dues", rp.canEditCustomers, canEditRbac && !lockedOwner) {
                        onUpdatePermission(rp.copy(canEditCustomers = it))
                    }
                    RbacToggle("Manage Products & Stock", rp.canManageInventory, canEditRbac && !lockedOwner) {
                        onUpdatePermission(rp.copy(canManageInventory = it))
                    }
                    RbacToggle("Reverse / Void Entries", rp.canDeleteOrReverse, canEditRbac && !lockedOwner) {
                        onUpdatePermission(rp.copy(canDeleteOrReverse = it))
                    }
                    RbacToggle("Manage Staff & Payroll", rp.canManageEmployees, canEditRbac && !lockedOwner) {
                        onUpdatePermission(rp.copy(canManageEmployees = it))
                    }
                }
            }
        }
    }
}

@Composable
private fun RbacToggle(label: String, checked: Boolean, enabled: Boolean, onChanged: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChanged, enabled = enabled)
    }
}

@Composable
private fun AuditLogSubTab(logs: List<ActivityLogEntity>, useBn: Boolean) {
    if (logs.isEmpty()) {
        EmptyStateCard(Icons.Default.History, "No audit activity yet", "Sales, reversals, HR updates, and payouts appear here.")
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        items(logs, key = { it.id }) { log ->
            ListItem(
                headlineContent = { Text(log.summary, style = MaterialTheme.typography.titleSmall) },
                supportingContent = {
                    Text("${log.actorName} • ${log.actionType} • ${MoneyUtils.formatDhakaDateTime(log.occurredAt, useBn)}")
                },
                leadingContent = {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = EmeraldPrimary)
                }
            )
            HorizontalDivider()
        }
    }
}
