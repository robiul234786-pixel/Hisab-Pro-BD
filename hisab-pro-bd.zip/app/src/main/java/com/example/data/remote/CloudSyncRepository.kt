package com.example.data.remote

import android.content.Context
import android.os.Build
import com.example.BuildConfig
import com.example.R
import com.example.data.local.*
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

data class CloudSyncSummary(
    val businessesSynced: Int,
    val recordsSynced: Int,
    val conflictsDetected: Int = 0,
    val syncedAtMillis: Long
)

class CloudSyncRepository(
    private val db: FirebaseFirestore,
    private val localDb: HisabDatabase,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context, localDb: HisabDatabase) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        localDb = localDb
    )

    private fun requireUserId(): String {
        val uid = auth.currentUser?.uid
        check(!uid.isNullOrBlank()) { "User must be signed in with Google before accessing Firestore." }
        return uid
    }

    private fun sanitizeFirestoreId(raw: String): String {
        return raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(128).ifBlank { "doc_0" }
    }

    private fun localDeviceName(): String = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifBlank { "Android Device" }

    suspend fun syncLocalToCloud(
        currentUserId: String,
        deviceId: String = "device_default"
    ): Result<CloudSyncSummary> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != currentUserId) {
            return Result.failure(IllegalStateException("Signed-in user changed; aborting sync."))
        }

        val now = System.currentTimeMillis()
        val userDocRef = db.collection("users").document(uid)
        val cleanDeviceId = sanitizeFirestoreId(deviceId)
        val businesses = localDb.businessDao().getAllBusinessesSync()

        return try {
            // 1. Check & register device authorization
            val devRef = userDocRef.collection("devices").document(cleanDeviceId)
            val existingDevSnap = devRef.get().await()
            if (existingDevSnap.exists()) {
                val remoteDev = existingDevSnap.toObject(CloudDevice::class.java)
                if (remoteDev?.revoked == true) {
                    localDb.authorizedDeviceDao().setRevoked(deviceId, true)
                    return Result.failure(SecurityException("This device access has been revoked by the business owner."))
                }
            }
            val cloudDev = CloudDevice(
                id = cleanDeviceId,
                userId = uid,
                deviceName = localDeviceName(),
                platform = "Android",
                appVersion = BuildConfig.VERSION_NAME,
                lastSyncAtMillis = now,
                revoked = false
            )
            if (!existingDevSnap.exists()) {
                devRef.set(cloudDev.toCreateMap(uid)).await()
            } else {
                devRef.update(cloudDev.toUpdateMap()).await()
            }
            localDb.authorizedDeviceDao().upsert(
                AuthorizedDeviceEntity(
                    id = deviceId,
                    userId = uid,
                    deviceName = localDeviceName(),
                    platform = "Android",
                    appVersion = BuildConfig.VERSION_NAME,
                    lastSyncAtMillis = now,
                    revoked = false,
                    isCurrentDevice = true,
                    createdAt = now
                )
            )

            // Fetch all cloud devices into local table
            val allDevSnap = userDocRef.collection("devices").get().await()
            val allCloudDevs = allDevSnap.toObjects(CloudDevice::class.java)
            localDb.authorizedDeviceDao().upsertAll(
                allCloudDevs.map { cd ->
                    AuthorizedDeviceEntity(
                        id = cd.id,
                        userId = uid,
                        deviceName = cd.deviceName,
                        platform = cd.platform,
                        appVersion = cd.appVersion,
                        lastSyncAtMillis = cd.lastSyncAtMillis,
                        revoked = cd.revoked,
                        isCurrentDevice = cd.id == cleanDeviceId,
                        createdAt = cd.createdAt?.toDate()?.time ?: now
                    )
                }
            )

            // 2. Profile upsert
            val profileSnap = userDocRef.get().await()
            val displayName = (auth.currentUser?.displayName ?: auth.currentUser?.email ?: "Hisab User")
                .take(100).ifBlank { "Hisab User" }
            val email = auth.currentUser?.email?.take(160)

            if (!profileSnap.exists()) {
                val createProfile = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "displayName" to displayName,
                    "businessCount" to businesses.size.toLong(),
                    "lastSyncAtMillis" to now,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!email.isNullOrBlank()) createProfile["email"] = email
                userDocRef.set(createProfile).await()
            } else {
                val updateProfile = mutableMapOf<String, Any>(
                    "displayName" to displayName,
                    "businessCount" to businesses.size.toLong(),
                    "lastSyncAtMillis" to now,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!email.isNullOrBlank()) updateProfile["email"] = email
                userDocRef.update(updateProfile).await()
            }

            // 3. Businesses & full ledger records with conflict detection
            var totalRecords = 0
            var conflicts = 0
            for (biz in businesses) {
                val bizDocId = sanitizeFirestoreId(biz.id)
                val bizRef = userDocRef.collection("businesses").document(bizDocId)
                val cloudBiz = CloudBusiness(
                    userId = uid,
                    name = biz.name,
                    category = biz.category,
                    phone = biz.phone.ifBlank { null },
                    address = biz.address.ifBlank { null },
                    languageCode = biz.languageCode,
                    openingCashPaisa = biz.openingCashPaisa,
                    inventoryEnabled = biz.inventoryEnabled,
                    taxEnabled = biz.taxEnabled,
                    defaultTaxRateBps = biz.defaultTaxRateBps.toLong(),
                    archived = biz.archived,
                    syncVersion = biz.syncVersion,
                    deviceId = cleanDeviceId
                )
                val existingBiz = bizRef.get().await()
                if (!existingBiz.exists()) {
                    bizRef.set(cloudBiz.toCreateMap(uid)).await()
                } else {
                    bizRef.update(cloudBiz.toUpdateMap()).await()
                }

                val records = buildLedgerRecordsForBusiness(uid, bizDocId, biz.id, cleanDeviceId)
                for (rec in records) {
                    val recId = sanitizeFirestoreId(rec.first)
                    val recRef = userDocRef.collection("ledger_records").document(recId)
                    val existingRec = recRef.get().await()
                    if (!existingRec.exists()) {
                        recRef.set(rec.second.toCreateMap(uid)).await()
                    } else {
                        val remote = existingRec.toObject(CloudLedgerRecord::class.java)
                        if (remote != null &&
                            remote.deviceId != null &&
                            remote.deviceId != cleanDeviceId &&
                            remote.syncVersion > rec.second.syncVersion
                        ) {
                            conflicts++
                            localDb.syncOutboxDao().upsert(
                                SyncOutboxEntity(
                                    id = "${rec.second.entityType}_${rec.first}",
                                    businessId = biz.id,
                                    entityType = rec.second.entityType,
                                    entityId = rec.first,
                                    operation = "CONFLICT",
                                    version = remote.syncVersion,
                                    updatedAtMillis = now,
                                    status = "CONFLICT",
                                    conflictDetail = "Cloud v${remote.syncVersion} vs Local v${rec.second.syncVersion} (${rec.second.title})"
                                )
                            )
                            continue
                        }
                        recRef.update(rec.second.toUpdateMap()).await()
                    }
                    totalRecords++
                }
            }

            // Mark non-conflict outbox entries as synced
            localDb.syncOutboxDao().getByStatusSync("PENDING").forEach { pending ->
                localDb.syncOutboxDao().markSynced(pending.id)
            }
            localDb.syncOutboxDao().purgeSynced()

            Result.success(
                CloudSyncSummary(
                    businessesSynced = businesses.size,
                    recordsSynced = totalRecords,
                    conflictsDetected = conflicts,
                    syncedAtMillis = now
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun revokeCloudDevice(currentUserId: String, targetDeviceId: String, revoke: Boolean): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != currentUserId) return Result.failure(IllegalStateException("User mismatch"))
        return try {
            val cleanId = sanitizeFirestoreId(targetDeviceId)
            db.collection("users").document(uid)
                .collection("devices").document(cleanId)
                .update(mapOf("revoked" to revoke, "updatedAt" to FieldValue.serverTimestamp()))
                .await()
            localDb.authorizedDeviceDao().setRevoked(targetDeviceId, revoke)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreCloudToLocal(currentUserId: String): Result<CloudSyncSummary> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != currentUserId) {
            return Result.failure(IllegalStateException("Signed-in user changed; aborting restore."))
        }

        val userDocRef = db.collection("users").document(uid)
        return try {
            val bizSnap = userDocRef.collection("businesses").get().await()
            val businesses = bizSnap.toObjects(
                CloudBusiness::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            val recSnap = userDocRef.collection("ledger_records").get().await()
            val records = recSnap.toObjects(
                CloudLedgerRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )

            var conflicts = 0
            val now = System.currentTimeMillis()

            businesses.forEach { cb ->
                val localExisting = localDb.businessDao().getById(cb.id)
                val cloudUpdated = cb.updatedAt?.toDate()?.time ?: now
                if (localExisting != null && localExisting.updatedAt > cloudUpdated + 5000L && localExisting.syncVersion > cb.syncVersion) {
                    conflicts++
                    localDb.syncOutboxDao().upsert(
                        SyncOutboxEntity(
                            id = "BUSINESS_${cb.id}",
                            businessId = cb.id,
                            entityType = "BUSINESS",
                            entityId = cb.id,
                            version = cb.syncVersion,
                            updatedAtMillis = now,
                            status = "CONFLICT",
                            conflictDetail = "Local business '${localExisting.name}' newer than cloud."
                        )
                    )
                } else {
                    localDb.businessDao().upsert(
                        BusinessEntity(
                            id = cb.id,
                            name = cb.name,
                            category = cb.category,
                            phone = cb.phone ?: "",
                            address = cb.address ?: "",
                            languageCode = cb.languageCode,
                            openingCashPaisa = cb.openingCashPaisa,
                            inventoryEnabled = cb.inventoryEnabled,
                            taxEnabled = cb.taxEnabled,
                            defaultTaxRateBps = cb.defaultTaxRateBps.toInt(),
                            archived = cb.archived,
                            createdAt = cb.createdAt?.toDate()?.time ?: now,
                            updatedAt = cloudUpdated,
                            syncVersion = cb.syncVersion,
                            lastModifiedDeviceId = cb.deviceId ?: ""
                        )
                    )
                }
            }

            records.forEach { rec ->
                when (rec.entityType) {
                    "ACCOUNT" -> {
                        val existing = localDb.accountDao().getById(rec.id)
                        if (existing == null || rec.balancePaisa != existing.currentBalancePaisa) {
                            localDb.accountDao().upsert(
                                AccountEntity(
                                    id = rec.id,
                                    businessId = rec.businessId,
                                    name = rec.title,
                                    type = rec.status,
                                    accountNumber = rec.subtitle ?: "",
                                    openingBalancePaisa = rec.amountPaisa,
                                    currentBalancePaisa = rec.balancePaisa,
                                    isDefault = rec.status == "CASH",
                                    archived = rec.archived,
                                    createdAt = rec.occurredAtMillis
                                )
                            )
                        }
                    }
                    "CUSTOMER" -> {
                        val existing = localDb.customerDao().getById(rec.id)
                        if (existing != null && existing.syncVersion > rec.syncVersion) {
                            conflicts++
                            localDb.syncOutboxDao().upsert(
                                SyncOutboxEntity(
                                    id = "CUSTOMER_${rec.id}",
                                    businessId = rec.businessId,
                                    entityType = "CUSTOMER",
                                    entityId = rec.id,
                                    version = rec.syncVersion,
                                    updatedAtMillis = now,
                                    status = "CONFLICT",
                                    conflictDetail = "Customer ${rec.title} modified locally (v${existing.syncVersion}) vs cloud (v${rec.syncVersion})"
                                )
                            )
                        } else {
                            localDb.customerDao().upsert(
                                CustomerEntity(
                                    id = rec.id,
                                    businessId = rec.businessId,
                                    customerCode = rec.status,
                                    name = rec.title,
                                    phone = rec.phone ?: "",
                                    address = rec.notes ?: "",
                                    category = rec.category ?: "Regular",
                                    currentDuePaisa = rec.balancePaisa,
                                    totalPurchasesPaisa = rec.amountPaisa,
                                    archived = rec.archived,
                                    createdAt = rec.occurredAtMillis,
                                    syncVersion = rec.syncVersion
                                )
                            )
                        }
                    }
                    "SUPPLIER" -> {
                        localDb.supplierDao().upsert(
                            SupplierEntity(
                                id = rec.id,
                                businessId = rec.businessId,
                                supplierCode = rec.status,
                                name = rec.title,
                                phone = rec.phone ?: "",
                                address = rec.notes ?: "",
                                currentPayablePaisa = rec.balancePaisa,
                                totalPurchasesPaisa = rec.amountPaisa,
                                archived = rec.archived,
                                createdAt = rec.occurredAtMillis,
                                syncVersion = rec.syncVersion
                            )
                        )
                    }
                    "PRODUCT" -> {
                        localDb.productDao().upsert(
                            ProductEntity(
                                id = rec.id,
                                businessId = rec.businessId,
                                name = rec.title,
                                sku = rec.subtitle ?: "",
                                category = rec.category ?: "General",
                                sellingPricePaisa = rec.amountPaisa,
                                stockMilliUnits = rec.balancePaisa,
                                unit = rec.status,
                                archived = rec.archived,
                                createdAt = rec.occurredAtMillis,
                                syncVersion = rec.syncVersion
                            )
                        )
                    }
                    "TRANSACTION" -> {
                        val existingTx = localDb.transactionDao().getById(rec.id)
                        if (existingTx == null) {
                            localDb.transactionDao().upsertAll(
                                listOf(
                                    AccountingTransactionEntity(
                                        id = rec.id,
                                        idempotencyKey = rec.id,
                                        businessId = rec.businessId,
                                        type = rec.status,
                                        partyName = rec.title,
                                        accountName = rec.subtitle ?: "",
                                        categoryName = rec.category ?: "",
                                        totalAmountPaisa = rec.amountPaisa,
                                        paidAmountPaisa = rec.balancePaisa,
                                        isReversed = rec.archived,
                                        notes = rec.notes ?: "",
                                        occurredAt = rec.occurredAtMillis,
                                        syncVersion = rec.syncVersion,
                                        deviceId = rec.deviceId ?: ""
                                    )
                                )
                            )
                        }
                    }
                    "EMPLOYEE" -> {
                        localDb.employeeDao().upsert(
                            EmployeeEntity(
                                id = rec.id,
                                businessId = rec.businessId,
                                name = rec.title,
                                phone = rec.phone ?: "",
                                role = rec.status,
                                salaryPaisa = rec.amountPaisa,
                                canViewReports = rec.status != EmployeeRoles.CASHIER,
                                canDeleteOrReverse = rec.status in listOf(EmployeeRoles.OWNER, EmployeeRoles.ADMINISTRATOR, EmployeeRoles.MANAGER),
                                canManageEmployees = rec.status in listOf(EmployeeRoles.OWNER, EmployeeRoles.ADMINISTRATOR),
                                canManageSettings = rec.status == EmployeeRoles.OWNER,
                                isActive = !rec.archived,
                                createdAt = rec.occurredAtMillis
                            )
                        )
                    }
                    "SALARY" -> {
                        localDb.salaryPaymentDao().insert(
                            SalaryPaymentEntity(
                                id = rec.id,
                                businessId = rec.businessId,
                                employeeId = rec.subtitle ?: "",
                                employeeName = rec.title,
                                monthKey = rec.category ?: "",
                                paymentType = rec.status,
                                amountPaisa = rec.amountPaisa,
                                accountId = "",
                                notes = rec.notes ?: "",
                                occurredAt = rec.occurredAtMillis
                            )
                        )
                    }
                }
            }

            Result.success(
                CloudSyncSummary(
                    businessesSynced = businesses.size,
                    recordsSynced = records.size,
                    conflictsDetected = conflicts,
                    syncedAtMillis = now
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "users/$uid/businesses")
            Result.failure(e)
        }
    }

    private suspend fun buildLedgerRecordsForBusiness(
        uid: String,
        bizDocId: String,
        localBizId: String,
        deviceId: String
    ): List<Pair<String, CloudLedgerRecord>> {
        val out = mutableListOf<Pair<String, CloudLedgerRecord>>()

        localDb.accountDao().getAccountsSync(localBizId).forEach { acc ->
            out.add(
                acc.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "ACCOUNT",
                    title = acc.name,
                    subtitle = acc.accountNumber.ifBlank { null },
                    amountPaisa = acc.openingBalancePaisa,
                    balancePaisa = acc.currentBalancePaisa,
                    status = acc.type,
                    occurredAtMillis = acc.createdAt,
                    archived = acc.archived,
                    deviceId = deviceId
                )
            )
        }

        localDb.customerDao().getCustomersSync(localBizId).forEach { cust ->
            out.add(
                cust.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "CUSTOMER",
                    title = cust.name,
                    subtitle = cust.category,
                    amountPaisa = cust.totalPurchasesPaisa,
                    balancePaisa = cust.currentDuePaisa,
                    status = cust.customerCode,
                    category = cust.category,
                    phone = cust.phone.ifBlank { null },
                    notes = cust.address.ifBlank { null },
                    occurredAtMillis = cust.createdAt,
                    archived = cust.archived,
                    syncVersion = cust.syncVersion,
                    deviceId = deviceId
                )
            )
        }

        localDb.supplierDao().getSuppliersSync(localBizId).forEach { sup ->
            out.add(
                sup.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "SUPPLIER",
                    title = sup.name,
                    amountPaisa = sup.totalPurchasesPaisa,
                    balancePaisa = sup.currentPayablePaisa,
                    status = sup.supplierCode,
                    phone = sup.phone.ifBlank { null },
                    notes = sup.address.ifBlank { null },
                    occurredAtMillis = sup.createdAt,
                    archived = sup.archived,
                    syncVersion = sup.syncVersion,
                    deviceId = deviceId
                )
            )
        }

        localDb.productDao().getProductsSync(localBizId).forEach { prod ->
            out.add(
                prod.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "PRODUCT",
                    title = prod.name,
                    subtitle = prod.sku.ifBlank { null },
                    amountPaisa = prod.sellingPricePaisa,
                    balancePaisa = prod.stockMilliUnits,
                    status = prod.unit,
                    category = prod.category,
                    occurredAtMillis = prod.createdAt,
                    archived = prod.archived,
                    syncVersion = prod.syncVersion,
                    deviceId = deviceId
                )
            )
        }

        localDb.transactionDao().getTransactionsSync(localBizId).forEach { tx ->
            out.add(
                tx.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "TRANSACTION",
                    title = tx.partyName.ifBlank { tx.categoryName.ifBlank { tx.type } },
                    subtitle = tx.accountName.ifBlank { null },
                    amountPaisa = tx.totalAmountPaisa,
                    balancePaisa = tx.paidAmountPaisa,
                    status = tx.type,
                    category = tx.categoryName.ifBlank { null },
                    notes = tx.notes.ifBlank { null },
                    occurredAtMillis = tx.occurredAt,
                    archived = tx.isReversed,
                    syncVersion = tx.syncVersion,
                    deviceId = tx.deviceId.ifBlank { deviceId }
                )
            )
        }

        localDb.employeeDao().getEmployeesSync(localBizId).forEach { emp ->
            out.add(
                emp.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "EMPLOYEE",
                    title = emp.name,
                    subtitle = emp.email.ifBlank { null },
                    amountPaisa = emp.salaryPaisa,
                    balancePaisa = 0L,
                    status = emp.role,
                    phone = emp.phone.ifBlank { null },
                    occurredAtMillis = emp.createdAt,
                    archived = !emp.isActive,
                    deviceId = deviceId
                )
            )
        }

        localDb.salaryPaymentDao().getSalaryPaymentsSync(localBizId).forEach { sp ->
            out.add(
                sp.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "SALARY",
                    title = sp.employeeName,
                    subtitle = sp.employeeId,
                    amountPaisa = sp.amountPaisa,
                    balancePaisa = 0L,
                    status = sp.paymentType,
                    category = sp.monthKey,
                    notes = sp.notes.ifBlank { null },
                    occurredAtMillis = sp.occurredAt,
                    archived = false,
                    deviceId = deviceId
                )
            )
        }

        localDb.activityLogDao().getActivityLogsSync(localBizId).take(100).forEach { log ->
            out.add(
                log.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "AUDIT_LOG",
                    title = log.summary,
                    subtitle = log.actorName,
                    amountPaisa = 0L,
                    balancePaisa = 0L,
                    status = log.actionType,
                    category = log.entityType,
                    occurredAtMillis = log.occurredAt,
                    archived = false,
                    deviceId = deviceId
                )
            )
        }

        return out
    }
}
