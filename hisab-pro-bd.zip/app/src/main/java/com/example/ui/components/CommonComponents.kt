package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.AccountingTransactionEntity
import com.example.data.local.TxTypes
import com.example.data.repository.MonthlyChartPoint
import com.example.ui.theme.*
import kotlin.math.max

@Composable
fun MetricCard(
    title: String,
    amountPaisa: Long,
    useBanglaDigits: Boolean,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null
) {
    Surface(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Text(
                text = MoneyUtils.formatTaka(amountPaisa, useBanglaDigits),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = MonoFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = accentColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun TransactionRowCard(
    tx: AccountingTransactionEntity,
    useBanglaDigits: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (icon, tint, signAmount) = when (tx.type) {
        TxTypes.SALE, TxTypes.CREDIT_SALE -> Triple(Icons.Default.PointOfSale, EmeraldPrimary, tx.totalAmountPaisa)
        TxTypes.CUSTOMER_PAYMENT -> Triple(Icons.Default.Payments, InfoBlue, tx.paidAmountPaisa)
        TxTypes.CUSTOMER_CREDIT_ADVANCE -> Triple(Icons.Default.CreditScore, WarningAmber, tx.totalAmountPaisa)
        TxTypes.CUSTOMER_REFUND, TxTypes.SALE_RETURN -> Triple(Icons.Default.AssignmentReturn, ExpenseRed, -tx.totalAmountPaisa)
        TxTypes.PURCHASE, TxTypes.SUPPLIER_PAYMENT -> Triple(Icons.Default.ShoppingCart, ExpenseRed, -tx.totalAmountPaisa)
        TxTypes.INCOME -> Triple(Icons.Default.TrendingUp, EmeraldPrimary, tx.totalAmountPaisa)
        TxTypes.EXPENSE -> Triple(Icons.Default.ReceiptLong, ExpenseRed, -tx.totalAmountPaisa)
        TxTypes.ACCOUNT_TRANSFER -> Triple(Icons.AutoMirrored.Filled.CompareArrows, InfoBlue, tx.totalAmountPaisa)
        TxTypes.REVERSAL -> Triple(Icons.Default.Undo, WarningAmber, tx.totalAmountPaisa)
        else -> Triple(Icons.Default.AccountBalanceWallet, MaterialTheme.colorScheme.primary, tx.totalAmountPaisa)
    }

    val title = tx.partyName.ifBlank { tx.categoryName.ifBlank { tx.type.replace('_', ' ') } }
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("tx_row_${tx.id}"),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = tx.type, tint = tint, modifier = Modifier.size(20.dp))
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (tx.isReversed) {
                        Surface(
                            color = WarningSoftAmber,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "REVERSED",
                                style = MaterialTheme.typography.labelSmall,
                                color = WarningAmber,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Text(
                    text = "${tx.type.replace('_', ' ')} • ${MoneyUtils.formatDhakaDate(tx.occurredAt, useBanglaDigits)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (tx.notes.isNotBlank()) {
                    Text(
                        text = tx.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = MoneyUtils.formatTaka(signAmount, useBanglaDigits, showSign = true),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = MonoFontFamily,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (tx.type == TxTypes.ACCOUNT_TRANSFER) InfoBlue
                    else if (signAmount >= 0) EmeraldPrimary else ExpenseRed
                )
                if (tx.dueDeltaPaisa > 0L && (tx.type == TxTypes.CREDIT_SALE || tx.type == TxTypes.SALE)) {
                    Text(
                        text = "Due ${MoneyUtils.formatTaka(tx.dueDeltaPaisa, useBanglaDigits)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarningAmber
                    )
                } else if (tx.accountName.isNotBlank()) {
                    Text(
                        text = tx.accountName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun MonthlySalesBarChart(
    points: List<MonthlyChartPoint>,
    useBanglaDigits: Boolean,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.monthlySalesChart, style = MaterialTheme.typography.titleMedium)
                val peak = points.maxOfOrNull { it.salesPaisa } ?: 0L
                Text(
                    text = "Peak: ${MoneyUtils.formatTaka(peak, useBanglaDigits)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldPrimary
                )
            }
            if (points.all { it.salesPaisa == 0L }) {
                EmptyChartPlaceholder(strings.noDataYet)
            } else {
                val maxVal = max(1L, points.maxOfOrNull { it.salesPaisa } ?: 1L)
                val barColor = EmeraldPrimary
                val trackColor = MaterialTheme.colorScheme.surfaceVariant
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    val count = points.size.coerceAtLeast(1)
                    val slotW = size.width / count
                    val barW = (slotW * 0.48f).coerceAtMost(36.dp.toPx())
                    points.forEachIndexed { idx, pt ->
                        val x = idx * slotW + (slotW - barW) / 2f
                        drawRoundRect(
                            color = trackColor,
                            topLeft = Offset(x, 0f),
                            size = Size(barW, size.height),
                            cornerRadius = CornerRadius(10f, 10f)
                        )
                        val ratio = (pt.salesPaisa.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)
                        val h = size.height * ratio
                        if (h > 0f) {
                            drawRoundRect(
                                color = barColor,
                                topLeft = Offset(x, size.height - h),
                                size = Size(barW, h),
                                cornerRadius = CornerRadius(10f, 10f)
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    points.forEach { pt ->
                        Text(
                            text = pt.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IncomeVsExpenseChart(
    points: List<MonthlyChartPoint>,
    useBanglaDigits: Boolean,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.incomeVsExpenseChart, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    LegendDot(color = EmeraldPrimary, label = if (strings.isBangla) "আয়" else "Income")
                    LegendDot(color = ExpenseRed, label = if (strings.isBangla) "ব্যয়" else "Expense")
                }
            }

            if (points.all { it.incomePaisa == 0L && it.expensePaisa == 0L }) {
                EmptyChartPlaceholder(strings.noDataYet)
            } else {
                val maxVal = max(1L, points.maxOfOrNull { max(it.incomePaisa, it.expensePaisa) } ?: 1L)
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    val count = points.size.coerceAtLeast(1)
                    val slotW = size.width / count
                    val barW = (slotW * 0.28f).coerceAtMost(20.dp.toPx())
                    val gap = 4.dp.toPx()
                    points.forEachIndexed { idx, pt ->
                        val center = idx * slotW + slotW / 2f
                        val incH = size.height * (pt.incomePaisa.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)
                        val expH = size.height * (pt.expensePaisa.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)

                        if (incH > 0f) {
                            drawRoundRect(
                                color = EmeraldPrimary,
                                topLeft = Offset(center - barW - gap / 2f, size.height - incH),
                                size = Size(barW, incH),
                                cornerRadius = CornerRadius(8f, 8f)
                            )
                        }
                        if (expH > 0f) {
                            drawRoundRect(
                                color = ExpenseRed,
                                topLeft = Offset(center + gap / 2f, size.height - expH),
                                size = Size(barW, expH),
                                cornerRadius = CornerRadius(8f, 8f)
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    points.forEach { pt ->
                        Text(
                            text = pt.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyChartPlaceholder(label: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.BarChart, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(EmeraldPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = EmeraldPrimary)
            }
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ResetHisabConfirmDialog(
    businessName: String,
    onConfirmReset: (clearMasterEntities: Boolean, backupBeforeReset: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var clearMasterEntities by remember { mutableStateOf(false) }
    var backupBeforeReset by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                Icons.Default.WarningAmber,
                contentDescription = strings.resetDialogTitle,
                tint = ExpenseRed
            )
        },
        title = { Text(strings.resetDialogTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = if (strings.isBangla) {
                        "\"$businessName\" ব্যবসার হিসাব রিসেট করতে নিচের অপশন নির্বাচন করুন।"
                    } else {
                        "Choose what to reset for \"$businessName\"."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { clearMasterEntities = false }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RadioButton(
                            selected = !clearMasterEntities,
                            onClick = { clearMasterEntities = false }
                        )
                        Text(strings.resetKeepListsOption, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ExpenseSoftRed.copy(alpha = 0.25f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { clearMasterEntities = true }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RadioButton(
                            selected = clearMasterEntities,
                            onClick = { clearMasterEntities = true }
                        )
                        Text(strings.resetFullWipeOption, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { backupBeforeReset = !backupBeforeReset },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Checkbox(
                        checked = backupBeforeReset,
                        onCheckedChange = { backupBeforeReset = it }
                    )
                    Text(
                        strings.backupBeforeResetLabel,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmReset(clearMasterEntities, backupBeforeReset)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                modifier = Modifier.heightIn(min = 48.dp).testTag("confirm_reset_hisab_button")
            ) {
                Text(strings.confirmResetAction)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text(strings.cancel)
            }
        }
    )
}
