package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.util.*
import com.example.data.local.*
import com.example.ui.OnlineShopUiState
import com.example.ui.theme.*

fun mfsBrandColor(methodOrType: String): Color = when (methodOrType.uppercase()) {
    AccountTypes.BKASH, OnlinePaymentMethods.BKASH -> BkashPink
    AccountTypes.NAGAD, OnlinePaymentMethods.NAGAD -> NagadOrange
    AccountTypes.ROCKET, OnlinePaymentMethods.ROCKET -> RocketPurple
    AccountTypes.UPAY, OnlinePaymentMethods.UPAY -> UpayBlue
    else -> EmeraldPrimary
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MfsWalletsSetupBottomSheet(
    state: OnlineShopUiState,
    useBanglaDigits: Boolean,
    onSaveWallet: (accountType: String, displayName: String, walletNumber: String) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val shopPhone = state.activeBusiness?.phone.orEmpty()

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.mfsWalletsSetupTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (strings.isBangla) {
                            "অর্ডার পেমেন্ট সরাসরি বিকাশ, নগদ, রকেট ও উপায় অ্যাকাউন্টে আনুন"
                        } else {
                            "Receive order payments directly into your bKash, Nagad, Rocket & Upay accounts"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = strings.cancel)
                }
            }

            // Honest Direct Wallet vs PGW API Info Banner
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = InfoSoftBlue,
                border = BorderStroke(1.dp, InfoBlue.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = InfoBlue, modifier = Modifier.size(20.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = if (strings.isBangla) "কীভাবে সরাসরি টাকা আসবে?" else "How Direct MFS Collection Works",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = DarkNavy
                        )
                        Text(
                            text = if (strings.isBangla) {
                                "১) আপনার বিকাশ/নগদ/রকেট/উপায় নম্বর সেভ করলে ক্রেতার ওয়েব শপ ও চেকআউটে নম্বর দেখাবে (০% ফি)। ক্রেতা টাকা পাঠিয়ে TrxID দিলে বা আপনি SMS পেস্ট করলেই সরাসরি ওয়ালেট ব্যালেন্স ও বিক্রয় খাতা আপডেট হবে।\n২) অটো পেমেন্ট গেটওয়ে (API) ব্যবহারের জন্য আলাদা মার্চেন্ট ট্রেড লাইসেন্স ও ব্যাকএন্ড সার্ভার প্রয়োজন।"
                            } else {
                                "1) Saving your wallet numbers displays them in Checkout & Web Shop (0% fee). When the customer sends money & provides TrxID — or you paste the confirmation SMS — your wallet balance & ledger credit automatically.\n2) Zero-touch PGW auto-debit requires an external merchant backend server & official bKash/Nagad merchant API keys."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkNavy.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            MfsPaymentParser.PROVIDERS.forEach { spec ->
                val existing = state.accounts.firstOrNull { !it.archived && it.type == spec.accountType }
                val accent = mfsBrandColor(spec.accountType)
                var labelDraft by remember(existing?.id, existing?.name) {
                    mutableStateOf(existing?.name ?: spec.defaultAccountName)
                }
                var numberDraft by remember(existing?.id, existing?.accountNumber, shopPhone) {
                    mutableStateOf(existing?.accountNumber?.ifBlank { "" } ?: "")
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(color = accent, shape = RoundedCornerShape(8.dp)) {
                                    Text(
                                        text = if (strings.isBangla) spec.labelBn else spec.labelEn,
                                        color = PureWhite,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    text = "USSD ${spec.ussdCode}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = MoneyUtils.formatTaka(existing?.currentBalancePaisa ?: 0L, useBanglaDigits),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = MonoFontFamily,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = accent
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = labelDraft,
                                onValueChange = { labelDraft = it },
                                label = { Text(if (strings.isBangla) "ধরন (Personal/Merchant)" else "Label") },
                                singleLine = true,
                                modifier = Modifier.weight(0.95f)
                            )
                            OutlinedTextField(
                                value = numberDraft,
                                onValueChange = { numberDraft = it },
                                label = { Text(if (strings.isBangla) "ওয়ালেট নম্বর" else "Wallet Number") },
                                placeholder = { Text(shopPhone.ifBlank { "01XXXXXXXXX" }) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1.25f)
                                    .testTag("mfs_wallet_number_${spec.accountType.lowercase()}")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { MfsPaymentParser.openMfsAppOrUssd(context, spec.accountType) },
                                modifier = Modifier.heightIn(min = 44.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp)
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp), tint = accent)
                                Spacer(Modifier.width(4.dp))
                                Text(if (strings.isBangla) "অ্যাপ / ${spec.ussdCode}" else "Open / ${spec.ussdCode}", maxLines = 1)
                            }
                            Spacer(Modifier.weight(1f))
                            Button(
                                onClick = {
                                    onSaveWallet(spec.accountType, labelDraft, numberDraft)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = PureWhite),
                                modifier = Modifier
                                    .heightIn(min = 44.dp)
                                    .testTag("mfs_wallet_save_${spec.accountType.lowercase()}")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.save)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CollectMfsOrderPaymentDialog(
    order: OnlineOrderEntity,
    accounts: List<AccountEntity>,
    shopPhone: String,
    useBanglaDigits: Boolean,
    onConfirmCollect: (
        paymentMethod: String,
        trxId: String,
        senderPhone: String,
        accountIdOverride: String?
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var selectedMethod by remember(order.id) {
        mutableStateOf(
            if (MfsPaymentParser.isMfsMethod(order.paymentMethod)) order.paymentMethod else OnlinePaymentMethods.BKASH
        )
    }
    var trxId by remember(order.id) { mutableStateOf(order.mfsTrxId) }
    var senderPhone by remember(order.id) {
        mutableStateOf(order.mfsSenderPhone.ifBlank { order.customerPhone })
    }
    var parsedAmountPaisa by remember { mutableStateOf<Long?>(null) }
    var smsFeedback by remember { mutableStateOf<String?>(null) }
    var copiedWallet by remember { mutableStateOf(false) }

    val spec = MfsPaymentParser.specFor(selectedMethod)
    val matchingAccount = accounts.firstOrNull { !it.archived && it.type == (spec?.accountType ?: AccountTypes.BKASH) }
    val merchantWalletNumber = matchingAccount?.accountNumber?.ifBlank { shopPhone }.orEmpty().ifBlank { shopPhone }
    val accent = mfsBrandColor(selectedMethod)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "${strings.collectMfsPaymentLabel} • ${order.orderNumber}",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SoftGreenAccent
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(order.customerName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = DarkNavy)
                            Text(
                                text = "${order.paymentMethod} • ${order.paymentStatus}",
                                style = MaterialTheme.typography.labelSmall,
                                color = DarkNavy.copy(alpha = 0.75f)
                            )
                        }
                        Text(
                            text = MoneyUtils.formatTaka(order.totalPaisa, useBanglaDigits),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = MonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = EmeraldDark
                        )
                    }
                }

                Text(
                    text = if (strings.isBangla) "মাধ্যম নির্বাচন করুন:" else "Select Receiving Wallet:",
                    style = MaterialTheme.typography.labelMedium
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MfsPaymentParser.PROVIDERS.forEach { provider ->
                        val pColor = mfsBrandColor(provider.paymentMethod)
                        FilterChip(
                            selected = selectedMethod == provider.paymentMethod,
                            onClick = {
                                selectedMethod = provider.paymentMethod
                                copiedWallet = false
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = pColor.copy(alpha = 0.16f),
                                selectedLabelColor = pColor
                            ),
                            label = {
                                Text(
                                    if (strings.isBangla) provider.labelBn else provider.labelEn,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        )
                    }
                }

                // Receiving wallet + copy + USSD/App launcher
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = accent.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = matchingAccount?.name ?: (spec?.labelEn ?: selectedMethod),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accent,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = merchantWalletNumber.ifBlank {
                                        if (strings.isBangla) "ওয়ালেট নম্বর সেট করা নেই" else "No wallet number saved yet"
                                    },
                                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (merchantWalletNumber.isNotBlank()) {
                                OutlinedButton(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(merchantWalletNumber))
                                        copiedWallet = true
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (copiedWallet) "Copied" else "Copy", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { MfsPaymentParser.openMfsAppOrUssd(context, selectedMethod) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp), tint = accent)
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    if (strings.isBangla) "অ্যাপ খুলুন" else "Open App",
                                    maxLines = 1,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    clipboard.getText()?.text?.let { sms ->
                                        val parsed = MfsPaymentParser.parseReceiptSms(sms)
                                        if (parsed.providerMethod != null) {
                                            selectedMethod = parsed.providerMethod
                                        }
                                        if (parsed.trxId.isNotBlank()) trxId = parsed.trxId
                                        if (parsed.senderPhone.isNotBlank()) senderPhone = parsed.senderPhone
                                        parsedAmountPaisa = parsed.amountPaisa
                                        smsFeedback = if (parsed.trxId.isNotBlank() || parsed.amountPaisa != null) {
                                            val amtTxt = parsed.amountPaisa?.let { MoneyUtils.formatTaka(it, useBanglaDigits) } ?: "-"
                                            "SMS parsed: ${parsed.providerMethod ?: selectedMethod} • $amtTxt • TrxID ${parsed.trxId.ifBlank { "?" }}"
                                        } else {
                                            "Could not detect TrxID from clipboard SMS"
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("collect_mfs_paste_sms_button")
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.pasteMfsSmsLabel, maxLines = 1, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }

                if (smsFeedback != null) {
                    val amountMismatch = parsedAmountPaisa != null && parsedAmountPaisa != order.totalPaisa
                    Text(
                        text = if (amountMismatch) {
                            "$smsFeedback (⚠ Amount differs from order total ${MoneyUtils.formatTaka(order.totalPaisa, useBanglaDigits)})"
                        } else {
                            smsFeedback.orEmpty()
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (amountMismatch) ExpenseRed else EmeraldPrimary
                    )
                }

                OutlinedTextField(
                    value = trxId,
                    onValueChange = { trxId = it.uppercase() },
                    label = { Text("${strings.mfsTrxIdLabel} *") },
                    placeholder = { Text("e.g. CJB7X9K2M1") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("collect_mfs_trxid_input")
                )

                OutlinedTextField(
                    value = senderPhone,
                    onValueChange = { senderPhone = it },
                    label = { Text(if (strings.isBangla) "প্রেরকের মোবাইল নম্বর (ঐচ্ছিক)" else "Sender Mobile No. (Optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("collect_mfs_sender_phone_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmCollect(selectedMethod, trxId.trim().uppercase(), senderPhone.trim(), matchingAccount?.id)
                    onDismiss()
                },
                enabled = trxId.trim().length >= 4,
                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = PureWhite),
                modifier = Modifier.testTag("confirm_collect_mfs_button")
            ) {
                Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(strings.verifyAndCreditWalletLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}
