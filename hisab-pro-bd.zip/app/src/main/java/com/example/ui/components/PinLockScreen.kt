package com.example.ui.components

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.core.util.LocalAppStrings
import com.example.ui.theme.DarkNavy
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.PureWhite

@Composable
fun PinLockScreen(
    biometricEnabled: Boolean,
    onVerifyPin: (String) -> Boolean,
    onBiometricUnlocked: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var entered by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun triggerBiometric() {
        val activity = context as? FragmentActivity ?: return
        val bm = BiometricManager.from(context)
        val canAuth = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) return

        val executor = ContextCompat.getMainExecutor(context)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onBiometricUnlocked()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(strings.appTitle)
            .setSubtitle(strings.unlockWithBiometric)
            .setNegativeButtonText(strings.cancel)
            .build()
        prompt.authenticate(info)
    }

    LaunchedEffect(biometricEnabled) {
        if (biometricEnabled) triggerBiometric()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavy)
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(EmeraldPrimary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = "Locked", tint = EmeraldLight, modifier = Modifier.size(30.dp))
            }
            Text(strings.appTitle, style = MaterialTheme.typography.headlineSmall, color = PureWhite)
            Text(strings.unlockWithPin, style = MaterialTheme.typography.bodyMedium, color = PureWhite.copy(alpha = 0.75f))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(6) { idx ->
                    val filled = idx < entered.length
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(if (filled) EmeraldLight else PureWhite.copy(alpha = 0.22f))
                    )
                }
            }

            errorMsg?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }

            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("BIO", "0", "DEL")
            )
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        row.forEach { key ->
                            when (key) {
                                "BIO" -> {
                                    Box(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .clickable(enabled = biometricEnabled) { triggerBiometric() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (biometricEnabled) {
                                            Icon(Icons.Default.Fingerprint, contentDescription = strings.unlockWithBiometric, tint = EmeraldLight, modifier = Modifier.size(28.dp))
                                        }
                                    }
                                }
                                "DEL" -> {
                                    Box(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                if (entered.isNotEmpty()) entered = entered.dropLast(1)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "Backspace", tint = PureWhite)
                                    }
                                }
                                else -> {
                                    Surface(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                if (entered.length < 6) {
                                                    entered += key
                                                    errorMsg = null
                                                    if (entered.length >= 4 && onVerifyPin(entered)) {
                                                        // Unlocked!
                                                    } else if (entered.length == 6 && !onVerifyPin(entered)) {
                                                        errorMsg = if (strings.isBangla) "ভুল পিন, আবার চেষ্টা করুন" else "Incorrect PIN"
                                                        entered = ""
                                                    }
                                                }
                                            }
                                            .testTag("pin_key_$key"),
                                        shape = CircleShape,
                                        color = PureWhite.copy(alpha = 0.1f)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = key,
                                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                                color = PureWhite
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (entered.length in 4..5) {
                Button(
                    onClick = {
                        if (!onVerifyPin(entered)) {
                            errorMsg = if (strings.isBangla) "ভুল পিন, আবার চেষ্টা করুন" else "Incorrect PIN"
                            entered = ""
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("pin_unlock_button")
                ) {
                    Text(strings.confirm)
                }
            }
        }
    }
}
