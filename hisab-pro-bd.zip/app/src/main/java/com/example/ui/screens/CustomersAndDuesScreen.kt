package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.util.ExportUtils
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.*
import com.example.ui.BusinessWorkspaceState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricCard
import com.example.ui.components.TransactionRowCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomersAndDuesScreen(
    state: BusinessWorkspaceState,
    initialSubTab: Int = 0,
    preselectedCustomerId: String? = null,
    onSaveCustomer: (id: String?, name: String, phone: String, address: String, photoUri: String?, category: String, openingDuePaisa: Long) -> Unit,
    onArchiveCustomer: (String, Boolean) -> Unit,
    onRecordDueEntry: (customerId: String, type: String, amountPaisa: Long, accountId: String, affectAccount: Boolean, notes: String, occurredAt: Long, dueDateMillis: Long?) -> Unit,
    onMarkBakiEntryRepaid: (entryId: String, repaymentDateMillis: Long) -> Unit = { _, _ -> },
    onSaveSupplier: (id: String?, name: String, phone: String, address: String, openingPayablePaisa: Long) -> Unit,
    onRecordSupplierPayment: (supplierId: String, amountPaisa: Long, accountId: String, notes: String) -> Unit
) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val context = LocalContext.current

    var subTab by remember(initialSubTab) { mutableIntStateOf(initialSubTab) } // 0 = Baki Khata, 1 = Customers, 2 = Suppliers
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var showArchived by remember { mutableStateOf(false) }

    var showCustomerEditor by remember { mutableStateOf<CustomerEntity?>(null) }
    var openNewCustomer by remember { mutableStateOf(false) }
    var selectedCustomerForStatement by remember { mutableStateOf<CustomerEntity?>(null) }
    var dueActionCustomer by remember { mutableStateOf<Pair<CustomerEntity, String>?>(null) }

    var showSupplierEditor by remember { mutableStateOf<SupplierEntity?>(null) }
    var openNewSupplier by remember { mutableStateOf(false) }
    var paySupplierTarget by remember { mutableStateOf<SupplierEntity?>(null) }
    var selectedSupplierForStatement by remember { mutableStateOf<SupplierEntity?>(null) }

    LaunchedEffect(preselectedCustomerId, state.customers) {
        if (!preselectedCustomerId.isNullOrBlank()) {
            state.customers.firstOrNull { it.id == preselectedCustomerId }?.let {
                selectedCustomerForStatement = it
            }
        }
    }

    val displayedCustomers = remember(state.customers, state.archivedCustomers, searchQuery, selectedCategory, showArchived) {
        val base = if (showArchived) state.archivedCustomers else state.customers
        base.filter { c ->
            val matchesQuery = searchQuery.isBlank() ||
                c.name.contains(searchQuery, ignoreCase = true) ||
                c.phone.contains(searchQuery, ignoreCase = true) ||
                c.customerCode.contains(searchQuery, ignoreCase = true)
            val matchesCat = selectedCategory == "All" || c.category == selectedCategory
            matchesQuery && matchesCat
        }
    }

    val dueCustomers = remember(displayedCustomers) {
        displayedCustomers.sortedByDescending { it.currentDuePaisa }
    }

    val displayedSuppliers = remember(state.suppliers, searchQuery) {
        state.suppliers.filter { s ->
            searchQuery.isBlank() ||
                s.name.contains(searchQuery, ignoreCase = true) ||
                s.phone.contains(searchQuery, ignoreCase = true) ||
                s.supplierCode.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (subTab == 2) openNewSupplier = true else openNewCustomer = true
                },
                containerColor = EmeraldPrimary,
                contentColor = PureWhite,
                modifier = Modifier.testTag("fab_add_party")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Add")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Segmented Top Switcher
            SingleChoiceSegmentedButtonRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                listOf(strings.dueLedgerTitle, strings.customers, strings.suppliers).forEachIndexed { idx, label ->
                    SegmentedButton(
                        selected = subTab == idx,
                        onClick = { subTab = idx },
                        shape = SegmentedButtonDefaults.itemShape(idx, 3),
                        modifier = Modifier.testTag("customers_subtab_$idx")
                    ) {
                        Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(strings.searchPlaceholder) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("party_search_input")
            )

            Spacer(Modifier.height(10.dp))

            when (subTab) {
                // 0: Digital Due Ledger (বাকির খাতা)
                0 -> {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MetricCard(
                                    title = strings.totalReceivable,
                                    amountPaisa = state.dashboard.totalReceivablesPaisa,
                                    useBanglaDigits = useBn,
                                    icon = Icons.Default.MenuBook,
                                    accentColor = WarningAmber,
                                    modifier = Modifier.weight(1f)
                                )
                                MetricCard(
                                    title = strings.totalCollected,
                                    amountPaisa = state.dashboard.totalCollectedDuesPaisa,
                                    useBanglaDigits = useBn,
                                    icon = Icons.Default.CheckCircle,
                                    accentColor = EmeraldPrimary,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (state.dashboard.overdueDuesPaisa > 0L) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = ExpenseSoftRed,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("${strings.overdueAmount} (>30d)", style = MaterialTheme.typography.titleSmall, color = ExpenseRed)
                                        Text(
                                            MoneyUtils.formatTaka(state.dashboard.overdueDuesPaisa, useBn),
                                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                            color = ExpenseRed
                                        )
                                    }
                                }
                            }
                        }

                        if (dueCustomers.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    icon = Icons.Default.MenuBook,
                                    title = strings.noDataYet,
                                    subtitle = if (strings.isBangla) "নতুন ক্রেতা যোগ করে বাকির হিসাব শুরু করুন" else "Add customers to track credit sales and partial payments."
                                )
                            }
                        } else {
                            items(dueCustomers, key = { it.id }) { cust ->
                                val nextDueDateMillis = remember(state.bakiEntries, cust.id) {
                                    state.bakiEntries
                                        .filter {
                                            it.customerId == cust.id &&
                                                it.entryType == BakiEntryTypes.CREDIT &&
                                                !it.isSettled &&
                                                it.promisedRepaymentDateMillis != null
                                        }
                                        .minOfOrNull { it.promisedRepaymentDateMillis!! }
                                }
                                val lastRepaymentDateMillis = remember(state.bakiEntries, cust.id) {
                                    state.bakiEntries
                                        .filter { it.customerId == cust.id && it.actualRepaymentDateMillis != null }
                                        .maxOfOrNull { it.actualRepaymentDateMillis!! }
                                }
                                DueLedgerCustomerCard(
                                    customer = cust,
                                    nextPromisedRepaymentMillis = nextDueDateMillis,
                                    lastRepaymentMillis = lastRepaymentDateMillis,
                                    useBanglaDigits = useBn,
                                    onGiveCredit = { dueActionCustomer = cust to TxTypes.CREDIT_SALE },
                                    onReceivePay = { dueActionCustomer = cust to TxTypes.CUSTOMER_PAYMENT },
                                    onOpenStatement = { selectedCustomerForStatement = cust },
                                    onWhatsApp = {
                                        val bizName = state.activeBusiness?.name ?: "Hisab Pro BD"
                                        val msg = if (strings.isBangla) {
                                            "প্রিয় ${cust.name}, $bizName-এ আপনার বর্তমান বকেয়া ${MoneyUtils.formatTaka(cust.currentDuePaisa, true)}। অনুগ্রহ করে সুবিধামতো পরিশোধ করুন। ধন্যবাদ।"
                                        } else {
                                            "Dear ${cust.name}, your current due balance at $bizName is ${MoneyUtils.formatTaka(cust.currentDuePaisa, false)}. Thank you."
                                        }
                                        ExportUtils.launchWhatsAppReminder(context, cust.phone, msg)
                                    },
                                    onSms = {
                                        val bizName = state.activeBusiness?.name ?: "Hisab Pro BD"
                                        val msg = "Reminder from $bizName: Your due balance is ${MoneyUtils.formatTaka(cust.currentDuePaisa, useBn)}."
                                        ExportUtils.launchSmsReminder(context, cust.phone, msg)
                                    }
                                )
                            }
                        }
                        item { Spacer(Modifier.height(72.dp)) }
                    }
                }

                // 1: Customers Directory
                1 -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedCategory == "All" && !showArchived,
                                    onClick = { selectedCategory = "All"; showArchived = false },
                                    label = { Text("All") }
                                )
                            }
                            items(CustomerCategories.ALL) { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat && !showArchived,
                                    onClick = { selectedCategory = cat; showArchived = false },
                                    label = { Text(cat) }
                                )
                            }
                            item {
                                FilterChip(
                                    selected = showArchived,
                                    onClick = { showArchived = !showArchived },
                                    label = { Text("Archived") }
                                )
                            }
                        }

                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (displayedCustomers.isEmpty()) {
                                item {
                                    EmptyStateCard(
                                        icon = Icons.Default.People,
                                        title = strings.noDataYet,
                                        subtitle = "Tap + to add a customer"
                                    )
                                }
                            } else {
                                items(displayedCustomers, key = { it.id }) { cust ->
                                    CustomerDirectoryCard(
                                        customer = cust,
                                        useBanglaDigits = useBn,
                                        onClick = { selectedCustomerForStatement = cust },
                                        onEdit = { showCustomerEditor = cust },
                                        onToggleArchive = { onArchiveCustomer(cust.id, !cust.archived) }
                                    )
                                }
                            }
                            item { Spacer(Modifier.height(72.dp)) }
                        }
                    }
                }

                // 2: Suppliers
                else -> {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            MetricCard(
                                title = strings.supplierPayables,
                                amountPaisa = state.dashboard.totalPayablesPaisa,
                                useBanglaDigits = useBn,
                                icon = Icons.Default.LocalShipping,
                                accentColor = ExpenseRed
                            )
                        }
                        if (displayedSuppliers.isEmpty()) {
                            item {
                                EmptyStateCard(
                                    icon = Icons.Default.LocalShipping,
                                    title = strings.noDataYet,
                                    subtitle = "Tap + to add a supplier"
                                )
                            }
                        } else {
                            items(displayedSuppliers, key = { it.id }) { sup ->
                                SupplierCard(
                                    supplier = sup,
                                    useBanglaDigits = useBn,
                                    onPay = { paySupplierTarget = sup },
                                    onEdit = { showSupplierEditor = sup },
                                    onOpenStatement = { selectedSupplierForStatement = sup }
                                )
                            }
                        }
                        item { Spacer(Modifier.height(72.dp)) }
                    }
                }
            }
        }
    }

    // Add/Edit Customer Dialog
    if (openNewCustomer || showCustomerEditor != null) {
        CustomerEditorDialog(
            existing = showCustomerEditor,
            onDismiss = { openNewCustomer = false; showCustomerEditor = null },
            onSave = { name, phone, address, photoUri, cat, openingDue ->
                onSaveCustomer(showCustomerEditor?.id, name, phone, address, photoUri, cat, openingDue)
                openNewCustomer = false
                showCustomerEditor = null
            }
        )
    }

    // Due Ledger Action Dialog (Credit Sale / Borrow / Partial or Full Payment / Refund)
    dueActionCustomer?.let { (cust, initialType) ->
        DueLedgerActionDialog(
            customer = cust,
            initialType = initialType,
            accounts = state.accounts,
            useBanglaDigits = useBn,
            onDismiss = { dueActionCustomer = null },
            onSubmit = { type, amountPaisa, accountId, affectAcc, notes, occurredAt, dueDateMillis ->
                onRecordDueEntry(cust.id, type, amountPaisa, accountId, affectAcc, notes, occurredAt, dueDateMillis)
                dueActionCustomer = null
            }
        )
    }

    // Customer Statement Sheet
    selectedCustomerForStatement?.let { cust ->
        val latest = state.customers.firstOrNull { it.id == cust.id } ?: cust
        val custTxs = remember(state.transactions, latest.id) {
            state.transactions.filter { it.customerId == latest.id }
        }
        val custBakiEntries = remember(state.bakiEntries, latest.id) {
            state.bakiEntries.filter { it.customerId == latest.id }
        }
        ModalBottomSheet(onDismissRequest = { selectedCustomerForStatement = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(latest.name, style = MaterialTheme.typography.titleLarge)
                        Text("${latest.customerCode} • ${latest.phone}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedButton(
                        onClick = {
                            val biz = state.activeBusiness ?: return@OutlinedButton
                            val pdf = ExportUtils.generateCustomerStatementPdf(context, biz, latest, custTxs, useBn)
                            ExportUtils.shareFile(context, pdf, "application/pdf", strings.exportPdfStatement)
                        }
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("PDF")
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("Purchases", latest.totalPurchasesPaisa, useBn, Icons.Default.ShoppingBag, EmeraldPrimary, modifier = Modifier.weight(1f))
                    MetricCard("Payments", latest.totalPaymentsPaisa, useBn, Icons.Default.Payments, InfoBlue, modifier = Modifier.weight(1f))
                }
                MetricCard("Current Due", latest.currentDuePaisa, useBn, Icons.Default.MenuBook, WarningAmber)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            selectedCustomerForStatement = null
                            dueActionCustomer = latest to TxTypes.CREDIT_SALE
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(strings.newCreditSale) }
                    FilledTonalButton(
                        onClick = {
                            selectedCustomerForStatement = null
                            dueActionCustomer = latest to TxTypes.CUSTOMER_PAYMENT
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(strings.recordPayment) }
                }

                Text("Statement History (${custTxs.size})", style = MaterialTheme.typography.titleMedium)
                LazyColumn(
                    modifier = Modifier.heightIn(max = 280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (custBakiEntries.isNotEmpty()) {
                        item {
                            Text(strings.dueLedgerTitle, style = MaterialTheme.typography.labelLarge, color = EmeraldPrimary)
                        }
                        items(custBakiEntries, key = { "bk_${it.id}" }) { bk ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(
                                            text = if (bk.entryType == BakiEntryTypes.REPAYMENT) strings.recordPayment else strings.newCreditSale,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = MoneyUtils.formatDhakaDate(bk.entryDateMillis, useBn),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        bk.promisedRepaymentDateMillis?.let { dueAt ->
                                            val isOverdue = !bk.isSettled && dueAt < System.currentTimeMillis()
                                            Text(
                                                text = "${strings.promisedRepaymentLabel}: ${MoneyUtils.formatDhakaDate(dueAt, useBn)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (isOverdue) ExpenseRed else WarningAmber
                                            )
                                        }
                                        bk.actualRepaymentDateMillis?.let { repaidAt ->
                                            Text(
                                                text = "${strings.repaymentDateLabel}: ${MoneyUtils.formatDhakaDate(repaidAt, useBn)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = EmeraldPrimary
                                            )
                                        }
                                    }
                                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = MoneyUtils.formatTaka(bk.amountPaisa, useBn),
                                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                            color = if (bk.entryType == BakiEntryTypes.REPAYMENT) EmeraldPrimary else WarningAmber
                                        )
                                        if (bk.entryType == BakiEntryTypes.CREDIT && !bk.isSettled) {
                                            OutlinedButton(
                                                onClick = { onMarkBakiEntryRepaid(bk.id, System.currentTimeMillis()) },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                modifier = Modifier.height(30.dp)
                                            ) {
                                                Text(strings.markRepaidLabel, style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    items(custTxs, key = { it.id }) { tx ->
                        TransactionRowCard(tx = tx, useBanglaDigits = useBn, onClick = {})
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // Supplier Editor
    if (openNewSupplier || showSupplierEditor != null) {
        SupplierEditorDialog(
            existing = showSupplierEditor,
            onDismiss = { openNewSupplier = false; showSupplierEditor = null },
            onSave = { name, phone, address, openingPay ->
                onSaveSupplier(showSupplierEditor?.id, name, phone, address, openingPay)
                openNewSupplier = false
                showSupplierEditor = null
            }
        )
    }

    // Supplier Payment Dialog
    paySupplierTarget?.let { sup ->
        SupplierPaymentDialog(
            supplier = sup,
            accounts = state.accounts,
            useBanglaDigits = useBn,
            onDismiss = { paySupplierTarget = null },
            onConfirm = { amount, accId, notes ->
                onRecordSupplierPayment(sup.id, amount, accId, notes)
                paySupplierTarget = null
            }
        )
    }

    selectedSupplierForStatement?.let { sup ->
        val latest = state.suppliers.firstOrNull { it.id == sup.id } ?: sup
        val supTxs = remember(state.transactions, latest.id) {
            state.transactions.filter { it.supplierId == latest.id }
        }
        ModalBottomSheet(onDismissRequest = { selectedSupplierForStatement = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("${latest.name} (${latest.supplierCode})", style = MaterialTheme.typography.titleLarge)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("Purchases", latest.totalPurchasesPaisa, useBn, Icons.Default.ShoppingCart, InfoBlue, modifier = Modifier.weight(1f))
                    MetricCard("Payable", latest.currentPayablePaisa, useBn, Icons.Default.CallMade, ExpenseRed, modifier = Modifier.weight(1f))
                }
                LazyColumn(
                    modifier = Modifier.heightIn(max = 280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(supTxs, key = { it.id }) { tx ->
                        TransactionRowCard(tx = tx, useBanglaDigits = useBn, onClick = {})
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun DueLedgerCustomerCard(
    customer: CustomerEntity,
    nextPromisedRepaymentMillis: Long? = null,
    lastRepaymentMillis: Long? = null,
    useBanglaDigits: Boolean,
    onGiveCredit: () -> Unit,
    onReceivePay: () -> Unit,
    onOpenStatement: () -> Unit,
    onWhatsApp: () -> Unit,
    onSms: () -> Unit
) {
    val strings = LocalAppStrings.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenStatement),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CustomerAvatar(customer)
                Column(modifier = Modifier.weight(1f)) {
                    Text(customer.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "${customer.customerCode} • ${customer.phone.ifBlank { customer.category }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (customer.currentDuePaisa > 0L && nextPromisedRepaymentMillis != null) {
                        val isOverdue = nextPromisedRepaymentMillis < System.currentTimeMillis()
                        Text(
                            text = "${strings.promisedRepaymentLabel}: ${MoneyUtils.formatDhakaDate(nextPromisedRepaymentMillis, useBanglaDigits)}" +
                                if (isOverdue) " (${strings.overdueLabel})" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isOverdue) ExpenseRed else WarningAmber
                        )
                    } else if (lastRepaymentMillis != null) {
                        Text(
                            text = "${strings.repaymentDateLabel}: ${MoneyUtils.formatDhakaDate(lastRepaymentMillis, useBanglaDigits)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = MoneyUtils.formatTaka(customer.currentDuePaisa, useBanglaDigits),
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                        color = if (customer.currentDuePaisa > 0) WarningAmber else EmeraldPrimary
                    )
                    Text(
                        text = if (customer.currentDuePaisa > 0) "Due" else strings.settledLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = onGiveCredit,
                    modifier = Modifier.weight(1f).height(40.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text(strings.newCreditSale, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                }
                Button(
                    onClick = onReceivePay,
                    modifier = Modifier.weight(1f).height(40.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text(strings.recordPayment, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                }
                if (customer.currentDuePaisa > 0 && customer.phone.isNotBlank()) {
                    IconButton(onClick = onWhatsApp) {
                        Icon(Icons.Default.Chat, contentDescription = strings.sendWhatsAppReminder, tint = EmeraldPrimary)
                    }
                    IconButton(onClick = onSms) {
                        Icon(Icons.Default.Sms, contentDescription = strings.sendSmsReminder, tint = InfoBlue)
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerDirectoryCard(
    customer: CustomerEntity,
    useBanglaDigits: Boolean,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onToggleArchive: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CustomerAvatar(customer)
            Column(modifier = Modifier.weight(1f)) {
                Text(customer.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${customer.customerCode} • ${customer.category} • ${customer.phone.ifBlank { "-" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = MoneyUtils.formatTaka(customer.currentDuePaisa, useBanglaDigits),
                style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                color = if (customer.currentDuePaisa > 0) WarningAmber else EmeraldPrimary
            )
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Edit")
            }
            IconButton(onClick = onToggleArchive) {
                Icon(if (customer.archived) Icons.Default.Unarchive else Icons.Default.Archive, contentDescription = "Archive")
            }
        }
    }
}

@Composable
private fun CustomerAvatar(customer: CustomerEntity) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(SoftGreenAccent),
        contentAlignment = Alignment.Center
    ) {
        if (!customer.photoUri.isNullOrBlank()) {
            AsyncImage(
                model = customer.photoUri,
                contentDescription = customer.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Text(
                text = customer.name.take(1).uppercase(),
                style = MaterialTheme.typography.titleMedium,
                color = EmeraldPrimary
            )
        }
    }
}

@Composable
private fun SupplierCard(
    supplier: SupplierEntity,
    useBanglaDigits: Boolean,
    onPay: () -> Unit,
    onEdit: () -> Unit,
    onOpenStatement: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenStatement),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(supplier.name, style = MaterialTheme.typography.titleMedium)
                    Text("${supplier.supplierCode} • ${supplier.phone.ifBlank { "-" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    text = MoneyUtils.formatTaka(supplier.currentPayablePaisa, useBanglaDigits),
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                    color = if (supplier.currentPayablePaisa > 0) ExpenseRed else EmeraldPrimary
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPay, modifier = Modifier.weight(1f).height(40.dp)) {
                    Text("Pay Supplier")
                }
                OutlinedButton(onClick = onEdit, modifier = Modifier.height(40.dp)) {
                    Text("Edit")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomerEditorDialog(
    existing: CustomerEntity?,
    onDismiss: () -> Unit,
    onSave: (name: String, phone: String, address: String, photoUri: String?, category: String, openingDuePaisa: Long) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var photoUri by remember { mutableStateOf(existing?.photoUri) }
    var category by remember { mutableStateOf(existing?.category ?: "Regular") }
    var openingDue by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) photoUri = uri.toString()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add Customer" else "Edit Customer") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (photoUri == null) "Photo (Optional)" else "Photo Selected")
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Customer Name *") }, singleLine = true, modifier = Modifier.testTag("customer_name_input"))
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone (+880)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.testTag("customer_phone_input"))
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, singleLine = true)
                Text("Category", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CustomerCategories.ALL.forEach { cat ->
                        FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                    }
                }
                if (existing == null) {
                    OutlinedTextField(
                        value = openingDue,
                        onValueChange = { openingDue = it },
                        label = { Text("Opening Due Balance (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name, MoneyUtils.formatBdPhone(phone), address, photoUri, category, MoneyUtils.parseTakaToPaisa(openingDue))
                    }
                },
                modifier = Modifier.testTag("save_customer_button")
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DueLedgerActionDialog(
    customer: CustomerEntity,
    initialType: String,
    accounts: List<AccountEntity>,
    useBanglaDigits: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (type: String, amountPaisa: Long, accountId: String, affectAccount: Boolean, notes: String, occurredAt: Long, dueDateMillis: Long?) -> Unit
) {
    val strings = LocalAppStrings.current
    var selectedType by remember { mutableStateOf(initialType) }
    var amountText by remember { mutableStateOf("") }
    var selectedAccount by remember { mutableStateOf(accounts.firstOrNull()) }
    var affectAccount by remember { mutableStateOf(initialType != TxTypes.CREDIT_SALE) }
    var notes by remember { mutableStateOf("") }
    var promisedRepaymentDateMillis by remember { mutableStateOf<Long?>(null) }
    var repaymentDateMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }

    val typeOptions = listOf(
        TxTypes.CREDIT_SALE to "Credit Sale",
        TxTypes.CUSTOMER_PAYMENT to "Receive Pay",
        TxTypes.CUSTOMER_CREDIT_ADVANCE to "Money Lent",
        TxTypes.CUSTOMER_REFUND to "Refund"
    )
    val dayMillis = 24L * 60L * 60L * 1000L

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${customer.name} • Due: ${MoneyUtils.formatTaka(customer.currentDuePaisa, useBanglaDigits)}") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    typeOptions.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            pair.forEach { (type, label) ->
                                FilterChip(
                                    selected = selectedType == type,
                                    onClick = {
                                        selectedType = type
                                        affectAccount = type != TxTypes.CREDIT_SALE
                                    },
                                    label = { Text(label) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (৳)") },
                    prefix = { Text("৳ ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("due_amount_input")
                )

                if (selectedType == TxTypes.CUSTOMER_PAYMENT && customer.currentDuePaisa > 0) {
                    TextButton(onClick = { amountText = MoneyUtils.paisaToInputString(customer.currentDuePaisa) }) {
                        Text("Pay Full Due (${MoneyUtils.formatTaka(customer.currentDuePaisa, useBanglaDigits)})")
                    }
                }

                if (selectedType == TxTypes.CUSTOMER_PAYMENT) {
                    Text(
                        text = "${strings.repaymentDateLabel}: ${MoneyUtils.formatDhakaDate(repaymentDateMillis, useBanglaDigits)}",
                        style = MaterialTheme.typography.labelMedium
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = false,
                            onClick = { repaymentDateMillis = System.currentTimeMillis() },
                            label = { Text("Today") }
                        )
                        FilterChip(
                            selected = false,
                            onClick = { repaymentDateMillis = System.currentTimeMillis() - dayMillis },
                            label = { Text("Yesterday") }
                        )
                        OutlinedButton(
                            onClick = { showDatePicker = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("pick_repayment_date_button")
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Pick Date")
                        }
                    }
                } else {
                    Text(
                        text = promisedRepaymentDateMillis?.let {
                            "${strings.promisedRepaymentLabel}: ${MoneyUtils.formatDhakaDate(it, useBanglaDigits)}"
                        } ?: "${strings.promisedRepaymentLabel} (Optional)",
                        style = MaterialTheme.typography.labelMedium
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(7, 15, 30).forEach { days ->
                            FilterChip(
                                selected = false,
                                onClick = { promisedRepaymentDateMillis = System.currentTimeMillis() + days * dayMillis },
                                label = { Text("+${days}d") }
                            )
                        }
                        OutlinedButton(
                            onClick = { showDatePicker = true },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("pick_promised_date_button")
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Pick Date")
                        }
                        if (promisedRepaymentDateMillis != null) {
                            TextButton(onClick = { promisedRepaymentDateMillis = null }) { Text("Clear") }
                        }
                    }
                }

                if (selectedType == TxTypes.CUSTOMER_CREDIT_ADVANCE) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Deduct from Cash/Account", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = affectAccount, onCheckedChange = { affectAccount = it })
                    }
                }

                if (selectedType != TxTypes.CREDIT_SALE && accounts.isNotEmpty()) {
                    Text("Account", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(accounts) { acc ->
                            FilterChip(
                                selected = selectedAccount?.id == acc.id,
                                onClick = { selectedAccount = acc },
                                label = { Text(acc.name) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paisa = MoneyUtils.parseTakaToPaisa(amountText)
                    val accId = selectedAccount?.id ?: accounts.firstOrNull()?.id.orEmpty()
                    if (paisa > 0L && accId.isNotBlank()) {
                        val occurred = if (selectedType == TxTypes.CUSTOMER_PAYMENT) {
                            repaymentDateMillis
                        } else {
                            System.currentTimeMillis()
                        }
                        val promised = if (selectedType == TxTypes.CUSTOMER_PAYMENT) {
                            null
                        } else {
                            promisedRepaymentDateMillis
                        }
                        onSubmit(selectedType, paisa, accId, affectAccount, notes, occurred, promised)
                    }
                },
                modifier = Modifier.testTag("due_submit_button")
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )

    if (showDatePicker) {
        val initialMillis = if (selectedType == TxTypes.CUSTOMER_PAYMENT) {
            repaymentDateMillis
        } else {
            promisedRepaymentDateMillis ?: (System.currentTimeMillis() + 7 * dayMillis)
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { picked ->
                        if (selectedType == TxTypes.CUSTOMER_PAYMENT) {
                            repaymentDateMillis = picked
                        } else {
                            promisedRepaymentDateMillis = picked
                        }
                    }
                    showDatePicker = false
                }) { Text(strings.confirm) }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text(strings.cancel) }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
private fun SupplierEditorDialog(
    existing: SupplierEntity?,
    onDismiss: () -> Unit,
    onSave: (name: String, phone: String, address: String, openingPayablePaisa: Long) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var address by remember { mutableStateOf(existing?.address ?: "") }
    var openingPay by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add Supplier" else "Edit Supplier") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Supplier Name *") }, singleLine = true)
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone (+880)") }, singleLine = true)
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, singleLine = true)
                if (existing == null) {
                    OutlinedTextField(value = openingPay, onValueChange = { openingPay = it }, label = { Text("Opening Payable (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    onSave(name, MoneyUtils.formatBdPhone(phone), address, MoneyUtils.parseTakaToPaisa(openingPay))
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SupplierPaymentDialog(
    supplier: SupplierEntity,
    accounts: List<AccountEntity>,
    useBanglaDigits: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (amountPaisa: Long, accountId: String, notes: String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var selectedAccount by remember { mutableStateOf(accounts.firstOrNull()) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pay ${supplier.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Payable: ${MoneyUtils.formatTaka(supplier.currentPayablePaisa, useBanglaDigits)}", color = ExpenseRed)
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Payment Amount (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(accounts) { acc ->
                        FilterChip(selected = selectedAccount?.id == acc.id, onClick = { selectedAccount = acc }, label = { Text(acc.name) })
                    }
                }
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") })
            }
        },
        confirmButton = {
            Button(onClick = {
                val paisa = MoneyUtils.parseTakaToPaisa(amountText)
                val accId = selectedAccount?.id ?: accounts.firstOrNull()?.id.orEmpty()
                if (paisa > 0L && accId.isNotBlank()) onConfirm(paisa, accId, notes)
            }) { Text("Pay") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
