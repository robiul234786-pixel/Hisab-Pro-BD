package com.example.workers

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.HisabProApplication
import com.example.R
import com.example.data.local.AppNotificationEntity
import com.example.data.local.HisabDatabase
import com.example.data.local.UserPreferences
import com.example.data.repository.AccountingRepository
import kotlinx.coroutines.flow.first
import java.io.File

class ScheduledBackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val db = HisabDatabase.getInstance(applicationContext)
        val repo = AccountingRepository(db)
        val prefs = UserPreferences(applicationContext)
        val settings = prefs.settingsFlow.first()

        if (!settings.onboardingCompleted) return Result.success()

        try {
            if (settings.autoBackupEnabled) {
                val json = repo.exportLocalBackupJson()
                val backupDir = File(applicationContext.filesDir, "backups")
                if (!backupDir.exists()) backupDir.mkdirs()
                File(backupDir, "hisab_auto_backup.json").writeText(json, Charsets.UTF_8)
                val now = System.currentTimeMillis()
                prefs.updateLastLocalBackup(now)

                if (settings.activeBusinessId.isNotBlank()) {
                    db.notificationDao().insert(
                        AppNotificationEntity(
                            businessId = settings.activeBusinessId,
                            type = "BACKUP_REMINDER",
                            title = "Automatic Backup Saved",
                            message = "Encrypted-ready local backup completed safely on device.",
                            createdAt = now
                        )
                    )
                }
            }

            if (settings.activeBusinessId.isNotBlank()) {
                val bizId = settings.activeBusinessId
                val products = db.productDao().getProductsSync(bizId)
                val lowStockCount = products.count { it.stockMilliUnits <= it.lowStockThresholdMilliUnits }
                val customersWithDue = db.customerDao().getCustomersSync(bizId).count { it.currentDuePaisa > 0L }

                // Privacy-safe system notification: never expose sensitive financial balances on lock screen
                if ((settings.lowStockAlertEnabled && lowStockCount > 0) ||
                    (settings.dueReminderEnabled && customersWithDue > 0)
                ) {
                    postPrivacySafeNotification(
                        title = "Hisab Pro BD Daily Reminder",
                        body = "You have business updates ready to review inside the app."
                    )
                }
            }
            return Result.success()
        } catch (_: Exception) {
            return Result.retry()
        }
    }

    private fun postPrivacySafeNotification(title: String, body: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                applicationContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return
        val notification = NotificationCompat.Builder(applicationContext, HisabProApplication.CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .build()
        manager.notify(1001, notification)
    }
}
