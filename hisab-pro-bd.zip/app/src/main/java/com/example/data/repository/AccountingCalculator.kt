package com.example.data.repository

import com.example.core.util.MoneyUtils
import com.example.data.local.*
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale

data class DashboardMetrics(
    val totalSalesPaisa: Long = 0L,
    val totalCashReceivedPaisa: Long = 0L,
    val totalReceivablesPaisa: Long = 0L,
    val totalPayablesPaisa: Long = 0L,
    val totalIncomePaisa: Long = 0L,
    val totalExpensesPaisa: Long = 0L,
    val grossProfitPaisa: Long = 0L,
    val netProfitPaisa: Long = 0L,
    val isEstimatedProfit: Boolean = false,
    val cashBalancePaisa: Long = 0L,
    val bankBalancePaisa: Long = 0L,
    val mfsBalancePaisa: Long = 0L,
    val todaysSalesPaisa: Long = 0L,
    val todaysExpensesPaisa: Long = 0L,
    val totalCollectedDuesPaisa: Long = 0L,
    val overdueDuesPaisa: Long = 0L
)

data class MonthlyChartPoint(
    val label: String,
    val salesPaisa: Long,
    val incomePaisa: Long,
    val expensePaisa: Long
)

data class ProfitAndLossReport(
    val grossSalesPaisa: Long = 0L,
    val salesReturnsPaisa: Long = 0L,
    val netSalesPaisa: Long = 0L,
    val cogsPaisa: Long = 0L,
    val grossProfitPaisa: Long = 0L,
    val otherIncomePaisa: Long = 0L,
    val operatingExpensesPaisa: Long = 0L,
    val netProfitPaisa: Long = 0L,
    val totalCashInPaisa: Long = 0L,
    val totalCashOutPaisa: Long = 0L,
    val isEstimated: Boolean = false
)

object AccountingCalculator {

    fun computeDashboard(
        accounts: List<AccountEntity>,
        customers: List<CustomerEntity>,
        suppliers: List<SupplierEntity>,
        transactions: List<AccountingTransactionEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): DashboardMetrics {
        val activeTxs = transactions.filter { !it.isReversed && it.type != TxTypes.REVERSAL }
        val (todayStart, todayEnd) = MoneyUtils.dhakaTodayBounds(nowMillis)
        val overdueCutoff = nowMillis - (30L * 24L * 60L * 60L * 1000L)

        var grossSales = 0L
        var salesReturns = 0L
        var cogs = 0L
        var otherIncome = 0L
        var expenses = 0L
        var cashReceived = 0L
        var todaysSales = 0L
        var todaysExpenses = 0L
        var collectedDues = 0L
        var estimated = false

        for (tx in activeTxs) {
            val isToday = tx.occurredAt in todayStart..todayEnd
            when (tx.type) {
                TxTypes.SALE, TxTypes.CREDIT_SALE -> {
                    grossSales += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa
                    if (tx.hasEstimatedCost) estimated = true
                    if (tx.cashFlowDeltaPaisa > 0L) cashReceived += tx.cashFlowDeltaPaisa
                    if (isToday) todaysSales += tx.totalAmountPaisa
                }
                TxTypes.SALE_RETURN -> {
                    salesReturns += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa // negative for return
                }
                TxTypes.CUSTOMER_PAYMENT -> {
                    if (tx.cashFlowDeltaPaisa > 0L) {
                        cashReceived += tx.cashFlowDeltaPaisa
                        collectedDues += tx.cashFlowDeltaPaisa
                    }
                }
                TxTypes.INCOME -> {
                    otherIncome += tx.totalAmountPaisa
                    if (tx.cashFlowDeltaPaisa > 0L) cashReceived += tx.cashFlowDeltaPaisa
                }
                TxTypes.EXPENSE -> {
                    expenses += tx.totalAmountPaisa
                    if (isToday) todaysExpenses += tx.totalAmountPaisa
                }
            }
        }

        val netSales = grossSales - salesReturns
        val grossProfit = netSales - cogs
        val totalIncome = netSales + otherIncome
        val netProfit = grossProfit + otherIncome - expenses

        val receivables = customers.sumOf { it.currentDuePaisa.coerceAtLeast(0L) }
        val overdue = customers.filter {
            it.currentDuePaisa > 0L && (it.overdueSinceMillis ?: Long.MAX_VALUE) < overdueCutoff
        }.sumOf { it.currentDuePaisa }
        val payables = suppliers.sumOf { it.currentPayablePaisa.coerceAtLeast(0L) }

        val cashBal = accounts.filter { it.type == AccountTypes.CASH }.sumOf { it.currentBalancePaisa }
        val bankBal = accounts.filter { it.type == AccountTypes.BANK }.sumOf { it.currentBalancePaisa }
        val mfsBal = accounts.filter {
            it.type == AccountTypes.BKASH || it.type == AccountTypes.NAGAD || it.type == AccountTypes.ROCKET || it.type == AccountTypes.CUSTOM
        }.sumOf { it.currentBalancePaisa }

        return DashboardMetrics(
            totalSalesPaisa = netSales,
            totalCashReceivedPaisa = cashReceived,
            totalReceivablesPaisa = receivables,
            totalPayablesPaisa = payables,
            totalIncomePaisa = totalIncome,
            totalExpensesPaisa = expenses,
            grossProfitPaisa = grossProfit,
            netProfitPaisa = netProfit,
            isEstimatedProfit = estimated,
            cashBalancePaisa = cashBal,
            bankBalancePaisa = bankBal,
            mfsBalancePaisa = mfsBal,
            todaysSalesPaisa = todaysSales,
            todaysExpensesPaisa = todaysExpenses,
            totalCollectedDuesPaisa = collectedDues,
            overdueDuesPaisa = overdue
        )
    }

    fun computeProfitAndLoss(
        transactions: List<AccountingTransactionEntity>,
        startMillis: Long,
        endMillis: Long
    ): ProfitAndLossReport {
        val active = transactions.filter {
            !it.isReversed && it.type != TxTypes.REVERSAL && it.occurredAt in startMillis..endMillis
        }
        var grossSales = 0L
        var salesReturns = 0L
        var cogs = 0L
        var otherIncome = 0L
        var expenses = 0L
        var cashIn = 0L
        var cashOut = 0L
        var estimated = false

        for (tx in active) {
            if (tx.type != TxTypes.ACCOUNT_TRANSFER) {
                if (tx.cashFlowDeltaPaisa > 0L) cashIn += tx.cashFlowDeltaPaisa
                if (tx.cashFlowDeltaPaisa < 0L) cashOut += -tx.cashFlowDeltaPaisa
            }
            when (tx.type) {
                TxTypes.SALE, TxTypes.CREDIT_SALE -> {
                    grossSales += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa
                    if (tx.hasEstimatedCost) estimated = true
                }
                TxTypes.SALE_RETURN -> {
                    salesReturns += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa
                }
                TxTypes.INCOME -> otherIncome += tx.totalAmountPaisa
                TxTypes.EXPENSE -> expenses += tx.totalAmountPaisa
            }
        }
        val netSales = grossSales - salesReturns
        val grossProfit = netSales - cogs
        val netProfit = grossProfit + otherIncome - expenses

        return ProfitAndLossReport(
            grossSalesPaisa = grossSales,
            salesReturnsPaisa = salesReturns,
            netSalesPaisa = netSales,
            cogsPaisa = cogs,
            grossProfitPaisa = grossProfit,
            otherIncomePaisa = otherIncome,
            operatingExpensesPaisa = expenses,
            netProfitPaisa = netProfit,
            totalCashInPaisa = cashIn,
            totalCashOutPaisa = cashOut,
            isEstimated = estimated
        )
    }

    fun computeLast6MonthsChart(
        transactions: List<AccountingTransactionEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): List<MonthlyChartPoint> {
        val today = Instant.ofEpochMilli(nowMillis).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate()
        val active = transactions.filter { !it.isReversed && it.type != TxTypes.REVERSAL }
        val fmt = DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH)

        return (5 downTo 0).map { offset ->
            val monthDate = today.minusMonths(offset.toLong()).withDayOfMonth(1)
            val start = monthDate.atStartOfDay(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli()
            val end = monthDate.plusMonths(1).atStartOfDay(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli() - 1L
            val monthTxs = active.filter { it.occurredAt in start..end }
            val sales = monthTxs.filter { it.type == TxTypes.SALE || it.type == TxTypes.CREDIT_SALE }
                .sumOf { it.totalAmountPaisa } -
                monthTxs.filter { it.type == TxTypes.SALE_RETURN }.sumOf { it.totalAmountPaisa }
            val income = sales + monthTxs.filter { it.type == TxTypes.INCOME }.sumOf { it.totalAmountPaisa }
            val expense = monthTxs.filter { it.type == TxTypes.EXPENSE }.sumOf { it.totalAmountPaisa }
            MonthlyChartPoint(
                label = monthDate.format(fmt),
                salesPaisa = sales.coerceAtLeast(0L),
                incomePaisa = income.coerceAtLeast(0L),
                expensePaisa = expense.coerceAtLeast(0L)
            )
        }
    }
}
