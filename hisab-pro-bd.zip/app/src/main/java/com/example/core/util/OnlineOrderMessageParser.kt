package com.example.core.util

import com.example.data.local.OnlinePaymentMethods
import com.example.data.local.ProductEntity
import org.json.JSONObject
import kotlin.math.roundToLong

data class ParsedOrderLine(
    val product: ProductEntity,
    val quantityMilliUnits: Long
)

data class ParsedIncomingOrder(
    val customerName: String = "",
    val customerPhone: String = "",
    val deliveryAddress: String = "",
    val deliveryDistrict: String = "Dhaka",
    val deliveryFeePaisa: Long = 6_000L,
    val paymentMethod: String = OnlinePaymentMethods.COD,
    val promoCode: String = "",
    val mfsTrxId: String = "",
    val mfsSenderPhone: String = "",
    val items: List<ParsedOrderLine> = emptyList(),
    val unmatchedLines: List<String> = emptyList(),
    val isStructuredPayload: Boolean = false
)

/**
 * Parses incoming customer orders copied from the no-app HTML5 Web Storefront,
 * WhatsApp, Facebook Messenger, or SMS into structured [ParsedIncomingOrder] items.
 */
object OnlineOrderMessageParser {

    private const val PAYLOAD_MARKER = "#HISAB_ORDER:"
    private val BD_PHONE_REGEX = Regex("""(?:\+?88)?(01[3-9]\d{8})""")

    fun parse(rawInput: String, catalog: List<ProductEntity>): ParsedIncomingOrder {
        val trimmed = rawInput.trim()
        if (trimmed.isBlank()) return ParsedIncomingOrder()

        val activeCatalog = catalog.filter { !it.archived }
        val markerIdx = trimmed.indexOf(PAYLOAD_MARKER, ignoreCase = true)
        if (markerIdx >= 0) {
            val jsonCandidate = extractJsonObject(trimmed.substring(markerIdx + PAYLOAD_MARKER.length))
            if (jsonCandidate != null) {
                parseStructuredJson(jsonCandidate, activeCatalog)?.let { return it }
            }
        }

        return parsePlainText(trimmed, activeCatalog)
    }

    private fun extractJsonObject(afterMarker: String): String? {
        val start = afterMarker.indexOf('{')
        if (start < 0) return null
        var depth = 0
        var inString = false
        var escaped = false
        for (i in start until afterMarker.length) {
            val ch = afterMarker[i]
            if (escaped) {
                escaped = false
                continue
            }
            if (ch == '\\') {
                escaped = true
                continue
            }
            if (ch == '"') {
                inString = !inString
                continue
            }
            if (!inString) {
                if (ch == '{') depth++
                else if (ch == '}') {
                    depth--
                    if (depth == 0) return afterMarker.substring(start, i + 1)
                }
            }
        }
        return null
    }

    private fun parseStructuredJson(jsonText: String, catalog: List<ProductEntity>): ParsedIncomingOrder? {
        return try {
            val obj = JSONObject(jsonText)
            val name = obj.optString("c", "").trim()
            val phone = obj.optString("p", "").trim()
            val addr = obj.optString("a", "").trim()
            val district = obj.optString("z", "Dhaka").ifBlank { "Dhaka" }
            val delivTaka = obj.optDouble("d", 60.0).coerceAtLeast(0.0)
            val delivPaisa = (delivTaka * 100.0).roundToLong()
            val pay = normalizePaymentMethod(obj.optString("pm", OnlinePaymentMethods.COD))
            val promo = obj.optString("pc", "").trim().uppercase()
            val trxId = obj.optString("trx", "").trim().uppercase()
            val senderPhone = obj.optString("sp", "").trim()

            val itemsArr = obj.optJSONArray("items")
            val matchedMap = linkedMapOf<String, MutablePair>()
            val unmatched = mutableListOf<String>()

            if (itemsArr != null) {
                for (i in 0 until itemsArr.length()) {
                    val itemObj = itemsArr.optJSONObject(i) ?: continue
                    val id = itemObj.optString("id", "").trim()
                    val itemName = itemObj.optString("n", "").trim()
                    val qtyUnits = itemObj.optDouble("q", 1.0).coerceAtLeast(0.001)
                    val qtyMilli = (qtyUnits * 1000.0).roundToLong().coerceAtLeast(1L)

                    val product = catalog.firstOrNull { it.id == id }
                        ?: findBestProductMatch(itemName, catalog)
                    if (product != null) {
                        val existing = matchedMap[product.id]
                        if (existing == null) {
                            matchedMap[product.id] = MutablePair(product, qtyMilli)
                        } else {
                            existing.qty += qtyMilli
                        }
                    } else if (itemName.isNotBlank()) {
                        unmatched += "$itemName × $qtyUnits"
                    }
                }
            }

            ParsedIncomingOrder(
                customerName = name,
                customerPhone = phone,
                deliveryAddress = addr,
                deliveryDistrict = district,
                deliveryFeePaisa = delivPaisa,
                paymentMethod = pay,
                promoCode = promo,
                mfsTrxId = trxId,
                mfsSenderPhone = senderPhone,
                items = matchedMap.values.map { ParsedOrderLine(it.product, it.qty) },
                unmatchedLines = unmatched,
                isStructuredPayload = true
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun parsePlainText(rawText: String, catalog: List<ProductEntity>): ParsedIncomingOrder {
        val normalized = MoneyUtils.normalizeDigits(rawText)
        val lines = normalized.lines().map { it.trim() }.filter { it.isNotBlank() }

        var name = ""
        var phone = BD_PHONE_REGEX.find(normalized.replace(" ", "").replace("-", ""))?.groupValues?.getOrNull(1).orEmpty()
        var addr = ""
        var district = when {
            normalized.contains("Pickup", ignoreCase = true) || normalized.contains("দোকান থেকে") -> "Pickup"
            normalized.contains("Outside Dhaka", ignoreCase = true) || normalized.contains("ঢাকার বাইরে") -> "Outside Dhaka"
            else -> "Dhaka"
        }
        var delivPaisa = when (district) {
            "Pickup" -> 0L
            "Outside Dhaka" -> 12_000L
            else -> 6_000L
        }
        var promo = ""
        val receipt = MfsPaymentParser.parseReceiptSms(rawText)
        val pay = receipt.providerMethod ?: normalizePaymentMethod(normalized)
        var trxId = receipt.trxId
        var senderMfs = receipt.senderPhone

        val matchedMap = linkedMapOf<String, MutablePair>()
        val unmatched = mutableListOf<String>()

        for (line in lines) {
            val lower = line.lowercase()
            when {
                lower.startsWith("name:") || lower.startsWith("customer:") || line.startsWith("নাম:") || line.startsWith("ক্রেতা:") -> {
                    name = line.substringAfter(':').trim()
                    continue
                }
                lower.startsWith("phone:") || lower.startsWith("mobile:") || line.startsWith("ফোন:") || line.startsWith("মোবাইল:") -> {
                    val valPart = line.substringAfter(':').trim()
                    phone = BD_PHONE_REGEX.find(valPart.replace(" ", "").replace("-", ""))?.groupValues?.getOrNull(1) ?: valPart
                    continue
                }
                lower.startsWith("trxid:") || lower.startsWith("trx id:") || lower.startsWith("txnid:") -> {
                    if (trxId.isBlank()) trxId = line.substringAfter(':').trim().uppercase()
                    continue
                }
                lower.startsWith("sender:") -> {
                    if (senderMfs.isBlank()) senderMfs = line.substringAfter(':').trim()
                    continue
                }
                lower.startsWith("address:") || lower.startsWith("addr:") || line.startsWith("ঠিকানা:") -> {
                    val rawAddr = line.substringAfter(':').trim()
                    val parenMatch = Regex("""\(([^)]+)\)$""").find(rawAddr)
                    if (parenMatch != null) {
                        val zoneCandidate = parenMatch.groupValues[1].trim()
                        if (zoneCandidate.equals("Dhaka", true) || zoneCandidate.equals("Outside Dhaka", true) || zoneCandidate.equals("Pickup", true)) {
                            district = zoneCandidate
                        }
                        addr = rawAddr.removeRange(parenMatch.range).trim()
                    } else {
                        addr = rawAddr
                    }
                    continue
                }
                lower.startsWith("delivery:") || line.startsWith("ডেলিভারি:") -> {
                    val num = Regex("""(\d+(?:\.\d+)?)""").find(line)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                    if (num != null) delivPaisa = (num * 100.0).roundToLong()
                    continue
                }
                lower.startsWith("promo:") || lower.startsWith("coupon:") -> {
                    promo = line.substringAfter(':').trim().uppercase()
                    continue
                }
                lower.startsWith("payment:") || lower.startsWith("pay:") ||
                    lower.startsWith("total") || lower.startsWith("*total") ||
                    lower.startsWith("discount") || line.contains("New Order", ignoreCase = true) -> {
                    continue
                }
            }

            if (promo.isBlank()) {
                when {
                    normalized.contains("SAVE50", ignoreCase = true) -> promo = "SAVE50"
                    normalized.contains("HISAB10", ignoreCase = true) -> promo = "HISAB10"
                    normalized.contains("DARAZ10", ignoreCase = true) -> promo = "DARAZ10"
                }
            }

            val parsedItem = parseItemLine(line, catalog)
            if (parsedItem != null) {
                val existing = matchedMap[parsedItem.product.id]
                if (existing == null) {
                    matchedMap[parsedItem.product.id] = MutablePair(parsedItem.product, parsedItem.quantityMilliUnits)
                } else {
                    existing.qty += parsedItem.quantityMilliUnits
                }
            } else if (line.startsWith("•") || line.startsWith("-") || line.startsWith("*")) {
                unmatched += line.trimStart('•', '-', '*', ' ')
            }
        }

        return ParsedIncomingOrder(
            customerName = name,
            customerPhone = phone,
            deliveryAddress = addr,
            deliveryDistrict = district,
            deliveryFeePaisa = delivPaisa,
            paymentMethod = pay,
            promoCode = promo,
            mfsTrxId = trxId,
            mfsSenderPhone = senderMfs,
            items = matchedMap.values.map { ParsedOrderLine(it.product, it.qty) },
            unmatchedLines = unmatched,
            isStructuredPayload = false
        )
    }

    private fun parseItemLine(line: String, catalog: List<ProductEntity>): ParsedOrderLine? {
        val cleaned = line
            .trimStart('•', '-', '*', ' ')
            .substringBefore('=')
            .trim()
        if (cleaned.isBlank()) return null

        // Pattern A: "<product> x <qty>" or "<product> × <qty>"
        val suffixQtyMatch = Regex("""^(.+?)\s*[x×*]\s*(\d+(?:\.\d+)?)\b.*$""", RegexOption.IGNORE_CASE).matchEntire(cleaned)
        if (suffixQtyMatch != null) {
            val prodPart = suffixQtyMatch.groupValues[1].trim()
            val qty = suffixQtyMatch.groupValues[2].toDoubleOrNull()?.coerceAtLeast(0.001) ?: 1.0
            findBestProductMatch(prodPart, catalog)?.let { prod ->
                return ParsedOrderLine(prod, (qty * 1000.0).roundToLong())
            }
        }

        // Pattern B: "<qty>x <product>" or "<qty> kg/pcs <product>"
        val prefixQtyMatch = Regex("""^(\d+(?:\.\d+)?)\s*(?:x|×|pcs|piece|pieces|kg|litre|liter|box|pack|টি|কেজি|লিটার|পিস)?\s+(.+)$""", RegexOption.IGNORE_CASE).matchEntire(cleaned)
        if (prefixQtyMatch != null) {
            val qty = prefixQtyMatch.groupValues[1].toDoubleOrNull()?.coerceAtLeast(0.001) ?: 1.0
            val prodPart = prefixQtyMatch.groupValues[2].trim()
            findBestProductMatch(prodPart, catalog)?.let { prod ->
                return ParsedOrderLine(prod, (qty * 1000.0).roundToLong())
            }
        }

        // Pattern C: Match longest catalog product name anywhere inside the line and grab any standalone qty
        val sortedCatalog = catalog.sortedByDescending { it.name.length }
        for (prod in sortedCatalog) {
            if (prod.name.length >= 2 && cleaned.contains(prod.name, ignoreCase = true)) {
                val remainder = cleaned.replace(prod.name, " ", ignoreCase = true)
                val qty = Regex("""(\d+(?:\.\d+)?)""").find(remainder)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 1.0
                return ParsedOrderLine(prod, (qty.coerceAtLeast(0.001) * 1000.0).roundToLong())
            }
        }

        return null
    }

    private fun findBestProductMatch(query: String, catalog: List<ProductEntity>): ProductEntity? {
        val q = query.trim()
        if (q.isBlank()) return null
        return catalog.firstOrNull { it.name.equals(q, ignoreCase = true) }
            ?: catalog.firstOrNull { it.sku.isNotBlank() && it.sku.equals(q, ignoreCase = true) }
            ?: catalog.filter {
                it.name.contains(q, ignoreCase = true) || q.contains(it.name, ignoreCase = true)
            }.maxByOrNull { it.name.length }
    }

    private fun normalizePaymentMethod(raw: String): String {
        val upper = raw.uppercase()
        return when {
            upper.contains("BKASH") || raw.contains("বিকাশ") -> OnlinePaymentMethods.BKASH
            upper.contains("NAGAD") || raw.contains("নগদ") -> OnlinePaymentMethods.NAGAD
            upper.contains("ROCKET") || raw.contains("রকেট") -> OnlinePaymentMethods.ROCKET
            upper.contains("UPAY") || raw.contains("উপায়") -> OnlinePaymentMethods.UPAY
            upper.contains("BANK") || raw.contains("ব্যাংক") -> OnlinePaymentMethods.BANK
            upper.contains("BAKI") || raw.contains("বাকি") -> OnlinePaymentMethods.BAKI_CREDIT
            else -> OnlinePaymentMethods.COD
        }
    }

    private class MutablePair(val product: ProductEntity, var qty: Long)
}
