package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.util.ExportUtils
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.TxTypes
import com.example.data.repository.AccountingCalculator
import com.example.ui.BusinessWorkspaceState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricCard
import com.example.ui.components.TransactionRowCard
import com.example.ui.theme.*

enum class ReportType(val title: String) {
    DAILY("Daily Report"),
    WEEKLY("Weekly Report"),
    MONTHLY("Monthly Report"),
    YEARLY("Yearly Report"),
    SALES("Sales Report"),
    PURCHASE("Purchase Report"),
    CUSTOMER_DUE("Customer Due"),
    SUPPLIER_PAYABLE("Supplier Payable"),
    INCOME("Income Report"),
    EXPENSE("Expense Report"),
    PROFIT_LOSS("Profit & Loss"),
    INVENTORY("Inventory Report"),
    CASHBOOK("Cashbook Report")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(state: BusinessWorkspaceState) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val context = LocalContext.current

    val canViewReports = state.activeEmployee?.canViewReports ?: true
    if (!canViewReports) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            EmptyStateCard(
                icon = Icons.Default.Lock,
                title = "Restricted Access",
                subtitle = "Current role (${state.activeEmployee?.role}) does not have permission to view financial reports."
            )
        }
        return
    }

    var selectedReport by remember { mutableStateOf(ReportType.PROFIT_LOSS) }
    var useCustomDateRange by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var customStartMillis by remember { mutableLongStateOf(MoneyUtils.dhakaMonthBounds().first) }
    var customEndMillis by remember { mutableLongStateOf(MoneyUtils.dhakaMonthBounds().second) }

    val (startMillis, endMillis) = remember(selectedReport, useCustomDateRange, customStartMillis, customEndMillis) {
        if (useCustomDateRange) {
            customStartMillis to customEndMillis
        } else {
            when (selectedReport) {
                ReportType.DAILY -> MoneyUtils.dhakaTodayBounds()
                ReportType.WEEKLY -> MoneyUtils.dhakaWeekBounds()
                ReportType.MONTHLY -> MoneyUtils.dhakaMonthBounds()
                ReportType.YEARLY -> MoneyUtils.dhakaYearBounds()
                else -> 0L to Long.MAX_VALUE
            }
        }
    }

    val pnl = remember(state.transactions, startMillis, endMillis) {
        AccountingCalculator.computeProfitAndLoss(state.transactions, startMillis, endMillis)
    }

    val filteredTransactions = remember(state.transactions, selectedReport, startMillis, endMillis) {
        val inRange = state.transactions.filter { it.occurredAt in startMillis..endMillis }
        when (selectedReport) {
            ReportType.SALES -> inRange.filter { it.type == TxTypes.SALE || it.type == TxTypes.CREDIT_SALE || it.type == TxTypes.SALE_RETURN }
            ReportType.PURCHASE -> inRange.filter { it.type == TxTypes.PURCHASE || it.type == TxTypes.PURCHASE_RETURN }
            ReportType.INCOME -> inRange.filter { it.type == TxTypes.INCOME || it.type == TxTypes.SALE || it.type == TxTypes.CREDIT_SALE }
            ReportType.EXPENSE -> inRange.filter { it.type == TxTypes.EXPENSE }
            ReportType.CASHBOOK -> inRange.filter { it.cashFlowDeltaPaisa != 0L || it.type == TxTypes.ACCOUNT_TRANSFER }
            else -> inRange
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.tabReports, style = MaterialTheme.typography.headlineSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { showDatePicker = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (useCustomDateRange) "Custom" else "Filter")
                    }
                    if (useCustomDateRange) {
                        IconButton(onClick = { useCustomDateRange = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Reset filter")
                        }
                    }
                }
            }
        }

        // Report Selector Chips (All 13 reports)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ReportType.entries) { rt ->
                    FilterChip(
                        selected = selectedReport == rt,
                        onClick = { selectedReport = rt },
                        label = { Text(rt.title) },
                        modifier = Modifier.testTag("report_chip_${rt.name.lowercase()}")
                    )
                }
            }
        }

        // Export Buttons
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        val bizName = state.activeBusiness?.name ?: "Hisab Pro BD"
                        val (summary, headers, rows) = buildExportPayload(selectedReport, state, pnl, filteredTransactions, useBn)
                        val pdf = ExportUtils.generateReportPdf(
                            context = context,
                            fileName = "hisab_${selectedReport.name.lowercase()}.pdf",
                            businessName = bizName,
                            reportTitle = selectedReport.title,
                            summaryRows = summary,
                            tableHeaders = headers,
                            tableRows = rows
                        )
                        ExportUtils.shareFile(context, pdf, "application/pdf", strings.exportPdf)
                    },
                    modifier = Modifier.weight(1f).testTag("export_pdf_button")
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.exportPdf)
                }
                OutlinedButton(
                    onClick = {
                        val (_, headers, rows) = buildExportPayload(selectedReport, state, pnl, filteredTransactions, useBn)
                        val csv = ExportUtils.generateExcelCsv(
                            context = context,
                            fileName = "hisab_${selectedReport.name.lowercase()}.csv",
                            headers = headers,
                            rows = rows
                        )
                        ExportUtils.shareFile(context, csv, "text/csv", strings.exportExcel)
                    },
                    modifier = Modifier.weight(1f).testTag("export_excel_button")
                ) {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.exportExcel)
                }
            }
        }

        // Specialized Report Content
        when (selectedReport) {
            ReportType.CUSTOMER_DUE -> {
                val dueList = state.customers.filter { it.currentDuePaisa > 0L }.sortedByDescending { it.currentDuePaisa }
                item {
                    MetricCard(strings.totalReceivable, state.dashboard.totalReceivablesPaisa, useBn, Icons.Default.MenuBook, WarningAmber)
                }
                items(dueList, key = { it.id }) { c ->
                    ListItem(
                        headlineContent = { Text(c.name) },
                        supportingContent = { Text("${c.customerCode} • ${c.phone}") },
                        trailingContent = {
                            Text(MoneyUtils.formatTaka(c.currentDuePaisa, useBn), fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold, color = WarningAmber)
                        }
                    )
                }
            }

            ReportType.SUPPLIER_PAYABLE -> {
                val payList = state.suppliers.filter { it.currentPayablePaisa > 0L }.sortedByDescending { it.currentPayablePaisa }
                item {
                    MetricCard(strings.supplierPayables, state.dashboard.totalPayablesPaisa, useBn, Icons.Default.LocalShipping, ExpenseRed)
                }
                items(payList, key = { it.id }) { s ->
                    ListItem(
                        headlineContent = { Text(s.name) },
                        supportingContent = { Text("${s.supplierCode} • ${s.phone}") },
                        trailingContent = {
                            Text(MoneyUtils.formatTaka(s.currentPayablePaisa, useBn), fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold, color = ExpenseRed)
                        }
                    )
                }
            }

            ReportType.INVENTORY -> {
                val totalStockVal = state.products.sumOf {
                    MoneyUtils.calculateLineTotalPaisa(it.stockMilliUnits, it.purchasePricePaisa)
                }
                item {
                    MetricCard("Stock Valuation (Cost)", totalStockVal, useBn, Icons.Default.Inventory2, EmeraldPrimary)
                }
                items(state.products, key = { it.id }) { p ->
                    val low = p.stockMilliUnits <= p.lowStockThresholdMilliUnits
                    ListItem(
                        headlineContent = { Text(p.name) },
                        supportingContent = { Text("Buy: ${MoneyUtils.formatTaka(p.purchasePricePaisa, useBn)} | Sell: ${MoneyUtils.formatTaka(p.sellingPricePaisa, useBn)}") },
                        trailingContent = {
                            Text(
                                "${MoneyUtils.milliUnitsToString(p.stockMilliUnits, useBn)} ${p.unit}",
                                color = if (low) ExpenseRed else EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                }
            }

            else -> {
                // Financial P&L + Cashflow Summary Card
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedReport.title, style = MaterialTheme.typography.titleMedium)
                                Surface(
                                    color = if (pnl.isEstimated) WarningSoftAmber else SoftGreenAccent,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = if (pnl.isEstimated) strings.estimatedProfit else strings.finalizedProfit,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (pnl.isEstimated) WarningAmber else EmeraldPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            ReportLine("Net Sales", MoneyUtils.formatTaka(pnl.netSalesPaisa, useBn))
                            ReportLine(strings.cogsLabel, MoneyUtils.formatTaka(pnl.cogsPaisa, useBn))
                            ReportLine(strings.grossProfit, MoneyUtils.formatTaka(pnl.grossProfitPaisa, useBn), highlight = true)
                            ReportLine("Other Income", MoneyUtils.formatTaka(pnl.otherIncomePaisa, useBn))
                            ReportLine("Operating Expenses", MoneyUtils.formatTaka(pnl.operatingExpensesPaisa, useBn))
                            HorizontalDivider()
                            ReportLine(
                                strings.netProfit,
                                MoneyUtils.formatTaka(pnl.netProfitPaisa, useBn),
                                highlight = true
                            )
                            HorizontalDivider()
                            ReportLine("Cash Inflow (Collected)", MoneyUtils.formatTaka(pnl.totalCashInPaisa, useBn))
                            ReportLine("Cash Outflow", MoneyUtils.formatTaka(pnl.totalCashOutPaisa, useBn))
                        }
                    }
                }

                items(filteredTransactions.take(60), key = { it.id }) { tx ->
                    TransactionRowCard(tx = tx, useBanglaDigits = useBn, onClick = {})
                }
            }
        }
    }

    if (showDatePicker) {
        val dateRangeState = rememberDateRangePickerState(
            initialSelectedStartDateMillis = customStartMillis,
            initialSelectedEndDateMillis = customEndMillis
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val s = dateRangeState.selectedStartDateMillis
                    val e = dateRangeState.selectedEndDateMillis
                    if (s != null && e != null) {
                        customStartMillis = s
                        customEndMillis = e + (24L * 60L * 60L * 1000L - 1L)
                        useCustomDateRange = true
                    }
                    showDatePicker = false
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) {
            DateRangePicker(state = dateRangeState, modifier = Modifier.height(420.dp))
        }
    }
}

@Composable
private fun ReportLine(label: String, value: String, highlight: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
            label,
            style = if (highlight) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
            color = if (highlight) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            style = if (highlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontFamily = MonoFontFamily,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
            color = if (highlight) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun buildExportPayload(
    reportType: ReportType,
    state: BusinessWorkspaceState,
    pnl: com.example.data.repository.ProfitAndLossReport,
    txs: List<com.example.data.local.AccountingTransactionEntity>,
    useBn: Boolean
): Triple<List<Pair<String, String>>, List<String>, List<List<String>>> {
    val summary = listOf(
        "Net Sales" to MoneyUtils.formatTaka(pnl.netSalesPaisa, useBn),
        "COGS" to MoneyUtils.formatTaka(pnl.cogsPaisa, useBn),
        "Gross Profit" to MoneyUtils.formatTaka(pnl.grossProfitPaisa, useBn),
        "Operating Expenses" to MoneyUtils.formatTaka(pnl.operatingExpensesPaisa, useBn),
        "Net Profit" to MoneyUtils.formatTaka(pnl.netProfitPaisa, useBn),
        "Total Receivables" to MoneyUtils.formatTaka(state.dashboard.totalReceivablesPaisa, useBn),
        "Total Payables" to MoneyUtils.formatTaka(state.dashboard.totalPayablesPaisa, useBn)
    )
    return when (reportType) {
        ReportType.CUSTOMER_DUE -> Triple(
            summary,
            listOf("Code", "Customer", "Phone", "Current Due"),
            state.customers.filter { it.currentDuePaisa > 0 }.map {
                listOf(it.customerCode, it.name, it.phone, MoneyUtils.formatTaka(it.currentDuePaisa, useBn))
            }
        )
        ReportType.SUPPLIER_PAYABLE -> Triple(
            summary,
            listOf("Code", "Supplier", "Phone", "Payable"),
            state.suppliers.filter { it.currentPayablePaisa > 0 }.map {
                listOf(it.supplierCode, it.name, it.phone, MoneyUtils.formatTaka(it.currentPayablePaisa, useBn))
            }
        )
        ReportType.INVENTORY -> Triple(
            summary,
            listOf("Product", "SKU", "Stock", "Buy Price", "Sell Price"),
            state.products.map {
                listOf(
                    it.name,
                    it.sku,
                    "${MoneyUtils.milliUnitsToString(it.stockMilliUnits, useBn)} ${it.unit}",
                    MoneyUtils.formatTaka(it.purchasePricePaisa, useBn),
                    MoneyUtils.formatTaka(it.sellingPricePaisa, useBn)
                )
            }
        )
        else -> Triple(
            summary,
            listOf("Date", "Type", "Party/Category", "Amount", "Cash Flow"),
            txs.map {
                listOf(
                    MoneyUtils.formatDhakaDate(it.occurredAt, useBn),
                    it.type,
                    it.partyName.ifBlank { it.categoryName },
                    MoneyUtils.formatTaka(it.totalAmountPaisa, useBn),
                    MoneyUtils.formatTaka(it.cashFlowDeltaPaisa, useBn)
                )
            }
        )
    }
}
