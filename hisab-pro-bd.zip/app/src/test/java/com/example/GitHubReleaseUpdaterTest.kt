package com.example

import com.example.data.remote.GitHubReleaseUpdater
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GitHubReleaseUpdaterTest {

    @Test
    fun `normalizeRepoSlug accepts owner repo and full github urls`() {
        assertEquals("srobiul/hisab-pro-bd", GitHubReleaseUpdater.normalizeRepoSlug("srobiul/hisab-pro-bd"))
        assertEquals("srobiul/hisab-pro-bd", GitHubReleaseUpdater.normalizeRepoSlug("https://github.com/srobiul/hisab-pro-bd"))
        assertEquals("srobiul/hisab-pro-bd", GitHubReleaseUpdater.normalizeRepoSlug("https://github.com/srobiul/hisab-pro-bd.git"))
        assertEquals("srobiul/hisab-pro-bd", GitHubReleaseUpdater.normalizeRepoSlug("https://github.com/srobiul/hisab-pro-bd/releases"))
        assertNull(GitHubReleaseUpdater.normalizeRepoSlug("invalid-repo"))
        assertNull(GitHubReleaseUpdater.normalizeRepoSlug(""))
    }

    @Test
    fun `semver comparison handles v prefixes and multi segment versions`() {
        assertTrue(GitHubReleaseUpdater.isRemoteVersionNewer("v1.0.1", "1.0"))
        assertTrue(GitHubReleaseUpdater.isRemoteVersionNewer("v1.2.0", "1.1.9"))
        assertTrue(GitHubReleaseUpdater.isRemoteVersionNewer("2.0.0-beta1", "1.9.9"))
        assertFalse(GitHubReleaseUpdater.isRemoteVersionNewer("v1.0.0", "1.0"))
        assertFalse(GitHubReleaseUpdater.isRemoteVersionNewer("v0.9.5", "1.0"))
    }

    @Test
    fun `parseLatestReleaseJson selects release apk asset and extracts metadata`() {
        val sampleJson = """
            {
              "tag_name": "v1.2.0",
              "name": "Hisab Pro BD v1.2.0",
              "body": "Added faster Baki Khata PDF export.",
              "published_at": "2026-11-25T10:00:00Z",
              "html_url": "https://github.com/srobiul/hisab-pro-bd/releases/tag/v1.2.0",
              "assets": [
                {
                  "name": "source-notes.txt",
                  "content_type": "text/plain",
                  "size": 512,
                  "browser_download_url": "https://github.com/srobiul/hisab-pro-bd/releases/download/v1.2.0/source-notes.txt"
                },
                {
                  "name": "hisab-pro-bd-debug.apk",
                  "content_type": "application/vnd.android.package-archive",
                  "size": 27000000,
                  "browser_download_url": "https://github.com/srobiul/hisab-pro-bd/releases/download/v1.2.0/hisab-pro-bd-debug.apk"
                },
                {
                  "name": "hisab-pro-bd-release.apk",
                  "content_type": "application/vnd.android.package-archive",
                  "size": 24000000,
                  "browser_download_url": "https://github.com/srobiul/hisab-pro-bd/releases/download/v1.2.0/hisab-pro-bd-release.apk"
                }
              ]
            }
        """.trimIndent()

        val release = GitHubReleaseUpdater.parseLatestReleaseJson(sampleJson)
        assertEquals("v1.2.0", release.tagName)
        assertEquals("Hisab Pro BD v1.2.0", release.releaseName)
        assertEquals("hisab-pro-bd-release.apk", release.apkAssetName)
        assertEquals(24_000_000L, release.apkSizeBytes)
        assertEquals(
            "https://github.com/srobiul/hisab-pro-bd/releases/download/v1.2.0/hisab-pro-bd-release.apk",
            release.apkDownloadUrl
        )
    }
}
