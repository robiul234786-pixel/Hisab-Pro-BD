package com.example.core.util

import com.example.data.local.AccountingTransactionEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.ProductEntity
import com.example.data.local.TxTypes
import java.time.Instant
import java.time.LocalDate
import java.util.Locale
import kotlin.math.abs

enum class VoiceIntentType {
    CUSTOMER_PAYMENT,
    CREDIT_SALE,
    SALE,
    EXPENSE,
    INCOME,
    QUERY_SUMMARY
}

data class ParsedVoiceCommand(
    val rawText: String,
    val intentType: VoiceIntentType,
    val customerId: String? = null,
    val customerName: String = "",
    val ambiguousCustomers: List<CustomerEntity> = emptyList(),
    val productId: String? = null,
    val productName: String = "",
    val quantityMilliUnits: Long = 1000L,
    val unit: String = "Piece",
    val amountPaisa: Long = 0L,
    val categoryName: String = "",
    val occurredAtMillis: Long = System.currentTimeMillis(),
    val dateLabel: String = "Today",
    val notes: String = "",
    val duplicateCandidate: AccountingTransactionEntity? = null,
    val queryPrompt: String? = null
)

object VoiceAccountingParser {

    private val bnWordMap = mapOf(
        "এক" to 1L, "দুই" to 2L, "তিন" to 3L, "চার" to 4L, "পাঁচ" to 5L,
        "ছয়" to 6L, "ছয়" to 6L, "সাত" to 7L, "আট" to 8L, "নয়" to 9L, "নয়" to 9L,
        "দশ" to 10L, "বিশ" to 20L, "ত্রিশ" to 30L, "চল্লিশ" to 40L, "পঞ্চাশ" to 50L,
        "ষাট" to 60L, "সত্তর" to 70L, "আশি" to 80L, "নব্বই" to 90L,
        "one" to 1L, "two" to 2L, "three" to 3L, "four" to 4L, "five" to 5L,
        "ten" to 10L, "twenty" to 20L, "thirty" to 30L, "forty" to 40L, "fifty" to 50L
    )

    private val scaleMap = mapOf(
        "শত" to 100L, "শ" to 100L, "hundred" to 100L,
        "হাজার" to 1000L, "thousand" to 1000L,
        "লক্ষ" to 100_000L, "লাখ" to 100_000L, "lakh" to 100_000L,
        "কোটি" to 10_000_000L
    )

    private val unitKeywords = listOf(
        "কেজি" to "Kg", "kg" to "Kg", "গ্রাম" to "Gram", "লিটার" to "Litre",
        "পিস" to "Piece", "piece" to "Piece", "pcs" to "Piece",
        "বস্তা" to "Bag", "ডজন" to "Dozen", "কার্টুন" to "Carton", "হালি" to "Hali"
    )

    private val expenseHints = listOf(
        "ভাড়া" to "Rent", "ভাড়া" to "Rent", "rent" to "Rent",
        "বিদ্যুৎ" to "Electricity", "কারেন্ট" to "Electricity", "electric" to "Electricity",
        "বেতন" to "Employee Salary", "salary" to "Employee Salary",
        "পরিবহন" to "Transport", "যাতায়াত" to "Transport", "গাড়ি" to "Transport", "transport" to "Transport",
        "খাবার" to "Food", "নাস্তা" to "Food", "food" to "Food",
        "মার্কেটিং" to "Marketing", "বিজ্ঞাপন" to "Marketing",
        "খরচ" to "Other Expenses", "ব্যয়" to "Other Expenses", "ব্যয়" to "Other Expenses",
        "expense" to "Other Expenses", "spent" to "Other Expenses", "bill" to "Other Expenses"
    )

    fun parse(
        rawText: String,
        customers: List<CustomerEntity>,
        products: List<ProductEntity>,
        recentTransactions: List<AccountingTransactionEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): ParsedVoiceCommand {
        val cleaned = rawText.trim()
        val lower = MoneyUtils.normalizeDigits(cleaned).lowercase(Locale.ENGLISH)

        // 1. Check if this is an analytics / query command ("আজকের বিক্রির হিসাব দেখাও", "show today's sales")
        val isQuery = listOf(
            "দেখাও", "কত টাকা", "হিসাব দেখাও", "লাভ কত", "বিক্রি হয়েছে", "বিক্রি হয়েছে",
            "show ", "how much", "what is", "report", "summary", "কার কাছে", "বাকি কত"
        ).any { lower.contains(it) } &&
            !listOf("পেলাম", "আদায়", "আদায়", "বাকিতে দিলাম", "খরচ করলাম", "দিলাম", "paid", "received", "sold")
                .any { lower.contains(it) }

        val (occurredAt, dateLabel) = extractDate(lower, nowMillis)

        if (isQuery) {
            return ParsedVoiceCommand(
                rawText = cleaned,
                intentType = VoiceIntentType.QUERY_SUMMARY,
                occurredAtMillis = occurredAt,
                dateLabel = dateLabel,
                queryPrompt = cleaned
            )
        }

        // 2. Extract numeric values & quantity
        val numbers = extractNumbers(lower)
        val detectedUnitPair = unitKeywords.firstOrNull { lower.contains(it.first) }
        var qtyMilli = 1000L
        var amountTaka = 0L

        if (detectedUnitPair != null && numbers.isNotEmpty()) {
            // Look for number immediately preceding unit
            val unitIdx = lower.indexOf(detectedUnitPair.first)
            val beforeUnit = lower.substring(0, unitIdx).trim()
            val numBeforeUnit = Regex("(\\d+(?:\\.\\d+)?)\\s*$").find(beforeUnit)?.groupValues?.get(1)?.toDoubleOrNull()
            if (numBeforeUnit != null) {
                qtyMilli = (numBeforeUnit * 1000.0).toLong().coerceAtLeast(1L)
                // Remaining numbers after unit or largest remaining number is amount
                val remainingNumbers = numbers.filter { abs(it - numBeforeUnit) > 0.001 }
                amountTaka = remainingNumbers.maxOrNull()?.toLong() ?: 0L
            } else {
                amountTaka = numbers.maxOrNull()?.toLong() ?: 0L
            }
        } else {
            amountTaka = numbers.maxOrNull()?.toLong() ?: 0L
        }

        // 3. Match product if present
        val matchedProduct = findMatchingProduct(lower, products)
        if (amountTaka == 0L && matchedProduct != null && matchedProduct.sellingPricePaisa > 0L) {
            amountTaka = MoneyUtils.calculateLineTotalPaisa(qtyMilli, matchedProduct.sellingPricePaisa) / 100L
        }
        val amountPaisa = if (amountTaka > 0L) amountTaka * 100L else 0L

        // 4. Match customers (detect exact or ambiguous matches)
        val customerCandidates = findCustomerCandidates(lower, customers)
        val exactCustomer = if (customerCandidates.size == 1) customerCandidates.first() else null
        val ambiguous = if (customerCandidates.size > 1) customerCandidates else emptyList()

        // 5. Determine Intent
        val isDueCredit = listOf(
            "বাকিতে", "বাকি দিলাম", "বাকিতে দিলাম", "ধার", "due", "credit", "baki"
        ).any { lower.contains(it) }

        val isCustomerPayment = listOf(
            "কাছ থেকে", "পেলাম", "আদায়", "আদায়", "জমা দিল", "জমা পেলাম",
            "received from", "paid me", "collected", "payment from"
        ).any { lower.contains(it) }

        val matchedExpenseHint = expenseHints.firstOrNull { lower.contains(it.first) }
        val isSaleWord = listOf(
            "বিক্রি", "বিক্রয়", "বিক্রয়", "বেচলাম", "sale", "sold", "bill"
        ).any { lower.contains(it) }

        val isIncomeWord = listOf(
            "আয়", "আয়", "income", "commission", "কমিশন"
        ).any { lower.contains(it) }

        val intent = when {
            isDueCredit -> VoiceIntentType.CREDIT_SALE
            isCustomerPayment && (customerCandidates.isNotEmpty() || !isIncomeWord) -> VoiceIntentType.CUSTOMER_PAYMENT
            matchedExpenseHint != null && !isSaleWord -> VoiceIntentType.EXPENSE
            isSaleWord || matchedProduct != null -> VoiceIntentType.SALE
            isIncomeWord -> VoiceIntentType.INCOME
            customerCandidates.isNotEmpty() && lower.contains("দিলাম") -> VoiceIntentType.CREDIT_SALE
            lower.contains("দিলাম") -> VoiceIntentType.EXPENSE
            else -> VoiceIntentType.SALE
        }

        val categoryName = when (intent) {
            VoiceIntentType.EXPENSE -> matchedExpenseHint?.second ?: "Other Expenses"
            VoiceIntentType.INCOME -> "Other Income"
            else -> ""
        }

        val effectiveUnit = detectedUnitPair?.second ?: matchedProduct?.unit ?: "Piece"
        val partyGuess = exactCustomer?.name
            ?: customerCandidates.firstOrNull()?.name
            ?: extractPartyTokenFallback(cleaned)

        val txTypeForDupCheck = when (intent) {
            VoiceIntentType.CUSTOMER_PAYMENT -> TxTypes.CUSTOMER_PAYMENT
            VoiceIntentType.CREDIT_SALE -> TxTypes.CREDIT_SALE
            VoiceIntentType.SALE -> TxTypes.SALE
            VoiceIntentType.EXPENSE -> TxTypes.EXPENSE
            VoiceIntentType.INCOME -> TxTypes.INCOME
            VoiceIntentType.QUERY_SUMMARY -> ""
        }

        val duplicate = if (amountPaisa > 0L && txTypeForDupCheck.isNotEmpty()) {
            findRecentDuplicate(
                recentTransactions = recentTransactions,
                txType = txTypeForDupCheck,
                amountPaisa = amountPaisa,
                customerId = exactCustomer?.id,
                nowMillis = nowMillis
            )
        } else null

        return ParsedVoiceCommand(
            rawText = cleaned,
            intentType = intent,
            customerId = exactCustomer?.id,
            customerName = if (intent == VoiceIntentType.CUSTOMER_PAYMENT || intent == VoiceIntentType.CREDIT_SALE || intent == VoiceIntentType.SALE) partyGuess else "",
            ambiguousCustomers = ambiguous,
            productId = matchedProduct?.id,
            productName = matchedProduct?.name ?: "",
            quantityMilliUnits = qtyMilli,
            unit = effectiveUnit,
            amountPaisa = amountPaisa,
            categoryName = categoryName,
            occurredAtMillis = occurredAt,
            dateLabel = dateLabel,
            notes = cleaned,
            duplicateCandidate = duplicate
        )
    }

    fun findRecentDuplicate(
        recentTransactions: List<AccountingTransactionEntity>,
        txType: String,
        amountPaisa: Long,
        customerId: String?,
        nowMillis: Long = System.currentTimeMillis(),
        windowMillis: Long = 5 * 60 * 1000L
    ): AccountingTransactionEntity? {
        return recentTransactions.firstOrNull { tx ->
            !tx.isReversed &&
                tx.type == txType &&
                tx.totalAmountPaisa == amountPaisa &&
                (customerId == null || tx.customerId == customerId) &&
                abs(nowMillis - tx.occurredAt) <= windowMillis
        }
    }

    private fun extractDate(lower: String, nowMillis: Long): Pair<Long, String> {
        val today = Instant.ofEpochMilli(nowMillis).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate()
        return when {
            lower.contains("গতকাল") || lower.contains("yesterday") -> {
                val d = today.minusDays(1)
                d.atTime(12, 0).atZone(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli() to "Yesterday"
            }
            lower.contains("পরশু") -> {
                val d = today.minusDays(2)
                d.atTime(12, 0).atZone(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli() to "2 days ago"
            }
            else -> nowMillis to "Today"
        }
    }

    private fun extractNumbers(lower: String): List<Double> {
        val results = mutableListOf<Double>()
        // Direct numeric tokens (already normalized from Bangla digits)
        Regex("\\d+(?:\\.\\d+)?").findAll(lower).forEach { m ->
            m.value.toDoubleOrNull()?.let { results.add(it) }
        }
        // Check Bengali/English word combinations like "পাঁচ হাজার", "দুই শত"
        val tokens = lower.split(Regex("[\\s,।.!?]+")).filter { it.isNotBlank() }
        var current = 0L
        var anyWordNum = false
        for (tok in tokens) {
            val base = bnWordMap[tok]
            val scale = scaleMap[tok]
            when {
                base != null -> {
                    current += base
                    anyWordNum = true
                }
                scale != null -> {
                    current = if (current == 0L) scale else current * scale
                    anyWordNum = true
                }
                else -> {
                    if (anyWordNum && current > 0L) {
                        results.add(current.toDouble())
                        current = 0L
                        anyWordNum = false
                    }
                }
            }
        }
        if (anyWordNum && current > 0L) {
            results.add(current.toDouble())
        }
        return results
    }

    private fun findCustomerCandidates(lower: String, customers: List<CustomerEntity>): List<CustomerEntity> {
        val normalizedQueryTokens = lower
            .split(Regex("[\\s,।.!?]+"))
            .map { stripBanglaSuffix(it) }
            .filter { it.length >= 2 }

        val querySkeletons = normalizedQueryTokens
            .map { phoneticSkeleton(it) }
            .filter { it.length >= 2 }
            .toSet()

        val matches = customers.filter { c ->
            val cName = c.name.trim().lowercase(Locale.ENGLISH)
            val cTokens = cName.split(Regex("\\s+")).filter { it.length >= 2 }
            val cSkeletons = cTokens.map { phoneticSkeleton(it) }.filter { it.length >= 2 }
            val cFirst = cTokens.firstOrNull().orEmpty()

            lower.contains(cName) ||
                (cFirst.length >= 2 && (lower.contains(cFirst) || normalizedQueryTokens.any { tok ->
                    cName.contains(tok)
                })) ||
                cSkeletons.any { cs -> querySkeletons.any { qs -> qs == cs } }
        }
        val exactFull = matches.filter { lower.contains(it.name.trim().lowercase(Locale.ENGLISH)) }
        return if (exactFull.size == 1) exactFull else matches
    }

    private fun stripBanglaSuffix(token: String): String {
        val suffixes = listOf("ের কাছ থেকে", "ের", "কে", "দের", "র", "'s")
        for (suf in suffixes) {
            if (token.endsWith(suf) && token.length > suf.length + 1) {
                return token.removeSuffix(suf)
            }
        }
        return token
    }

    private fun phoneticSkeleton(token: String): String {
        val bnToLat = mapOf(
            'ক' to 'k', 'খ' to 'k', 'গ' to 'g', 'ঘ' to 'g',
            'চ' to 'c', 'ছ' to 'c', 'জ' to 'j', 'ঝ' to 'j', 'য' to 'j', 'য়' to 'y',
            'ট' to 't', 'ঠ' to 't', 'ড' to 'd', 'ঢ' to 'd',
            'ত' to 't', 'থ' to 't', 'দ' to 'd', 'ধ' to 'd',
            'ন' to 'n', 'ণ' to 'n', 'ঙ' to 'n', 'ঞ' to 'n',
            'প' to 'p', 'ফ' to 'p', 'ব' to 'b', 'ভ' to 'b',
            'ম' to 'm', 'র' to 'r', 'ড়' to 'r', 'ঢ়' to 'r',
            'ল' to 'l', 'শ' to 's', 'ষ' to 's', 'স' to 's', 'হ' to 'h'
        )
        val latNorm = token
            .replace("sh", "s")
            .replace("kh", "k")
            .replace("gh", "g")
            .replace("ch", "c")
            .replace("jh", "j")
            .replace("th", "t")
            .replace("dh", "d")
            .replace("ph", "p")
            .replace("bh", "b")
        val sb = StringBuilder()
        var lastChar = '\u0000'
        for (ch in latNorm) {
            val mapped: Char? = when {
                ch in bnToLat -> bnToLat[ch]
                ch in listOf('a', 'e', 'i', 'o', 'u', 'y', 'w') -> null
                ch == 'q' -> 'k'
                ch == 'z' -> 'j'
                ch == 'v' || ch == 'f' -> if (ch == 'v') 'b' else 'p'
                ch in 'a'..'z' -> ch
                else -> null
            }
            if (mapped != null && mapped != lastChar) {
                sb.append(mapped)
                lastChar = mapped
            }
        }
        return sb.toString()
    }

    private fun findMatchingProduct(lower: String, products: List<ProductEntity>): ProductEntity? {
        val querySkeletons = lower.split(Regex("[\\s,।.!?]+"))
            .map { phoneticSkeleton(stripBanglaSuffix(it)) }
            .filter { it.length >= 2 }
            .toSet()
        return products.firstOrNull { prod ->
            val pName = prod.name.trim().lowercase(Locale.ENGLISH)
            val words = pName.split(" ").filter { it.length >= 2 }
            val wordSkeletons = words.map { phoneticSkeleton(it) }.filter { it.length >= 2 }
            lower.contains(pName) ||
                words.any { lower.contains(it) } ||
                wordSkeletons.any { it in querySkeletons }
        }
    }

    private fun extractPartyTokenFallback(raw: String): String {
        val firstWord = raw.trim().split(Regex("\\s+")).firstOrNull().orEmpty()
        return stripBanglaSuffix(firstWord)
    }
}
