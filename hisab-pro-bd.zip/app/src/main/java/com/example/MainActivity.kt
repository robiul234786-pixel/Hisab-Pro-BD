package com.example

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.credentials.CredentialManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.util.LocalAppStrings
import com.example.core.util.stringsForLanguage
import com.example.data.local.TxTypes
import com.example.data.remote.FirebaseAuthHelper
import com.example.ui.MainViewModel
import com.example.ui.components.BrandedSplashScreen
import com.example.ui.components.OnboardingWizard
import com.example.ui.components.PinLockScreen
import com.example.ui.screens.*
import com.example.ui.theme.HisabProTheme

enum class BottomNavTab {
    HOME, CUSTOMERS, TRANSACTIONS, REPORTS, SETTINGS
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel()
            val settings by viewModel.settingsState.collectAsStateWithLifecycle()
            val workspace by viewModel.workspaceState.collectAsStateWithLifecycle()
            val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
            val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
            val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()

            var splashDone by remember { mutableStateOf(false) }

            val darkTheme = when (settings.darkModePreference) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }
            val appStrings = remember(settings.languageCode) {
                stringsForLanguage(settings.languageCode)
            }

            val context = LocalContext.current
            val scope = rememberCoroutineScope()
            val credentialManager = remember { CredentialManager.create(context) }

            // Attempt silent Google auto-sign-in only if user previously authorized an account
            LaunchedEffect(Unit) {
                FirebaseAuthHelper.attemptAutoSignIn(
                    context = context,
                    credentialManager = credentialManager,
                    onAuthSuccess = {},
                    onUnauthenticated = {},
                    scope = scope
                )
            }

            CompositionLocalProvider(LocalAppStrings provides appStrings) {
                HisabProTheme(darkTheme = darkTheme, isBangla = appStrings.isBangla) {
                    val snackbarHostState = remember { SnackbarHostState() }
                    LaunchedEffect(statusMessage) {
                        statusMessage?.let { msg ->
                            snackbarHostState.showSnackbar(msg)
                            viewModel.clearStatusMessage()
                        }
                    }

                    when {
                        !splashDone -> {
                            BrandedSplashScreen(onFinished = { splashDone = true })
                        }
                        !settings.onboardingCompleted -> {
                            OnboardingWizard(
                                initialLanguageCode = settings.languageCode,
                                onLanguageSelected = viewModel::setLanguage,
                                onRestoreBackupUri = viewModel::restoreBackupFromUri,
                                onCompleteSetup = viewModel::completeOnboarding,
                                onGoogleRestoreSuccess = { uid -> viewModel.restoreFromCloud(uid) }
                            )
                        }
                        isLocked -> {
                            PinLockScreen(
                                biometricEnabled = settings.biometricEnabled,
                                onVerifyPin = viewModel::unlockWithPin,
                                onBiometricUnlocked = viewModel::unlockBiometric
                            )
                        }
                        else -> {
                            MainAppShell(
                                workspace = workspace,
                                isSyncing = isSyncing,
                                snackbarHostState = snackbarHostState,
                                viewModel = viewModel
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MainAppShell(
    workspace: com.example.ui.BusinessWorkspaceState,
    isSyncing: Boolean,
    snackbarHostState: SnackbarHostState,
    viewModel: MainViewModel
) {
    val strings = LocalAppStrings.current
    var currentTab by remember { mutableStateOf(BottomNavTab.HOME) }
    var customersSubTab by remember { mutableIntStateOf(0) }
    var preselectedCustomerId by remember { mutableStateOf<String?>(null) }
    var transactionsSubTab by remember { mutableIntStateOf(0) }

    var showQuickAddCustomer by remember { mutableStateOf(false) }
    var showQuickDueModal by remember { mutableStateOf<String?>(null) }

    // Back handler returns secondary tabs to Home
    BackHandler(enabled = currentTab != BottomNavTab.HOME) {
        currentTab = BottomNavTab.HOME
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                val navItems = listOf(
                    Triple(BottomNavTab.HOME, strings.tabHome, Icons.Default.Dashboard),
                    Triple(BottomNavTab.CUSTOMERS, strings.tabCustomers, Icons.Default.People),
                    Triple(BottomNavTab.TRANSACTIONS, strings.tabTransactions, Icons.Default.PointOfSale),
                    Triple(BottomNavTab.REPORTS, strings.tabReports, Icons.Default.Assessment),
                    Triple(BottomNavTab.SETTINGS, strings.tabSettings, Icons.Default.Settings)
                )
                navItems.forEach { (tab, label, icon) ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = {
                            preselectedCustomerId = null
                            currentTab = tab
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, maxLines = 1) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                BottomNavTab.HOME -> {
                    HomeDashboardScreen(
                        state = workspace,
                        onSwitchBusiness = viewModel::switchBusiness,
                        onCreateBusiness = { name, cat, phone, addr, openingCash, inv ->
                            viewModel.createAdditionalBusiness(name, cat, phone, addr, null, openingCash, inv)
                        },
                        onQuickAction = { action ->
                            when (action) {
                                QuickActionType.ADD_SALE -> {
                                    transactionsSubTab = 0
                                    currentTab = BottomNavTab.TRANSACTIONS
                                }
                                QuickActionType.ADD_CUSTOMER -> showQuickAddCustomer = true
                                QuickActionType.ADD_DUE -> showQuickDueModal = TxTypes.CREDIT_SALE
                                QuickActionType.RECEIVE_PAYMENT -> showQuickDueModal = TxTypes.CUSTOMER_PAYMENT
                                QuickActionType.ADD_EXPENSE -> {
                                    transactionsSubTab = 2
                                    currentTab = BottomNavTab.TRANSACTIONS
                                }
                                QuickActionType.ADD_PURCHASE -> {
                                    transactionsSubTab = 1
                                    currentTab = BottomNavTab.TRANSACTIONS
                                }
                            }
                        },
                        onMarkNotificationsRead = viewModel::markNotificationsRead,
                        onOpenTransactionDetail = {
                            transactionsSubTab = 4
                            currentTab = BottomNavTab.TRANSACTIONS
                        },
                        onOpenCustomerDetail = { custId ->
                            preselectedCustomerId = custId
                            customersSubTab = 0
                            currentTab = BottomNavTab.CUSTOMERS
                        },
                        onLockApp = viewModel::lockNow
                    )
                }
                BottomNavTab.CUSTOMERS -> {
                    CustomersAndDuesScreen(
                        state = workspace,
                        initialSubTab = customersSubTab,
                        preselectedCustomerId = preselectedCustomerId,
                        onSaveCustomer = viewModel::saveCustomer,
                        onArchiveCustomer = viewModel::archiveCustomer,
                        onRecordDueEntry = viewModel::recordDueEntry,
                        onSaveSupplier = viewModel::saveSupplier,
                        onRecordSupplierPayment = viewModel::recordSupplierPayment
                    )
                }
                BottomNavTab.TRANSACTIONS -> {
                    TransactionsHubScreen(
                        state = workspace,
                        initialSubTab = transactionsSubTab,
                        onRecordSale = viewModel::recordSale,
                        onRecordPurchase = viewModel::recordPurchase,
                        onRecordIncomeOrExpense = viewModel::recordIncomeOrExpense,
                        onCreateCategory = viewModel::createCategory,
                        onSaveAccount = viewModel::saveAccount,
                        onTransferAccounts = viewModel::transferAccounts,
                        onRecordReturnOrCorrection = viewModel::recordReturnOrCorrection,
                        onReverseTransaction = viewModel::reverseTransaction,
                        onLoadInvoiceItems = { invId -> viewModel.repo.getInvoiceItems(invId) }
                    )
                }
                BottomNavTab.REPORTS -> {
                    ReportsScreen(state = workspace)
                }
                BottomNavTab.SETTINGS -> {
                    SettingsScreen(
                        state = workspace,
                        isSyncing = isSyncing,
                        onUpdateBusiness = viewModel::updateBusiness,
                        onSaveProduct = viewModel::saveProduct,
                        onAdjustStock = viewModel::adjustStock,
                        onSaveEmployee = viewModel::saveEmployee,
                        onRemoveEmployee = viewModel::removeEmployee,
                        onSetActiveEmployee = viewModel::setActiveEmployee,
                        onSetPin = viewModel::setPin,
                        onRemovePin = viewModel::removePin,
                        onSetBiometric = viewModel::setBiometricEnabled,
                        onSetLanguage = viewModel::setLanguage,
                        onSetBanglaDigits = viewModel::setBanglaDigits,
                        onSetDarkMode = viewModel::setDarkMode,
                        onUpdateNotifications = viewModel::updateNotificationPrefs,
                        onExportBackupUri = viewModel::exportBackupToUri,
                        onRestoreBackupUri = viewModel::restoreBackupFromUri,
                        onSyncToCloud = viewModel::syncToCloud,
                        onRestoreFromCloud = viewModel::restoreFromCloud
                    )
                }
            }
        }
    }

    if (showQuickAddCustomer) {
        CustomerEditorDialog(
            existing = null,
            onDismiss = { showQuickAddCustomer = false },
            onSave = { name, phone, address, photoUri, cat, openingDue ->
                viewModel.saveCustomer(null, name, phone, address, photoUri, cat, openingDue)
                showQuickAddCustomer = false
            }
        )
    }

    showQuickDueModal?.let { initialType ->
        if (workspace.customers.isEmpty()) {
            AlertDialog(
                onDismissRequest = { showQuickDueModal = null },
                title = { Text("No Customers Yet") },
                text = { Text("Add a customer first to record credit or payments in Baki Khata.") },
                confirmButton = {
                    Button(onClick = {
                        showQuickDueModal = null
                        showQuickAddCustomer = true
                    }) { Text("Add Customer") }
                },
                dismissButton = { TextButton(onClick = { showQuickDueModal = null }) { Text("Cancel") } }
            )
        } else {
            var pickedCustomer by remember { mutableStateOf(workspace.customers.first()) }
            var showPicker by remember { mutableStateOf(true) }
            if (showPicker) {
                AlertDialog(
                    onDismissRequest = { showQuickDueModal = null },
                    title = { Text("Select Customer") },
                    text = {
                        Column {
                            workspace.customers.take(10).forEach { c ->
                                TextButton(onClick = { pickedCustomer = c; showPicker = false }) {
                                    Text("${c.name} (${c.customerCode})")
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showQuickDueModal = null }) { Text("Cancel") } }
                )
            } else {
                DueLedgerActionDialog(
                    customer = pickedCustomer,
                    initialType = initialType,
                    accounts = workspace.accounts,
                    useBanglaDigits = workspace.settings.useBanglaDigits,
                    onDismiss = { showQuickDueModal = null },
                    onSubmit = { type, amountPaisa, accId, affectAcc, notes ->
                        viewModel.recordDueEntry(pickedCustomer.id, type, amountPaisa, accId, affectAcc, notes)
                        showQuickDueModal = null
                    }
                )
            }
        }
    }
}
