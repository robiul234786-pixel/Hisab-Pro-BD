package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.util.LocalAppStrings
import com.example.core.util.MfsPaymentParser
import com.example.core.util.MoneyUtils
import com.example.data.local.*
import com.example.ui.OnlineShopUiState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailBottomSheet(
    product: ProductEntity,
    isWishlisted: Boolean,
    cartQuantityMilliUnits: Long,
    useBanglaDigits: Boolean,
    onToggleWishlist: () -> Unit,
    onAddToCart: (Long) -> Unit,
    onBuyNow: (Long) -> Unit,
    onOpenProductQr: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var qtyInput by remember(product.id) { mutableStateOf("1") }
    val selectedQtyMilli = MoneyUtils.parseQtyToMilliUnits(qtyInput).coerceAtLeast(1_000L)
    val hasDiscount = product.onlineComparePricePaisa > product.sellingPricePaisa && product.sellingPricePaisa > 0L
    val discountPct = if (hasDiscount) {
        (((product.onlineComparePricePaisa - product.sellingPricePaisa) * 100L) / product.onlineComparePricePaisa).toInt()
    } else 0

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(ShopOrangeSoft),
                contentAlignment = Alignment.Center
            ) {
                if (!product.imageUri.isNullOrBlank()) {
                    AsyncImage(
                        model = product.imageUri,
                        contentDescription = product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        Icons.Default.ShoppingBag,
                        contentDescription = product.name,
                        tint = ShopOrange,
                        modifier = Modifier.size(64.dp)
                    )
                }
                if (hasDiscount) {
                    Surface(
                        color = ShopOrange,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "-$discountPct% OFF",
                            color = PureWhite,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                IconButton(
                    onClick = onToggleWishlist,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                ) {
                    Icon(
                        if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Wishlist",
                        tint = if (isWishlisted) ExpenseRed else DarkNavy
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                FilledTonalIconButton(
                    onClick = onOpenProductQr,
                    modifier = Modifier.testTag("product_detail_qr_button")
                ) {
                    Icon(
                        Icons.Default.QrCode2,
                        contentDescription = strings.productQrCodeLabel,
                        tint = ShopOrange
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = MoneyUtils.formatTaka(product.sellingPricePaisa, useBanglaDigits),
                    style = MaterialTheme.typography.headlineSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                    color = ShopOrange
                )
                if (hasDiscount) {
                    Text(
                        text = MoneyUtils.formatTaka(product.onlineComparePricePaisa, useBanglaDigits),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontFamily = MonoFontFamily,
                            textDecoration = TextDecoration.LineThrough
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(color = WarningSoftAmber, shape = RoundedCornerShape(8.dp)) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = ShopGoldStar, modifier = Modifier.size(16.dp))
                        Text(
                            text = "${product.ratingX10 / 10}.${product.ratingX10 % 10}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = DarkNavy
                        )
                    }
                }
                Text(
                    text = "${product.soldCount} sold • ${MoneyUtils.milliUnitsToString(product.stockMilliUnits, useBanglaDigits)} ${product.unit} in stock",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (product.onlineDescription.isNotBlank()) {
                Text(product.onlineDescription, style = MaterialTheme.typography.bodyMedium)
            } else {
                Text(
                    text = if (strings.isBangla) {
                        "বিভাগ: ${product.category} • একক: ${product.unit}। স্টক থেকে সরাসরি ডেলিভারি।"
                    } else {
                        "Category: ${product.category} • Unit: ${product.unit}. Fulfilled directly from shop inventory."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    if (strings.isBangla) "পরিমাণ (${product.unit})" else "Quantity (${product.unit})",
                    style = MaterialTheme.typography.titleSmall
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalIconButton(
                        onClick = {
                            val current = MoneyUtils.parseQtyToMilliUnits(qtyInput)
                            val next = (current - 1_000L).coerceAtLeast(1_000L)
                            qtyInput = MoneyUtils.milliUnitsToString(next)
                        }
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease quantity")
                    }
                    Text(
                        text = MoneyUtils.milliUnitsToString(selectedQtyMilli, useBanglaDigits),
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    FilledTonalIconButton(
                        onClick = {
                            val current = MoneyUtils.parseQtyToMilliUnits(qtyInput)
                            qtyInput = MoneyUtils.milliUnitsToString(current + 1_000L)
                        }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase quantity")
                    }
                }
            }

            if (cartQuantityMilliUnits > 0L) {
                Text(
                    text = if (strings.isBangla) {
                        "কার্টে আগে থেকেই ${MoneyUtils.milliUnitsToString(cartQuantityMilliUnits, true)} ${product.unit} আছে"
                    } else {
                        "Already in cart: ${MoneyUtils.milliUnitsToString(cartQuantityMilliUnits)} ${product.unit}"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = EmeraldPrimary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onAddToCart(selectedQtyMilli)
                        onDismiss()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 50.dp)
                        .testTag("detail_add_to_cart_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, ShopOrange),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ShopOrange)
                ) {
                    Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.addToCartLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Button(
                    onClick = {
                        onBuyNow(selectedQtyMilli)
                        onDismiss()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 50.dp)
                        .testTag("detail_buy_now_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ShopOrange)
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.buyNowLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CartCheckoutBottomSheet(
    state: OnlineShopUiState,
    directBuyItem: Pair<ProductEntity, Long>?,
    useBanglaDigits: Boolean,
    previewPromoDiscount: (Long, String) -> Long,
    onSetCartQuantity: (String, Long) -> Unit,
    onPlaceOrder: (
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        deliveryDistrict: String,
        deliveryFeePaisa: Long,
        promoCode: String,
        paymentMethod: String,
        accountId: String?,
        customerId: String?,
        notes: String,
        mfsTrxId: String,
        mfsSenderPhone: String
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }
    var deliveryZone by remember { mutableStateOf("Dhaka") } // Dhaka (৳60), Outside Dhaka (৳120), Pickup (৳0)
    var promoInput by remember { mutableStateOf("") }
    var appliedPromo by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(OnlinePaymentMethods.COD) }
    var selectedAccountId by remember(state.accounts) {
        mutableStateOf(state.accounts.firstOrNull { it.isDefault || it.type == AccountTypes.CASH }?.id)
    }
    var mfsTrxId by remember { mutableStateOf("") }
    var mfsSenderPhone by remember { mutableStateOf("") }
    var walletCopied by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }

    val lineSummaries = remember(directBuyItem, state.cartItems) {
        if (directBuyItem != null) {
            val (prod, qty) = directBuyItem
            listOf(
                Triple(
                    prod,
                    qty,
                    MoneyUtils.calculateLineTotalPaisa(qty, prod.sellingPricePaisa)
                )
            )
        } else {
            state.cartItems.map { Triple(it.product, it.quantityMilliUnits, it.lineTotalPaisa) }
        }
    }
    val subtotalPaisa = lineSummaries.sumOf { it.third }
    val deliveryFeePaisa = when (deliveryZone) {
        "Dhaka" -> 6_000L
        "Outside Dhaka" -> 12_000L
        else -> 0L
    }
    val discountPaisa = previewPromoDiscount(subtotalPaisa, appliedPromo)
    val grandTotalPaisa = (subtotalPaisa - discountPaisa).coerceAtLeast(0L) + deliveryFeePaisa

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (directBuyItem != null) strings.buyNowLabel else strings.checkoutLabel,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            // Cart items list
            lineSummaries.forEach { (prod, qty, total) ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = "${MoneyUtils.milliUnitsToString(qty, useBanglaDigits)} ${prod.unit} × ${MoneyUtils.formatTaka(prod.sellingPricePaisa, useBanglaDigits)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (directBuyItem == null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { onSetCartQuantity(prod.id, (qty - 1_000L).coerceAtLeast(0L)) }) {
                                    Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease")
                                }
                                IconButton(onClick = { onSetCartQuantity(prod.id, qty + 1_000L) }) {
                                    Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = ShopOrange)
                                }
                            }
                        }
                        Text(
                            text = MoneyUtils.formatTaka(total, useBanglaDigits),
                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            // Pick Existing Customer shortcut
            if (state.customers.isNotEmpty()) {
                Text(
                    text = if (strings.isBangla) "বিদ্যমান ক্রেতা বেছে নিন (ঐচ্ছিক)" else "Quick Select Customer (Optional)",
                    style = MaterialTheme.typography.labelMedium
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(state.customers.take(8), key = { it.id }) { c ->
                        FilterChip(
                            selected = selectedCustomer?.id == c.id,
                            onClick = {
                                if (selectedCustomer?.id == c.id) {
                                    selectedCustomer = null
                                } else {
                                    selectedCustomer = c
                                    customerName = c.name
                                    customerPhone = c.phone
                                    if (deliveryAddress.isBlank()) deliveryAddress = c.address
                                }
                            },
                            label = { Text(c.name) }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text(if (strings.isBangla) "ক্রেতার নাম *" else "Receiver Name *") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_customer_name_input")
            )
            OutlinedTextField(
                value = customerPhone,
                onValueChange = { customerPhone = it },
                label = { Text(if (strings.isBangla) "মোবাইল নম্বর (+880)" else "Phone Number (+880)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_customer_phone_input")
            )
            OutlinedTextField(
                value = deliveryAddress,
                onValueChange = { deliveryAddress = it },
                label = { Text(if (strings.isBangla) "ডেলিভারি ঠিকানা" else "Delivery Address") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("checkout_address_input")
            )

            // Delivery Zone
            Text(strings.deliveryFeeLabel, style = MaterialTheme.typography.labelMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Dhaka" to "Inside Dhaka (৳60)",
                    "Outside Dhaka" to "Outside Dhaka (৳120)",
                    "Pickup" to "Shop Pickup (৳0)"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = deliveryZone == key,
                        onClick = { deliveryZone = key },
                        label = { Text(label) }
                    )
                }
            }

            // Promo Code
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = promoInput,
                    onValueChange = { promoInput = it.uppercase() },
                    label = { Text("Promo Code (SAVE50 / HISAB10)") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("checkout_promo_input")
                )
                FilledTonalButton(
                    onClick = { appliedPromo = promoInput.trim().uppercase() },
                    modifier = Modifier.heightIn(min = 50.dp)
                ) {
                    Text("Apply")
                }
            }

            // Payment Method
            Text(
                if (strings.isBangla) "পেমেন্ট মাধ্যম" else "Payment Method",
                style = MaterialTheme.typography.labelMedium
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    OnlinePaymentMethods.COD to "Cash on Delivery",
                    OnlinePaymentMethods.BKASH to "bKash",
                    OnlinePaymentMethods.NAGAD to "Nagad",
                    OnlinePaymentMethods.ROCKET to "Rocket",
                    OnlinePaymentMethods.UPAY to "Upay",
                    OnlinePaymentMethods.BANK to "Bank",
                    OnlinePaymentMethods.BAKI_CREDIT to "Baki Credit"
                ).forEach { (method, label) ->
                    FilterChip(
                        selected = paymentMethod == method,
                        onClick = {
                            paymentMethod = method
                            walletCopied = false
                            val matchingAcc = when (method) {
                                OnlinePaymentMethods.BKASH -> state.accounts.firstOrNull { it.type == AccountTypes.BKASH }
                                OnlinePaymentMethods.NAGAD -> state.accounts.firstOrNull { it.type == AccountTypes.NAGAD }
                                OnlinePaymentMethods.ROCKET -> state.accounts.firstOrNull { it.type == AccountTypes.ROCKET }
                                OnlinePaymentMethods.UPAY -> state.accounts.firstOrNull { it.type == AccountTypes.UPAY }
                                OnlinePaymentMethods.BANK -> state.accounts.firstOrNull { it.type == AccountTypes.BANK }
                                else -> state.accounts.firstOrNull { it.type == AccountTypes.CASH || it.isDefault }
                            }
                            if (matchingAcc != null) selectedAccountId = matchingAcc.id
                        },
                        label = { Text(label) }
                    )
                }
            }

            if (MfsPaymentParser.isMfsMethod(paymentMethod)) {
                val mfsSpec = MfsPaymentParser.specFor(paymentMethod)
                val targetAcc = state.accounts.firstOrNull { it.id == selectedAccountId }
                    ?: state.accounts.firstOrNull { it.type == (mfsSpec?.accountType ?: "") }
                val walletNum = targetAcc?.accountNumber?.ifBlank { state.activeBusiness?.phone.orEmpty() }
                    ?: state.activeBusiness?.phone.orEmpty()
                val mfsAccent = mfsBrandColor(paymentMethod)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = mfsAccent.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, mfsAccent.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${mfsSpec?.labelEn ?: paymentMethod} • ${targetAcc?.name ?: "Wallet"}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = mfsAccent,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (walletNum.isNotBlank()) {
                                        if (strings.isBangla) "টাকা পাঠানোর নম্বর: $walletNum" else "Send Money / Pay to: $walletNum"
                                    } else {
                                        if (strings.isBangla) "MFS ওয়ালেট নম্বর সেট করুন" else "Set merchant wallet number in MFS Setup"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (walletNum.isNotBlank()) {
                                    IconButton(onClick = {
                                        clipboard.setText(AnnotatedString(walletNum))
                                        walletCopied = true
                                    }) {
                                        Icon(
                                            if (walletCopied) Icons.Default.Done else Icons.Default.ContentCopy,
                                            contentDescription = "Copy Wallet",
                                            tint = mfsAccent
                                        )
                                    }
                                }
                                IconButton(onClick = { MfsPaymentParser.openMfsAppOrUssd(context, paymentMethod) }) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = "Open MFS", tint = mfsAccent)
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = mfsTrxId,
                                onValueChange = { mfsTrxId = it.uppercase() },
                                label = { Text("${strings.mfsTrxIdLabel} (Optional)") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1.2f)
                                    .testTag("checkout_mfs_trxid_input")
                            )
                            OutlinedButton(
                                onClick = {
                                    clipboard.getText()?.text?.let { sms ->
                                        val parsed = MfsPaymentParser.parseReceiptSms(sms)
                                        if (parsed.trxId.isNotBlank()) mfsTrxId = parsed.trxId
                                        if (parsed.senderPhone.isNotBlank()) mfsSenderPhone = parsed.senderPhone
                                    }
                                },
                                modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("SMS", maxLines = 1)
                            }
                        }
                        OutlinedTextField(
                            value = mfsSenderPhone,
                            onValueChange = { mfsSenderPhone = it },
                            label = { Text(if (strings.isBangla) "প্রেরকের MFS নম্বর (ঐচ্ছিক)" else "Sender MFS Mobile (Optional)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            if (paymentMethod != OnlinePaymentMethods.COD && paymentMethod != OnlinePaymentMethods.BAKI_CREDIT && state.accounts.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(state.accounts, key = { it.id }) { acc ->
                        FilterChip(
                            selected = selectedAccountId == acc.id,
                            onClick = { selectedAccountId = acc.id },
                            label = { Text(acc.name) }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(if (strings.isBangla) "নোট (ঐচ্ছিক)" else "Order Note (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Order Summary Card
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SoftGreenAccent,
                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SummaryPriceRow("Subtotal", MoneyUtils.formatTaka(subtotalPaisa, useBanglaDigits))
                    if (discountPaisa > 0L) {
                        SummaryPriceRow(
                            "Promo ($appliedPromo)",
                            "-${MoneyUtils.formatTaka(discountPaisa, useBanglaDigits)}",
                            EmeraldPrimary
                        )
                    }
                    SummaryPriceRow(strings.deliveryFeeLabel, MoneyUtils.formatTaka(deliveryFeePaisa, useBanglaDigits))
                    HorizontalDivider(color = EmeraldPrimary.copy(alpha = 0.25f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total Payable", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DarkNavy)
                        Text(
                            MoneyUtils.formatTaka(grandTotalPaisa, useBanglaDigits),
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                            color = ShopOrange
                        )
                    }
                }
            }

            Button(
                onClick = {
                    onPlaceOrder(
                        customerName,
                        customerPhone,
                        deliveryAddress,
                        deliveryZone,
                        deliveryFeePaisa,
                        appliedPromo,
                        paymentMethod,
                        selectedAccountId,
                        selectedCustomer?.id,
                        notes,
                        mfsTrxId.trim().uppercase(),
                        mfsSenderPhone.trim()
                    )
                    onDismiss()
                },
                enabled = customerName.isNotBlank() && lineSummaries.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = ShopOrange),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("place_online_order_button")
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("${strings.placeOrderLabel} • ${MoneyUtils.formatTaka(grandTotalPaisa, useBanglaDigits)}")
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SummaryPriceRow(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color = DarkNavy
) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = DarkNavy.copy(alpha = 0.8f))
        Text(value, style = MaterialTheme.typography.bodyMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.SemiBold), color = valueColor)
    }
}

@Composable
fun OnlineListingEditorDialog(
    product: ProductEntity,
    onSave: (onlineListed: Boolean, comparePricePaisa: Long, description: String, isFlashDeal: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var onlineListed by remember(product.id) { mutableStateOf(product.onlineListed) }
    var isFlashDeal by remember(product.id) { mutableStateOf(product.isFlashDeal) }
    var comparePriceInput by remember(product.id) {
        mutableStateOf(
            if (product.onlineComparePricePaisa > 0L) (product.onlineComparePricePaisa / 100.0).toInt().toString() else ""
        )
    }
    var description by remember(product.id) { mutableStateOf(product.onlineDescription) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Shop Listing: ${product.name}") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Visible in Online Shop", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = onlineListed, onCheckedChange = { onlineListed = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Feature in Flash Deals", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isFlashDeal, onCheckedChange = { isFlashDeal = it })
                }
                OutlinedTextField(
                    value = comparePriceInput,
                    onValueChange = { comparePriceInput = it },
                    label = { Text("Compare / MRP Price (৳, optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Online Store Description") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val comparePaisa = if (comparePriceInput.isBlank()) 0L else MoneyUtils.parseTakaToPaisa(comparePriceInput)
                    onSave(onlineListed, comparePaisa, description, isFlashDeal)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = ShopOrange)
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuickAddShopProductDialog(
    onSaveProduct: (String?, String, String, String, String, Long, Long, Long, String, Long, String?) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }
    var buyPrice by remember { mutableStateOf("") }
    var sellPrice by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("10") }
    var unit by remember { mutableStateOf("Piece") }
    var imgUri by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) imgUri = uri.toString()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Online Shop Product") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) {
                    Text(if (imgUri == null) "Select Product Photo (Optional)" else "Photo Selected")
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = buyPrice,
                        onValueChange = { buyPrice = it },
                        label = { Text("Buy (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it },
                        label = { Text("Sell (৳) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = stock,
                    onValueChange = { stock = it },
                    label = { Text("Opening Stock") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Piece", "KG", "Liter", "Box", "Packet").forEach { u ->
                        FilterChip(selected = unit == u, onClick = { unit = u }, label = { Text(u) })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanSell = MoneyUtils.parseTakaToPaisa(sellPrice)
                    if (name.isNotBlank() && cleanSell > 0L) {
                        onSaveProduct(
                            null, name, "", "", category,
                            MoneyUtils.parseTakaToPaisa(buyPrice),
                            cleanSell,
                            MoneyUtils.parseQtyToMilliUnits(stock).coerceAtLeast(1_000L),
                            unit, 5_000L, imgUri
                        )
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ShopOrange)
            ) { Text("Add Product") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun OrderSuccessDialog(
    order: OnlineOrderEntity,
    useBanglaDigits: Boolean,
    onShareOrder: (OnlineOrderEntity) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(40.dp)) },
        title = { Text("Order ${order.orderNumber} Confirmed!") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Customer: ${order.customerName}")
                Text("Total: ${MoneyUtils.formatTaka(order.totalPaisa, useBanglaDigits)}")
                Text("Payment: ${order.paymentMethod} (${order.paymentStatus})")
                if (order.mfsTrxId.isNotBlank()) {
                    Text("TrxID: ${order.mfsTrxId}", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                }
                Text(
                    if (order.invoiceId != null) {
                        "Posted directly to sales ledger & stock updated."
                    } else {
                        "COD order created. It will post to ledger when marked Delivered."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onShareOrder(order) },
                colors = ButtonDefaults.buttonColors(containerColor = ShopOrange)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Share Receipt")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}

fun shareOnlineShopCatalog(context: Context, businessName: String, products: List<ProductEntity>, useBn: Boolean) {
    val lines = buildString {
        appendLine("🛍️ *$businessName — Online Shop*")
        appendLine("Order directly via WhatsApp or Cash on Delivery:")
        appendLine()
        products.take(25).forEachIndexed { idx, p ->
            val price = MoneyUtils.formatTaka(p.sellingPricePaisa, useBn)
            val stockTag = if (p.stockMilliUnits > 0L) "In Stock" else "Pre-order"
            appendLine("${idx + 1}. ${p.name} — $price/${p.unit} ($stockTag)")
        }
        appendLine()
        appendLine("Promo Codes: SAVE50 (৳50 off) • HISAB10 (10% off)")
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, lines)
    }
    context.startActivity(Intent.createChooser(intent, "Share Online Shop Catalog"))
}

fun shareOnlineOrderSummary(
    context: Context,
    businessName: String,
    order: OnlineOrderEntity,
    items: List<OnlineOrderItemEntity>,
    useBn: Boolean
) {
    val msg = buildString {
        appendLine("📦 *$businessName — Order ${order.orderNumber}*")
        appendLine("Status: ${order.orderStatus} | Payment: ${order.paymentMethod} (${order.paymentStatus})")
        if (order.mfsTrxId.isNotBlank()) {
            appendLine("TrxID: ${order.mfsTrxId}${if (order.mfsSenderPhone.isNotBlank()) " (From ${order.mfsSenderPhone})" else ""}")
        }
        appendLine("Customer: ${order.customerName} (${order.customerPhone})")
        if (order.deliveryAddress.isNotBlank()) {
            appendLine("Address: ${order.deliveryAddress} (${order.deliveryDistrict})")
        }
        appendLine()
        items.forEach { item ->
            appendLine("• ${item.productName} × ${MoneyUtils.milliUnitsToString(item.quantityMilliUnits, useBn)} ${item.unit} = ${MoneyUtils.formatTaka(item.lineTotalPaisa, useBn)}")
        }
        appendLine()
        appendLine("Delivery: ${MoneyUtils.formatTaka(order.deliveryFeePaisa, useBn)}")
        if (order.discountPaisa > 0L) appendLine("Discount: -${MoneyUtils.formatTaka(order.discountPaisa, useBn)}")
        appendLine("*Total: ${MoneyUtils.formatTaka(order.totalPaisa, useBn)}*")
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, msg)
    }
    context.startActivity(Intent.createChooser(intent, "Share Order ${order.orderNumber}"))
}
