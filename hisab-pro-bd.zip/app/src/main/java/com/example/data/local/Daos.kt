package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BusinessDao {
    @Query("SELECT * FROM businesses WHERE archived = 0 ORDER BY createdAt ASC")
    fun observeBusinesses(): Flow<List<BusinessEntity>>

    @Query("SELECT * FROM businesses WHERE archived = 0 ORDER BY createdAt ASC")
    suspend fun getAllBusinessesSync(): List<BusinessEntity>

    @Query("SELECT * FROM businesses WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): BusinessEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(business: BusinessEntity)
}

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts WHERE businessId = :businessId AND archived = 0 ORDER BY isDefault DESC, createdAt ASC")
    fun observeAccounts(businessId: String): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE businessId = :businessId AND archived = 0")
    suspend fun getAccountsSync(businessId: String): List<AccountEntity>

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(account: AccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(accounts: List<AccountEntity>)

    @Query("UPDATE accounts SET currentBalancePaisa = :newBalance WHERE id = :accountId")
    suspend fun updateBalance(accountId: String, newBalance: Long)

    @Query("UPDATE accounts SET openingBalancePaisa = 0, currentBalancePaisa = 0 WHERE businessId = :businessId")
    suspend fun resetBalancesForBusiness(businessId: String)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE businessId = :businessId AND archived = 0 ORDER BY name ASC")
    fun observeCustomers(businessId: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE businessId = :businessId AND archived = 1 ORDER BY name ASC")
    fun observeArchivedCustomers(businessId: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE businessId = :businessId")
    suspend fun getCustomersSync(businessId: String): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CustomerEntity?

    @Query("SELECT COUNT(*) FROM customers WHERE businessId = :businessId")
    suspend fun countForBusiness(businessId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(customers: List<CustomerEntity>)

    @Update
    suspend fun update(customer: CustomerEntity)

    @Query(
        "UPDATE customers SET openingDuePaisa = 0, currentDuePaisa = 0, totalPurchasesPaisa = 0, " +
            "totalPaymentsPaisa = 0, overdueSinceMillis = NULL, updatedAt = :now, syncVersion = syncVersion + 1 " +
            "WHERE businessId = :businessId"
    )
    suspend fun resetBalancesForBusiness(businessId: String, now: Long)

    @Query("DELETE FROM customers WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE businessId = :businessId AND archived = 0 ORDER BY name ASC")
    fun observeSuppliers(businessId: String): Flow<List<SupplierEntity>>

    @Query("SELECT * FROM suppliers WHERE businessId = :businessId")
    suspend fun getSuppliersSync(businessId: String): List<SupplierEntity>

    @Query("SELECT * FROM suppliers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): SupplierEntity?

    @Query("SELECT COUNT(*) FROM suppliers WHERE businessId = :businessId")
    suspend fun countForBusiness(businessId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(supplier: SupplierEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(suppliers: List<SupplierEntity>)

    @Update
    suspend fun update(supplier: SupplierEntity)

    @Query(
        "UPDATE suppliers SET openingPayablePaisa = 0, currentPayablePaisa = 0, totalPurchasesPaisa = 0, " +
            "totalPaymentsPaisa = 0, updatedAt = :now, syncVersion = syncVersion + 1 " +
            "WHERE businessId = :businessId"
    )
    suspend fun resetBalancesForBusiness(businessId: String, now: Long)

    @Query("DELETE FROM suppliers WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE businessId = :businessId AND archived = 0 ORDER BY name ASC")
    fun observeProducts(businessId: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE businessId = :businessId")
    suspend fun getProductsSync(businessId: String): List<ProductEntity>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(products: List<ProductEntity>)

    @Query("UPDATE products SET stockMilliUnits = :newStock, updatedAt = :updatedAt, syncVersion = syncVersion + 1 WHERE id = :productId")
    suspend fun updateStock(productId: String, newStock: Long, updatedAt: Long)

    @Query("DELETE FROM products WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface StockMovementDao {
    @Query("SELECT * FROM stock_movements WHERE businessId = :businessId ORDER BY occurredAt DESC LIMIT 200")
    fun observeMovements(businessId: String): Flow<List<StockMovementEntity>>

    @Query("SELECT * FROM stock_movements WHERE businessId = :businessId")
    suspend fun getMovementsSync(businessId: String): List<StockMovementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(movement: StockMovementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(movements: List<StockMovementEntity>)

    @Query("DELETE FROM stock_movements WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE businessId = :businessId ORDER BY isSystem DESC, name ASC")
    fun observeCategories(businessId: String): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE businessId = :businessId")
    suspend fun getCategoriesSync(businessId: String): List<CategoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(categories: List<CategoryEntity>)
}

@Dao
interface AccountingTransactionDao {
    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId ORDER BY occurredAt DESC, createdAt DESC")
    fun observeTransactions(businessId: String): Flow<List<AccountingTransactionEntity>>

    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId AND customerId = :customerId ORDER BY occurredAt DESC")
    fun observeCustomerTransactions(businessId: String, customerId: String): Flow<List<AccountingTransactionEntity>>

    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId AND supplierId = :supplierId ORDER BY occurredAt DESC")
    fun observeSupplierTransactions(businessId: String, supplierId: String): Flow<List<AccountingTransactionEntity>>

    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId ORDER BY occurredAt DESC")
    suspend fun getTransactionsSync(businessId: String): List<AccountingTransactionEntity>

    @Query("SELECT * FROM accounting_transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AccountingTransactionEntity?

    @Query("SELECT * FROM accounting_transactions WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getByIdempotencyKey(key: String): AccountingTransactionEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(tx: AccountingTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(txs: List<AccountingTransactionEntity>)

    @Query("UPDATE accounting_transactions SET isReversed = 1, syncVersion = syncVersion + 1 WHERE id = :txId")
    suspend fun markReversed(txId: String)

    @Query("DELETE FROM accounting_transactions WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices WHERE businessId = :businessId ORDER BY occurredAt DESC")
    fun observeInvoices(businessId: String): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE businessId = :businessId")
    suspend fun getInvoicesSync(businessId: String): List<InvoiceEntity>

    @Query("SELECT * FROM invoices WHERE id = :invoiceId LIMIT 1")
    suspend fun getInvoiceById(invoiceId: String): InvoiceEntity?

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId")
    suspend fun getItemsForInvoice(invoiceId: String): List<InvoiceItemEntity>

    @Query("SELECT * FROM invoice_items WHERE invoiceId IN (SELECT id FROM invoices WHERE businessId = :businessId)")
    fun observeAllInvoiceItems(businessId: String): Flow<List<InvoiceItemEntity>>

    @Query("SELECT * FROM invoice_items WHERE invoiceId IN (SELECT id FROM invoices WHERE businessId = :businessId)")
    suspend fun getAllInvoiceItemsSync(businessId: String): List<InvoiceItemEntity>

    @Query("SELECT COUNT(*) FROM invoices WHERE businessId = :businessId AND invoiceType = :type")
    suspend fun countInvoices(businessId: String, type: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<InvoiceItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoices(invoices: List<InvoiceEntity>)

    @Query("UPDATE invoice_items SET returnedMilliUnits = returnedMilliUnits + :qty WHERE id = :itemId")
    suspend fun incrementReturnedQty(itemId: String, qty: Long)

    @Query("DELETE FROM invoice_items WHERE invoiceId IN (SELECT id FROM invoices WHERE businessId = :businessId)")
    suspend fun deleteAllItemsForBusiness(businessId: String)

    @Query("DELETE FROM invoices WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface EmployeeDao {
    @Query("SELECT * FROM employees WHERE businessId = :businessId ORDER BY createdAt ASC")
    fun observeEmployees(businessId: String): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM employees WHERE businessId = :businessId")
    suspend fun getEmployeesSync(businessId: String): List<EmployeeEntity>

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): EmployeeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(employee: EmployeeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(employees: List<EmployeeEntity>)

    @Query("DELETE FROM employees WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface AppNotificationDao {
    @Query("SELECT * FROM app_notifications WHERE businessId = :businessId ORDER BY createdAt DESC LIMIT 100")
    fun observeNotifications(businessId: String): Flow<List<AppNotificationEntity>>

    @Query("SELECT COUNT(*) FROM app_notifications WHERE businessId = :businessId AND isRead = 0")
    fun observeUnreadCount(businessId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: AppNotificationEntity)

    @Query("UPDATE app_notifications SET isRead = 1 WHERE businessId = :businessId")
    suspend fun markAllRead(businessId: String)

    @Query("DELETE FROM app_notifications WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records WHERE businessId = :businessId ORDER BY dateKey DESC, createdAt DESC LIMIT 300")
    fun observeAttendance(businessId: String): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance_records WHERE businessId = :businessId AND dateKey = :dateKey")
    suspend fun getForDate(businessId: String, dateKey: String): List<AttendanceEntity>

    @Query("SELECT * FROM attendance_records WHERE businessId = :businessId AND employeeId = :employeeId AND dateKey = :dateKey LIMIT 1")
    suspend fun getForEmployeeDate(businessId: String, employeeId: String, dateKey: String): AttendanceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: AttendanceEntity)

    @Query("DELETE FROM attendance_records WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface LeaveRequestDao {
    @Query("SELECT * FROM leave_requests WHERE businessId = :businessId ORDER BY createdAt DESC LIMIT 200")
    fun observeLeaves(businessId: String): Flow<List<LeaveRequestEntity>>

    @Query("SELECT * FROM leave_requests WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): LeaveRequestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: LeaveRequestEntity)

    @Query("DELETE FROM leave_requests WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface SalaryPaymentDao {
    @Query("SELECT * FROM salary_payments WHERE businessId = :businessId ORDER BY occurredAt DESC LIMIT 200")
    fun observeSalaryPayments(businessId: String): Flow<List<SalaryPaymentEntity>>

    @Query("SELECT * FROM salary_payments WHERE businessId = :businessId")
    suspend fun getSalaryPaymentsSync(businessId: String): List<SalaryPaymentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(payment: SalaryPaymentEntity)

    @Query("DELETE FROM salary_payments WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface ActivityLogDao {
    @Query("SELECT * FROM activity_logs WHERE businessId = :businessId ORDER BY occurredAt DESC LIMIT 300")
    fun observeActivityLogs(businessId: String): Flow<List<ActivityLogEntity>>

    @Query("SELECT * FROM activity_logs WHERE businessId = :businessId ORDER BY occurredAt DESC LIMIT 300")
    suspend fun getActivityLogsSync(businessId: String): List<ActivityLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: ActivityLogEntity)
}

@Dao
interface RolePermissionDao {
    @Query("SELECT * FROM role_permissions WHERE businessId = :businessId ORDER BY roleName ASC")
    fun observeRolePermissions(businessId: String): Flow<List<RolePermissionEntity>>

    @Query("SELECT * FROM role_permissions WHERE businessId = :businessId")
    suspend fun getRolePermissionsSync(businessId: String): List<RolePermissionEntity>

    @Query("SELECT * FROM role_permissions WHERE businessId = :businessId AND roleName = :roleName LIMIT 1")
    suspend fun getForRole(businessId: String, roleName: String): RolePermissionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(permission: RolePermissionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(permissions: List<RolePermissionEntity>)
}

@Dao
interface SyncOutboxDao {
    @Query("SELECT * FROM sync_outbox ORDER BY updatedAtMillis DESC")
    fun observeAll(): Flow<List<SyncOutboxEntity>>

    @Query("SELECT * FROM sync_outbox WHERE status = :status ORDER BY updatedAtMillis ASC")
    suspend fun getByStatusSync(status: String): List<SyncOutboxEntity>

    @Query("SELECT * FROM sync_outbox WHERE status = 'CONFLICT' ORDER BY updatedAtMillis DESC")
    fun observeConflicts(): Flow<List<SyncOutboxEntity>>

    @Query("SELECT COUNT(*) FROM sync_outbox WHERE status = 'PENDING'")
    fun observePendingCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: SyncOutboxEntity)

    @Query("UPDATE sync_outbox SET status = 'SYNCED', conflictDetail = '' WHERE id = :id")
    suspend fun markSynced(id: String)

    @Query("DELETE FROM sync_outbox WHERE status = 'SYNCED'")
    suspend fun purgeSynced()

    @Query("DELETE FROM sync_outbox WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM sync_outbox WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}

@Dao
interface AuthorizedDeviceDao {
    @Query("SELECT * FROM authorized_devices WHERE userId = :userId ORDER BY lastSyncAtMillis DESC")
    fun observeDevices(userId: String): Flow<List<AuthorizedDeviceEntity>>

    @Query("SELECT * FROM authorized_devices WHERE userId = :userId")
    suspend fun getDevicesSync(userId: String): List<AuthorizedDeviceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(device: AuthorizedDeviceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(devices: List<AuthorizedDeviceEntity>)

    @Query("UPDATE authorized_devices SET revoked = :revoked WHERE id = :deviceId")
    suspend fun setRevoked(deviceId: String, revoked: Boolean)
}

@Dao
interface BakiKhataDao {
    @Query("SELECT * FROM baki_khata_entries WHERE businessId = :businessId ORDER BY entryDateMillis DESC, createdAt DESC")
    fun observeEntriesForBusiness(businessId: String): Flow<List<BakiKhataEntryEntity>>

    @Query("SELECT * FROM baki_khata_entries WHERE businessId = :businessId AND customerId = :customerId ORDER BY entryDateMillis DESC, createdAt DESC")
    fun observeEntriesForCustomer(businessId: String, customerId: String): Flow<List<BakiKhataEntryEntity>>

    @Query(
        "SELECT * FROM baki_khata_entries WHERE businessId = :businessId AND entryType = 'CREDIT' " +
            "AND isSettled = 0 AND promisedRepaymentDateMillis IS NOT NULL ORDER BY promisedRepaymentDateMillis ASC"
    )
    fun observeUpcomingOrOverdueDues(businessId: String): Flow<List<BakiKhataEntryEntity>>

    @Query("SELECT * FROM baki_khata_entries WHERE businessId = :businessId ORDER BY entryDateMillis DESC, createdAt DESC")
    suspend fun getEntriesForBusinessSync(businessId: String): List<BakiKhataEntryEntity>

    @Query("SELECT * FROM baki_khata_entries WHERE customerId = :customerId ORDER BY entryDateMillis DESC, createdAt DESC")
    suspend fun getEntriesForCustomerSync(customerId: String): List<BakiKhataEntryEntity>

    @Query("SELECT * FROM baki_khata_entries WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): BakiKhataEntryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: BakiKhataEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<BakiKhataEntryEntity>)

    @Query(
        "UPDATE baki_khata_entries SET isSettled = 1, actualRepaymentDateMillis = :repaymentDateMillis, " +
            "syncVersion = syncVersion + 1 WHERE id = :entryId"
    )
    suspend fun markEntrySettled(entryId: String, repaymentDateMillis: Long)

    @Query(
        "UPDATE baki_khata_entries SET isSettled = 1, " +
            "actualRepaymentDateMillis = COALESCE(actualRepaymentDateMillis, :repaymentDateMillis), " +
            "syncVersion = syncVersion + 1 " +
            "WHERE customerId = :customerId AND entryType = 'CREDIT' AND isSettled = 0"
    )
    suspend fun markOpenCreditsSettledForCustomer(customerId: String, repaymentDateMillis: Long)

    @Query("DELETE FROM baki_khata_entries WHERE businessId = :businessId")
    suspend fun deleteAllForBusiness(businessId: String)
}
