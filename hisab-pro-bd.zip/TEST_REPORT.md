# HISAB PRO BD — Verification & Test Report

**Application ID:** `com.aistudio.hisabprobd.kxmzpq`  
**Build Variant:** `debug` (`app/build/outputs/apk/debug/app-debug.apk`)  
**Report Date:** 2026-11-25

---

## 1. Architecture & Non-Destructive Upgrade Audit

- **Database Preservation (`HisabDatabase` v1 → v2 via `MIGRATION_1_2`)**:
  - Added versioned sync columns (`syncVersion`, `lastModifiedDeviceId`, `deviceId`) and extended employee HR/RBAC columns (`email`, `salaryPaisa`, `canRecordSales`, `canEditCustomers`, `canManageInventory`) non-destructively via `ALTER TABLE`.
  - Added 7 new Pro tables (`attendance_records`, `leave_requests`, `salary_payments`, `activity_logs`, `role_permissions`, `sync_outbox`, `authorized_devices`) with indices.
  - Zero destructive migrations (`fallbackToDestructiveMigration` is not used).
- **AI Business Assistant & App Check**:
  - `configureAppCheck(this, intent)` initialized in `MainActivity.onCreate()` before any Firebase service calls.
  - `AiBusinessAssistant` uses `Firebase.ai.generativeModel("gemini-3.8-flash")` with real Room ledger/invoice/inventory context, explicit date-range reporting, zero vs. unavailable data distinction, and confirmation-gated write proposals.
- **Voice Accounting**:
  - `VoiceAccountingParser` supports Bangla & English speech/text commands, Bangla-to-Latin consonant-skeleton cross-script customer/product matching, ambiguous customer disambiguation, and 5-minute duplicate transaction detection.
- **Security & Encrypted Backups**:
  - `SecurityUtils` implements PBKDF2WithHmacSHA256 (100,000 iterations) + AES-256-GCM authenticated encryption (`HISAB_PRO_ENC_V1`) for `.hisabenc` backup export and passphrase-prompted restore.

---

## 2. Unit & Robolectric Test Suite (`:app:testDebugUnitTest`)

**Command Executed:**
```bash
JAVA_TOOL_OPTIONS="-Drobolectric.offline=true -Drobolectric.dependency.dir=/home/appuser/.m2/repository/org/robolectric/android-all-instrumented/16-robolectric-13921718-i7" \
  gradle :app:testDebugUnitTest --tests "com.example.*" --console=plain
```

**Overall Result:** **19 / 19 Passed** (`0` failures, `0` errors, `0` skipped)

| Test Suite | Tests | Passed | Failed | Key Coverage |
|---|---:|---:|---:|---|
| `ProUpgradeRobolectricTest` | 6 | 6 | 0 | Room `MIGRATION_1_2` data preservation, Bangla/English Voice NLP & cross-script ambiguity/duplicate detection, Pro Analytics (MoM growth, missing-cost flag, health score, calendar), AES-256-GCM encrypted backup roundtrip & wrong-passphrase rejection, HR salary/attendance/leave/RBAC propagation & outbox conflict resolution, Code-128 bitmap + ESC/POS payload + UTF-8 CSV export |
| `HisabDatabaseRobolectricTest` | 4 | 4 | 0 | Baki Khata due ledger & partial payments, POS stock/COGS/profit & non-profit transfers, reversible audit ledger, multi-business data isolation |
| `AccountingEngineTest` | 4 | 4 | 0 | Taka/Paisa BigDecimal parsing, Bangla numerals, `HALF_UP` line/tax math, BD phone formatting, Asia/Dhaka (`UTC+6`) day bounds |
| `GitHubReleaseUpdaterTest` | 3 | 3 | 0 | GitHub slug/URL normalization, SemVer comparison, release APK asset selection |
| `ExampleRobolectricTest` | 1 | 1 | 0 | Robolectric Android context resource verification |
| `ExampleUnitTest` | 1 | 1 | 0 | JVM baseline verification |

*Note on Robolectric PDF testing:* Android's native `PdfDocument` relies on native `libhwui`/PDFium (`mNativeDocument = 0` under Robolectric API 36), so `ExportUtils.generateReportPdf` is guarded in the Robolectric test while Code-128 Bitmap rendering, ESC/POS thermal payload construction, and UTF-8 Bangla CSV generation are verified directly in full.

---

## 3. Firestore Security Rules Verification

- **Rules File:** `firestore.rules` (deployed to project Firestore database)
- **Test File:** `firestore.test.js`
- **Coverage:** Unauthenticated deny, authenticated owner CRUD across businesses/ledgers/devices, cross-user access denial, and revoked-device write denial (`3/3` emulator test suites passed during rules verification).

---

## 4. Compilation & Debug APK Build

- `compile_applet`: **Succeeded**
- `gradle :app:assembleDebug --console=plain`: **Succeeded**
- **Output Artifact:** `app/build/outputs/apk/debug/app-debug.apk`
