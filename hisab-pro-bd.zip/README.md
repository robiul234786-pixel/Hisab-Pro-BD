# HISAB PRO BD

**HISAB PRO BD** is an offline-first Native Android business accounting and management application built with Kotlin, Jetpack Compose, Material 3, Room, WorkManager, and optional Firebase Authentication + Cloud Firestore sync for businesses in Bangladesh.

## Features

- **Offline-First Accounting Engine (Room)**: Full accounting workflows work offline with atomic `withTransaction` writes and integer Paisa (`1 BDT = 100 Paisa`) + `BigDecimal` arithmetic.
- **Multi-Business Support**: Run multiple shops or companies under one app with completely isolated ledgers, accounts, customers, suppliers, inventory, and reports.
- **Onboarding & Security**: Branded splash screen, 3-step business profile setup (with logo picker, Bangla/English toggle, opening cash, optional inventory mode, and optional PIN + Biometric lock).
- **Financial Dashboard**: Live database-backed metrics (Sales, Cash Received, Customer Receivables, Supplier Payables, Income, Expenses, Net Profit, Cash/Bank/MFS balances, Today's Sales & Expenses, Quick Actions, Recent Transactions, Top Customers, Low Stock Alerts, and 6-month Sales & Income vs Expense charts).
- **Digital Due Ledger (বাকির খাতা) & Customer Management**: Credit sales, advances, partial/full payments, refunds, automatic due tracking, PDF customer statements, and user-initiated WhatsApp/SMS payment reminders.
- **Supplier Management & Purchases**: Supplier payables, cash/credit purchases, partial/full supplier payments, and supplier statements.
- **POS Sales & Billing**: Multi-item POS cart, walk-in or customer sales, discounts, configurable VAT/Tax, cash/partial/credit payments, stock/COGS updates, PDF invoices, and system print receipts.
- **Optional Inventory**: Toggleable inventory module for service vs product businesses with SKU, barcode, multi-unit support (`Piece`, `KG`, `Gram`, `Liter`, `Meter`, `Box`, `Packet`, `Dozen`), low-stock thresholds, and stock movement history.
- **Cashbook & Multi-Account Transfers**: Separate Cash, Bank, bKash, Nagad, Rocket, and Custom accounts with non-profit-affecting account transfers and traceable reversals.
- **Reports & Exports**: 13 financial & operational reports with custom date filtering, PDF export, and Excel-compatible CSV export.
- **Backup & Cloud Sync**: Manual JSON export/import, WorkManager scheduled local backups, and optional Google Sign-In (`CredentialManager`) + Cloud Firestore sync.

## Architecture

- `app/src/main/java/com/example/data/local/`: Room entities, DAOs, database (`HisabDatabase`), and `DataStore` preferences (`UserPreferences`).
- `app/src/main/java/com/example/data/repository/`: `AccountingRepository` (transactional ledger engine & JSON backup) and `AccountingCalculator` (dashboard & P&L analytics).
- `app/src/main/java/com/example/data/remote/`: `FirebaseAuthHelper` (Google Sign-In via Credential Manager), `CloudSyncRepository` (named Firestore database sync), `CloudSyncModels`, and `FirestoreErrorHandler`.
- `app/src/main/java/com/example/core/util/`: `MoneyUtils` (Paisa & Asia/Dhaka formatting), `AppStrings` (English + Bangla localization), `SecurityUtils`, and `ExportUtils` (PDF, CSV, PrintManager, WhatsApp/SMS intents).
- `app/src/main/java/com/example/workers/`: `ScheduledBackupWorker` (WorkManager periodic backups).
- `app/src/main/java/com/example/ui/`: `MainViewModel`, adaptive Material 3 Compose screens, and components.

## Firebase Configuration

- **Offline Core**: All core accounting works without Firebase or internet.
- **Cloud Sync (Optional)**:
  - `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml` configure Firebase Auth and the named Cloud Firestore database (`firestore_database_id`).
  - `firestore.rules` enforces strict per-user ownership (`request.auth.uid == userId`) across `/users/{userId}` and `/users/{userId}/businesses/{businessId}/**`.
  - Sign-in uses Google Sign-In via Jetpack `CredentialManager`.

## Build & Test Instructions

### Run Unit & Robolectric Tests
```bash
gradle :app:testDebugUnitTest
```

### Build Debug APK
```bash
gradle :app:assembleDebug
```
The generated debug APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`
