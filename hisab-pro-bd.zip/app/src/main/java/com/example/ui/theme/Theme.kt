package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = PureWhite,
    primaryContainer = SoftGreenContainer,
    onPrimaryContainer = DarkNavy,
    secondary = DarkNavy,
    onSecondary = PureWhite,
    secondaryContainer = LightSurfaceVariant,
    onSecondaryContainer = DarkNavy,
    tertiary = EmeraldDark,
    onTertiary = PureWhite,
    tertiaryContainer = SoftGreenAccent,
    onTertiaryContainer = EmeraldDark,
    background = PureWhite,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = BorderLight,
    error = ExpenseRed,
    onError = PureWhite,
    errorContainer = ExpenseSoftRed,
    onErrorContainer = ExpenseRed
)

private val DarkColors = darkColorScheme(
    primary = EmeraldLight,
    onPrimary = DarkNavy,
    primaryContainer = EmeraldDark,
    onPrimaryContainer = PureWhite,
    secondary = DarkNavyLight,
    onSecondary = TextPrimaryDark,
    secondaryContainer = DarkCard,
    onSecondaryContainer = TextPrimaryDark,
    tertiary = EmeraldPrimary,
    onTertiary = PureWhite,
    tertiaryContainer = DarkNavySurface,
    onTertiaryContainer = EmeraldLight,
    background = DarkBackground,
    onBackground = TextPrimaryDark,
    surface = DarkNavySurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = DarkCard,
    onSurfaceVariant = TextSecondaryDark,
    outline = BorderDark,
    error = ExpenseDarkRed,
    onError = DarkNavy,
    errorContainer = Color(0xFF450A0A),
    onErrorContainer = ExpenseSoftRed
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun HisabProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    isBangla: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = buildAppTypography(isBangla),
        shapes = AppShapes,
        content = content
    )
}
