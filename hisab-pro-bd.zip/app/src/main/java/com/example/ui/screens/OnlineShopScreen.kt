package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.core.util.ParsedIncomingOrder
import com.example.data.local.*
import com.example.data.repository.AccountingRepository
import com.example.ui.OnlineShopUiState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnlineShopScreen(
    state: OnlineShopUiState,
    useBanglaDigits: Boolean,
    snackbarHostState: SnackbarHostState,
    onBack: () -> Unit,
    onSearchChange: (String) -> Unit,
    onSelectCategory: (String) -> Unit,
    onToggleWishlist: (String) -> Unit,
    onAddToCart: (String, Long) -> Unit,
    onSetCartQuantity: (String, Long) -> Unit,
    onPreviewPromoDiscount: (Long, String) -> Long,
    onPlaceOrder: (
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        deliveryDistrict: String,
        deliveryFeePaisa: Long,
        promoCode: String,
        paymentMethod: String,
        accountId: String?,
        customerId: String?,
        notes: String,
        mfsTrxId: String,
        mfsSenderPhone: String,
        directSingleItem: Pair<String, Long>?,
        customLines: List<AccountingRepository.OnlineCheckoutLine>?
    ) -> Unit,
    onAdvanceOrderStatus: (String, String) -> Unit,
    onCollectOrderMfsPayment: (
        orderId: String,
        paymentMethod: String,
        trxId: String,
        senderPhone: String,
        accountIdOverride: String?
    ) -> Unit,
    onSaveMfsWallet: (accountType: String, displayName: String, walletNumber: String) -> Unit,
    onUpdateProductListing: (String, Boolean, Long, String, Boolean) -> Unit,
    onSaveProduct: (String?, String, String, String, String, Long, Long, Long, String, Long, String?) -> Unit,
    onSaveCustomWebShopUrl: (String) -> Unit,
    onParseIncomingOrder: (String) -> ParsedIncomingOrder,
    onClearLastPlacedOrder: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val businessName = state.activeBusiness?.name ?: strings.appTitle

    var activeTab by remember { mutableIntStateOf(0) } // 0=Storefront, 1=Orders, 2=Manage
    var selectedProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showCheckoutSheet by remember { mutableStateOf(false) }
    var directBuyItem by remember { mutableStateOf<Pair<ProductEntity, Long>?>(null) }
    var editListingTarget by remember { mutableStateOf<ProductEntity?>(null) }
    var showQuickAddProduct by remember { mutableStateOf(false) }
    var showNoAppReachSheet by remember { mutableStateOf(false) }
    var showWebPreviewDialog by remember { mutableStateOf(false) }
    var showImportOrderDialog by remember { mutableStateOf(false) }
    var showDigitalCatalogSheet by remember { mutableStateOf(false) }
    var qrTargetProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showMfsWalletsSheet by remember { mutableStateOf(false) }
    var collectMfsTargetOrder by remember { mutableStateOf<OnlineOrderEntity?>(null) }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("online_shop_back")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                            }
                            Column {
                                Text(
                                    text = "$businessName • ${strings.onlineShopTitle}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = strings.onlineShopSubtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ShopOrange,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { showDigitalCatalogSheet = true },
                                modifier = Modifier.testTag("shop_catalog_hub_button")
                            ) {
                                Icon(
                                    Icons.Default.AutoAwesomeMosaic,
                                    contentDescription = strings.digitalCatalogTitle,
                                    tint = ShopOrange
                                )
                            }
                            IconButton(
                                onClick = { showNoAppReachSheet = true },
                                modifier = Modifier.testTag("shop_no_app_reach_button")
                            ) {
                                Icon(
                                    Icons.Default.QrCode2,
                                    contentDescription = strings.noAppWebShopTitle,
                                    tint = EmeraldPrimary
                                )
                            }
                            IconButton(
                                onClick = { showMfsWalletsSheet = true },
                                modifier = Modifier.testTag("shop_mfs_wallets_button")
                            ) {
                                Icon(
                                    Icons.Default.AccountBalanceWallet,
                                    contentDescription = strings.mfsWalletsSetupTitle,
                                    tint = BkashPink
                                )
                            }
                            BadgedBox(
                                badge = {
                                    if (state.cartItemCount > 0) {
                                        Badge(containerColor = ShopOrange, contentColor = PureWhite) {
                                            Text(state.cartItemCount.toString())
                                        }
                                    }
                                }
                            ) {
                                IconButton(
                                    onClick = {
                                        directBuyItem = null
                                        showCheckoutSheet = true
                                    },
                                    enabled = state.cartItemCount > 0,
                                    modifier = Modifier.testTag("shop_cart_button")
                                ) {
                                    Icon(Icons.Default.ShoppingCart, contentDescription = strings.checkoutLabel, tint = ShopOrange)
                                }
                            }
                        }
                    }

                    if (activeTab == 0) {
                        OutlinedTextField(
                            value = state.searchQuery,
                            onValueChange = onSearchChange,
                            placeholder = { Text(if (strings.isBangla) "দারাজ-স্টাইল শপে পণ্য খুঁজুন..." else "Search products, categories, deals...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ShopOrange) },
                            trailingIcon = {
                                if (state.searchQuery.isNotBlank()) {
                                    IconButton(onClick = { onSearchChange("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("shop_search_input")
                        )
                    }

                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        val tabs = listOf(
                            strings.shopStorefrontTab to "storefront",
                            "${strings.shopOrdersTab} (${state.orders.size})" to "orders",
                            strings.shopManageTab to "manage"
                        )
                        tabs.forEachIndexed { index, (label, tag) ->
                            SegmentedButton(
                                selected = activeTab == index,
                                onClick = { activeTab = index },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = tabs.size),
                                modifier = Modifier.testTag("shop_tab_$tag")
                            ) {
                                Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            if (activeTab == 0 && state.cartItemCount > 0) {
                Surface(
                    color = DarkNavy,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${state.cartItemCount} item(s) in cart",
                                style = MaterialTheme.typography.labelMedium,
                                color = PureWhite.copy(alpha = 0.8f)
                            )
                            Text(
                                text = MoneyUtils.formatTaka(state.cartSubtotalPaisa, useBanglaDigits),
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                color = ShopOrangeSoft
                            )
                        }
                        Button(
                            onClick = {
                                directBuyItem = null
                                showCheckoutSheet = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ShopOrange),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("shop_checkout_bar_button")
                        ) {
                            Text(strings.checkoutLabel, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(6.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (activeTab) {
                0 -> StorefrontTabContent(
                    state = state,
                    businessName = businessName,
                    useBanglaDigits = useBanglaDigits,
                    onSelectCategory = onSelectCategory,
                    onToggleWishlist = onToggleWishlist,
                    onOpenProductDetail = { selectedProduct = it },
                    onAddToCart = onAddToCart,
                    onOpenCatalogHub = { showDigitalCatalogSheet = true },
                    onOpenNoAppReach = { showNoAppReachSheet = true },
                    onPreviewWebShop = { showWebPreviewDialog = true },
                    onShareCatalog = {
                        shareOnlineShopCatalog(context, businessName, state.storefrontProducts, useBanglaDigits)
                    },
                    onOpenManage = { activeTab = 2 }
                )
                1 -> OnlineOrdersTabContent(
                    state = state,
                    businessName = businessName,
                    useBanglaDigits = useBanglaDigits,
                    onOpenImportOrder = { showImportOrderDialog = true },
                    onOpenMfsWallets = { showMfsWalletsSheet = true },
                    onCollectMfsPayment = { collectMfsTargetOrder = it },
                    onAdvanceOrderStatus = onAdvanceOrderStatus,
                    onShareOrder = { order, items ->
                        shareOnlineOrderSummary(context, businessName, order, items, useBanglaDigits)
                    }
                )
                else -> ManageShopTabContent(
                    state = state,
                    useBanglaDigits = useBanglaDigits,
                    onAddNewProduct = { showQuickAddProduct = true },
                    onOpenMfsWallets = { showMfsWalletsSheet = true },
                    onQuickToggleListed = { prod, listed ->
                        onUpdateProductListing(prod.id, listed, prod.onlineComparePricePaisa, prod.onlineDescription, prod.isFlashDeal)
                    },
                    onQuickToggleFlash = { prod, flash ->
                        onUpdateProductListing(prod.id, prod.onlineListed, prod.onlineComparePricePaisa, prod.onlineDescription, flash)
                    },
                    onEditListing = { editListingTarget = it },
                    onOpenProductQr = { qrTargetProduct = it }
                )
            }
        }
    }

    selectedProduct?.let { prod ->
        ProductDetailBottomSheet(
            product = prod,
            isWishlisted = prod.id in state.wishlistIds,
            cartQuantityMilliUnits = state.cartQuantities[prod.id] ?: 0L,
            useBanglaDigits = useBanglaDigits,
            onToggleWishlist = { onToggleWishlist(prod.id) },
            onAddToCart = { qty -> onAddToCart(prod.id, qty) },
            onBuyNow = { qty ->
                directBuyItem = prod to qty
                showCheckoutSheet = true
            },
            onOpenProductQr = {
                selectedProduct = null
                qrTargetProduct = prod
            },
            onDismiss = { selectedProduct = null }
        )
    }

    if (showCheckoutSheet) {
        CartCheckoutBottomSheet(
            state = state,
            directBuyItem = directBuyItem,
            useBanglaDigits = useBanglaDigits,
            previewPromoDiscount = onPreviewPromoDiscount,
            onSetCartQuantity = onSetCartQuantity,
            onPlaceOrder = { name, phone, addr, district, fee, promo, method, accId, custId, notes, trxId, senderPhone ->
                val directPair = directBuyItem?.let { it.first.id to it.second }
                onPlaceOrder(name, phone, addr, district, fee, promo, method, accId, custId, notes, trxId, senderPhone, directPair, null)
            },
            onDismiss = {
                showCheckoutSheet = false
                directBuyItem = null
            }
        )
    }

    editListingTarget?.let { prod ->
        OnlineListingEditorDialog(
            product = prod,
            onSave = { listed, comparePaisa, desc, flash ->
                onUpdateProductListing(prod.id, listed, comparePaisa, desc, flash)
            },
            onDismiss = { editListingTarget = null }
        )
    }

    if (showQuickAddProduct) {
        QuickAddShopProductDialog(
            onSaveProduct = onSaveProduct,
            onDismiss = { showQuickAddProduct = false }
        )
    }

    state.lastPlacedOrder?.let { placedOrder ->
        OrderSuccessDialog(
            order = placedOrder,
            useBanglaDigits = useBanglaDigits,
            onShareOrder = { ord ->
                shareOnlineOrderSummary(
                    context = context,
                    businessName = businessName,
                    order = ord,
                    items = state.orderItemsByOrderId[ord.id].orEmpty(),
                    useBn = useBanglaDigits
                )
            },
            onDismiss = onClearLastPlacedOrder
        )
    }

    if (showNoAppReachSheet) {
        NoAppShopReachBottomSheet(
            state = state,
            useBanglaDigits = useBanglaDigits,
            onSaveCustomWebShopUrl = onSaveCustomWebShopUrl,
            onPreviewWebShop = {
                showNoAppReachSheet = false
                showWebPreviewDialog = true
            },
            onDismiss = { showNoAppReachSheet = false }
        )
    }

    if (showWebPreviewDialog) {
        WebShopPreviewDialog(
            business = state.activeBusiness,
            products = state.allProducts,
            isBanglaDefault = strings.isBangla,
            accounts = state.accounts,
            onDismiss = { showWebPreviewDialog = false }
        )
    }

    if (showImportOrderDialog) {
        ImportCustomerOrderDialog(
            state = state,
            useBanglaDigits = useBanglaDigits,
            onParseOrder = onParseIncomingOrder,
            onConfirmImport = { name, phone, addr, district, fee, promo, method, accId, notes, trxId, senderPhone, lines ->
                onPlaceOrder(name, phone, addr, district, fee, promo, method, accId, null, notes, trxId, senderPhone, null, lines)
            },
            onDismiss = { showImportOrderDialog = false }
        )
    }

    if (showDigitalCatalogSheet) {
        DigitalCatalogHubBottomSheet(
            state = state,
            useBanglaDigits = useBanglaDigits,
            onSelectProductForQr = { prod ->
                showDigitalCatalogSheet = false
                qrTargetProduct = prod
            },
            onPreviewWebCatalog = { showWebPreviewDialog = true },
            onDismiss = { showDigitalCatalogSheet = false }
        )
    }

    qrTargetProduct?.let { prod ->
        ProductQrCodeDialog(
            business = state.activeBusiness,
            product = prod,
            customWebShopUrl = state.customWebShopUrl,
            useBanglaDigits = useBanglaDigits,
            onDismiss = { qrTargetProduct = null }
        )
    }

    if (showMfsWalletsSheet) {
        MfsWalletsSetupBottomSheet(
            state = state,
            useBanglaDigits = useBanglaDigits,
            onSaveWallet = onSaveMfsWallet,
            onDismiss = { showMfsWalletsSheet = false }
        )
    }

    collectMfsTargetOrder?.let { targetOrder ->
        CollectMfsOrderPaymentDialog(
            order = targetOrder,
            accounts = state.accounts,
            shopPhone = state.activeBusiness?.phone.orEmpty(),
            useBanglaDigits = useBanglaDigits,
            onConfirmCollect = { method, trxId, senderPhone, accOverride ->
                onCollectOrderMfsPayment(targetOrder.id, method, trxId, senderPhone, accOverride)
            },
            onDismiss = { collectMfsTargetOrder = null }
        )
    }
}

@Composable
private fun StorefrontTabContent(
    state: OnlineShopUiState,
    businessName: String,
    useBanglaDigits: Boolean,
    onSelectCategory: (String) -> Unit,
    onToggleWishlist: (String) -> Unit,
    onOpenProductDetail: (ProductEntity) -> Unit,
    onAddToCart: (String, Long) -> Unit,
    onOpenCatalogHub: () -> Unit,
    onOpenNoAppReach: () -> Unit,
    onPreviewWebShop: () -> Unit,
    onShareCatalog: () -> Unit,
    onOpenManage: () -> Unit
) {
    val strings = LocalAppStrings.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Daraz-style Promo Hero Banner
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = ShopOrange
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(ShopOrange, ShopOrangeDark, DarkNavy)))
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(color = PureWhite.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp)) {
                                Text(
                                    text = "MALL • FAST BD DELIVERY",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = PureWhite,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            TextButton(
                                onClick = onShareCatalog,
                                colors = ButtonDefaults.textButtonColors(contentColor = PureWhite)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.shareShopLabel)
                            }
                        }
                        Text(
                            text = "$businessName Online Store",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                        Text(
                            text = if (strings.isBangla) {
                                "প্রোমো কোড: SAVE50 (৳৫০ ছাড়) • HISAB10 (১০% ছাড়) • বিকাশ, নগদ, রকেট, উপায় ও COD"
                            } else {
                                "Use SAVE50 (৳50 off) or HISAB10 (10% off) • bKash, Nagad, Rocket, Upay & COD"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = PureWhite.copy(alpha = 0.9f)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onOpenCatalogHub,
                                colors = ButtonDefaults.buttonColors(containerColor = PureWhite, contentColor = ShopOrangeDark),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 44.dp)
                                    .testTag("shop_hero_catalog_button")
                            ) {
                                Icon(Icons.Default.AutoAwesomeMosaic, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(5.dp))
                                Text(
                                    text = if (strings.isBangla) "ক্যাটালগ ও পণ্য QR" else "Catalog & Product QRs",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            OutlinedButton(
                                onClick = onOpenNoAppReach,
                                border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.65f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .heightIn(min = 44.dp)
                                    .testTag("shop_hero_no_app_button")
                            ) {
                                Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = if (strings.isBangla) "শপ QR" else "Shop QR",
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1
                                )
                            }
                            OutlinedButton(
                                onClick = onPreviewWebShop,
                                border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.65f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .heightIn(min = 44.dp)
                                    .testTag("shop_hero_preview_web_button")
                            ) {
                                Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = if (strings.isBangla) "ওয়েব" else "Web",
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Category Filter Chips
        item {
            val chips = buildList {
                add("All")
                if (state.flashDealProducts.isNotEmpty()) add("Flash Deals")
                if (state.wishlistIds.isNotEmpty()) add("Wishlist")
                addAll(state.categories)
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(chips) { cat ->
                    FilterChip(
                        selected = state.selectedCategory == cat,
                        onClick = { onSelectCategory(cat) },
                        label = { Text(cat) },
                        leadingIcon = if (cat == "Flash Deals") {
                            { Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp), tint = ShopOrange) }
                        } else null
                    )
                }
            }
        }

        // Flash Sale Carousel
        if (state.flashDealProducts.isNotEmpty() && state.selectedCategory == "All" && state.searchQuery.isBlank()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.FlashOn, contentDescription = null, tint = ShopOrange)
                        Text(strings.flashSaleTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(state.flashDealProducts, key = { "flash_${it.id}" }) { prod ->
                            ShopProductCard(
                                product = prod,
                                isWishlisted = prod.id in state.wishlistIds,
                                cartQty = state.cartQuantities[prod.id] ?: 0L,
                                useBanglaDigits = useBanglaDigits,
                                onToggleWishlist = { onToggleWishlist(prod.id) },
                                onClick = { onOpenProductDetail(prod) },
                                onAddToCart = { onAddToCart(prod.id, 1_000L) },
                                modifier = Modifier.width(168.dp)
                            )
                        }
                    }
                }
            }
        }

        // Empty Catalog Prompt
        if (state.storefrontProducts.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Storefront, contentDescription = null, tint = ShopOrange, modifier = Modifier.size(44.dp))
                        Text(
                            text = if (strings.isBangla) "শপে এখনো কোনো পণ্য নেই" else "No Products Listed Yet",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = onOpenManage,
                            colors = ButtonDefaults.buttonColors(containerColor = ShopOrange)
                        ) {
                            Text(if (strings.isBangla) "পণ্য যোগ করুন" else "Add / List Products")
                        }
                    }
                }
            }
        } else {
            item {
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val cols = if (maxWidth >= 600.dp) 3 else 2
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        state.storefrontProducts.chunked(cols).forEach { rowProducts ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                rowProducts.forEach { prod ->
                                    ShopProductCard(
                                        product = prod,
                                        isWishlisted = prod.id in state.wishlistIds,
                                        cartQty = state.cartQuantities[prod.id] ?: 0L,
                                        useBanglaDigits = useBanglaDigits,
                                        onToggleWishlist = { onToggleWishlist(prod.id) },
                                        onClick = { onOpenProductDetail(prod) },
                                        onAddToCart = { onAddToCart(prod.id, 1_000L) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                repeat(cols - rowProducts.size) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShopProductCard(
    product: ProductEntity,
    isWishlisted: Boolean,
    cartQty: Long,
    useBanglaDigits: Boolean,
    onToggleWishlist: () -> Unit,
    onClick: () -> Unit,
    onAddToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hasDiscount = product.onlineComparePricePaisa > product.sellingPricePaisa && product.sellingPricePaisa > 0L
    val discountPct = if (hasDiscount) {
        (((product.onlineComparePricePaisa - product.sellingPricePaisa) * 100L) / product.onlineComparePricePaisa).toInt()
    } else 0

    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(112.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ShopOrangeSoft),
                contentAlignment = Alignment.Center
            ) {
                if (!product.imageUri.isNullOrBlank()) {
                    AsyncImage(
                        model = product.imageUri,
                        contentDescription = product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Default.ShoppingBag, contentDescription = product.name, tint = ShopOrange, modifier = Modifier.size(40.dp))
                }
                if (hasDiscount) {
                    Surface(
                        color = ShopOrange,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                    ) {
                        Text(
                            text = "-$discountPct%",
                            style = MaterialTheme.typography.labelSmall,
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                IconButton(
                    onClick = onToggleWishlist,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(36.dp)
                ) {
                    Icon(
                        if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Wishlist",
                        tint = if (isWishlisted) ExpenseRed else DarkNavy,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Text(
                text = product.name,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                minLines = 2
            )

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Default.Star, contentDescription = null, tint = ShopGoldStar, modifier = Modifier.size(14.dp))
                Text(
                    text = "${product.ratingX10 / 10}.${product.ratingX10 % 10} (${product.soldCount})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = MoneyUtils.formatTaka(product.sellingPricePaisa, useBanglaDigits),
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                    color = ShopOrange
                )
                if (hasDiscount) {
                    Text(
                        text = MoneyUtils.formatTaka(product.onlineComparePricePaisa, useBanglaDigits),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonoFontFamily,
                            textDecoration = TextDecoration.LineThrough
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            FilledTonalButton(
                onClick = onAddToCart,
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = if (cartQty > 0L) SoftGreenAccent else ShopOrangeSoft,
                    contentColor = if (cartQty > 0L) EmeraldPrimary else ShopOrange
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 42.dp)
                    .testTag("shop_add_cart_${product.id}")
            ) {
                Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    text = if (cartQty > 0L) "+1 (${MoneyUtils.milliUnitsToString(cartQty, useBanglaDigits)})" else LocalAppStrings.current.addToCartLabel,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun OnlineOrdersTabContent(
    state: OnlineShopUiState,
    businessName: String,
    useBanglaDigits: Boolean,
    onOpenImportOrder: () -> Unit,
    onOpenMfsWallets: () -> Unit,
    onCollectMfsPayment: (OnlineOrderEntity) -> Unit,
    onAdvanceOrderStatus: (String, String) -> Unit,
    onShareOrder: (OnlineOrderEntity, List<OnlineOrderItemEntity>) -> Unit
) {
    val strings = LocalAppStrings.current
    var statusFilter by remember { mutableStateOf("ALL") }
    val filteredOrders = remember(state.orders, statusFilter) {
        if (statusFilter == "ALL") state.orders else state.orders.filter { it.orderStatus == statusFilter }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = onOpenImportOrder,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = SoftGreenAccent,
                        contentColor = EmeraldDark
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("shop_import_order_button")
                ) {
                    Icon(Icons.Default.ContentPasteGo, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = strings.importCustomerOrderLabel,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                FilledTonalButton(
                    onClick = onOpenMfsWallets,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = BkashPink.copy(alpha = 0.14f),
                        contentColor = BkashPink
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .testTag("orders_mfs_wallets_button")
                ) {
                    Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (strings.isBangla) "বিকাশ/নগদ/উপায়" else "MFS Wallets",
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("ALL") + OnlineOrderStatuses.FLOW + OnlineOrderStatuses.CANCELLED) { st ->
                    FilterChip(selected = statusFilter == st, onClick = { statusFilter = st }, label = { Text(st) })
                }
            }
        }

        if (filteredOrders.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(40.dp))
                        Text("No online orders in this filter", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }

        items(filteredOrders, key = { it.id }) { order ->
            val items = state.orderItemsByOrderId[order.id].orEmpty()
            val nextStatus = when (order.orderStatus) {
                OnlineOrderStatuses.PENDING -> OnlineOrderStatuses.CONFIRMED
                OnlineOrderStatuses.CONFIRMED -> OnlineOrderStatuses.PACKED
                OnlineOrderStatuses.PACKED -> OnlineOrderStatuses.SHIPPED
                OnlineOrderStatuses.SHIPPED -> OnlineOrderStatuses.DELIVERED
                else -> null
            }
            val currentIdx = OnlineOrderStatuses.FLOW.indexOf(order.orderStatus)

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${order.orderNumber} • ${order.customerName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "${order.customerPhone} • ${order.deliveryDistrict} • ${MoneyUtils.formatDhakaDateTime(order.createdAt, useBanglaDigits)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Surface(
                            color = if (order.orderStatus == OnlineOrderStatuses.DELIVERED) SoftGreenAccent else ShopOrangeSoft,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = order.orderStatus,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (order.orderStatus == OnlineOrderStatuses.DELIVERED) EmeraldPrimary else ShopOrange,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // 5-Step Daraz-Style Progress Tracker
                    if (order.orderStatus != OnlineOrderStatuses.CANCELLED) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OnlineOrderStatuses.FLOW.forEachIndexed { idx, step ->
                                val reached = currentIdx >= idx
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(if (reached) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (reached) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = PureWhite, modifier = Modifier.size(12.dp))
                                        }
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = step.take(4),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (reached) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    items.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                "${item.productName} × ${MoneyUtils.milliUnitsToString(item.quantityMilliUnits, useBanglaDigits)} ${item.unit}",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                MoneyUtils.formatTaka(item.lineTotalPaisa, useBanglaDigits),
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "${order.paymentMethod} • ${order.paymentStatus}${if (order.invoiceId != null) " • Ledger Synced" else ""}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (order.invoiceId != null) EmeraldPrimary else WarningAmber
                            )
                            if (order.mfsTrxId.isNotBlank()) {
                                Text(
                                    text = "TrxID: ${order.mfsTrxId}${if (order.mfsSenderPhone.isNotBlank()) " • ${order.mfsSenderPhone}" else ""}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = mfsBrandColor(order.paymentMethod),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        Text(
                            MoneyUtils.formatTaka(order.totalPaisa, useBanglaDigits),
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                            color = ShopOrange
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (nextStatus != null) {
                            Button(
                                onClick = { onAdvanceOrderStatus(order.id, nextStatus) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (nextStatus == OnlineOrderStatuses.DELIVERED) EmeraldPrimary else ShopOrange
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("order_advance_${order.id}")
                            ) {
                                Text(
                                    if (nextStatus == OnlineOrderStatuses.DELIVERED) "Deliver & Sync Ledger" else "Mark $nextStatus",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (order.paymentStatus != "PAID" && order.orderStatus != OnlineOrderStatuses.CANCELLED) {
                            FilledTonalButton(
                                onClick = { onCollectMfsPayment(order) },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = BkashPink.copy(alpha = 0.14f),
                                    contentColor = BkashPink
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp),
                                modifier = Modifier.testTag("order_collect_mfs_${order.id}")
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.collectMfsPaymentLabel, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        if (order.orderStatus != OnlineOrderStatuses.DELIVERED && order.orderStatus != OnlineOrderStatuses.CANCELLED) {
                            OutlinedButton(
                                onClick = { onAdvanceOrderStatus(order.id, OnlineOrderStatuses.CANCELLED) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed)
                            ) { Text("Cancel") }
                        }
                        IconButton(onClick = { onShareOrder(order, items) }) {
                            Icon(Icons.Default.Share, contentDescription = "Share $businessName order")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManageShopTabContent(
    state: OnlineShopUiState,
    useBanglaDigits: Boolean,
    onAddNewProduct: () -> Unit,
    onOpenMfsWallets: () -> Unit,
    onQuickToggleListed: (ProductEntity, Boolean) -> Unit,
    onQuickToggleFlash: (ProductEntity, Boolean) -> Unit,
    onEditListing: (ProductEntity) -> Unit,
    onOpenProductQr: (ProductEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Shop Inventory (${state.allProducts.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = onOpenMfsWallets) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(16.dp), tint = BkashPink)
                        Spacer(Modifier.width(4.dp))
                        Text("MFS", color = BkashPink)
                    }
                    Button(
                        onClick = onAddNewProduct,
                        colors = ButtonDefaults.buttonColors(containerColor = ShopOrange)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Add Product")
                    }
                }
            }
        }

        items(state.allProducts, key = { it.id }) { prod ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(
                                "${MoneyUtils.formatTaka(prod.sellingPricePaisa, useBanglaDigits)}/${prod.unit} • Stock ${MoneyUtils.milliUnitsToString(prod.stockMilliUnits, useBanglaDigits)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { onOpenProductQr(prod) },
                                modifier = Modifier.testTag("manage_product_qr_${prod.id}")
                            ) {
                                Icon(Icons.Default.QrCode2, contentDescription = "Product QR", tint = EmeraldPrimary)
                            }
                            TextButton(onClick = { onEditListing(prod) }) { Text("Edit Deal") }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Online", style = MaterialTheme.typography.labelMedium)
                            Switch(checked = prod.onlineListed, onCheckedChange = { onQuickToggleListed(prod, it) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Flash Deal", style = MaterialTheme.typography.labelMedium)
                            Switch(checked = prod.isFlashDeal, onCheckedChange = { onQuickToggleFlash(prod, it) })
                        }
                    }
                }
            }
        }
    }
}
