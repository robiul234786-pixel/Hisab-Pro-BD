package com.example.core.util

import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object SecurityUtils {
    private const val BACKUP_MAGIC = "HISAB_PRO_ENC_V1"
    private const val PBKDF2_ITERATIONS = 100_000
    private const val KEY_LENGTH_BITS = 256
    private const val GCM_TAG_BITS = 128

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.getEncoder().encodeToString(bytes)
    }

    fun hashPin(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val input = "$salt:$pin".toByteArray(Charsets.UTF_8)
        val hashed = digest.digest(input)
        return hashed.joinToString("") { "%02x".format(it) }
    }

    fun verifyPin(pin: String, salt: String, expectedHash: String): Boolean {
        if (salt.isBlank() || expectedHash.isBlank()) return false
        return hashPin(pin, salt) == expectedHash
    }

    fun isEncryptedBackup(payload: String): Boolean {
        val trimmed = payload.trim()
        if (!trimmed.startsWith("{")) return false
        return try {
            val obj = JSONObject(trimmed)
            obj.optString("format") == BACKUP_MAGIC
        } catch (_: Exception) {
            false
        }
    }

    fun encryptBackup(plainJson: String, passphrase: String): String {
        require(passphrase.length >= 4) { "Passphrase must be at least 4 characters" }
        val rng = SecureRandom()
        val salt = ByteArray(16).also { rng.nextBytes(it) }
        val iv = ByteArray(12).also { rng.nextBytes(it) }
        val key = deriveAesKey(passphrase, salt)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        val cipherBytes = cipher.doFinal(plainJson.toByteArray(Charsets.UTF_8))

        val encoder = Base64.getEncoder()
        return JSONObject().apply {
            put("format", BACKUP_MAGIC)
            put("kdf", "PBKDF2WithHmacSHA256")
            put("iterations", PBKDF2_ITERATIONS)
            put("salt", encoder.encodeToString(salt))
            put("iv", encoder.encodeToString(iv))
            put("ciphertext", encoder.encodeToString(cipherBytes))
        }.toString()
    }

    fun decryptBackup(encryptedEnvelope: String, passphrase: String): String {
        require(passphrase.isNotBlank()) { "Passphrase is required to decrypt backup" }
        val obj = JSONObject(encryptedEnvelope.trim())
        require(obj.optString("format") == BACKUP_MAGIC) { "Unsupported encrypted backup format" }
        val decoder = Base64.getDecoder()
        val salt = decoder.decode(obj.getString("salt"))
        val iv = decoder.decode(obj.getString("iv"))
        val cipherBytes = decoder.decode(obj.getString("ciphertext"))
        val iterations = obj.optInt("iterations", PBKDF2_ITERATIONS).coerceIn(10_000, 500_000)

        val key = deriveAesKey(passphrase, salt, iterations)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        val plainBytes = cipher.doFinal(cipherBytes)
        return String(plainBytes, Charsets.UTF_8)
    }

    private fun deriveAesKey(
        passphrase: String,
        salt: ByteArray,
        iterations: Int = PBKDF2_ITERATIONS
    ): SecretKeySpec {
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, iterations, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(keyBytes, "AES")
    }
}
