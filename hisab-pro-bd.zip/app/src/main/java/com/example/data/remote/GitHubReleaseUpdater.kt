package com.example.data.remote

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class GitHubReleaseInfo(
    val tagName: String,
    val releaseName: String,
    val releaseNotes: String,
    val publishedAt: String,
    val htmlUrl: String,
    val apkAssetName: String?,
    val apkDownloadUrl: String?,
    val apkSizeBytes: Long
)

sealed interface UpdateUiState {
    data object Idle : UpdateUiState
    data object Checking : UpdateUiState
    data class UpToDate(val currentVersion: String, val latestTag: String) : UpdateUiState
    data class UpdateAvailable(val currentVersion: String, val release: GitHubReleaseInfo) : UpdateUiState
    data class Downloading(
        val release: GitHubReleaseInfo,
        val progressPercent: Int,
        val downloadedBytes: Long,
        val totalBytes: Long
    ) : UpdateUiState
    data class ReadyToInstall(val release: GitHubReleaseInfo, val apkFilePath: String) : UpdateUiState
    data class Error(val message: String) : UpdateUiState
}

object GitHubReleaseUpdater {

    private val SLUG_REGEX = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")

    /**
     * Accepts "owner/repo" or "https://github.com/owner/repo(.git)" and returns normalized "owner/repo",
     * or null if invalid.
     */
    fun normalizeRepoSlug(rawInput: String): String? {
        val trimmed = rawInput.trim()
            .removePrefix("https://github.com/")
            .removePrefix("http://github.com/")
            .removePrefix("github.com/")
            .trim('/')
            .removeSuffix(".git")
        val parts = trimmed.split('/').filter { it.isNotBlank() }
        if (parts.size < 2) return null
        val slug = "${parts[0]}/${parts[1]}"
        return if (SLUG_REGEX.matches(slug)) slug else null
    }

    /**
     * Compares version strings like "v1.2.0" and "1.0" safely.
     * Returns > 0 if remoteTag is newer than currentVersion.
     */
    fun compareVersions(remoteTag: String, currentVersion: String): Int {
        val remoteParts = parseNumericVersionParts(remoteTag)
        val currentParts = parseNumericVersionParts(currentVersion)
        val maxLen = maxOf(remoteParts.size, currentParts.size)
        for (i in 0 until maxLen) {
            val r = remoteParts.getOrElse(i) { 0 }
            val c = currentParts.getOrElse(i) { 0 }
            if (r != c) return r.compareTo(c)
        }
        return 0
    }

    fun isRemoteVersionNewer(remoteTag: String, currentVersion: String): Boolean {
        return compareVersions(remoteTag, currentVersion) > 0
    }

    private fun parseNumericVersionParts(version: String): List<Int> {
        val clean = version.trim()
            .removePrefix("v")
            .removePrefix("V")
            .substringBefore('-')
            .substringBefore('+')
        if (clean.isBlank()) return listOf(0)
        return clean.split('.').map { seg ->
            seg.takeWhile { it.isDigit() }.toIntOrNull() ?: 0
        }
    }

    fun parseLatestReleaseJson(jsonString: String): GitHubReleaseInfo {
        val root = JSONObject(jsonString)
        val tagName = root.optString("tag_name").ifBlank { root.optString("name", "0.0.0") }
        val releaseName = root.optString("name").ifBlank { tagName }
        val releaseNotes = root.optString("body", "").trim()
        val publishedAt = root.optString("published_at", "")
        val htmlUrl = root.optString("html_url", "")

        val assets = root.optJSONArray("assets")
        val apkAssets = mutableListOf<Triple<String, String, Long>>()
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                val name = asset.optString("name", "")
                val downloadUrl = asset.optString("browser_download_url", "")
                val contentType = asset.optString("content_type", "")
                val size = asset.optLong("size", 0L)
                val isApk = name.endsWith(".apk", ignoreCase = true) ||
                    contentType.equals("application/vnd.android.package-archive", ignoreCase = true)
                if (isApk && downloadUrl.isNotBlank()) {
                    apkAssets.add(Triple(name, downloadUrl, size))
                }
            }
        }

        // Prefer release/universal APK if multiple APKs are attached to the release
        val pickedApk = apkAssets.firstOrNull { it.first.contains("release", ignoreCase = true) }
            ?: apkAssets.firstOrNull()

        return GitHubReleaseInfo(
            tagName = tagName,
            releaseName = releaseName,
            releaseNotes = releaseNotes,
            publishedAt = publishedAt,
            htmlUrl = htmlUrl,
            apkAssetName = pickedApk?.first,
            apkDownloadUrl = pickedApk?.second,
            apkSizeBytes = pickedApk?.third ?: 0L
        )
    }

    suspend fun fetchLatestRelease(repoSlug: String): Result<GitHubReleaseInfo> = withContext(Dispatchers.IO) {
        try {
            val cleanSlug = normalizeRepoSlug(repoSlug)
                ?: return@withContext Result.failure(
                    IllegalArgumentException("Invalid GitHub repository format. Use owner/repo.")
                )
            val url = URL("https://api.github.com/repos/$cleanSlug/releases/latest")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 15_000
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("User-Agent", "HisabProBD-Android")
            }
            try {
                val code = conn.responseCode
                if (code == HttpURLConnection.HTTP_OK) {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    Result.success(parseLatestReleaseJson(body))
                } else if (code == HttpURLConnection.HTTP_NOT_FOUND) {
                    Result.failure(IllegalStateException("No published GitHub release found for $cleanSlug."))
                } else if (code == 403 || code == 429) {
                    Result.failure(IllegalStateException("GitHub API rate limit reached. Please try again later."))
                } else {
                    Result.failure(IllegalStateException("GitHub check failed (HTTP $code)."))
                }
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun downloadApk(
        apkUrl: String,
        destDir: File,
        fileName: String,
        expectedSizeBytes: Long,
        onProgress: (percent: Int, downloadedBytes: Long, totalBytes: Long) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (!destDir.exists()) destDir.mkdirs()
            // Clean previous downloaded APKs in cache/updates
            destDir.listFiles()?.forEach { old ->
                if (old.isFile && (old.name.endsWith(".apk") || old.name.endsWith(".tmp"))) {
                    old.delete()
                }
            }

            val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "hisab_pro_update.apk" }
            val tempFile = File(destDir, "$safeName.tmp")
            val finalFile = File(destDir, safeName)

            val conn = openFollowingRedirects(apkUrl)
            try {
                val code = conn.responseCode
                if (code !in 200..299) {
                    return@withContext Result.failure(IllegalStateException("Download failed (HTTP $code)."))
                }
                val contentLength = conn.contentLengthLong.takeIf { it > 0L } ?: expectedSizeBytes
                val buffer = ByteArray(16 * 1024)
                var downloaded = 0L
                var lastReportedPct = -1

                conn.inputStream.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            val pct = if (contentLength > 0L) {
                                ((downloaded * 100L) / contentLength).toInt().coerceIn(0, 100)
                            } else 0
                            if (pct != lastReportedPct) {
                                lastReportedPct = pct
                                onProgress(pct, downloaded, contentLength)
                            }
                        }
                        output.flush()
                    }
                }

                // Sanity check: APK is a ZIP archive starting with 'P', 'K'
                if (!tempFile.exists() || tempFile.length() < 1024L) {
                    tempFile.delete()
                    return@withContext Result.failure(IllegalStateException("Downloaded APK file is incomplete."))
                }
                val header = ByteArray(2)
                tempFile.inputStream().use { it.read(header) }
                if (header[0] != 'P'.code.toByte() || header[1] != 'K'.code.toByte()) {
                    tempFile.delete()
                    return@withContext Result.failure(IllegalStateException("Downloaded file is not a valid APK package."))
                }

                if (finalFile.exists()) finalFile.delete()
                if (!tempFile.renameTo(finalFile)) {
                    tempFile.copyTo(finalFile, overwrite = true)
                    tempFile.delete()
                }
                onProgress(100, finalFile.length(), finalFile.length())
                Result.success(finalFile)
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun openFollowingRedirects(startUrl: String, maxRedirects: Int = 5): HttpURLConnection {
        var currentUrl = startUrl
        repeat(maxRedirects) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 20_000
                readTimeout = 60_000
                setRequestProperty("User-Agent", "HisabProBD-Android")
            }
            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location.isNullOrBlank()) {
                    throw IllegalStateException("Redirect missing Location header")
                }
                currentUrl = URL(URL(currentUrl), location).toString()
            } else {
                return conn
            }
        }
        throw IllegalStateException("Too many redirects while downloading APK")
    }

    fun canInstallPackages(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    fun createUnknownSourcesSettingsIntent(context: Context): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            )
        } else {
            Intent(Settings.ACTION_SECURITY_SETTINGS)
        }
    }

    fun launchApkInstaller(context: Context, apkFile: File): Boolean {
        if (!apkFile.exists()) return false
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
