package com.example.core.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

/**
 * Pure-Kotlin ISO/IEC 18004 QR Code generator (Byte mode, Error Correction Level L, Versions 1..10).
 * Generates scannable QR matrices and branded printable shop counter QR posters without external dependencies.
 */
object QrCodeGenerator {

    private data class VersionSpec(
        val version: Int,
        val totalDataCodewords: Int,
        val ecCodewordsPerBlock: Int,
        val group1Blocks: Int,
        val group1DataCodewords: Int,
        val group2Blocks: Int,
        val group2DataCodewords: Int,
        val alignments: IntArray,
        val remainderBits: Int
    )

    // ISO/IEC 18004 EC Level L specs for Versions 1..10 (up to 271 UTF-8 bytes)
    private val VERSION_SPECS = listOf(
        VersionSpec(1, 19, 7, 1, 19, 0, 0, intArrayOf(), 0),
        VersionSpec(2, 34, 10, 1, 34, 0, 0, intArrayOf(6, 18), 7),
        VersionSpec(3, 55, 15, 1, 55, 0, 0, intArrayOf(6, 22), 7),
        VersionSpec(4, 80, 20, 1, 80, 0, 0, intArrayOf(6, 26), 7),
        VersionSpec(5, 108, 26, 1, 108, 0, 0, intArrayOf(6, 30), 7),
        VersionSpec(6, 136, 18, 2, 68, 0, 0, intArrayOf(6, 34), 7),
        VersionSpec(7, 156, 20, 2, 78, 0, 0, intArrayOf(6, 22, 38), 0),
        VersionSpec(8, 194, 24, 2, 97, 0, 0, intArrayOf(6, 24, 42), 0),
        VersionSpec(9, 232, 30, 2, 116, 0, 0, intArrayOf(6, 26, 46), 0),
        VersionSpec(10, 274, 18, 2, 68, 2, 69, intArrayOf(6, 28, 50), 0)
    )

    // Precomputed Version Information (18-bit BCH) for Versions 7..10
    private val VERSION_INFO_BITS = mapOf(
        7 to 0x07C94,
        8 to 0x085BC,
        9 to 0x09A99,
        10 to 0x0A4D3
    )

    // Precomputed Format Information (15-bit BCH XOR 0x5412) for EC Level L (01) & Masks 0..7
    private val FORMAT_INFO_L = intArrayOf(
        0x77C4, 0x72F3, 0x7DAA, 0x789D, 0x662F, 0x6318, 0x6C41, 0x6976
    )

    private val GF_EXP = IntArray(512)
    private val GF_LOG = IntArray(256)

    init {
        var x = 1
        for (i in 0 until 255) {
            GF_EXP[i] = x
            GF_LOG[x] = i
            x = x shl 1
            if (x and 0x100 != 0) x = x xor 0x11D
        }
        for (i in 255 until 512) {
            GF_EXP[i] = GF_EXP[i - 255]
        }
    }

    private fun gfMul(a: Int, b: Int): Int {
        if (a == 0 || b == 0) return 0
        return GF_EXP[GF_LOG[a] + GF_LOG[b]]
    }

    private fun rsGeneratorPoly(ecCount: Int): IntArray {
        var poly = intArrayOf(1)
        for (i in 0 until ecCount) {
            val factor = intArrayOf(1, GF_EXP[i])
            val next = IntArray(poly.size + 1)
            for (p in poly.indices) {
                for (f in factor.indices) {
                    next[p + f] = next[p + f] xor gfMul(poly[p], factor[f])
                }
            }
            poly = next
        }
        return poly
    }

    private fun rsComputeEc(data: IntArray, ecCount: Int): IntArray {
        val gen = rsGeneratorPoly(ecCount)
        val buffer = IntArray(data.size + ecCount)
        System.arraycopy(data, 0, buffer, 0, data.size)
        for (i in data.indices) {
            val coef = buffer[i]
            if (coef != 0) {
                for (j in gen.indices) {
                    buffer[i + j] = buffer[i + j] xor gfMul(gen[j], coef)
                }
            }
        }
        return buffer.copyOfRange(data.size, data.size + ecCount)
    }

    /**
     * Generates a square boolean QR module matrix (true = dark module, false = light module).
     * Automatically fits Byte-mode UTF-8 payload into Versions 1..10 (up to 271 bytes).
     */
    fun encodeMatrix(content: String): Array<BooleanArray> {
        val rawBytes = content.ifBlank { "https://wa.me/" }.toByteArray(Charsets.UTF_8)
        val bytes = if (rawBytes.size > 271) rawBytes.copyOf(271) else rawBytes

        val spec = VERSION_SPECS.firstOrNull { v ->
            val charCountBits = if (v.version <= 9) 8 else 16
            val neededBits = 4 + charCountBits + bytes.size * 8
            neededBits <= v.totalDataCodewords * 8
        } ?: VERSION_SPECS.last()

        val charCountBits = if (spec.version <= 9) 8 else 16
        val bitList = ArrayList<Int>(spec.totalDataCodewords * 8)
        fun appendBits(value: Int, count: Int) {
            for (i in (count - 1) downTo 0) {
                bitList.add((value ushr i) and 1)
            }
        }

        // Byte mode indicator (0100) + byte length + data
        appendBits(0b0100, 4)
        appendBits(bytes.size, charCountBits)
        for (b in bytes) {
            appendBits(b.toInt() and 0xFF, 8)
        }

        val maxBits = spec.totalDataCodewords * 8
        val terminator = minOf(4, maxBits - bitList.size)
        repeat(terminator) { bitList.add(0) }
        while (bitList.size % 8 != 0) bitList.add(0)
        var padIndex = 0
        while (bitList.size < maxBits) {
            appendBits(if (padIndex % 2 == 0) 0xEC else 0x11, 8)
            padIndex++
        }

        val dataCodewords = IntArray(spec.totalDataCodewords) { i ->
            var v = 0
            for (b in 0 until 8) {
                v = (v shl 1) or bitList[i * 8 + b]
            }
            v
        }

        // Split into RS blocks and compute EC codewords
        val dataBlocks = mutableListOf<IntArray>()
        val ecBlocks = mutableListOf<IntArray>()
        var offset = 0
        repeat(spec.group1Blocks) {
            val block = dataCodewords.copyOfRange(offset, offset + spec.group1DataCodewords)
            offset += spec.group1DataCodewords
            dataBlocks.add(block)
            ecBlocks.add(rsComputeEc(block, spec.ecCodewordsPerBlock))
        }
        repeat(spec.group2Blocks) {
            val block = dataCodewords.copyOfRange(offset, offset + spec.group2DataCodewords)
            offset += spec.group2DataCodewords
            dataBlocks.add(block)
            ecBlocks.add(rsComputeEc(block, spec.ecCodewordsPerBlock))
        }

        val finalBits = ArrayList<Int>(spec.totalDataCodewords * 8 + ecBlocks.size * spec.ecCodewordsPerBlock * 8 + spec.remainderBits)
        val maxDataBlockLen = maxOf(spec.group1DataCodewords, spec.group2DataCodewords)
        for (i in 0 until maxDataBlockLen) {
            for (blk in dataBlocks) {
                if (i < blk.size) {
                    val cw = blk[i]
                    for (bit in 7 downTo 0) finalBits.add((cw ushr bit) and 1)
                }
            }
        }
        for (i in 0 until spec.ecCodewordsPerBlock) {
            for (ec in ecBlocks) {
                val cw = ec[i]
                for (bit in 7 downTo 0) finalBits.add((cw ushr bit) and 1)
            }
        }
        repeat(spec.remainderBits) { finalBits.add(0) }

        val size = 21 + 4 * (spec.version - 1)
        val modules = Array(size) { BooleanArray(size) }
        val isFunction = Array(size) { BooleanArray(size) }

        fun setFunc(r: Int, c: Int, dark: Boolean) {
            if (r in 0 until size && c in 0 until size) {
                modules[r][c] = dark
                isFunction[r][c] = true
            }
        }

        fun drawFinder(top: Int, left: Int) {
            for (dy in -1..7) {
                for (dx in -1..7) {
                    val r = top + dy
                    val c = left + dx
                    if (r !in 0 until size || c !in 0 until size) continue
                    val dark = if (dy !in 0..6 || dx !in 0..6) {
                        false // separator
                    } else {
                        val dist = maxOf(abs(dy - 3), abs(dx - 3))
                        dist != 2
                    }
                    setFunc(r, c, dark)
                }
            }
        }

        drawFinder(0, 0)
        drawFinder(0, size - 7)
        drawFinder(size - 7, 0)

        // Timing patterns
        for (i in 8 until size - 8) {
            setFunc(6, i, i % 2 == 0)
            setFunc(i, 6, i % 2 == 0)
        }

        // Alignment patterns
        val coords = spec.alignments
        for (ay in coords) {
            for (ax in coords) {
                if (isFunction[ay][ax]) continue
                for (dy in -2..2) {
                    for (dx in -2..2) {
                        val dist = maxOf(abs(dy), abs(dx))
                        setFunc(ay + dy, ax + dx, dist != 1)
                    }
                }
            }
        }

        // Dark module
        setFunc(size - 8, 8, true)

        // Reserve format areas
        for (i in 0..8) {
            if (i != 6) {
                setFunc(8, i, false)
                setFunc(i, 8, false)
            }
        }
        for (i in (size - 8) until size) {
            setFunc(8, i, false)
            if (i >= size - 7) setFunc(i, 8, false)
        }

        // Version information (Versions 7+)
        VERSION_INFO_BITS[spec.version]?.let { bits ->
            for (i in 0 until 18) {
                val dark = ((bits ushr i) and 1) == 1
                val r = i / 3
                val c = size - 11 + (i % 3)
                setFunc(r, c, dark)
                setFunc(c, r, dark)
            }
        }

        // Place data bits in zig-zag order
        var bitIdx = 0
        var upward = true
        var col = size - 1
        while (col > 0) {
            if (col == 6) col-- // Skip vertical timing column
            for (step in 0 until size) {
                val r = if (upward) size - 1 - step else step
                for (dc in 0..1) {
                    val c = col - dc
                    if (!isFunction[r][c]) {
                        val bit = if (bitIdx < finalBits.size) finalBits[bitIdx] == 1 else false
                        modules[r][c] = bit
                        bitIdx++
                    }
                }
            }
            upward = !upward
            col -= 2
        }

        // Evaluate 8 masks & pick minimum penalty
        var bestMask = 0
        var bestPenalty = Int.MAX_VALUE
        for (mask in 0..7) {
            val candidate = Array(size) { r ->
                BooleanArray(size) { c ->
                    if (isFunction[r][c]) modules[r][c]
                    else modules[r][c] xor maskMatches(mask, r, c)
                }
            }
            applyFormatBits(candidate, size, FORMAT_INFO_L[mask])
            val penalty = computePenalty(candidate, size)
            if (penalty < bestPenalty) {
                bestPenalty = penalty
                bestMask = mask
            }
        }

        // Apply best mask directly
        for (r in 0 until size) {
            for (c in 0 until size) {
                if (!isFunction[r][c] && maskMatches(bestMask, r, c)) {
                    modules[r][c] = !modules[r][c]
                }
            }
        }
        applyFormatBits(modules, size, FORMAT_INFO_L[bestMask])
        return modules
    }

    private fun maskMatches(mask: Int, r: Int, c: Int): Boolean = when (mask) {
        0 -> (r + c) % 2 == 0
        1 -> r % 2 == 0
        2 -> c % 3 == 0
        3 -> (r + c) % 3 == 0
        4 -> ((r / 2) + (c / 3)) % 2 == 0
        5 -> (r * c) % 2 + (r * c) % 3 == 0
        6 -> ((r * c) % 2 + (r * c) % 3) % 2 == 0
        else -> ((r + c) % 2 + (r * c) % 3) % 2 == 0
    }

    private fun applyFormatBits(m: Array<BooleanArray>, size: Int, formatBits: Int) {
        for (i in 0..5) m[8][i] = ((formatBits ushr (14 - i)) and 1) == 1
        m[8][7] = ((formatBits ushr 8) and 1) == 1
        m[8][8] = ((formatBits ushr 7) and 1) == 1
        m[7][8] = ((formatBits ushr 6) and 1) == 1
        for (i in 9..14) m[14 - i][8] = ((formatBits ushr (14 - i)) and 1) == 1

        for (i in 0..6) m[size - 1 - i][8] = ((formatBits ushr (14 - i)) and 1) == 1
        for (i in 7..14) m[8][size - 15 + i] = ((formatBits ushr (14 - i)) and 1) == 1
    }

    private fun computePenalty(m: Array<BooleanArray>, size: Int): Int {
        var penalty = 0
        // Rule 1: 5+ consecutive same color in row or col
        for (r in 0 until size) {
            var runLen = 1
            for (c in 1 until size) {
                if (m[r][c] == m[r][c - 1]) runLen++ else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }
        for (c in 0 until size) {
            var runLen = 1
            for (r in 1 until size) {
                if (m[r][c] == m[r - 1][c]) runLen++ else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }
        // Rule 2: 2x2 blocks
        for (r in 0 until size - 1) {
            for (c in 0 until size - 1) {
                val v = m[r][c]
                if (m[r][c + 1] == v && m[r + 1][c] == v && m[r + 1][c + 1] == v) penalty += 3
            }
        }
        // Rule 4: dark ratio
        var darkCount = 0
        for (r in 0 until size) for (c in 0 until size) if (m[r][c]) darkCount++
        val pct = (darkCount * 100) / (size * size)
        val k = abs(pct - 50) / 5
        penalty += k * 10
        return penalty
    }

    fun generateQrBitmap(content: String, sizePx: Int = 520, quietModules: Int = 4): Bitmap {
        val matrix = encodeMatrix(content)
        val count = matrix.size
        val totalModules = count + quietModules * 2
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = false
        }
        val cell = sizePx.toFloat() / totalModules.toFloat()
        for (r in 0 until count) {
            for (c in 0 until count) {
                if (matrix[r][c]) {
                    val left = (c + quietModules) * cell
                    val top = (r + quietModules) * cell
                    canvas.drawRect(left, top, left + cell + 0.5f, top + cell + 0.5f, paint)
                }
            }
        }
        return bmp
    }

    /**
     * Renders a branded Daraz-orange & Dark-Navy Shop Counter QR Poster PNG
     * so shopkeepers can print or share it on Facebook/WhatsApp — customers scan & order with zero app download.
     */
    fun generateShopQrPosterFile(
        context: Context,
        businessName: String,
        businessCategory: String,
        phone: String,
        targetOrderUrl: String
    ): File {
        val w = 1080
        val h = 1440
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.parseColor("#FFF8F5"))

        val headerPaint = Paint().apply { color = Color.parseColor("#F85606") }
        canvas.drawRect(0f, 0f, w.toFloat(), 270f, headerPaint)

        val navyPaint = Paint().apply { color = Color.parseColor("#101C2C") }
        canvas.drawRect(0f, h - 180f, w.toFloat(), h.toFloat(), navyPaint)

        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 56f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val subTitlePaint = Paint().apply {
            color = Color.parseColor("#FFE4D6")
            textSize = 30f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(businessName.take(28), w / 2f, 125f, titlePaint)
        canvas.drawText("$businessCategory • Online Store", w / 2f, 185f, subTitlePaint)

        val cardPaint = Paint().apply {
            color = Color.WHITE
            isAntiAlias = true
        }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#F85606")
            style = Paint.Style.STROKE
            strokeWidth = 6f
            isAntiAlias = true
        }
        val cardRect = RectF(130f, 330f, w - 130f, 1110f)
        canvas.drawRoundRect(cardRect, 40f, 40f, cardPaint)
        canvas.drawRoundRect(cardRect, 40f, 40f, borderPaint)

        val qrBmp = generateQrBitmap(targetOrderUrl, sizePx = 680, quietModules = 3)
        canvas.drawBitmap(qrBmp, (w - 680) / 2f, 365f, null)

        val scanLabelPaint = Paint().apply {
            color = Color.parseColor("#101C2C")
            textSize = 32f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("Scan QR to Order Without Any App", w / 2f, 1175f, scanLabelPaint)

        val promoPaint = Paint().apply {
            color = Color.parseColor("#F85606")
            textSize = 28f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("Promo: SAVE50 (Tk 50 Off)  •  HISAB10 (10% Off)", w / 2f, 1225f, promoPaint)

        val footerPaint = Paint().apply {
            color = Color.WHITE
            textSize = 32f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val footerSubPaint = Paint().apply {
            color = Color.parseColor("#34D399")
            textSize = 26f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("COD  •  bKash  •  Nagad  •  Rocket  •  Upay", w / 2f, h - 102f, footerPaint)
        canvas.drawText(if (phone.isNotBlank()) "Shop Contact: $phone" else "Fast Home Delivery", w / 2f, h - 52f, footerSubPaint)

        val exportsDir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
        val file = File(exportsDir, "shop_qr_poster_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file
    }

    data class CatalogVisualItem(
        val productName: String,
        val category: String,
        val priceText: String,
        val comparePriceText: String?,
        val discountPct: Int,
        val isFlashDeal: Boolean,
        val productOrderUrl: String
    )

    /**
     * Generates a dedicated, print-ready PNG QR flyer for a single product so customers
     * can scan and order that exact item immediately without installing the app.
     */
    fun generateProductQrPosterFile(
        context: Context,
        businessName: String,
        phone: String,
        productName: String,
        category: String,
        priceText: String,
        comparePriceText: String?,
        discountPct: Int,
        productOrderUrl: String
    ): File {
        val w = 1080
        val h = 1380
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.parseColor("#FFF8F5"))

        val headerPaint = Paint().apply { color = Color.parseColor("#101C2C") }
        canvas.drawRect(0f, 0f, w.toFloat(), 210f, headerPaint)

        val accentBand = Paint().apply { color = Color.parseColor("#F85606") }
        canvas.drawRect(0f, 200f, w.toFloat(), 218f, accentBand)

        val shopPaint = Paint().apply {
            color = Color.WHITE
            textSize = 44f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val tagPaint = Paint().apply {
            color = Color.parseColor("#34D399")
            textSize = 26f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(businessName.take(28), w / 2f, 95f, shopPaint)
        canvas.drawText("SCAN TO ORDER PRODUCT INSTANTLY", w / 2f, 152f, tagPaint)

        // Category pill
        val catBg = Paint().apply { color = Color.parseColor("#FFE8DC"); isAntiAlias = true }
        val catRect = RectF(w / 2f - 170f, 250f, w / 2f + 170f, 304f)
        canvas.drawRoundRect(catRect, 27f, 27f, catBg)
        val catTextPaint = Paint().apply {
            color = Color.parseColor("#D94400")
            textSize = 25f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(category.ifBlank { "Featured" }.take(20), w / 2f, 286f, catTextPaint)

        val namePaint = Paint().apply {
            color = Color.parseColor("#101C2C")
            textSize = 50f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(productName.take(28), w / 2f, 376f, namePaint)

        val pricePaint = Paint().apply {
            color = Color.parseColor("#F85606")
            textSize = 58f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val priceLine = buildString {
            append(priceText)
            if (!comparePriceText.isNullOrBlank() && discountPct > 0) {
                append("   (-$discountPct% OFF)")
            }
        }
        canvas.drawText(priceLine, w / 2f, 448f, pricePaint)

        // QR frame card
        val cardPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#F85606")
            style = Paint.Style.STROKE
            strokeWidth = 6f
            isAntiAlias = true
        }
        val qrCard = RectF(180f, 490f, w - 180f, 1170f)
        canvas.drawRoundRect(qrCard, 36f, 36f, cardPaint)
        canvas.drawRoundRect(qrCard, 36f, 36f, borderPaint)

        val qrBmp = generateQrBitmap(productOrderUrl, sizePx = 610, quietModules = 3)
        canvas.drawBitmap(qrBmp, (w - 610) / 2f, 525f, null)

        val footerBg = Paint().apply { color = Color.parseColor("#101C2C") }
        canvas.drawRect(0f, h - 160f, w.toFloat(), h.toFloat(), footerBg)
        val footerTitle = Paint().apply {
            color = Color.WHITE
            textSize = 30f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val footerSub = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            textSize = 24f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("No App Needed • COD / bKash / Nagad / Rocket / Upay", w / 2f, h - 92f, footerTitle)
        canvas.drawText(if (phone.isNotBlank()) "Order Desk: $phone" else "Fast Home Delivery", w / 2f, h - 44f, footerSub)

        val exportsDir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
        val safeName = productName.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "product" }
        val file = File(exportsDir, "${safeName}_qr_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file
    }

    /**
     * Generates a visually appealing 1080x1920 Magazine-Style Digital Shop Catalog PNG
     * featuring up to 6 top products, each with its own scannable QR code + a master shop QR header.
     */
    fun generateVisualCatalogPosterFile(
        context: Context,
        businessName: String,
        businessCategory: String,
        phone: String,
        shopOrderUrl: String,
        items: List<CatalogVisualItem>
    ): File {
        val w = 1080
        val h = 1920
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.parseColor("#F4F6F8"))

        // Header Banner
        val navyPaint = Paint().apply { color = Color.parseColor("#101C2C") }
        canvas.drawRect(0f, 0f, w.toFloat(), 270f, navyPaint)
        val orangeStrip = Paint().apply { color = Color.parseColor("#F85606") }
        canvas.drawRect(0f, 260f, w.toFloat(), 276f, orangeStrip)

        val shopTitlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 52f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val shopSubPaint = Paint().apply {
            color = Color.parseColor("#34D399")
            textSize = 27f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val shopPhonePaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            textSize = 24f
            isAntiAlias = true
        }
        canvas.drawText(businessName.take(24), 48f, 96f, shopTitlePaint)
        canvas.drawText("DIGITAL PRODUCT CATALOG • NO APP NEEDED", 48f, 148f, shopSubPaint)
        canvas.drawText(
            "$businessCategory" + if (phone.isNotBlank()) "  •  $phone" else "",
            48f,
            198f,
            shopPhonePaint
        )

        // Master shop QR in header top-right
        val masterBg = Paint().apply { color = Color.WHITE; isAntiAlias = true }
        canvas.drawRoundRect(RectF(836f, 34f, 1034f, 232f), 20f, 20f, masterBg)
        val masterQr = generateQrBitmap(shopOrderUrl, sizePx = 176, quietModules = 2)
        canvas.drawBitmap(masterQr, 847f, 45f, null)

        // 2x3 Product Grid (up to 6 featured items)
        val featured = items.take(6)
        val cols = 2
        val startX = 40f
        val gapX = 28f
        val cardW = (w - startX * 2 - gapX) / cols
        val startY = 304f
        val gapY = 26f
        val cardH = 470f

        val cardBgPaint = Paint().apply { color = Color.WHITE; isAntiAlias = true }
        val cardBorderPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = true
        }
        val badgeOffPaint = Paint().apply { color = Color.parseColor("#F85606"); isAntiAlias = true }
        val badgeFlashPaint = Paint().apply { color = Color.parseColor("#101C2C"); isAntiAlias = true }
        val badgeTxtPaint = Paint().apply {
            color = Color.WHITE
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val itemCatPaint = Paint().apply {
            color = Color.parseColor("#10A36C")
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val itemNamePaint = Paint().apply {
            color = Color.parseColor("#101C2C")
            textSize = 31f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val itemPricePaint = Paint().apply {
            color = Color.parseColor("#F85606")
            textSize = 38f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val itemComparePaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 23f
            flags = Paint.STRIKE_THRU_TEXT_FLAG or Paint.ANTI_ALIAS_FLAG
        }
        val qrWrapPaint = Paint().apply { color = Color.parseColor("#FFF8F5"); isAntiAlias = true }
        val scanMiniPaint = Paint().apply {
            color = Color.parseColor("#52637A")
            textSize = 20f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        featured.forEachIndexed { idx, item ->
            val col = idx % cols
            val row = idx / cols
            val left = startX + col * (cardW + gapX)
            val top = startY + row * (cardH + gapY)
            val rect = RectF(left, top, left + cardW, top + cardH)
            canvas.drawRoundRect(rect, 26f, 26f, cardBgPaint)
            canvas.drawRoundRect(rect, 26f, 26f, cardBorderPaint)

            // Badges row
            if (item.discountPct > 0) {
                val bRect = RectF(left + 20f, top + 18f, left + 132f, top + 54f)
                canvas.drawRoundRect(bRect, 10f, 10f, badgeOffPaint)
                canvas.drawText("-${item.discountPct}%", left + 36f, top + 44f, badgeTxtPaint)
            }
            if (item.isFlashDeal) {
                val fLeft = if (item.discountPct > 0) left + 144f else left + 20f
                val fRect = RectF(fLeft, top + 18f, fLeft + 116f, top + 54f)
                canvas.drawRoundRect(fRect, 10f, 10f, badgeFlashPaint)
                canvas.drawText("FLASH", fLeft + 20f, top + 44f, badgeTxtPaint)
            }

            canvas.drawText(item.category.ifBlank { "Shop Item" }.take(22), left + 22f, top + 92f, itemCatPaint)
            canvas.drawText(item.productName.take(22), left + 22f, top + 134f, itemNamePaint)
            canvas.drawText(item.priceText, left + 22f, top + 186f, itemPricePaint)
            if (!item.comparePriceText.isNullOrBlank()) {
                canvas.drawText(item.comparePriceText, left + 22f, top + 218f, itemComparePaint)
            }

            // Per-product mini scannable QR
            val qrSize = 196
            val qrLeft = left + (cardW - qrSize) / 2f
            val qrTop = top + 230f
            canvas.drawRoundRect(
                RectF(qrLeft - 12f, qrTop - 10f, qrLeft + qrSize + 12f, qrTop + qrSize + 10f),
                16f,
                16f,
                qrWrapPaint
            )
            val prodQr = generateQrBitmap(item.productOrderUrl, sizePx = qrSize, quietModules = 2)
            canvas.drawBitmap(prodQr, qrLeft, qrTop, null)
            canvas.drawText("Scan QR to Order", left + cardW / 2f, top + cardH - 16f, scanMiniPaint)
        }

        // Bottom Footer
        canvas.drawRect(0f, h - 134f, w.toFloat(), h.toFloat(), navyPaint)
        val footerMain = Paint().apply {
            color = Color.WHITE
            textSize = 28f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val footerAccent = Paint().apply {
            color = Color.parseColor("#FFD6C2")
            textSize = 23f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("Scan Any Product QR with Phone Camera to Order Directly", w / 2f, h - 76f, footerMain)
        canvas.drawText("Promo: SAVE50 • HISAB10 | COD • bKash • Nagad • Rocket • Upay", w / 2f, h - 34f, footerAccent)

        val exportsDir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
        val file = File(exportsDir, "digital_shop_catalog_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file
    }
}
