package com.example.core.util

import android.content.Context
import com.example.data.local.AccountEntity
import com.example.data.local.AccountTypes
import com.example.data.local.BusinessEntity
import com.example.data.local.ProductEntity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

/**
 * Generates zero-app-install discovery & ordering assets for any Online Shop:
 * 1. Complete, self-contained Daraz-style HTML5 Mobile Web Storefront (works in Chrome/Safari/GitHub Pages/Netlify Drop)
 * 2. Direct WhatsApp click-to-order URL (`https://wa.me/880...`)
 * 3. Facebook / WhatsApp / Messenger shop catalog post
 */
object WebStorefrontGenerator {

    fun normalizeBdWhatsAppDigits(phone: String): String {
        val digits = MoneyUtils.normalizeDigits(phone).filter { it.isDigit() }
        return when {
            digits.startsWith("880") && digits.length >= 13 -> digits
            digits.startsWith("01") && digits.length >= 11 -> "88$digits"
            digits.startsWith("1") && digits.length == 10 -> "880$digits"
            else -> digits
        }
    }

    fun buildDirectWhatsAppCatalogUrl(businessName: String, phone: String): String {
        val waDigits = normalizeBdWhatsAppDigits(phone)
        val greeting = URLEncoder.encode(
            "Assalamu Alaikum $businessName, I want to see products & order from your Online Shop.",
            "UTF-8"
        )
        return if (waDigits.isNotBlank()) {
            "https://wa.me/$waDigits?text=$greeting"
        } else {
            "https://wa.me/?text=$greeting"
        }
    }

    fun resolveCustomerShopEntryUrl(
        business: BusinessEntity?,
        customWebShopUrl: String
    ): String {
        val trimmed = customWebShopUrl.trim()
        if (trimmed.startsWith("https://", ignoreCase = true) || trimmed.startsWith("http://", ignoreCase = true)) {
            return trimmed
        }
        return buildDirectWhatsAppCatalogUrl(
            businessName = business?.name ?: "Online Shop",
            phone = business?.phone.orEmpty()
        )
    }

    /**
     * Generates a compact scannable URL for an individual product.
     * - If a hosted Web Shop URL is configured, appends `?product=<id>` so scanning opens that product directly.
     * - Otherwise creates a direct WhatsApp pre-filled order link (`https://wa.me/880...?text=...`)
     *   kept compact so Version 5-8 QR codes stay crisp and scannable even on small catalog tiles.
     */
    fun buildProductOrderUrl(
        business: BusinessEntity?,
        product: ProductEntity,
        customWebShopUrl: String
    ): String {
        val trimmed = customWebShopUrl.trim()
        if (trimmed.startsWith("https://", ignoreCase = true) || trimmed.startsWith("http://", ignoreCase = true)) {
            val sep = if ('?' in trimmed) '&' else '?'
            val encodedId = URLEncoder.encode(product.id, "UTF-8")
            return "$trimmed${sep}product=$encodedId"
        }
        val waDigits = normalizeBdWhatsAppDigits(business?.phone.orEmpty())
        val priceTaka = product.sellingPricePaisa / 100L
        val shopTag = (business?.name ?: "Shop").trim().take(22)
        val prodTag = product.name.trim().take(36)
        val msg = "Order: $prodTag (Tk $priceTaka/${product.unit.ifBlank { "pc" }}) Qty: 1 - $shopTag"
        val encoded = URLEncoder.encode(msg, "UTF-8")
        return if (waDigits.isNotBlank()) {
            "https://wa.me/$waDigits?text=$encoded"
        } else {
            "https://wa.me/?text=$encoded"
        }
    }

    fun buildSocialShopPost(
        business: BusinessEntity?,
        products: List<ProductEntity>,
        targetOrderUrl: String,
        useBanglaDigits: Boolean
    ): String {
        val shopName = business?.name ?: "Online Shop"
        val listed = products.filter { !it.archived && it.onlineListed }
        val flash = listed.filter { it.isFlashDeal || it.onlineComparePricePaisa > it.sellingPricePaisa }
        return buildString {
            appendLine("🛍️ *$shopName — অনলাইন শপ এখন খোলা!*")
            if (!business?.address.isNullOrBlank()) {
                appendLine("📍 ${business?.address}")
            }
            appendLine("অ্যাপ ডাউনলোড ছাড়াই সরাসরি অর্ডার করুন নিচের লিংক থেকে 👇")
            appendLine("🔗 $targetOrderUrl")
            appendLine()
            if (flash.isNotEmpty()) {
                appendLine("⚡ *ফ্ল্যাশ ডিল / Flash Deals:*")
                flash.take(6).forEach { p ->
                    val price = MoneyUtils.formatTaka(p.sellingPricePaisa, useBanglaDigits)
                    val old = if (p.onlineComparePricePaisa > p.sellingPricePaisa) {
                        " (আগে ${MoneyUtils.formatTaka(p.onlineComparePricePaisa, useBanglaDigits)})"
                    } else ""
                    appendLine("🔥 ${p.name} — $price/${p.unit}$old")
                }
                appendLine()
            }
            appendLine("📦 *জনপ্রিয় পণ্যসমূহ:*")
            listed.take(15).forEachIndexed { idx, p ->
                val price = MoneyUtils.formatTaka(p.sellingPricePaisa, useBanglaDigits)
                appendLine("${idx + 1}. ${p.name} — $price/${p.unit}")
            }
            appendLine()
            appendLine("🎁 প্রোমো কোড: *SAVE50* (৳৫০ ছাড়) | *HISAB10* (১০% ছাড়)")
            appendLine("💳 পেমেন্ট: ক্যাশ অন ডেলিভারি (COD), বিকাশ, নগদ, রকেট")
            if (!business?.phone.isNullOrBlank()) {
                appendLine("📞 কল/হোয়াটসঅ্যাপ: ${business?.phone}")
            }
        }
    }

    fun exportWebStorefrontHtmlFile(
        context: Context,
        business: BusinessEntity?,
        products: List<ProductEntity>,
        isBanglaDefault: Boolean,
        accounts: List<AccountEntity> = emptyList()
    ): File {
        val exportsDir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
        val slug = (business?.name ?: "hisab_shop")
            .lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "online_shop" }
        val file = File(exportsDir, "${slug}_online_shop.html")
        val html = generateWebStorefrontHtml(business, products, isBanglaDefault, accounts)
        file.writeText(html, Charsets.UTF_8)
        return file
    }

    fun generateWebStorefrontHtml(
        business: BusinessEntity?,
        products: List<ProductEntity>,
        isBanglaDefault: Boolean,
        accounts: List<AccountEntity> = emptyList()
    ): String {
        val shopName = escapeHtml(business?.name ?: "Hisab Online Shop")
        val shopCategory = escapeHtml(business?.category ?: "Retail Store")
        val shopPhone = business?.phone.orEmpty()
        val shopAddress = escapeHtml(business?.address ?: "Bangladesh")
        val waDigits = normalizeBdWhatsAppDigits(shopPhone)
        val mfsWalletMap = JSONObject().apply {
            listOf(AccountTypes.BKASH, AccountTypes.NAGAD, AccountTypes.ROCKET, AccountTypes.UPAY).forEach { type ->
                val acc = accounts.firstOrNull { !it.archived && it.type == type }
                val num = acc?.accountNumber?.trim().orEmpty().ifBlank { shopPhone.trim() }
                put(type, JSONObject().apply {
                    put("name", acc?.name ?: type)
                    put("num", num)
                })
            }
        }

        val listed = products.filter { !it.archived && it.onlineListed }
        val catalogArr = JSONArray()
        listed.forEach { p ->
            catalogArr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("cat", p.category.ifBlank { "General" })
                put("unit", p.unit.ifBlank { "Piece" })
                put("price", p.sellingPricePaisa / 100.0)
                put("compare", p.onlineComparePricePaisa / 100.0)
                put("flash", p.isFlashDeal || (p.onlineComparePricePaisa > p.sellingPricePaisa && p.sellingPricePaisa > 0L))
                put("stock", p.stockMilliUnits / 1000.0)
                put("desc", p.onlineDescription)
                put("rating", p.ratingX10 / 10.0)
                put("sold", p.soldCount)
            })
        }
        val safeCatalogJson = catalogArr.toString().replace("</", "<\\/")
        val defaultLang = if (isBanglaDefault) "bn" else "en"

        return """
<!DOCTYPE html>
<html lang="$defaultLang">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>$shopName — Online Shop</title>
<style>
  :root {
    --orange: #F85606;
    --orange-dark: #D94400;
    --orange-soft: #FFF1EA;
    --navy: #101C2C;
    --emerald: #10A36C;
    --bg: #F4F6F8;
    --card: #FFFFFF;
    --border: #E2E8F0;
    --muted: #52637A;
  }
  * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
  body { margin: 0; background: var(--bg); color: var(--navy); padding-bottom: 92px; }
  header {
    position: sticky; top: 0; z-index: 20; background: #fff;
    border-bottom: 1px solid var(--border); padding: 12px 14px;
  }
  .top-row { display: flex; justify-content: space-between; align-items: center; gap: 8px; }
  .shop-title { font-size: 18px; font-weight: 800; color: var(--navy); margin: 0; }
  .shop-sub { font-size: 12px; color: var(--orange); font-weight: 600; }
  .lang-btn {
    border: 1px solid var(--orange); background: var(--orange-soft); color: var(--orange);
    border-radius: 999px; padding: 6px 12px; font-weight: 700; font-size: 12px; cursor: pointer;
  }
  .search-wrap { margin-top: 10px; }
  .search-input {
    width: 100%; padding: 10px 14px; border-radius: 12px; border: 1px solid var(--border);
    font-size: 14px; outline: none; background: var(--bg);
  }
  .search-input:focus { border-color: var(--orange); background: #fff; }
  .container { max-width: 960px; margin: 0 auto; padding: 14px; }
  .hero {
    background: linear-gradient(135deg, var(--orange), var(--orange-dark), var(--navy));
    color: #fff; border-radius: 18px; padding: 16px; margin-bottom: 14px;
  }
  .hero-badge {
    display: inline-block; background: rgba(255,255,255,0.2); padding: 4px 10px;
    border-radius: 8px; font-size: 11px; font-weight: 700; margin-bottom: 8px;
  }
  .hero h2 { margin: 0 0 6px 0; font-size: 20px; }
  .hero p { margin: 0; font-size: 13px; opacity: 0.92; line-height: 1.45; }
  .chips { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 8px; margin-bottom: 10px; }
  .chip {
    white-space: nowrap; border: 1px solid var(--border); background: #fff; color: var(--navy);
    border-radius: 999px; padding: 7px 14px; font-size: 13px; font-weight: 600; cursor: pointer;
  }
  .chip.active { background: var(--orange); color: #fff; border-color: var(--orange); }
  .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
  @media (min-width: 640px) { .grid { grid-template-columns: repeat(3, 1fr); gap: 14px; } }
  .card {
    background: var(--card); border: 1px solid var(--border); border-radius: 16px;
    padding: 10px; display: flex; flex-direction: column; justify-content: space-between;
  }
  .thumb {
    height: 110px; border-radius: 12px; background: var(--orange-soft); position: relative;
    display: flex; align-items: center; justify-content: center; font-size: 34px; margin-bottom: 8px;
  }
  .badge-off {
    position: absolute; top: 8px; left: 8px; background: var(--orange); color: #fff;
    font-size: 11px; font-weight: 800; padding: 2px 7px; border-radius: 6px;
  }
  .badge-flash {
    position: absolute; top: 8px; right: 8px; background: var(--navy); color: #FDE047;
    font-size: 10px; font-weight: 800; padding: 2px 6px; border-radius: 6px;
  }
  .pname { font-size: 14px; font-weight: 700; margin-bottom: 4px; min-height: 36px; }
  .pmeta { font-size: 11px; color: var(--muted); margin-bottom: 6px; }
  .price-row { display: flex; align-items: baseline; gap: 6px; margin-bottom: 8px; }
  .price { font-size: 17px; font-weight: 800; color: var(--orange); }
  .compare { font-size: 12px; color: var(--muted); text-decoration: line-through; }
  .btn-add {
    width: 100%; border: none; background: var(--orange-soft); color: var(--orange);
    padding: 9px; border-radius: 10px; font-weight: 700; font-size: 13px; cursor: pointer;
  }
  .btn-add.in-cart { background: #E6F7F0; color: var(--emerald); }
  .qty-row { display: flex; align-items: center; justify-content: space-between; gap: 6px; }
  .qty-btn {
    border: none; background: var(--orange); color: #fff; width: 32px; height: 32px;
    border-radius: 8px; font-weight: 800; font-size: 16px; cursor: pointer;
  }
  .cart-bar {
    position: fixed; bottom: 0; left: 0; right: 0; background: var(--navy); color: #fff;
    padding: 12px 16px; display: none; align-items: center; justify-content: space-between;
    z-index: 30; box-shadow: 0 -4px 16px rgba(0,0,0,0.18);
  }
  .cart-btn {
    background: var(--orange); color: #fff; border: none; border-radius: 12px;
    padding: 11px 18px; font-weight: 800; font-size: 14px; cursor: pointer;
  }
  .modal-bg {
    position: fixed; inset: 0; background: rgba(16,28,44,0.58); z-index: 40;
    display: none; align-items: flex-end; justify-content: center;
  }
  .sheet {
    background: #fff; width: 100%; max-width: 560px; max-height: 92vh; overflow-y: auto;
    border-radius: 22px 22px 0 0; padding: 18px;
  }
  .field { width: 100%; padding: 10px 12px; border: 1px solid var(--border); border-radius: 10px; margin-bottom: 10px; font-size: 14px; }
  .summary-box {
    background: #E6F7F0; border: 1px solid rgba(16,163,108,0.35); border-radius: 12px;
    padding: 12px; margin: 10px 0 14px 0; font-size: 13px;
  }
  .summary-row { display: flex; justify-content: space-between; margin-bottom: 4px; }
  .btn-wa {
    width: 100%; border: none; background: #16A34A; color: #fff; padding: 13px;
    border-radius: 12px; font-weight: 800; font-size: 15px; cursor: pointer; margin-bottom: 8px;
  }
  .btn-sec {
    width: 100%; border: 1px solid var(--border); background: #fff; color: var(--navy); padding: 11px;
    border-radius: 12px; font-weight: 700; font-size: 14px; cursor: pointer; margin-bottom: 8px;
  }
  .quick-overlay {
    position: fixed; inset: 0; background: rgba(16,28,44,0.62); z-index: 45;
    display: none; align-items: center; justify-content: center; padding: 16px;
  }
  .quick-card {
    background: #fff; width: 100%; max-width: 440px; border-radius: 20px; padding: 18px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.22);
  }
  @media print {
    header .search-wrap, .lang-btn, .cart-bar, .btn-add, .qty-row, #printBtn { display: none !important; }
    body { padding-bottom: 0; background: #fff; }
    .grid { grid-template-columns: repeat(3, 1fr); }
  }
</style>
</head>
<body>
<header>
  <div class="top-row">
    <div>
      <h1 class="shop-title">$shopName</h1>
      <div class="shop-sub" id="subtitleTxt">$shopCategory • $shopAddress</div>
    </div>
    <button class="lang-btn" id="langBtn" onclick="toggleLang()">বাংলা / EN</button>
  </div>
  <div class="search-wrap">
    <input class="search-input" id="searchInput" oninput="renderProducts()" placeholder="Search products..." />
  </div>
</header>

<div class="container">
  <div class="hero">
    <span class="hero-badge" id="heroBadge">NO APP NEEDED • DIRECT WEB SHOP</span>
    <h2 id="heroTitle">$shopName</h2>
    <p id="heroDesc">Promo Codes: SAVE50 (৳50 off) • HISAB10 (10% off) | COD, bKash, Nagad &amp; Rocket</p>
  </div>
  <div class="chips" id="catChips"></div>
  <div class="grid" id="productGrid"></div>
</div>

<div class="cart-bar" id="cartBar">
  <div>
    <div style="font-size:12px;opacity:0.8" id="cartCountTxt">0 items</div>
    <div style="font-size:18px;font-weight:800;color:#FFD6C2" id="cartSubtotalTxt">৳0</div>
  </div>
  <button class="cart-btn" id="openCartBtn" onclick="openCheckout()">Checkout →</button>
</div>

<div class="modal-bg" id="checkoutModal">
  <div class="sheet">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <h3 style="margin:0" id="checkoutHeading">Your Order</h3>
      <button onclick="closeCheckout()" style="border:none;background:none;font-size:20px;cursor:pointer;">✕</button>
    </div>
    <div id="cartItemsContainer" style="margin-bottom:12px;"></div>
    <input class="field" id="custName" placeholder="Your Name *" />
    <input class="field" id="custPhone" type="tel" placeholder="Mobile Number (+880) *" />
    <input class="field" id="custAddr" placeholder="Delivery Address *" />
    <select class="field" id="delivZone" onchange="updateCheckoutSummary()">
      <option value="Dhaka|60">Inside Dhaka Delivery (৳60)</option>
      <option value="Outside Dhaka|120">Outside Dhaka Delivery (৳120)</option>
      <option value="Pickup|0">Shop Pickup (৳0)</option>
    </select>
    <select class="field" id="payMethod" onchange="updateMfsBox()">
      <option value="COD">Cash on Delivery (COD)</option>
      <option value="BKASH">bKash (বিকাশ)</option>
      <option value="NAGAD">Nagad (নগদ)</option>
      <option value="ROCKET">Rocket (রকেট)</option>
      <option value="UPAY">Upay (উপায়)</option>
      <option value="BANK">Bank Transfer</option>
    </select>
    <div id="mfsBox" style="display:none;background:#FFF7ED;border:1px solid #FDBA74;border-radius:12px;padding:12px;margin-bottom:10px;font-size:13px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px;">
        <b id="mfsBoxTitle" style="color:#9A3412;">bKash Payment</b>
        <button type="button" onclick="copyMfsNum()" style="border:1px solid #F85606;background:#fff;color:#F85606;border-radius:8px;padding:4px 10px;font-weight:700;font-size:12px;cursor:pointer;">Copy Number</button>
      </div>
      <div id="mfsNumberTxt" style="font-size:15px;font-weight:800;color:#101C2C;margin-bottom:6px;"></div>
      <div id="mfsGuideTxt" style="font-size:12px;color:#52637A;margin-bottom:8px;"></div>
      <a id="mfsDialLink" href="tel:*247%23" style="display:inline-block;background:#101C2C;color:#fff;text-decoration:none;border-radius:8px;padding:6px 12px;font-size:12px;font-weight:700;margin-bottom:8px;">Dial USSD (*247#)</a>
      <input class="field" id="mfsSenderPhone" type="tel" style="margin-bottom:6px;" placeholder="Sender bKash/Nagad/Rocket/Upay Number" />
      <input class="field" id="mfsTrxId" style="margin-bottom:0;" placeholder="Transaction ID (TrxID) *" />
    </div>
    <input class="field" id="promoCode" oninput="updateCheckoutSummary()" placeholder="Promo Code (SAVE50 / HISAB10)" />
    <div class="summary-box" id="summaryBox"></div>
    <button class="btn-wa" id="waOrderBtn" onclick="submitOrder('wa')">Order on WhatsApp</button>
    <button class="btn-sec" id="smsOrderBtn" onclick="submitOrder('sms')">Order via SMS</button>
    <button class="btn-sec" id="copyOrderBtn" onclick="submitOrder('copy')">Copy Order Message</button>
  </div>
</div>

<div class="quick-overlay" id="quickViewModal">
  <div class="quick-card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <span id="qvBadge" style="background:#FFF1EA;color:#F85606;font-size:11px;font-weight:800;padding:4px 8px;border-radius:6px;">PRODUCT</span>
      <button onclick="closeQuickView()" style="border:none;background:none;font-size:20px;cursor:pointer;">✕</button>
    </div>
    <h3 id="qvName" style="margin:0 0 6px 0;font-size:18px;"></h3>
    <div id="qvPrice" style="font-size:22px;font-weight:800;color:#F85606;margin-bottom:6px;"></div>
    <p id="qvDesc" style="font-size:13px;color:#52637A;margin:0 0 14px 0;line-height:1.45;"></p>
    <button class="btn-wa" id="qvAddCartBtn">Add to Cart &amp; Checkout</button>
    <button class="btn-sec" onclick="closeQuickView()">Continue Browsing</button>
  </div>
</div>

<script>
const SHOP_NAME = ${JSONObject.quote(business?.name ?: "Hisab Online Shop")};
const SHOP_WA = ${JSONObject.quote(waDigits)};
const SHOP_PHONE = ${JSONObject.quote(shopPhone)};
const MFS_WALLETS = $mfsWalletMap;
const MFS_USSD = { BKASH: "*247#", NAGAD: "*167#", ROCKET: "*322#", UPAY: "*268#" };
const PRODUCTS = $safeCatalogJson;
let lang = "$defaultLang";
let activeCat = "All";
let cart = {};

const I18N = {
  en: {
    search: "Search products...",
    heroBadge: "NO APP NEEDED • DIRECT WEB SHOP",
    heroDesc: "Promo Codes: SAVE50 (৳50 off) • HISAB10 (10% off) | COD, bKash, Nagad & Rocket",
    all: "All", flash: "⚡ Flash Deals", add: "Add to Cart", checkout: "Checkout →",
    itemsTxt: "item(s)", orderTitle: "Complete Your Order",
    waBtn: "Order on WhatsApp", smsBtn: "Order via SMS", copyBtn: "Copy Order Text",
    needInfo: "Please enter your name and mobile number.",
    copied: "Order copied! Send it on Facebook Messenger or WhatsApp."
  },
  bn: {
    search: "পণ্য খুঁজুন...",
    heroBadge: "অ্যাপ ছাড়াই সরাসরি ওয়েব শপ",
    heroDesc: "প্রোমো কোড: SAVE50 (৳৫০ ছাড়) • HISAB10 (১০% ছাড়) | ক্যাশ অন ডেলিভারি, বিকাশ, নগদ",
    all: "সব পণ্য", flash: "⚡ ফ্ল্যাশ ডিল", add: "কার্টে যোগ করুন", checkout: "অর্ডার করুন →",
    itemsTxt: "টি পণ্য", orderTitle: "অর্ডার সম্পন্ন করুন",
    waBtn: "WhatsApp-এ অর্ডার পাঠান", smsBtn: "SMS-এ অর্ডার পাঠান", copyBtn: "অর্ডার টেক্সট কপি করুন",
    needInfo: "অনুগ্রহ করে আপনার নাম ও মোবাইল নম্বর লিখুন।",
    copied: "অর্ডার কপি হয়েছে! এখন Messenger বা WhatsApp-এ পেস্ট করে পাঠান।"
  }
};

function toggleLang() {
  lang = (lang === "bn") ? "en" : "bn";
  applyLabels();
  renderCategories();
  renderProducts();
}

function applyLabels() {
  const t = I18N[lang];
  document.getElementById("searchInput").placeholder = t.search;
  document.getElementById("heroBadge").innerText = t.heroBadge;
  document.getElementById("heroDesc").innerText = t.heroDesc;
  document.getElementById("openCartBtn").innerText = t.checkout;
  document.getElementById("checkoutHeading").innerText = t.orderTitle;
  document.getElementById("waOrderBtn").innerText = t.waBtn;
  document.getElementById("smsOrderBtn").innerText = t.smsBtn;
  document.getElementById("copyOrderBtn").innerText = t.copyBtn;
}

function renderCategories() {
  const t = I18N[lang];
  const cats = ["All"];
  if (PRODUCTS.some(p => p.flash)) cats.push("Flash");
  PRODUCTS.forEach(p => { if (!cats.includes(p.cat)) cats.push(p.cat); });
  const wrap = document.getElementById("catChips");
  wrap.innerHTML = cats.map(c => {
    const label = c === "All" ? t.all : (c === "Flash" ? t.flash : c);
    return '<button class="chip ' + (activeCat === c ? 'active' : '') + '" onclick="setCat(\'' + c.replace(/'/g, "\\'") + '\')">' + label + '</button>';
  }).join("");
}

function setCat(c) { activeCat = c; renderCategories(); renderProducts(); }

function renderProducts() {
  const t = I18N[lang];
  const q = document.getElementById("searchInput").value.trim().toLowerCase();
  const list = PRODUCTS.filter(p => {
    const mq = !q || p.name.toLowerCase().includes(q) || p.cat.toLowerCase().includes(q);
    const mc = activeCat === "All" ? true : (activeCat === "Flash" ? p.flash : p.cat === activeCat);
    return mq && mc;
  });
  const grid = document.getElementById("productGrid");
  if (!list.length) {
    grid.innerHTML = '<div style="grid-column:1/-1;background:#fff;padding:24px;border-radius:14px;text-align:center;">No products found</div>';
    return;
  }
  grid.innerHTML = list.map(p => {
    const hasOff = p.compare > p.price && p.price > 0;
    const offPct = hasOff ? Math.round(((p.compare - p.price) * 100) / p.compare) : 0;
    const qty = cart[p.id] || 0;
    const actionHtml = qty > 0
      ? '<div class="qty-row"><button class="qty-btn" onclick="addCart(\'' + p.id + '\',-1)">-</button><b>' + qty + ' ' + p.unit + '</b><button class="qty-btn" onclick="addCart(\'' + p.id + '\',1)">+</button></div>'
      : '<button class="btn-add" onclick="addCart(\'' + p.id + '\',1)">' + t.add + '</button>';
    return '<div class="card">' +
      '<div>' +
        '<div class="thumb">🛍️' +
          (hasOff ? '<span class="badge-off">-' + offPct + '%</span>' : '') +
          (p.flash ? '<span class="badge-flash">FLASH</span>' : '') +
        '</div>' +
        '<div class="pname">' + esc(p.name) + '</div>' +
        '<div class="pmeta">★ ' + p.rating.toFixed(1) + ' • ' + p.sold + ' sold</div>' +
        '<div class="price-row"><span class="price">৳' + p.price.toFixed(0) + '</span>' +
          (hasOff ? '<span class="compare">৳' + p.compare.toFixed(0) + '</span>' : '') +
        '</div>' +
      '</div>' +
      actionHtml +
    '</div>';
  }).join("");
}

function addCart(id, delta) {
  const next = (cart[id] || 0) + delta;
  if (next <= 0) delete cart[id]; else cart[id] = next;
  updateCartBar();
  renderProducts();
  if (document.getElementById("checkoutModal").style.display === "flex") {
    renderCheckoutItems();
    updateCheckoutSummary();
  }
}

function updateCartBar() {
  const entries = Object.entries(cart);
  const bar = document.getElementById("cartBar");
  if (!entries.length) { bar.style.display = "none"; return; }
  let sub = 0;
  entries.forEach(([id, q]) => {
    const p = PRODUCTS.find(x => x.id === id);
    if (p) sub += p.price * q;
  });
  document.getElementById("cartCountTxt").innerText = entries.length + " " + I18N[lang].itemsTxt;
  document.getElementById("cartSubtotalTxt").innerText = "৳" + sub.toFixed(0);
  bar.style.display = "flex";
}

function openCheckout() {
  renderCheckoutItems();
  updateCheckoutSummary();
  document.getElementById("checkoutModal").style.display = "flex";
}
function closeCheckout() { document.getElementById("checkoutModal").style.display = "none"; }

function renderCheckoutItems() {
  const wrap = document.getElementById("cartItemsContainer");
  wrap.innerHTML = Object.entries(cart).map(([id, q]) => {
    const p = PRODUCTS.find(x => x.id === id);
    if (!p) return "";
    return '<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #eee;">' +
      '<div><b>' + esc(p.name) + '</b><br><small>' + q + ' ' + p.unit + ' × ৳' + p.price.toFixed(0) + '</small></div>' +
      '<b>৳' + (p.price * q).toFixed(0) + '</b></div>';
  }).join("");
}

function calcSummary() {
  let sub = 0;
  const items = [];
  Object.entries(cart).forEach(([id, q]) => {
    const p = PRODUCTS.find(x => x.id === id);
    if (p && q > 0) {
      sub += p.price * q;
      items.push({ id: p.id, n: p.name, u: p.unit, q: q, pr: p.price });
    }
  });
  const zoneRaw = document.getElementById("delivZone").value.split("|");
  const district = zoneRaw[0];
  const deliv = Number(zoneRaw[1] || 0);
  const code = document.getElementById("promoCode").value.trim().toUpperCase();
  let disc = 0;
  if (code === "SAVE50") disc = Math.min(50, sub);
  else if (code === "HISAB10" || code === "DARAZ10") disc = Math.min(500, Math.round(sub * 0.1));
  const total = Math.max(0, sub - disc) + deliv;
  return { sub, disc, deliv, total, district, code, items };
}

function updateCheckoutSummary() {
  const s = calcSummary();
  document.getElementById("summaryBox").innerHTML =
    '<div class="summary-row"><span>Subtotal</span><b>৳' + s.sub.toFixed(0) + '</b></div>' +
    (s.disc > 0 ? '<div class="summary-row" style="color:#10A36C"><span>Promo (' + esc(s.code) + ')</span><b>-৳' + s.disc.toFixed(0) + '</b></div>' : '') +
    '<div class="summary-row"><span>Delivery (' + s.district + ')</span><b>৳' + s.deliv.toFixed(0) + '</b></div>' +
    '<hr style="border:none;border-top:1px solid rgba(16,163,108,0.25);margin:6px 0">' +
    '<div class="summary-row" style="font-size:16px"><b>Total</b><b style="color:#F85606">৳' + s.total.toFixed(0) + '</b></div>';
}

function updateMfsBox() {
  const pay = document.getElementById("payMethod").value;
  const box = document.getElementById("mfsBox");
  if (!["BKASH", "NAGAD", "ROCKET", "UPAY"].includes(pay)) {
    box.style.display = "none";
    return;
  }
  const w = MFS_WALLETS[pay] || { name: pay, num: SHOP_PHONE };
  const ussd = MFS_USSD[pay] || "*247#";
  const numStr = (w.num && w.num.trim()) ? w.num : (SHOP_PHONE || "Ask shop on WhatsApp");
  document.getElementById("mfsBoxTitle").innerText = w.name + " Payment";
  document.getElementById("mfsNumberTxt").innerText = numStr;
  document.getElementById("mfsGuideTxt").innerText =
    lang === "bn"
      ? ("এই নম্বরে টাকা পাঠিয়ে (Send Money / Payment) নিচে আপনার নম্বর ও TrxID লিখুন।")
      : ("Send Money / Payment to this " + pay + " number, then enter your TrxID below.");
  const dial = document.getElementById("mfsDialLink");
  dial.href = "tel:" + encodeURIComponent(ussd);
  dial.innerText = "Dial " + pay + " (" + ussd + ")";
  box.style.display = "block";
}

function copyMfsNum() {
  const txt = document.getElementById("mfsNumberTxt").innerText;
  if (navigator.clipboard && txt) {
    navigator.clipboard.writeText(txt);
    alert("Copied: " + txt);
  }
}

function submitOrder(mode) {
  const name = document.getElementById("custName").value.trim();
  const phone = document.getElementById("custPhone").value.trim();
  const addr = document.getElementById("custAddr").value.trim();
  const pay = document.getElementById("payMethod").value;
  const senderMfs = (document.getElementById("mfsSenderPhone") ? document.getElementById("mfsSenderPhone").value.trim() : "");
  const trxId = (document.getElementById("mfsTrxId") ? document.getElementById("mfsTrxId").value.trim().toUpperCase() : "");
  const s = calcSummary();
  if (!name || !phone) { alert(I18N[lang].needInfo); return; }
  if (!s.items.length) return;

  const lines = s.items.map(i => "• " + i.n + " × " + i.q + " " + i.u + " = ৳" + (i.pr * i.q).toFixed(0)).join("\n");
  const payload = JSON.stringify({
    c: name, p: phone, a: addr, z: s.district, d: s.deliv, pm: pay, pc: s.code,
    trx: trxId, sp: senderMfs,
    items: s.items.map(i => ({ id: i.id, n: i.n, q: i.q }))
  });
  const mfsInfo = trxId ? ("\nTrxID: " + trxId + (senderMfs ? ("\nSender: " + senderMfs) : "")) : "";
  const msg = "🛒 *New Order — " + SHOP_NAME + "*\n" +
    "Name: " + name + "\nPhone: " + phone + "\nAddress: " + addr + " (" + s.district + ")\n" +
    "Payment: " + pay + mfsInfo + "\n\n" + lines + "\n\n" +
    "Delivery: ৳" + s.deliv + (s.disc > 0 ? "\nDiscount (" + s.code + "): -৳" + s.disc : "") +
    "\n*Total Payable: ৳" + s.total.toFixed(0) + "*\n\n#HISAB_ORDER:" + payload;

  if (mode === "wa") {
    const waBase = SHOP_WA ? ("https://wa.me/" + SHOP_WA) : "https://wa.me/";
    window.location.href = waBase + "?text=" + encodeURIComponent(msg);
  } else if (mode === "sms") {
    window.location.href = "sms:" + SHOP_PHONE + "?body=" + encodeURIComponent(msg);
  } else {
    if (navigator.clipboard) navigator.clipboard.writeText(msg);
    alert(I18N[lang].copied);
  }
}

function openQuickView(prodId) {
  const p = PRODUCTS.find(x => x.id === prodId);
  if (!p) return;
  document.getElementById("qvBadge").innerText = p.cat + (p.flash ? " • ⚡ FLASH" : "");
  document.getElementById("qvName").innerText = p.name;
  document.getElementById("qvPrice").innerText = "৳" + p.price.toFixed(0) + " / " + p.unit;
  document.getElementById("qvDesc").innerText = p.desc || ("Available stock: " + p.stock + " " + p.unit);
  document.getElementById("qvAddCartBtn").onclick = function() {
    addCart(p.id, 1);
    closeQuickView();
    openCheckout();
  };
  document.getElementById("quickViewModal").style.display = "flex";
}

function closeQuickView() {
  document.getElementById("quickViewModal").style.display = "none";
}

function esc(s) {
  return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

applyLabels();
renderCategories();
renderProducts();
try {
  const focusProd = new URLSearchParams(window.location.search).get("product");
  if (focusProd) openQuickView(focusProd);
} catch (_) {}
</script>
</body>
</html>
        """.trimIndent()
    }

    private fun escapeHtml(raw: String): String =
        raw.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")
}
