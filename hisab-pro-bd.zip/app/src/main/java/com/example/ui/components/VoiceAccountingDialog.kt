package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.core.util.ParsedVoiceCommand
import com.example.core.util.VoiceIntentType
import com.example.core.util.VoiceSpeechHelper
import com.example.data.local.AccountEntity
import com.example.data.local.CustomerEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VoiceAccountingDialog(
    accounts: List<AccountEntity>,
    useBanglaDigits: Boolean,
    initialBangla: Boolean,
    onParseCommand: (String) -> ParsedVoiceCommand,
    onExecuteCommand: (ParsedVoiceCommand, String, (Boolean, String) -> Unit) -> Unit,
    onAskAiQuery: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val speechHelper = remember { VoiceSpeechHelper(context) }

    DisposableEffect(Unit) {
        onDispose { speechHelper.stop() }
    }

    var useBanglaVoice by remember { mutableStateOf(initialBangla) }
    var isListening by remember { mutableStateOf(false) }
    var speechError by remember { mutableStateOf<String?>(null) }
    var rawText by remember { mutableStateOf("") }
    var parsed by remember { mutableStateOf<ParsedVoiceCommand?>(null) }

    var editableAmount by remember { mutableStateOf("") }
    var editablePartyOrCategory by remember { mutableStateOf("") }
    var editableNotes by remember { mutableStateOf("") }
    var selectedAccount by remember(accounts) { mutableStateOf(accounts.firstOrNull()) }

    fun applyParsed(cmd: ParsedVoiceCommand) {
        parsed = cmd
        editableAmount = if (cmd.amountPaisa > 0L) MoneyUtils.paisaToInputString(cmd.amountPaisa) else ""
        editablePartyOrCategory = when (cmd.intentType) {
            VoiceIntentType.EXPENSE, VoiceIntentType.INCOME -> cmd.categoryName
            VoiceIntentType.SALE -> cmd.productName.ifBlank { cmd.customerName }
            else -> cmd.customerName
        }
        editableNotes = cmd.notes
    }

    fun startSpeech() {
        speechError = null
        val langTag = if (useBanglaVoice) "bn-BD" else "en-US"
        speechHelper.startListening(
            languageTag = langTag,
            onResult = { spoken ->
                rawText = spoken
                applyParsed(onParseCommand(spoken))
            },
            onPartial = { partial ->
                rawText = partial
            },
            onError = { err ->
                speechError = err
            },
            onListeningChanged = { active ->
                isListening = active
            }
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startSpeech()
        } else {
            speechError = "Microphone permission denied. Use manual text entry below."
        }
    }

    val quickSamples = listOf(
        "রহিমের কাছ থেকে ২০০০ টাকা পেলাম",
        "করিমকে ৫০০০ টাকা বাকিতে দিলাম",
        "দোকানের ভাড়া ৩০০০ টাকা দিলাম",
        "১০ কেজি চাল বিক্রি করলাম"
    )

    ModalBottomSheet(onDismissRequest = {
        speechHelper.stop()
        onDismiss()
    }) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.voiceAccountingTitle, style = MaterialTheme.typography.titleLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = useBanglaVoice,
                        onClick = { useBanglaVoice = true },
                        label = { Text("বাংলা") }
                    )
                    FilterChip(
                        selected = !useBanglaVoice,
                        onClick = { useBanglaVoice = false },
                        label = { Text("EN") }
                    )
                }
            }

            Button(
                onClick = {
                    if (isListening) {
                        speechHelper.stop()
                        isListening = false
                    } else {
                        val hasPerm = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (hasPerm) {
                            startSpeech()
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isListening) ExpenseRed else EmeraldPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("voice_mic_button")
            ) {
                Icon(
                    if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = strings.voiceTapToSpeak
                )
                Spacer(Modifier.width(8.dp))
                Text(if (isListening) strings.voiceListening else strings.voiceTapToSpeak)
            }

            speechError?.let { err ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = WarningSoftAmber,
                    border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.45f))
                ) {
                    Text(
                        err,
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkNavy,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            OutlinedTextField(
                value = rawText,
                onValueChange = { rawText = it },
                label = { Text(strings.voiceTextFallbackHint) },
                trailingIcon = {
                    IconButton(
                        onClick = {
                            if (rawText.isNotBlank()) applyParsed(onParseCommand(rawText))
                        },
                        modifier = Modifier.testTag("voice_parse_button")
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = "Parse voice command")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("voice_text_input")
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quickSamples) { sample ->
                    SuggestionChip(
                        onClick = {
                            rawText = sample
                            applyParsed(onParseCommand(sample))
                        },
                        label = { Text(sample, maxLines = 1) }
                    )
                }
            }

            parsed?.let { current ->
                HorizontalDivider()
                Text("Editable Transaction Preview", style = MaterialTheme.typography.titleMedium)

                if (current.intentType == VoiceIntentType.QUERY_SUMMARY) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = SoftGreenAccent,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Detected Analytics Question", style = MaterialTheme.typography.titleSmall, color = DarkNavy)
                            Text(current.queryPrompt ?: current.rawText, style = MaterialTheme.typography.bodyMedium, color = DarkNavy)
                            Button(
                                onClick = {
                                    val q = current.queryPrompt ?: current.rawText
                                    onDismiss()
                                    onAskAiQuery(q)
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Open in AI Business Assistant")
                            }
                        }
                    }
                } else {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            VoiceIntentType.CUSTOMER_PAYMENT to "Receive Pay",
                            VoiceIntentType.CREDIT_SALE to "Credit / Baki",
                            VoiceIntentType.SALE to "Cash Sale",
                            VoiceIntentType.EXPENSE to "Expense",
                            VoiceIntentType.INCOME to "Income"
                        ).forEach { (intent, lbl) ->
                            FilterChip(
                                selected = current.intentType == intent,
                                onClick = { parsed = current.copy(intentType = intent) },
                                label = { Text(lbl) }
                            )
                        }
                    }

                    if (current.ambiguousCustomers.size > 1) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = WarningSoftAmber,
                            border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("voice_ambiguous_customer_picker")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(strings.ambiguousCustomerFound, style = MaterialTheme.typography.labelMedium, color = DarkNavy)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(current.ambiguousCustomers, key = { it.id }) { cust: CustomerEntity ->
                                        FilterChip(
                                            selected = current.customerId == cust.id,
                                            onClick = {
                                                parsed = current.copy(
                                                    customerId = cust.id,
                                                    customerName = cust.name
                                                )
                                                editablePartyOrCategory = cust.name
                                            },
                                            label = { Text("${cust.name} (${cust.phone.ifBlank { cust.customerCode }})") }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    current.duplicateCandidate?.let { dup ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ExpenseRed.copy(alpha = 0.10f),
                            border = BorderStroke(1.dp, ExpenseRed.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = ExpenseRed)
                                Text(
                                    "${strings.duplicateTxWarning} (${dup.partyName.ifBlank { dup.categoryName }}: ${MoneyUtils.formatTaka(dup.totalAmountPaisa, useBanglaDigits)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ExpenseRed
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editablePartyOrCategory,
                            onValueChange = { editablePartyOrCategory = it },
                            label = {
                                Text(
                                    if (current.intentType == VoiceIntentType.EXPENSE || current.intentType == VoiceIntentType.INCOME)
                                        "Category" else "Customer / Item"
                                )
                            },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editableAmount,
                            onValueChange = { editableAmount = it },
                            label = { Text("Amount (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssistChip(
                            onClick = {},
                            leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            label = { Text("Date: ${current.dateLabel}") }
                        )
                        if (current.productName.isNotBlank() || current.quantityMilliUnits > 1000L) {
                            Text(
                                "Qty: ${MoneyUtils.milliUnitsToString(current.quantityMilliUnits, useBanglaDigits)} ${current.unit}",
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldPrimary
                            )
                        }
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(accounts, key = { it.id }) { acc ->
                            FilterChip(
                                selected = selectedAccount?.id == acc.id,
                                onClick = { selectedAccount = acc },
                                label = { Text(acc.name) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editableNotes,
                        onValueChange = { editableNotes = it },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Button(
                        onClick = {
                            val finalAmount = MoneyUtils.parseTakaToPaisa(editableAmount)
                            val updatedCmd = current.copy(
                                amountPaisa = finalAmount,
                                customerName = if (current.intentType != VoiceIntentType.EXPENSE && current.intentType != VoiceIntentType.INCOME)
                                    editablePartyOrCategory.trim() else current.customerName,
                                productName = if (current.intentType == VoiceIntentType.SALE && current.productId == null)
                                    editablePartyOrCategory.trim() else current.productName,
                                categoryName = if (current.intentType == VoiceIntentType.EXPENSE || current.intentType == VoiceIntentType.INCOME)
                                    editablePartyOrCategory.trim() else current.categoryName,
                                notes = editableNotes.trim()
                            )
                            val accId = selectedAccount?.id ?: accounts.firstOrNull()?.id.orEmpty()
                            onExecuteCommand(updatedCmd, accId) { ok, _ ->
                                if (ok) onDismiss()
                            }
                        },
                        enabled = MoneyUtils.parseTakaToPaisa(editableAmount) > 0L,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("voice_confirm_save_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.voicePreviewConfirm)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
