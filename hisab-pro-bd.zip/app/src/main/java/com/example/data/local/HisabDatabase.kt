package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        BusinessEntity::class,
        AccountEntity::class,
        CustomerEntity::class,
        SupplierEntity::class,
        ProductEntity::class,
        StockMovementEntity::class,
        CategoryEntity::class,
        AccountingTransactionEntity::class,
        InvoiceEntity::class,
        InvoiceItemEntity::class,
        EmployeeEntity::class,
        AppNotificationEntity::class,
        AttendanceEntity::class,
        LeaveRequestEntity::class,
        SalaryPaymentEntity::class,
        ActivityLogEntity::class,
        RolePermissionEntity::class,
        SyncOutboxEntity::class,
        AuthorizedDeviceEntity::class,
        BakiKhataEntryEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class HisabDatabase : RoomDatabase() {
    abstract fun businessDao(): BusinessDao
    abstract fun accountDao(): AccountDao
    abstract fun customerDao(): CustomerDao
    abstract fun supplierDao(): SupplierDao
    abstract fun productDao(): ProductDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun categoryDao(): CategoryDao
    abstract fun transactionDao(): AccountingTransactionDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun notificationDao(): AppNotificationDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun leaveRequestDao(): LeaveRequestDao
    abstract fun salaryPaymentDao(): SalaryPaymentDao
    abstract fun activityLogDao(): ActivityLogDao
    abstract fun rolePermissionDao(): RolePermissionDao
    abstract fun syncOutboxDao(): SyncOutboxDao
    abstract fun authorizedDeviceDao(): AuthorizedDeviceDao
    abstract fun bakiKhataDao(): BakiKhataDao

    companion object {
        @Volatile
        private var INSTANCE: HisabDatabase? = null

        /**
         * Safe non-destructive migration from Schema v1 to v2.
         * Preserves every existing business, account, customer, supplier, product,
         * invoice, employee, notification, and transaction record intact.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE businesses ADD COLUMN syncVersion INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE businesses ADD COLUMN lastModifiedDeviceId TEXT NOT NULL DEFAULT ''")

                db.execSQL("ALTER TABLE customers ADD COLUMN syncVersion INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE suppliers ADD COLUMN syncVersion INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE products ADD COLUMN syncVersion INTEGER NOT NULL DEFAULT 1")

                db.execSQL("ALTER TABLE accounting_transactions ADD COLUMN syncVersion INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE accounting_transactions ADD COLUMN deviceId TEXT NOT NULL DEFAULT ''")

                db.execSQL("ALTER TABLE employees ADD COLUMN email TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE employees ADD COLUMN salaryPaisa INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE employees ADD COLUMN canRecordSales INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE employees ADD COLUMN canEditCustomers INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE employees ADD COLUMN canManageInventory INTEGER NOT NULL DEFAULT 0")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS attendance_records (
                        id TEXT NOT NULL PRIMARY KEY,
                        businessId TEXT NOT NULL,
                        employeeId TEXT NOT NULL,
                        employeeName TEXT NOT NULL,
                        dateKey TEXT NOT NULL,
                        status TEXT NOT NULL,
                        checkInMillis INTEGER,
                        checkOutMillis INTEGER,
                        notes TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_attendance_records_businessId ON attendance_records(businessId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_attendance_records_employeeId ON attendance_records(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_attendance_records_dateKey ON attendance_records(dateKey)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS leave_requests (
                        id TEXT NOT NULL PRIMARY KEY,
                        businessId TEXT NOT NULL,
                        employeeId TEXT NOT NULL,
                        employeeName TEXT NOT NULL,
                        startDateKey TEXT NOT NULL,
                        endDateKey TEXT NOT NULL,
                        leaveType TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        status TEXT NOT NULL,
                        approvedBy TEXT NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_leave_requests_businessId ON leave_requests(businessId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_leave_requests_employeeId ON leave_requests(employeeId)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS salary_payments (
                        id TEXT NOT NULL PRIMARY KEY,
                        businessId TEXT NOT NULL,
                        employeeId TEXT NOT NULL,
                        employeeName TEXT NOT NULL,
                        monthKey TEXT NOT NULL,
                        paymentType TEXT NOT NULL,
                        amountPaisa INTEGER NOT NULL,
                        accountId TEXT NOT NULL,
                        notes TEXT NOT NULL,
                        occurredAt INTEGER NOT NULL,
                        createdBy TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_salary_payments_businessId ON salary_payments(businessId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_salary_payments_employeeId ON salary_payments(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_salary_payments_occurredAt ON salary_payments(occurredAt)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS activity_logs (
                        id TEXT NOT NULL PRIMARY KEY,
                        businessId TEXT NOT NULL,
                        actorEmployeeId TEXT NOT NULL,
                        actorName TEXT NOT NULL,
                        actorRole TEXT NOT NULL,
                        actionType TEXT NOT NULL,
                        entityType TEXT NOT NULL,
                        entityId TEXT NOT NULL,
                        summary TEXT NOT NULL,
                        occurredAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_activity_logs_businessId ON activity_logs(businessId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_activity_logs_occurredAt ON activity_logs(occurredAt)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS role_permissions (
                        id TEXT NOT NULL PRIMARY KEY,
                        businessId TEXT NOT NULL,
                        roleName TEXT NOT NULL,
                        canViewDashboard INTEGER NOT NULL,
                        canViewReports INTEGER NOT NULL,
                        canRecordSales INTEGER NOT NULL,
                        canEditCustomers INTEGER NOT NULL,
                        canManageInventory INTEGER NOT NULL,
                        canDeleteOrReverse INTEGER NOT NULL,
                        canManageEmployees INTEGER NOT NULL,
                        canManageSettings INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_role_permissions_businessId ON role_permissions(businessId)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_role_permissions_businessId_roleName ON role_permissions(businessId, roleName)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS sync_outbox (
                        id TEXT NOT NULL PRIMARY KEY,
                        businessId TEXT NOT NULL,
                        entityType TEXT NOT NULL,
                        entityId TEXT NOT NULL,
                        operation TEXT NOT NULL,
                        version INTEGER NOT NULL,
                        updatedAtMillis INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        conflictDetail TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_outbox_businessId ON sync_outbox(businessId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_outbox_status ON sync_outbox(status)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS authorized_devices (
                        id TEXT NOT NULL PRIMARY KEY,
                        userId TEXT NOT NULL,
                        deviceName TEXT NOT NULL,
                        platform TEXT NOT NULL,
                        appVersion TEXT NOT NULL,
                        lastSyncAtMillis INTEGER NOT NULL,
                        revoked INTEGER NOT NULL,
                        isCurrentDevice INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_authorized_devices_userId ON authorized_devices(userId)")
            }
        }

        /**
         * Safe non-destructive migration from Schema v2 to v3.
         * Adds normalized baki_khata_entries table and backfills existing customer due history.
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS baki_khata_entries (
                        id TEXT NOT NULL PRIMARY KEY,
                        businessId TEXT NOT NULL,
                        customerId TEXT NOT NULL,
                        customerName TEXT NOT NULL,
                        entryType TEXT NOT NULL,
                        amountPaisa INTEGER NOT NULL,
                        remainingBalanceAfterPaisa INTEGER NOT NULL,
                        entryDateMillis INTEGER NOT NULL,
                        promisedRepaymentDateMillis INTEGER,
                        actualRepaymentDateMillis INTEGER,
                        isSettled INTEGER NOT NULL,
                        notes TEXT NOT NULL,
                        transactionId TEXT,
                        createdAt INTEGER NOT NULL,
                        syncVersion INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_baki_khata_entries_businessId ON baki_khata_entries(businessId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_baki_khata_entries_customerId ON baki_khata_entries(customerId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_baki_khata_entries_promisedRepaymentDateMillis ON baki_khata_entries(promisedRepaymentDateMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_baki_khata_entries_entryDateMillis ON baki_khata_entries(entryDateMillis)")

                db.execSQL(
                    """
                    INSERT OR IGNORE INTO baki_khata_entries (
                        id, businessId, customerId, customerName, entryType, amountPaisa,
                        remainingBalanceAfterPaisa, entryDateMillis, promisedRepaymentDateMillis,
                        actualRepaymentDateMillis, isSettled, notes, transactionId, createdAt, syncVersion
                    )
                    SELECT
                        'bk_' || t.id,
                        t.businessId,
                        t.customerId,
                        t.partyName,
                        CASE WHEN t.type = 'CUSTOMER_PAYMENT' THEN 'REPAYMENT' ELSE 'CREDIT' END,
                        CASE WHEN t.type IN ('CREDIT_SALE', 'CUSTOMER_CREDIT_ADVANCE', 'CUSTOMER_REFUND')
                             THEN CASE WHEN t.dueDeltaPaisa > 0 THEN t.dueDeltaPaisa ELSE t.totalAmountPaisa END
                             ELSE t.totalAmountPaisa END,
                        COALESCE((SELECT c.currentDuePaisa FROM customers c WHERE c.id = t.customerId), 0),
                        t.occurredAt,
                        t.dueDateMillis,
                        CASE WHEN t.type = 'CUSTOMER_PAYMENT' THEN t.occurredAt ELSE NULL END,
                        CASE WHEN t.type = 'CUSTOMER_PAYMENT' THEN 1 ELSE 0 END,
                        t.notes,
                        t.id,
                        t.createdAt,
                        1
                    FROM accounting_transactions t
                    WHERE t.customerId IS NOT NULL
                      AND t.isReversed = 0
                      AND (
                          t.type IN ('CREDIT_SALE', 'CUSTOMER_CREDIT_ADVANCE', 'CUSTOMER_PAYMENT', 'CUSTOMER_REFUND')
                          OR t.dueDeltaPaisa > 0
                      )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): HisabDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    HisabDatabase::class.java,
                    "hisab_pro_bd.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
