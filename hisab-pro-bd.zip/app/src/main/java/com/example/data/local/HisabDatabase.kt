package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        BusinessEntity::class,
        AccountEntity::class,
        CustomerEntity::class,
        SupplierEntity::class,
        ProductEntity::class,
        StockMovementEntity::class,
        CategoryEntity::class,
        AccountingTransactionEntity::class,
        InvoiceEntity::class,
        InvoiceItemEntity::class,
        EmployeeEntity::class,
        AppNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class HisabDatabase : RoomDatabase() {
    abstract fun businessDao(): BusinessDao
    abstract fun accountDao(): AccountDao
    abstract fun customerDao(): CustomerDao
    abstract fun supplierDao(): SupplierDao
    abstract fun productDao(): ProductDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun categoryDao(): CategoryDao
    abstract fun transactionDao(): AccountingTransactionDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun notificationDao(): AppNotificationDao

    companion object {
        @Volatile
        private var INSTANCE: HisabDatabase? = null

        // Forward-compatible migration registry: future schema versions add explicit Migration(n, n+1)
        // and never use fallbackToDestructiveMigration() so user accounting data is never lost.
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Reserved for future non-destructive upgrades
            }
        }

        fun getInstance(context: Context): HisabDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    HisabDatabase::class.java,
                    "hisab_pro_bd.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
