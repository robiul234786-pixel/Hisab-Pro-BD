package com.example.data.repository

import com.example.core.util.MoneyUtils
import com.example.data.local.*
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale

data class DashboardMetrics(
    val totalSalesPaisa: Long = 0L,
    val totalCashReceivedPaisa: Long = 0L,
    val totalReceivablesPaisa: Long = 0L,
    val totalPayablesPaisa: Long = 0L,
    val totalIncomePaisa: Long = 0L,
    val totalExpensesPaisa: Long = 0L,
    val grossProfitPaisa: Long = 0L,
    val netProfitPaisa: Long = 0L,
    val isEstimatedProfit: Boolean = false,
    val cashBalancePaisa: Long = 0L,
    val bankBalancePaisa: Long = 0L,
    val mfsBalancePaisa: Long = 0L,
    val todaysSalesPaisa: Long = 0L,
    val todaysExpensesPaisa: Long = 0L,
    val totalCollectedDuesPaisa: Long = 0L,
    val overdueDuesPaisa: Long = 0L
)

data class MonthlyChartPoint(
    val label: String,
    val salesPaisa: Long,
    val incomePaisa: Long,
    val expensePaisa: Long
)

data class ProfitAndLossReport(
    val grossSalesPaisa: Long = 0L,
    val salesReturnsPaisa: Long = 0L,
    val netSalesPaisa: Long = 0L,
    val cogsPaisa: Long = 0L,
    val grossProfitPaisa: Long = 0L,
    val otherIncomePaisa: Long = 0L,
    val operatingExpensesPaisa: Long = 0L,
    val netProfitPaisa: Long = 0L,
    val totalCashInPaisa: Long = 0L,
    val totalCashOutPaisa: Long = 0L,
    val isEstimated: Boolean = false
)

object AccountingCalculator {

    fun computeDashboard(
        accounts: List<AccountEntity>,
        customers: List<CustomerEntity>,
        suppliers: List<SupplierEntity>,
        transactions: List<AccountingTransactionEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): DashboardMetrics {
        val activeTxs = transactions.filter { !it.isReversed && it.type != TxTypes.REVERSAL }
        val (todayStart, todayEnd) = MoneyUtils.dhakaTodayBounds(nowMillis)
        val overdueCutoff = nowMillis - (30L * 24L * 60L * 60L * 1000L)

        var grossSales = 0L
        var salesReturns = 0L
        var cogs = 0L
        var otherIncome = 0L
        var expenses = 0L
        var cashReceived = 0L
        var todaysSales = 0L
        var todaysExpenses = 0L
        var collectedDues = 0L
        var estimated = false

        for (tx in activeTxs) {
            val isToday = tx.occurredAt in todayStart..todayEnd
            when (tx.type) {
                TxTypes.SALE, TxTypes.CREDIT_SALE -> {
                    grossSales += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa
                    if (tx.hasEstimatedCost) estimated = true
                    if (tx.cashFlowDeltaPaisa > 0L) cashReceived += tx.cashFlowDeltaPaisa
                    if (isToday) todaysSales += tx.totalAmountPaisa
                }
                TxTypes.SALE_RETURN -> {
                    salesReturns += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa // negative for return
                }
                TxTypes.CUSTOMER_PAYMENT -> {
                    if (tx.cashFlowDeltaPaisa > 0L) {
                        cashReceived += tx.cashFlowDeltaPaisa
                        collectedDues += tx.cashFlowDeltaPaisa
                    }
                }
                TxTypes.INCOME -> {
                    otherIncome += tx.totalAmountPaisa
                    if (tx.cashFlowDeltaPaisa > 0L) cashReceived += tx.cashFlowDeltaPaisa
                }
                TxTypes.EXPENSE -> {
                    expenses += tx.totalAmountPaisa
                    if (isToday) todaysExpenses += tx.totalAmountPaisa
                }
            }
        }

        val netSales = grossSales - salesReturns
        val grossProfit = netSales - cogs
        val totalIncome = netSales + otherIncome
        val netProfit = grossProfit + otherIncome - expenses

        val receivables = customers.sumOf { it.currentDuePaisa.coerceAtLeast(0L) }
        val overdue = customers.filter {
            it.currentDuePaisa > 0L && (it.overdueSinceMillis ?: Long.MAX_VALUE) < overdueCutoff
        }.sumOf { it.currentDuePaisa }
        val payables = suppliers.sumOf { it.currentPayablePaisa.coerceAtLeast(0L) }

        val cashBal = accounts.filter { it.type == AccountTypes.CASH }.sumOf { it.currentBalancePaisa }
        val bankBal = accounts.filter { it.type == AccountTypes.BANK }.sumOf { it.currentBalancePaisa }
        val mfsBal = accounts.filter {
            it.type == AccountTypes.BKASH || it.type == AccountTypes.NAGAD || it.type == AccountTypes.ROCKET || it.type == AccountTypes.CUSTOM
        }.sumOf { it.currentBalancePaisa }

        return DashboardMetrics(
            totalSalesPaisa = netSales,
            totalCashReceivedPaisa = cashReceived,
            totalReceivablesPaisa = receivables,
            totalPayablesPaisa = payables,
            totalIncomePaisa = totalIncome,
            totalExpensesPaisa = expenses,
            grossProfitPaisa = grossProfit,
            netProfitPaisa = netProfit,
            isEstimatedProfit = estimated,
            cashBalancePaisa = cashBal,
            bankBalancePaisa = bankBal,
            mfsBalancePaisa = mfsBal,
            todaysSalesPaisa = todaysSales,
            todaysExpensesPaisa = todaysExpenses,
            totalCollectedDuesPaisa = collectedDues,
            overdueDuesPaisa = overdue
        )
    }

    fun computeProfitAndLoss(
        transactions: List<AccountingTransactionEntity>,
        startMillis: Long,
        endMillis: Long
    ): ProfitAndLossReport {
        val active = transactions.filter {
            !it.isReversed && it.type != TxTypes.REVERSAL && it.occurredAt in startMillis..endMillis
        }
        var grossSales = 0L
        var salesReturns = 0L
        var cogs = 0L
        var otherIncome = 0L
        var expenses = 0L
        var cashIn = 0L
        var cashOut = 0L
        var estimated = false

        for (tx in active) {
            if (tx.type != TxTypes.ACCOUNT_TRANSFER) {
                if (tx.cashFlowDeltaPaisa > 0L) cashIn += tx.cashFlowDeltaPaisa
                if (tx.cashFlowDeltaPaisa < 0L) cashOut += -tx.cashFlowDeltaPaisa
            }
            when (tx.type) {
                TxTypes.SALE, TxTypes.CREDIT_SALE -> {
                    grossSales += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa
                    if (tx.hasEstimatedCost) estimated = true
                }
                TxTypes.SALE_RETURN -> {
                    salesReturns += tx.totalAmountPaisa
                    cogs += tx.cogsPaisa
                }
                TxTypes.INCOME -> otherIncome += tx.totalAmountPaisa
                TxTypes.EXPENSE -> expenses += tx.totalAmountPaisa
            }
        }
        val netSales = grossSales - salesReturns
        val grossProfit = netSales - cogs
        val netProfit = grossProfit + otherIncome - expenses

        return ProfitAndLossReport(
            grossSalesPaisa = grossSales,
            salesReturnsPaisa = salesReturns,
            netSalesPaisa = netSales,
            cogsPaisa = cogs,
            grossProfitPaisa = grossProfit,
            otherIncomePaisa = otherIncome,
            operatingExpensesPaisa = expenses,
            netProfitPaisa = netProfit,
            totalCashInPaisa = cashIn,
            totalCashOutPaisa = cashOut,
            isEstimated = estimated
        )
    }

    fun computeLast6MonthsChart(
        transactions: List<AccountingTransactionEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): List<MonthlyChartPoint> {
        val today = Instant.ofEpochMilli(nowMillis).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate()
        val active = transactions.filter { !it.isReversed && it.type != TxTypes.REVERSAL }
        val fmt = DateTimeFormatter.ofPattern("MMM", Locale.ENGLISH)

        return (5 downTo 0).map { offset ->
            val monthDate = today.minusMonths(offset.toLong()).withDayOfMonth(1)
            val start = monthDate.atStartOfDay(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli()
            val end = monthDate.plusMonths(1).atStartOfDay(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli() - 1L
            val monthTxs = active.filter { it.occurredAt in start..end }
            val sales = monthTxs.filter { it.type == TxTypes.SALE || it.type == TxTypes.CREDIT_SALE }
                .sumOf { it.totalAmountPaisa } -
                monthTxs.filter { it.type == TxTypes.SALE_RETURN }.sumOf { it.totalAmountPaisa }
            val income = sales + monthTxs.filter { it.type == TxTypes.INCOME }.sumOf { it.totalAmountPaisa }
            val expense = monthTxs.filter { it.type == TxTypes.EXPENSE }.sumOf { it.totalAmountPaisa }
            MonthlyChartPoint(
                label = monthDate.format(fmt),
                salesPaisa = sales.coerceAtLeast(0L),
                incomePaisa = income.coerceAtLeast(0L),
                expensePaisa = expense.coerceAtLeast(0L)
            )
        }
    }

    fun computeAdvancedAnalytics(
        accounts: List<AccountEntity>,
        customers: List<CustomerEntity>,
        products: List<ProductEntity>,
        transactions: List<AccountingTransactionEntity>,
        invoices: List<InvoiceEntity>,
        invoiceItems: List<InvoiceItemEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): AdvancedAnalyticsReport {
        val activeTxs = transactions.filter { !it.isReversed && it.type != TxTypes.REVERSAL }
        val today = Instant.ofEpochMilli(nowMillis).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate()

        val curMonthStart = today.withDayOfMonth(1).atStartOfDay(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli()
        val curMonthEnd = today.plusDays(1).atStartOfDay(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli() - 1L
        val prevMonthDate = today.minusMonths(1).withDayOfMonth(1)
        val prevMonthStart = prevMonthDate.atStartOfDay(MoneyUtils.DHAKA_ZONE).toInstant().toEpochMilli()
        val prevMonthEnd = curMonthStart - 1L

        val curPnl = computeProfitAndLoss(activeTxs, curMonthStart, curMonthEnd)
        val prevPnl = computeProfitAndLoss(activeTxs, prevMonthStart, prevMonthEnd)

        val salesGrowthPct: Double? = when {
            prevPnl.netSalesPaisa > 0L ->
                ((curPnl.netSalesPaisa - prevPnl.netSalesPaisa).toDouble() / prevPnl.netSalesPaisa.toDouble()) * 100.0
            curPnl.netSalesPaisa > 0L -> null // Previous month had no recorded sales
            else -> 0.0
        }
        val profitGrowthPct: Double? = when {
            prevPnl.netProfitPaisa > 0L ->
                ((curPnl.netProfitPaisa - prevPnl.netProfitPaisa).toDouble() / prevPnl.netProfitPaisa.toDouble()) * 100.0
            else -> null
        }

        // Product Profitability & Best Sellers from Sales Invoice Items
        val saleInvoiceIds = invoices.filter { it.invoiceType == "SALE" }.map { it.id }.toSet()
        val saleItems = invoiceItems.filter { it.invoiceId in saleInvoiceIds }
        val productAgg = mutableMapOf<String, MutableProductAgg>()
        saleItems.forEach { item ->
            val netQty = (item.quantityMilliUnits - item.returnedMilliUnits).coerceAtLeast(0L)
            if (netQty <= 0L) return@forEach
            val key = item.productId ?: item.itemName
            val agg = productAgg.getOrPut(key) { MutableProductAgg(item.productId, item.itemName, item.unit) }
            val revenue = MoneyUtils.calculateLineTotalPaisa(netQty, item.unitPricePaisa)
            val cost = MoneyUtils.calculateLineTotalPaisa(netQty, item.costPricePaisa)
            agg.qtyMilli += netQty
            agg.revenuePaisa += revenue
            agg.costPaisa += cost
            if (item.costPricePaisa <= 0L) agg.hasMissingCost = true
        }
        val productPerf = productAgg.values.map {
            ProductPerformanceRow(
                productId = it.productId,
                itemName = it.itemName,
                unit = it.unit,
                quantitySoldMilliUnits = it.qtyMilli,
                revenuePaisa = it.revenuePaisa,
                costPaisa = it.costPaisa,
                profitPaisa = it.revenuePaisa - it.costPaisa,
                hasMissingCost = it.hasMissingCost
            )
        }.sortedByDescending { it.profitPaisa }

        val bestSelling = productPerf.sortedByDescending { it.quantitySoldMilliUnits }

        // Expense Category Breakdown
        val expenseTxs = activeTxs.filter { it.type == TxTypes.EXPENSE }
        val totalExp = expenseTxs.sumOf { it.totalAmountPaisa }.coerceAtLeast(0L)
        val expenseBreakdown = expenseTxs
            .groupBy { it.categoryName.ifBlank { "Other Expenses" } }
            .map { (cat, list) ->
                val amt = list.sumOf { it.totalAmountPaisa }
                CategoryExpenseShare(
                    categoryName = cat,
                    amountPaisa = amt,
                    sharePercent = if (totalExp > 0L) (amt.toDouble() / totalExp.toDouble()) * 100.0 else 0.0
                )
            }
            .sortedByDescending { it.amountPaisa }

        // Customer Purchase Trends
        val customerTrends = customers.map { c ->
            val count = activeTxs.count { it.customerId == c.id && (it.type == TxTypes.SALE || it.type == TxTypes.CREDIT_SALE) }
            CustomerTrendRow(
                customerId = c.id,
                name = c.name,
                currentDuePaisa = c.currentDuePaisa,
                totalPurchasesPaisa = c.totalPurchasesPaisa,
                totalPaymentsPaisa = c.totalPaymentsPaisa,
                orderCount = count
            )
        }.sortedByDescending { it.totalPurchasesPaisa }

        // Financial Calendar Map (yyyy-MM-dd -> summary)
        val dateFmt = DateTimeFormatter.ISO_LOCAL_DATE
        val calendarMap = mutableMapOf<String, CalendarDaySummary>()
        activeTxs.forEach { tx ->
            val key = Instant.ofEpochMilli(tx.occurredAt).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate().format(dateFmt)
            val prev = calendarMap[key] ?: CalendarDaySummary(dateKey = key)
            val salesAdd = if (tx.type == TxTypes.SALE || tx.type == TxTypes.CREDIT_SALE) tx.totalAmountPaisa else 0L
            val expAdd = if (tx.type == TxTypes.EXPENSE) tx.totalAmountPaisa else 0L
            val cashInAdd = if (tx.cashFlowDeltaPaisa > 0L) tx.cashFlowDeltaPaisa else 0L
            val dueAdd = if (tx.dueDeltaPaisa > 0L) tx.dueDeltaPaisa else 0L
            calendarMap[key] = prev.copy(
                salesPaisa = prev.salesPaisa + salesAdd,
                expensePaisa = prev.expensePaisa + expAdd,
                cashInPaisa = prev.cashInPaisa + cashInAdd,
                dueAddedPaisa = prev.dueAddedPaisa + dueAdd,
                transactionCount = prev.transactionCount + 1
            )
        }

        // Business Health Score (0-100)
        val dash = computeDashboard(accounts, customers, emptyList(), transactions, nowMillis)
        val totalLiquid = dash.cashBalancePaisa + dash.bankBalancePaisa + dash.mfsBalancePaisa
        val profitMarginPct = if (dash.totalSalesPaisa > 0L) {
            (dash.netProfitPaisa.toDouble() / dash.totalSalesPaisa.toDouble()) * 100.0
        } else 0.0
        val lowStockCount = products.count { !it.archived && it.stockMilliUnits <= it.lowStockThresholdMilliUnits }

        var score = 50
        if (dash.totalSalesPaisa > 0L) {
            score += when {
                profitMarginPct >= 20.0 -> 20
                profitMarginPct >= 10.0 -> 14
                profitMarginPct > 0.0 -> 8
                else -> -10
            }
        }
        if (totalLiquid > 0L) score += 10
        val receivableRatio = if (dash.totalSalesPaisa > 0L) {
            dash.totalReceivablesPaisa.toDouble() / dash.totalSalesPaisa.toDouble()
        } else 0.0
        score += when {
            receivableRatio <= 0.2 -> 12
            receivableRatio <= 0.45 -> 6
            else -> -8
        }
        score += if (lowStockCount == 0) 8 else if (lowStockCount <= 3) 3 else -6
        val boundedScore = score.coerceIn(10, 100)
        val grade = when {
            boundedScore >= 80 -> "Excellent"
            boundedScore >= 65 -> "Healthy"
            boundedScore >= 45 -> "Moderate"
            else -> "Needs Attention"
        }

        return AdvancedAnalyticsReport(
            currentMonthSalesPaisa = curPnl.netSalesPaisa,
            previousMonthSalesPaisa = prevPnl.netSalesPaisa,
            currentMonthProfitPaisa = curPnl.netProfitPaisa,
            previousMonthProfitPaisa = prevPnl.netProfitPaisa,
            salesGrowthPercent = salesGrowthPct,
            profitGrowthPercent = profitGrowthPct,
            productProfitability = productPerf,
            bestSellingProducts = bestSelling,
            expenseBreakdown = expenseBreakdown,
            customerTrends = customerTrends,
            calendarDayMap = calendarMap,
            healthReport = BusinessHealthReport(
                score = boundedScore,
                grade = grade,
                profitMarginPercent = profitMarginPct,
                totalLiquidPaisa = totalLiquid,
                receivableToSalesPercent = receivableRatio * 100.0,
                lowStockCount = lowStockCount
            )
        )
    }

    private data class MutableProductAgg(
        val productId: String?,
        val itemName: String,
        val unit: String,
        var qtyMilli: Long = 0L,
        var revenuePaisa: Long = 0L,
        var costPaisa: Long = 0L,
        var hasMissingCost: Boolean = false
    )
}

data class ProductPerformanceRow(
    val productId: String?,
    val itemName: String,
    val unit: String,
    val quantitySoldMilliUnits: Long,
    val revenuePaisa: Long,
    val costPaisa: Long,
    val profitPaisa: Long,
    val hasMissingCost: Boolean
)

data class CategoryExpenseShare(
    val categoryName: String,
    val amountPaisa: Long,
    val sharePercent: Double
)

data class CustomerTrendRow(
    val customerId: String,
    val name: String,
    val currentDuePaisa: Long,
    val totalPurchasesPaisa: Long,
    val totalPaymentsPaisa: Long,
    val orderCount: Int
)

data class CalendarDaySummary(
    val dateKey: String,
    val salesPaisa: Long = 0L,
    val expensePaisa: Long = 0L,
    val cashInPaisa: Long = 0L,
    val dueAddedPaisa: Long = 0L,
    val transactionCount: Int = 0
)

data class BusinessHealthReport(
    val score: Int = 50,
    val grade: String = "Moderate",
    val profitMarginPercent: Double = 0.0,
    val totalLiquidPaisa: Long = 0L,
    val receivableToSalesPercent: Double = 0.0,
    val lowStockCount: Int = 0
)

data class AdvancedAnalyticsReport(
    val currentMonthSalesPaisa: Long = 0L,
    val previousMonthSalesPaisa: Long = 0L,
    val currentMonthProfitPaisa: Long = 0L,
    val previousMonthProfitPaisa: Long = 0L,
    val salesGrowthPercent: Double? = null,
    val profitGrowthPercent: Double? = null,
    val productProfitability: List<ProductPerformanceRow> = emptyList(),
    val bestSellingProducts: List<ProductPerformanceRow> = emptyList(),
    val expenseBreakdown: List<CategoryExpenseShare> = emptyList(),
    val customerTrends: List<CustomerTrendRow> = emptyList(),
    val calendarDayMap: Map<String, CalendarDaySummary> = emptyMap(),
    val healthReport: BusinessHealthReport = BusinessHealthReport()
)
