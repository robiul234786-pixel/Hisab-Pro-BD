package com.example

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.util.LocalAppStrings
import com.example.core.util.stringsForLanguage
import com.example.data.local.TxTypes
import com.example.data.remote.FirebaseAuthHelper
import com.example.data.remote.configureAppCheck
import com.example.ui.MainViewModel
import com.example.ui.OnlineShopViewModel
import com.example.ui.components.AiAssistantSheet
import com.example.ui.components.BrandedSplashScreen
import com.example.ui.components.OnboardingWizard
import com.example.ui.components.PinLockScreen
import com.example.ui.components.SyncAndDevicesSheet
import com.example.ui.components.VoiceAccountingDialog
import com.example.ui.screens.*
import com.example.ui.theme.HisabProTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

enum class BottomNavTab {
    HOME, CUSTOMERS, TRANSACTIONS, REPORTS, SETTINGS
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel()
            val settings by viewModel.settingsState.collectAsStateWithLifecycle()
            val workspace by viewModel.workspaceState.collectAsStateWithLifecycle()
            val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
            val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
            val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
            val updateState by viewModel.updateState.collectAsStateWithLifecycle()
            val pendingEncryptedRestoreUri by viewModel.pendingEncryptedRestoreUri.collectAsStateWithLifecycle()

            var splashDone by remember { mutableStateOf(false) }

            val darkTheme = when (settings.darkModePreference) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }
            val appStrings = remember(settings.languageCode) {
                stringsForLanguage(settings.languageCode)
            }

            val context = LocalContext.current
            val scope = rememberCoroutineScope()
            val credentialManager = remember { CredentialManager.create(context) }

            // Attempt silent Google auto-sign-in only if user previously authorized an account
            LaunchedEffect(Unit) {
                FirebaseAuthHelper.attemptAutoSignIn(
                    context = context,
                    credentialManager = credentialManager,
                    onAuthSuccess = {},
                    onUnauthenticated = {},
                    scope = scope
                )
            }

            CompositionLocalProvider(LocalAppStrings provides appStrings) {
                HisabProTheme(darkTheme = darkTheme, isBangla = appStrings.isBangla) {
                    val snackbarHostState = remember { SnackbarHostState() }
                    LaunchedEffect(statusMessage) {
                        statusMessage?.let { msg ->
                            snackbarHostState.showSnackbar(msg)
                            viewModel.clearStatusMessage()
                        }
                    }

                    when {
                        !splashDone -> {
                            BrandedSplashScreen(onFinished = { splashDone = true })
                        }
                        !settings.onboardingCompleted -> {
                            OnboardingWizard(
                                initialLanguageCode = settings.languageCode,
                                onLanguageSelected = viewModel::setLanguage,
                                onRestoreBackupUri = viewModel::restoreBackupFromUri,
                                onCompleteSetup = viewModel::completeOnboarding,
                                onGoogleRestoreSuccess = { uid -> viewModel.restoreFromCloud(uid) }
                            )
                        }
                        isLocked -> {
                            PinLockScreen(
                                biometricEnabled = settings.biometricEnabled,
                                onVerifyPin = viewModel::unlockWithPin,
                                onBiometricUnlocked = viewModel::unlockBiometric
                            )
                        }
                        else -> {
                            MainAppShell(
                                workspace = workspace,
                                isSyncing = isSyncing,
                                updateState = updateState,
                                snackbarHostState = snackbarHostState,
                                viewModel = viewModel
                            )
                        }
                    }

                    pendingEncryptedRestoreUri?.let { encUri ->
                        var restorePassphrase by remember(encUri) { mutableStateOf("") }
                        AlertDialog(
                            onDismissRequest = viewModel::dismissPendingEncryptedRestore,
                            title = { Text(appStrings.encryptedBackupLabel) },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        "Enter the passphrase used when exporting this encrypted backup.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    OutlinedTextField(
                                        value = restorePassphrase,
                                        onValueChange = { restorePassphrase = it },
                                        label = { Text(appStrings.passphraseLabel) },
                                        visualTransformation = PasswordVisualTransformation(),
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth().testTag("restore_passphrase_input")
                                    )
                                }
                            },
                            confirmButton = {
                                Button(
                                    onClick = { viewModel.restoreBackupFromUri(encUri, restorePassphrase) },
                                    enabled = restorePassphrase.isNotBlank()
                                ) { Text(appStrings.confirm) }
                            },
                            dismissButton = {
                                TextButton(onClick = viewModel::dismissPendingEncryptedRestore) {
                                    Text(appStrings.cancel)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MainAppShell(
    workspace: com.example.ui.BusinessWorkspaceState,
    isSyncing: Boolean,
    updateState: com.example.data.remote.UpdateUiState,
    snackbarHostState: SnackbarHostState,
    viewModel: MainViewModel
) {
    val strings = LocalAppStrings.current
    val aiUiState by viewModel.aiUiState.collectAsStateWithLifecycle()
    val aiMessages by viewModel.aiMessages.collectAsStateWithLifecycle()
    val latestSnapshotInfo by viewModel.latestSnapshotInfo.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(BottomNavTab.HOME) }
    var customersSubTab by remember { mutableIntStateOf(0) }
    var preselectedCustomerId by remember { mutableStateOf<String?>(null) }
    var transactionsSubTab by remember { mutableIntStateOf(0) }

    var showQuickAddCustomer by remember { mutableStateOf(false) }
    var showQuickDueModal by remember { mutableStateOf<String?>(null) }
    var showAiSheet by remember { mutableStateOf(false) }
    var showVoiceDialog by remember { mutableStateOf(false) }
    var showSyncDevicesSheet by remember { mutableStateOf(false) }
    var showOnlineShop by remember { mutableStateOf(false) }

    val onlineShopViewModel: OnlineShopViewModel = viewModel()
    val onlineShopState by onlineShopViewModel.uiState.collectAsStateWithLifecycle()
    val activeBizId = workspace.activeBusiness?.id.orEmpty()
    LaunchedEffect(activeBizId) {
        if (activeBizId.isNotBlank()) onlineShopViewModel.setBusinessId(activeBizId)
    }
    LaunchedEffect(onlineShopState.statusMessage) {
        onlineShopState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            onlineShopViewModel.clearStatusMessage()
        }
    }

    BackHandler(enabled = showOnlineShop) {
        showOnlineShop = false
    }

    // Back handler returns secondary tabs to Home
    BackHandler(enabled = !showOnlineShop && currentTab != BottomNavTab.HOME) {
        currentTab = BottomNavTab.HOME
    }

    if (showOnlineShop) {
        OnlineShopScreen(
            state = onlineShopState,
            useBanglaDigits = workspace.settings.useBanglaDigits,
            snackbarHostState = snackbarHostState,
            onBack = { showOnlineShop = false },
            onSearchChange = onlineShopViewModel::setSearchQuery,
            onSelectCategory = onlineShopViewModel::selectCategory,
            onToggleWishlist = onlineShopViewModel::toggleWishlist,
            onAddToCart = onlineShopViewModel::addToCart,
            onSetCartQuantity = onlineShopViewModel::setCartQuantity,
            onPreviewPromoDiscount = onlineShopViewModel::previewPromoDiscount,
            onPlaceOrder = { name, phone, addr, district, fee, promo, method, accId, custId, notes, trxId, senderPhone, directItem, customLines ->
                onlineShopViewModel.placeOrder(
                    customerName = name,
                    customerPhone = phone,
                    deliveryAddress = addr,
                    deliveryDistrict = district,
                    deliveryFeePaisa = fee,
                    promoCode = promo,
                    paymentMethod = method,
                    accountId = accId,
                    customerId = custId,
                    notes = notes,
                    mfsTrxId = trxId,
                    mfsSenderPhone = senderPhone,
                    directSingleItem = directItem,
                    customLines = customLines
                )
            },
            onAdvanceOrderStatus = { orderId, status ->
                onlineShopViewModel.advanceOrderStatus(orderId, status)
            },
            onCollectOrderMfsPayment = { orderId, method, trxId, senderPhone, accOverride ->
                onlineShopViewModel.collectOrderMfsPayment(orderId, method, trxId, senderPhone, accOverride)
            },
            onSaveMfsWallet = onlineShopViewModel::saveMfsWallet,
            onUpdateProductListing = onlineShopViewModel::updateProductListing,
            onSaveProduct = viewModel::saveProduct,
            onSaveCustomWebShopUrl = onlineShopViewModel::setCustomWebShopUrl,
            onParseIncomingOrder = onlineShopViewModel::parseIncomingOrder,
            onClearLastPlacedOrder = onlineShopViewModel::clearLastPlacedOrder
        )
        return
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                val navItems = listOf(
                    Triple(BottomNavTab.HOME, strings.tabHome, Icons.Default.Dashboard),
                    Triple(BottomNavTab.CUSTOMERS, strings.tabCustomers, Icons.Default.People),
                    Triple(BottomNavTab.TRANSACTIONS, strings.tabTransactions, Icons.Default.PointOfSale),
                    Triple(BottomNavTab.REPORTS, strings.tabReports, Icons.Default.Assessment),
                    Triple(BottomNavTab.SETTINGS, strings.tabSettings, Icons.Default.Settings)
                )
                navItems.forEach { (tab, label, icon) ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = {
                            preselectedCustomerId = null
                            currentTab = tab
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, maxLines = 1) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                BottomNavTab.HOME -> {
                    HomeDashboardScreen(
                        state = workspace,
                        onSwitchBusiness = viewModel::switchBusiness,
                        onCreateBusiness = { name, cat, phone, addr, openingCash, inv ->
                            viewModel.createAdditionalBusiness(name, cat, phone, addr, null, openingCash, inv)
                        },
                        onQuickAction = { action ->
                            when (action) {
                                QuickActionType.ADD_SALE -> {
                                    transactionsSubTab = 0
                                    currentTab = BottomNavTab.TRANSACTIONS
                                }
                                QuickActionType.ADD_CUSTOMER -> showQuickAddCustomer = true
                                QuickActionType.ADD_DUE -> showQuickDueModal = TxTypes.CREDIT_SALE
                                QuickActionType.RECEIVE_PAYMENT -> showQuickDueModal = TxTypes.CUSTOMER_PAYMENT
                                QuickActionType.ADD_EXPENSE -> {
                                    transactionsSubTab = 2
                                    currentTab = BottomNavTab.TRANSACTIONS
                                }
                                QuickActionType.ADD_PURCHASE -> {
                                    transactionsSubTab = 1
                                    currentTab = BottomNavTab.TRANSACTIONS
                                }
                            }
                        },
                        onMarkNotificationsRead = viewModel::markNotificationsRead,
                        onOpenTransactionDetail = {
                            transactionsSubTab = 4
                            currentTab = BottomNavTab.TRANSACTIONS
                        },
                        onOpenCustomerDetail = { custId ->
                            preselectedCustomerId = custId
                            customersSubTab = 0
                            currentTab = BottomNavTab.CUSTOMERS
                        },
                        onLockApp = viewModel::lockNow,
                        onOpenAiAssistant = { showAiSheet = true },
                        onOpenVoiceEntry = { showVoiceDialog = true },
                        onOpenSyncDevices = { showSyncDevicesSheet = true },
                        onOpenOnlineShop = { showOnlineShop = true },
                        hasSavedSnapshot = latestSnapshotInfo != null,
                        onSaveAllAccounts = viewModel::saveAllAccountsSnapshot,
                        onRestoreLastSnapshot = viewModel::restoreLatestSnapshot,
                        onResetAccounts = viewModel::resetActiveBusinessHisab
                    )
                }
                BottomNavTab.CUSTOMERS -> {
                    CustomersAndDuesScreen(
                        state = workspace,
                        initialSubTab = customersSubTab,
                        preselectedCustomerId = preselectedCustomerId,
                        onSaveCustomer = viewModel::saveCustomer,
                        onArchiveCustomer = viewModel::archiveCustomer,
                        onRecordDueEntry = viewModel::recordDueEntry,
                        onMarkBakiEntryRepaid = viewModel::markBakiEntryRepaid,
                        onSaveSupplier = viewModel::saveSupplier,
                        onRecordSupplierPayment = viewModel::recordSupplierPayment
                    )
                }
                BottomNavTab.TRANSACTIONS -> {
                    TransactionsHubScreen(
                        state = workspace,
                        initialSubTab = transactionsSubTab,
                        onRecordSale = viewModel::recordSale,
                        onRecordPurchase = viewModel::recordPurchase,
                        onRecordIncomeOrExpense = viewModel::recordIncomeOrExpense,
                        onCreateCategory = viewModel::createCategory,
                        onSaveAccount = viewModel::saveAccount,
                        onTransferAccounts = viewModel::transferAccounts,
                        onRecordReturnOrCorrection = viewModel::recordReturnOrCorrection,
                        onReverseTransaction = viewModel::reverseTransaction,
                        onLoadInvoiceItems = { invId -> viewModel.repo.getInvoiceItems(invId) },
                        onOpenVoiceEntry = { showVoiceDialog = true }
                    )
                }
                BottomNavTab.REPORTS -> {
                    ReportsScreen(state = workspace)
                }
                BottomNavTab.SETTINGS -> {
                    SettingsScreen(
                        state = workspace,
                        isSyncing = isSyncing,
                        updateState = updateState,
                        onUpdateBusiness = viewModel::updateBusiness,
                        onSaveProduct = viewModel::saveProduct,
                        onAdjustStock = viewModel::adjustStock,
                        onSaveEmployee = viewModel::saveEmployee,
                        onSaveEmployeeExtended = viewModel::saveEmployeeExtended,
                        onRemoveEmployee = viewModel::removeEmployee,
                        onSetActiveEmployee = viewModel::setActiveEmployee,
                        onRecordAttendance = viewModel::recordAttendance,
                        onSubmitLeave = viewModel::submitLeaveRequest,
                        onDecideLeave = viewModel::decideLeaveRequest,
                        onRecordSalary = viewModel::recordSalaryPayment,
                        onUpdateRolePermission = viewModel::updateRolePermission,
                        onSetPin = viewModel::setPin,
                        onRemovePin = viewModel::removePin,
                        onSetBiometric = viewModel::setBiometricEnabled,
                        onSetLanguage = viewModel::setLanguage,
                        onSetBanglaDigits = viewModel::setBanglaDigits,
                        onSetDarkMode = viewModel::setDarkMode,
                        onUpdateNotifications = viewModel::updateNotificationPrefs,
                        onExportBackupUri = viewModel::exportBackupToUri,
                        onExportBackupWithPassphrase = viewModel::exportBackupToUri,
                        onRestoreBackupUri = viewModel::restoreBackupFromUri,
                        onSyncToCloud = viewModel::syncToCloud,
                        onRestoreFromCloud = viewModel::restoreFromCloud,
                        onOpenSyncDevices = { showSyncDevicesSheet = true },
                        onCheckForUpdate = viewModel::checkForAppUpdate,
                        onDownloadUpdate = viewModel::downloadAvailableUpdate,
                        onResetUpdateState = viewModel::resetUpdateState,
                        latestSnapshotInfo = latestSnapshotInfo,
                        onSaveAllAccounts = viewModel::saveAllAccountsSnapshot,
                        onRestoreLastSnapshot = viewModel::restoreLatestSnapshot,
                        onResetAccounts = viewModel::resetActiveBusinessHisab
                    )
                }
            }
        }
    }

    if (showQuickAddCustomer) {
        CustomerEditorDialog(
            existing = null,
            onDismiss = { showQuickAddCustomer = false },
            onSave = { name, phone, address, photoUri, cat, openingDue ->
                viewModel.saveCustomer(null, name, phone, address, photoUri, cat, openingDue)
                showQuickAddCustomer = false
            }
        )
    }

    showQuickDueModal?.let { initialType ->
        if (workspace.customers.isEmpty()) {
            AlertDialog(
                onDismissRequest = { showQuickDueModal = null },
                title = { Text("No Customers Yet") },
                text = { Text("Add a customer first to record credit or payments in Baki Khata.") },
                confirmButton = {
                    Button(onClick = {
                        showQuickDueModal = null
                        showQuickAddCustomer = true
                    }) { Text("Add Customer") }
                },
                dismissButton = { TextButton(onClick = { showQuickDueModal = null }) { Text("Cancel") } }
            )
        } else {
            var pickedCustomer by remember { mutableStateOf(workspace.customers.first()) }
            var showPicker by remember { mutableStateOf(true) }
            if (showPicker) {
                AlertDialog(
                    onDismissRequest = { showQuickDueModal = null },
                    title = { Text("Select Customer") },
                    text = {
                        Column {
                            workspace.customers.take(10).forEach { c ->
                                TextButton(onClick = { pickedCustomer = c; showPicker = false }) {
                                    Text("${c.name} (${c.customerCode})")
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showQuickDueModal = null }) { Text("Cancel") } }
                )
            } else {
                DueLedgerActionDialog(
                    customer = pickedCustomer,
                    initialType = initialType,
                    accounts = workspace.accounts,
                    useBanglaDigits = workspace.settings.useBanglaDigits,
                    onDismiss = { showQuickDueModal = null },
                    onSubmit = { type, amountPaisa, accId, affectAcc, notes, occurredAt, dueDateMillis ->
                        viewModel.recordDueEntry(
                            customerId = pickedCustomer.id,
                            type = type,
                            amountPaisa = amountPaisa,
                            accountId = accId,
                            affectAccount = affectAcc,
                            notes = notes,
                            occurredAt = occurredAt,
                            dueDateMillis = dueDateMillis
                        )
                        showQuickDueModal = null
                    }
                )
            }
        }
    }

    if (showAiSheet) {
        AiAssistantSheet(
            messages = aiMessages,
            aiUiState = aiUiState,
            useBanglaDigits = workspace.settings.useBanglaDigits,
            onAskQuestion = viewModel::askAiAssistant,
            onConfirmAction = viewModel::confirmAiProposedAction,
            onClearChat = viewModel::clearAiChat,
            onDismiss = { showAiSheet = false }
        )
    }

    if (showVoiceDialog) {
        VoiceAccountingDialog(
            accounts = workspace.accounts,
            useBanglaDigits = workspace.settings.useBanglaDigits,
            initialBangla = strings.isBangla,
            onParseCommand = viewModel::parseVoiceCommand,
            onExecuteCommand = viewModel::executeVoiceCommand,
            onAskAiQuery = { query ->
                showVoiceDialog = false
                showAiSheet = true
                viewModel.askAiAssistant(query)
            },
            onDismiss = { showVoiceDialog = false }
        )
    }

    if (showSyncDevicesSheet) {
        SyncAndDevicesSheet(
            state = workspace,
            currentUserId = Firebase.auth.currentUser?.uid,
            isSyncing = isSyncing,
            onToggleAutoSync = viewModel::setAutoCloudSync,
            onSyncNow = viewModel::syncToCloud,
            onResolveConflict = viewModel::resolveSyncConflict,
            onRevokeDevice = viewModel::revokeCloudDevice,
            onDismiss = { showSyncDevicesSheet = false }
        )
    }
}
