package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.util.SecurityUtils
import com.example.data.local.*
import com.example.data.remote.CloudSyncRepository
import com.example.data.remote.CloudSyncSummary
import com.example.data.repository.AccountingCalculator
import com.example.data.repository.AccountingRepository
import com.example.data.repository.DashboardMetrics
import com.example.data.repository.MonthlyChartPoint
import com.example.data.repository.SaleCartLine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class BusinessWorkspaceState(
    val settings: AppSettingsState = AppSettingsState(),
    val businesses: List<BusinessEntity> = emptyList(),
    val activeBusiness: BusinessEntity? = null,
    val accounts: List<AccountEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val archivedCustomers: List<CustomerEntity> = emptyList(),
    val suppliers: List<SupplierEntity> = emptyList(),
    val products: List<ProductEntity> = emptyList(),
    val stockMovements: List<StockMovementEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val transactions: List<AccountingTransactionEntity> = emptyList(),
    val invoices: List<InvoiceEntity> = emptyList(),
    val employees: List<EmployeeEntity> = emptyList(),
    val activeEmployee: EmployeeEntity? = null,
    val notifications: List<AppNotificationEntity> = emptyList(),
    val unreadNotifications: Int = 0,
    val dashboard: DashboardMetrics = DashboardMetrics(),
    val monthlyChart: List<MonthlyChartPoint> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = HisabDatabase.getInstance(application)
    val repo = AccountingRepository(db)
    val prefs = UserPreferences(application)
    val cloudSyncRepo = CloudSyncRepository(application, db)

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private var lockCheckedOnLaunch = false

    val settingsState: StateFlow<AppSettingsState> = prefs.settingsFlow
        .onEach { settings ->
            if (!lockCheckedOnLaunch && settings.onboardingCompleted && settings.hasPin) {
                _isLocked.value = true
                lockCheckedOnLaunch = true
            } else if (!lockCheckedOnLaunch && settings.onboardingCompleted) {
                lockCheckedOnLaunch = true
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettingsState())

    private val activeBusinessIdFlow: Flow<String> = combine(
        prefs.settingsFlow,
        repo.observeBusinesses()
    ) { settings, businesses ->
        val valid = businesses.firstOrNull { it.id == settings.activeBusinessId }
        valid?.id ?: businesses.firstOrNull()?.id.orEmpty()
    }.distinctUntilChanged()

    val workspaceState: StateFlow<BusinessWorkspaceState> = combine(
        prefs.settingsFlow,
        repo.observeBusinesses(),
        activeBusinessIdFlow.flatMapLatest { bizId ->
            if (bizId.isBlank()) {
                flowOf(EmptyBusinessBundle)
            } else {
                combine(
                    repo.observeAccounts(bizId),
                    repo.observeCustomers(bizId),
                    repo.observeArchivedCustomers(bizId),
                    repo.observeSuppliers(bizId),
                    repo.observeProducts(bizId),
                    repo.observeStockMovements(bizId),
                    repo.observeCategories(bizId),
                    repo.observeTransactions(bizId),
                    repo.observeInvoices(bizId),
                    repo.observeEmployees(bizId),
                    repo.observeNotifications(bizId),
                    repo.observeUnreadNotificationCount(bizId)
                ) { arr ->
                    @Suppress("UNCHECKED_CAST")
                    BusinessBundle(
                        accounts = arr[0] as List<AccountEntity>,
                        customers = arr[1] as List<CustomerEntity>,
                        archivedCustomers = arr[2] as List<CustomerEntity>,
                        suppliers = arr[3] as List<SupplierEntity>,
                        products = arr[4] as List<ProductEntity>,
                        stockMovements = arr[5] as List<StockMovementEntity>,
                        categories = arr[6] as List<CategoryEntity>,
                        transactions = arr[7] as List<AccountingTransactionEntity>,
                        invoices = arr[8] as List<InvoiceEntity>,
                        employees = arr[9] as List<EmployeeEntity>,
                        notifications = arr[10] as List<AppNotificationEntity>,
                        unreadCount = arr[11] as Int
                    )
                }
            }
        }
    ) { settings, businesses, bundle ->
        val activeBiz = businesses.firstOrNull { it.id == settings.activeBusinessId } ?: businesses.firstOrNull()
        val activeEmp = bundle.employees.firstOrNull { it.id == settings.activeEmployeeId }
            ?: bundle.employees.firstOrNull { it.role == EmployeeRoles.OWNER }
            ?: bundle.employees.firstOrNull()
        val dashboard = AccountingCalculator.computeDashboard(
            accounts = bundle.accounts,
            customers = bundle.customers,
            suppliers = bundle.suppliers,
            transactions = bundle.transactions
        )
        val chart = AccountingCalculator.computeLast6MonthsChart(bundle.transactions)
        BusinessWorkspaceState(
            settings = settings,
            businesses = businesses,
            activeBusiness = activeBiz,
            accounts = bundle.accounts,
            customers = bundle.customers,
            archivedCustomers = bundle.archivedCustomers,
            suppliers = bundle.suppliers,
            products = bundle.products,
            stockMovements = bundle.stockMovements,
            categories = bundle.categories,
            transactions = bundle.transactions,
            invoices = bundle.invoices,
            employees = bundle.employees,
            activeEmployee = activeEmp,
            notifications = bundle.notifications,
            unreadNotifications = bundle.unreadCount,
            dashboard = dashboard,
            monthlyChart = chart
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), BusinessWorkspaceState())

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun unlockWithPin(pin: String): Boolean {
        val s = settingsState.value
        val ok = SecurityUtils.verifyPin(pin, s.pinSalt, s.pinHash)
        if (ok) _isLocked.value = false
        return ok
    }

    fun unlockBiometric() {
        _isLocked.value = false
    }

    fun lockNow() {
        if (settingsState.value.hasPin) {
            _isLocked.value = true
        }
    }

    fun setPin(pin: String) {
        viewModelScope.launch {
            val salt = SecurityUtils.generateSalt()
            val hash = SecurityUtils.hashPin(pin, salt)
            prefs.setPin(hash, salt)
            _statusMessage.value = "Security PIN enabled"
        }
    }

    fun removePin() {
        viewModelScope.launch {
            prefs.clearPin()
            _isLocked.value = false
            _statusMessage.value = "Security PIN removed"
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setBiometricEnabled(enabled) }
    }

    fun completeOnboarding(
        name: String,
        category: String,
        phone: String,
        address: String,
        logoUri: String?,
        languageCode: String,
        openingCashPaisa: Long,
        inventoryEnabled: Boolean,
        pin: String
    ) {
        viewModelScope.launch {
            val biz = repo.createBusinessWithDefaults(
                name = name,
                category = category,
                phone = phone,
                address = address,
                logoUri = logoUri,
                languageCode = languageCode,
                openingCashPaisa = openingCashPaisa,
                inventoryEnabled = inventoryEnabled
            )
            if (pin.length in 4..6) {
                val salt = SecurityUtils.generateSalt()
                val hash = SecurityUtils.hashPin(pin, salt)
                prefs.setPin(hash, salt)
            }
            prefs.completeOnboarding(biz.id, languageCode)
        }
    }

    fun createAdditionalBusiness(
        name: String,
        category: String,
        phone: String,
        address: String,
        logoUri: String?,
        openingCashPaisa: Long,
        inventoryEnabled: Boolean
    ) {
        viewModelScope.launch {
            val biz = repo.createBusinessWithDefaults(
                name = name,
                category = category,
                phone = phone,
                address = address,
                logoUri = logoUri,
                languageCode = settingsState.value.languageCode,
                openingCashPaisa = openingCashPaisa,
                inventoryEnabled = inventoryEnabled
            )
            prefs.setActiveBusinessId(biz.id)
            _statusMessage.value = "Switched to ${biz.name}"
        }
    }

    fun switchBusiness(businessId: String) {
        viewModelScope.launch { prefs.setActiveBusinessId(businessId) }
    }

    fun updateBusiness(business: BusinessEntity) {
        viewModelScope.launch {
            repo.updateBusiness(business)
            _statusMessage.value = "Business profile updated"
        }
    }

    fun setLanguage(code: String) {
        viewModelScope.launch { prefs.setLanguage(code) }
    }

    fun setBanglaDigits(enabled: Boolean) {
        viewModelScope.launch { prefs.setBanglaDigits(enabled) }
    }

    fun setDarkMode(mode: String) {
        viewModelScope.launch { prefs.setDarkMode(mode) }
    }

    fun setActiveEmployee(employeeId: String) {
        viewModelScope.launch { prefs.setActiveEmployeeId(employeeId) }
    }

    fun updateNotificationPrefs(due: Boolean, stock: Boolean, daily: Boolean, backup: Boolean) {
        viewModelScope.launch { prefs.updateNotificationSettings(due, stock, daily, backup) }
    }

    fun markNotificationsRead() {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch { repo.markNotificationsRead(bizId) }
    }

    private fun operatorName(): String =
        workspaceState.value.activeEmployee?.let { "${it.name} (${it.role})" } ?: "Owner"

    fun saveCustomer(
        existingId: String?,
        name: String,
        phone: String,
        address: String,
        photoUri: String?,
        category: String,
        openingDuePaisa: Long
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveCustomer(bizId, existingId, name, phone, address, photoUri, category, openingDuePaisa)
            _statusMessage.value = "Customer saved"
        }
    }

    fun archiveCustomer(customerId: String, archived: Boolean) {
        viewModelScope.launch { repo.setCustomerArchived(customerId, archived) }
    }

    fun saveSupplier(
        existingId: String?,
        name: String,
        phone: String,
        address: String,
        openingPayablePaisa: Long
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveSupplier(bizId, existingId, name, phone, address, openingPayablePaisa)
            _statusMessage.value = "Supplier saved"
        }
    }

    fun saveProduct(
        existingId: String?,
        name: String,
        sku: String,
        barcode: String,
        category: String,
        purchasePricePaisa: Long,
        sellingPricePaisa: Long,
        initialStockMilliUnits: Long,
        unit: String,
        lowStockThresholdMilliUnits: Long,
        imageUri: String?
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveProduct(
                bizId, existingId, name, sku, barcode, category,
                purchasePricePaisa, sellingPricePaisa, initialStockMilliUnits,
                unit, lowStockThresholdMilliUnits, imageUri, operatorName()
            )
            _statusMessage.value = "Product saved"
        }
    }

    fun adjustStock(productId: String, type: String, deltaMilliUnits: Long, notes: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.adjustStock(bizId, productId, type, deltaMilliUnits, notes, operatorName())
            _statusMessage.value = "Stock updated"
        }
    }

    fun recordSale(
        customerId: String?,
        lines: List<SaleCartLine>,
        discountPaisa: Long,
        taxRateBps: Int,
        paidPaisa: Long,
        accountId: String,
        notes: String,
        onComplete: (InvoiceEntity) -> Unit = {}
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                val inv = repo.recordSale(
                    bizId, customerId, lines, discountPaisa, taxRateBps,
                    paidPaisa, accountId, notes, createdBy = operatorName()
                )
                _statusMessage.value = "Invoice ${inv.invoiceNumber} saved"
                onComplete(inv)
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Could not save sale"
            }
        }
    }

    fun recordDueEntry(
        customerId: String,
        type: String,
        amountPaisa: Long,
        accountId: String,
        affectAccount: Boolean,
        notes: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                repo.recordDueLedgerEntry(
                    bizId, customerId, type, amountPaisa, accountId,
                    affectAccount, notes, createdBy = operatorName()
                )
                _statusMessage.value = "Due ledger updated"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Failed to update due ledger"
            }
        }
    }

    fun recordPurchase(
        supplierId: String?,
        lines: List<SaleCartLine>,
        paidPaisa: Long,
        accountId: String,
        notes: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                val inv = repo.recordPurchase(
                    bizId, supplierId, lines, paidPaisa, accountId, notes, createdBy = operatorName()
                )
                _statusMessage.value = "Purchase ${inv.invoiceNumber} recorded"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Purchase failed"
            }
        }
    }

    fun recordSupplierPayment(supplierId: String, amountPaisa: Long, accountId: String, notes: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.recordSupplierPayment(bizId, supplierId, amountPaisa, accountId, notes, createdBy = operatorName())
            _statusMessage.value = "Supplier payment recorded"
        }
    }

    fun recordIncomeOrExpense(
        isExpense: Boolean,
        amountPaisa: Long,
        categoryId: String?,
        categoryName: String,
        accountId: String,
        notes: String,
        attachmentUri: String?
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.recordIncomeOrExpense(
                bizId, isExpense, amountPaisa, categoryId, categoryName,
                accountId, notes, attachmentUri, createdBy = operatorName()
            )
            _statusMessage.value = if (isExpense) "Expense recorded" else "Income recorded"
        }
    }

    fun createCategory(name: String, type: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch { repo.createCustomCategory(bizId, name, type) }
    }

    fun saveAccount(name: String, type: String, number: String, openingBalancePaisa: Long) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveAccount(bizId, name, type, number, openingBalancePaisa)
            _statusMessage.value = "Account added"
        }
    }

    fun transferAccounts(fromId: String, toId: String, amountPaisa: Long, notes: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                repo.recordAccountTransfer(bizId, fromId, toId, amountPaisa, notes, createdBy = operatorName())
                _statusMessage.value = "Account transfer completed"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Transfer failed"
            }
        }
    }

    fun recordReturnOrCorrection(
        type: String,
        customerId: String?,
        supplierId: String?,
        productId: String?,
        quantityMilliUnits: Long,
        amountPaisa: Long,
        refundCash: Boolean,
        accountId: String,
        notes: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.recordReturnOrCorrection(
                bizId, type, customerId, supplierId, productId,
                quantityMilliUnits, amountPaisa, refundCash, accountId, notes, operatorName()
            )
            _statusMessage.value = "Adjustment recorded"
        }
    }

    fun reverseTransaction(txId: String, reason: String) {
        val emp = workspaceState.value.activeEmployee
        if (emp != null && !emp.canDeleteOrReverse) {
            _statusMessage.value = "Permission denied: ${emp.role} cannot reverse transactions"
            return
        }
        viewModelScope.launch {
            repo.reverseTransaction(txId, reason, operatorName())
            _statusMessage.value = "Reversal audit entry recorded"
        }
    }

    fun saveEmployee(name: String, phone: String, role: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveEmployee(bizId, name, phone, role)
            _statusMessage.value = "Employee added"
        }
    }

    fun removeEmployee(id: String) {
        viewModelScope.launch { repo.removeEmployee(id) }
    }

    fun exportBackupToUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = repo.exportLocalBackupJson()
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                    it.write(json.toByteArray(Charsets.UTF_8))
                }
                prefs.updateLastLocalBackup(System.currentTimeMillis())
                _statusMessage.value = "Local backup exported successfully"
            } catch (e: Exception) {
                _statusMessage.value = "Export failed: ${e.message}"
            }
        }
    }

    fun restoreBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val json = getApplication<Application>().contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                } ?: return@launch
                val count = repo.restoreLocalBackupJson(json)
                if (count > 0) {
                    val businesses = db.businessDao().getAllBusinessesSync()
                    businesses.firstOrNull()?.let { prefs.completeOnboarding(it.id, it.languageCode) }
                    _statusMessage.value = "Restored $count business(es) from backup"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Restore failed: ${e.message}"
            }
        }
    }

    fun syncToCloud(currentUserId: String) {
        if (_isSyncing.value) return
        viewModelScope.launch {
            _isSyncing.value = true
            val result: Result<CloudSyncSummary> = cloudSyncRepo.syncLocalToCloud(currentUserId)
            _isSyncing.value = false
            result.onSuccess { summary ->
                prefs.updateLastCloudSync(summary.syncedAtMillis)
                _statusMessage.value = "Synced ${summary.businessesSynced} business(es), ${summary.recordsSynced} records"
            }.onFailure { err ->
                _statusMessage.value = "Cloud sync failed: ${err.message}"
            }
        }
    }

    fun restoreFromCloud(currentUserId: String) {
        if (_isSyncing.value) return
        viewModelScope.launch {
            _isSyncing.value = true
            val result = cloudSyncRepo.restoreCloudToLocal(currentUserId)
            _isSyncing.value = false
            result.onSuccess { summary ->
                prefs.updateLastCloudSync(summary.syncedAtMillis)
                val businesses = db.businessDao().getAllBusinessesSync()
                businesses.firstOrNull()?.let { prefs.completeOnboarding(it.id, it.languageCode) }
                _statusMessage.value = "Restored ${summary.businessesSynced} business(es) from cloud"
            }.onFailure { err ->
                _statusMessage.value = "Cloud restore failed: ${err.message}"
            }
        }
    }

    private data class BusinessBundle(
        val accounts: List<AccountEntity>,
        val customers: List<CustomerEntity>,
        val archivedCustomers: List<CustomerEntity>,
        val suppliers: List<SupplierEntity>,
        val products: List<ProductEntity>,
        val stockMovements: List<StockMovementEntity>,
        val categories: List<CategoryEntity>,
        val transactions: List<AccountingTransactionEntity>,
        val invoices: List<InvoiceEntity>,
        val employees: List<EmployeeEntity>,
        val notifications: List<AppNotificationEntity>,
        val unreadCount: Int
    )

    private val EmptyBusinessBundle = BusinessBundle(
        emptyList(), emptyList(), emptyList(), emptyList(), emptyList(),
        emptyList(), emptyList(), emptyList(), emptyList(), emptyList(),
        emptyList(), 0
    )
}
