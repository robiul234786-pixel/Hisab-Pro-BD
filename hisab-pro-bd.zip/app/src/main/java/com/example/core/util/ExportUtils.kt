package com.example.core.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.data.local.AccountingTransactionEntity
import com.example.data.local.BusinessEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.InvoiceEntity
import com.example.data.local.InvoiceItemEntity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.URLEncoder

object ExportUtils {

    private fun exportsDir(context: Context): File {
        val dir = File(context.cacheDir, "exports")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }

    fun launchWhatsAppReminder(context: Context, phone: String, message: String) {
        val digits = MoneyUtils.normalizeDigits(phone).filter { it.isDigit() }
        val bdDigits = when {
            digits.startsWith("880") -> digits
            digits.startsWith("01") -> "88$digits"
            else -> digits
        }
        val encoded = URLEncoder.encode(message, "UTF-8")
        val uri = if (bdDigits.isNotBlank()) {
            Uri.parse("https://wa.me/$bdDigits?text=$encoded")
        } else {
            Uri.parse("https://wa.me/?text=$encoded")
        }
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(intent)
    }

    fun launchSmsReminder(context: Context, phone: String, message: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${phone.trim()}")
            putExtra("sms_body", message)
        }
        context.startActivity(intent)
    }

    fun generateInvoicePdf(
        context: Context,
        business: BusinessEntity,
        invoice: InvoiceEntity,
        items: List<InvoiceItemEntity>,
        useBanglaDigits: Boolean
    ): File {
        val pdf = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdf.startPage(pageInfo)
        val c = page.canvas

        val titlePaint = Paint().apply {
            color = Color.parseColor("#101C2C")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val emeraldPaint = Paint().apply {
            color = Color.parseColor("#10A36C")
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 11f
        }
        val boldPaint = Paint().apply {
            color = Color.parseColor("#101C2C")
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }

        var y = 48f
        c.drawText(business.name, 40f, y, titlePaint)
        y += 18f
        c.drawText("${business.category} | ${business.phone}", 40f, y, bodyPaint)
        if (business.address.isNotBlank()) {
            y += 16f
            c.drawText(business.address, 40f, y, bodyPaint)
        }
        y += 22f
        c.drawLine(40f, y, 555f, y, linePaint)
        y += 22f

        val label = if (invoice.invoiceType == "PURCHASE") "PURCHASE BILL" else "SALES INVOICE"
        c.drawText("$label: ${invoice.invoiceNumber}", 40f, y, emeraldPaint)
        c.drawText("Date: ${MoneyUtils.formatDhakaDateTime(invoice.occurredAt)}", 330f, y, bodyPaint)
        y += 18f
        c.drawText("Party: ${invoice.partyName}", 40f, y, boldPaint)
        y += 22f

        c.drawLine(40f, y, 555f, y, linePaint)
        y += 16f
        c.drawText("Item", 40f, y, boldPaint)
        c.drawText("Qty", 290f, y, boldPaint)
        c.drawText("Rate", 370f, y, boldPaint)
        c.drawText("Total", 475f, y, boldPaint)
        y += 8f
        c.drawLine(40f, y, 555f, y, linePaint)
        y += 18f

        items.forEach { item ->
            if (y > 760f) return@forEach
            val qtyStr = "${MoneyUtils.milliUnitsToString(item.quantityMilliUnits, useBanglaDigits)} ${item.unit}"
            c.drawText(item.itemName.take(34), 40f, y, bodyPaint)
            c.drawText(qtyStr, 290f, y, bodyPaint)
            c.drawText(MoneyUtils.formatTaka(item.unitPricePaisa, useBanglaDigits), 370f, y, bodyPaint)
            c.drawText(MoneyUtils.formatTaka(item.lineTotalPaisa, useBanglaDigits), 475f, y, bodyPaint)
            y += 18f
        }

        y += 8f
        c.drawLine(300f, y, 555f, y, linePaint)
        y += 18f
        c.drawText("Subtotal:", 340f, y, bodyPaint)
        c.drawText(MoneyUtils.formatTaka(invoice.subtotalPaisa, useBanglaDigits), 465f, y, bodyPaint)
        y += 16f
        if (invoice.discountPaisa > 0) {
            c.drawText("Discount:", 340f, y, bodyPaint)
            c.drawText("-${MoneyUtils.formatTaka(invoice.discountPaisa, useBanglaDigits)}", 465f, y, bodyPaint)
            y += 16f
        }
        if (invoice.taxPaisa > 0) {
            c.drawText("VAT / Tax:", 340f, y, bodyPaint)
            c.drawText(MoneyUtils.formatTaka(invoice.taxPaisa, useBanglaDigits), 465f, y, bodyPaint)
            y += 16f
        }
        c.drawText("Grand Total:", 340f, y, boldPaint)
        c.drawText(MoneyUtils.formatTaka(invoice.totalPaisa, useBanglaDigits), 465f, y, boldPaint)
        y += 16f
        c.drawText("Paid:", 340f, y, bodyPaint)
        c.drawText(MoneyUtils.formatTaka(invoice.paidPaisa, useBanglaDigits), 465f, y, bodyPaint)
        y += 16f
        c.drawText("Due:", 340f, y, emeraldPaint)
        c.drawText(MoneyUtils.formatTaka(invoice.duePaisa, useBanglaDigits), 465f, y, emeraldPaint)

        y += 38f
        c.drawText("Generated by Hisab Pro BD", 40f, y, bodyPaint)

        pdf.finishPage(page)
        val outFile = File(exportsDir(context), "${invoice.invoiceNumber}.pdf")
        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        return outFile
    }

    fun printPdfDocument(context: Context, pdfFile: File, jobName: String) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(pdfFile.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    FileInputStream(pdfFile).use { input ->
                        FileOutputStream(destination?.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }
        printManager.print(jobName, adapter, null)
    }

    fun generateCustomerStatementPdf(
        context: Context,
        business: BusinessEntity,
        customer: CustomerEntity,
        transactions: List<AccountingTransactionEntity>,
        useBanglaDigits: Boolean
    ): File {
        val lines = mutableListOf<Pair<String, String>>()
        lines.add("Customer" to "${customer.name} (${customer.customerCode})")
        lines.add("Phone" to customer.phone.ifBlank { "-" })
        lines.add("Current Outstanding Due" to MoneyUtils.formatTaka(customer.currentDuePaisa, useBanglaDigits))
        lines.add("Total Purchases" to MoneyUtils.formatTaka(customer.totalPurchasesPaisa, useBanglaDigits))
        lines.add("Total Payments" to MoneyUtils.formatTaka(customer.totalPaymentsPaisa, useBanglaDigits))
        val rows = transactions.take(40).map { tx ->
            listOf(
                MoneyUtils.formatDhakaDate(tx.occurredAt, useBanglaDigits),
                tx.type.replace('_', ' '),
                MoneyUtils.formatTaka(tx.totalAmountPaisa, useBanglaDigits),
                MoneyUtils.formatTaka(tx.paidAmountPaisa, useBanglaDigits),
                tx.notes.ifBlank { "-" }
            )
        }
        return generateReportPdf(
            context = context,
            fileName = "statement_${customer.customerCode}.pdf",
            businessName = business.name,
            reportTitle = "Customer Statement - ${customer.name}",
            summaryRows = lines,
            tableHeaders = listOf("Date", "Type", "Amount", "Paid", "Notes"),
            tableRows = rows
        )
    }

    fun generateReportPdf(
        context: Context,
        fileName: String,
        businessName: String,
        reportTitle: String,
        summaryRows: List<Pair<String, String>>,
        tableHeaders: List<String>,
        tableRows: List<List<String>>
    ): File {
        val pdf = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        var page = pdf.startPage(pageInfo)
        var c = page.canvas

        val titlePaint = Paint().apply {
            color = Color.parseColor("#101C2C")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subtitlePaint = Paint().apply {
            color = Color.parseColor("#10A36C")
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 10f
        }
        val boldPaint = Paint().apply {
            color = Color.parseColor("#101C2C")
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1f
        }

        var y = 44f
        c.drawText(businessName, 36f, y, titlePaint)
        y += 18f
        c.drawText(reportTitle, 36f, y, subtitlePaint)
        y += 14f
        c.drawText("Generated: ${MoneyUtils.formatDhakaDateTime(System.currentTimeMillis())}", 36f, y, bodyPaint)
        y += 14f
        c.drawLine(36f, y, 559f, y, linePaint)
        y += 18f

        summaryRows.forEach { (k, v) ->
            c.drawText(k, 36f, y, boldPaint)
            c.drawText(v, 300f, y, bodyPaint)
            y += 15f
        }

        if (tableHeaders.isNotEmpty()) {
            y += 10f
            c.drawLine(36f, y, 559f, y, linePaint)
            y += 15f
            val colWidth = 520f / tableHeaders.size.coerceAtLeast(1)
            tableHeaders.forEachIndexed { idx, h ->
                c.drawText(h.take(16), 36f + idx * colWidth, y, boldPaint)
            }
            y += 8f
            c.drawLine(36f, y, 559f, y, linePaint)
            y += 14f

            tableRows.forEach { row ->
                if (y > 790f) {
                    pdf.finishPage(page)
                    page = pdf.startPage(pageInfo)
                    c = page.canvas
                    y = 44f
                }
                row.forEachIndexed { idx, cell ->
                    c.drawText(cell.take(18), 36f + idx * colWidth, y, bodyPaint)
                }
                y += 14f
            }
        }

        pdf.finishPage(page)
        val outFile = File(exportsDir(context), fileName)
        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        return outFile
    }

    /**
     * Generates an Excel-compatible SpreadsheetML (.xls) / CSV workbook file that opens cleanly in Microsoft Excel & Google Sheets.
     */
    fun generateExcelCsv(
        context: Context,
        fileName: String,
        headers: List<String>,
        rows: List<List<String>>
    ): File {
        val sb = StringBuilder()
        // UTF-8 BOM so Excel renders Bangla Unicode cleanly without mojibake!
        sb.append('\uFEFF')
        sb.append(headers.joinToString(",") { escapeCsv(it) }).append('\n')
        rows.forEach { row ->
            sb.append(row.joinToString(",") { escapeCsv(it) }).append('\n')
        }
        val outFile = File(exportsDir(context), fileName)
        outFile.writeText(sb.toString(), Charsets.UTF_8)
        return outFile
    }

    private fun escapeCsv(value: String): String {
        val needsQuotes = value.contains(',') || value.contains('"') || value.contains('\n')
        val escaped = value.replace("\"", "\"\"")
        return if (needsQuotes) "\"$escaped\"" else escaped
    }
}
