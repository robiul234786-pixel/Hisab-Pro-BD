package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.util.BarcodeScannerHelper
import com.example.core.util.ExportUtils
import com.example.core.util.SecurityUtils
import com.example.core.util.ThermalPrinterHelper
import com.example.core.util.VoiceAccountingParser
import com.example.core.util.VoiceIntentType
import com.example.data.local.*
import com.example.data.repository.AccountingCalculator
import com.example.data.repository.AccountingRepository
import com.example.data.repository.SaleCartLine
import com.example.ui.BakiKhataViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.time.Instant
import java.time.format.DateTimeFormatter

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ProUpgradeRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: HisabDatabase
    private lateinit var repo: AccountingRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, HisabDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = AccountingRepository(db)
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `migration 1 to 2 preserves all existing v1 business customer product employee and ledger data`() = runBlocking {
        val dbFile = File(context.cacheDir, "migration_v1_to_v2_test.db")
        if (dbFile.exists()) dbFile.delete()

        val rawDb = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS businesses (
                id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
                phone TEXT NOT NULL, address TEXT NOT NULL, logoUri TEXT,
                languageCode TEXT NOT NULL, openingCashPaisa INTEGER NOT NULL,
                inventoryEnabled INTEGER NOT NULL, taxEnabled INTEGER NOT NULL,
                defaultTaxRateBps INTEGER NOT NULL, archived INTEGER NOT NULL,
                createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, name TEXT NOT NULL,
                type TEXT NOT NULL, accountNumber TEXT NOT NULL,
                openingBalancePaisa INTEGER NOT NULL, currentBalancePaisa INTEGER NOT NULL,
                isDefault INTEGER NOT NULL, archived INTEGER NOT NULL, createdAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_accounts_businessId ON accounts(businessId)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS customers (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, customerCode TEXT NOT NULL,
                name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL, photoUri TEXT,
                category TEXT NOT NULL, openingDuePaisa INTEGER NOT NULL, currentDuePaisa INTEGER NOT NULL,
                totalPurchasesPaisa INTEGER NOT NULL, totalPaymentsPaisa INTEGER NOT NULL,
                overdueSinceMillis INTEGER, archived INTEGER NOT NULL,
                createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_customers_businessId ON customers(businessId)")
        rawDb.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_customers_businessId_customerCode ON customers(businessId, customerCode)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS suppliers (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, supplierCode TEXT NOT NULL,
                name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL,
                openingPayablePaisa INTEGER NOT NULL, currentPayablePaisa INTEGER NOT NULL,
                totalPurchasesPaisa INTEGER NOT NULL, totalPaymentsPaisa INTEGER NOT NULL,
                archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_suppliers_businessId ON suppliers(businessId)")
        rawDb.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_suppliers_businessId_supplierCode ON suppliers(businessId, supplierCode)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS products (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, name TEXT NOT NULL,
                sku TEXT NOT NULL, barcode TEXT NOT NULL, category TEXT NOT NULL,
                purchasePricePaisa INTEGER NOT NULL, sellingPricePaisa INTEGER NOT NULL,
                stockMilliUnits INTEGER NOT NULL, unit TEXT NOT NULL,
                lowStockThresholdMilliUnits INTEGER NOT NULL, imageUri TEXT,
                archived INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_products_businessId ON products(businessId)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS stock_movements (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, productId TEXT NOT NULL,
                productName TEXT NOT NULL, movementType TEXT NOT NULL, deltaMilliUnits INTEGER NOT NULL,
                balanceAfterMilliUnits INTEGER NOT NULL, unitCostPaisa INTEGER NOT NULL,
                referenceId TEXT, notes TEXT NOT NULL, occurredAt INTEGER NOT NULL, createdBy TEXT NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_stock_movements_businessId ON stock_movements(businessId)")
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_stock_movements_productId ON stock_movements(productId)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS categories (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, name TEXT NOT NULL,
                nameBn TEXT NOT NULL, type TEXT NOT NULL, isSystem INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_categories_businessId ON categories(businessId)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS accounting_transactions (
                id TEXT NOT NULL PRIMARY KEY, idempotencyKey TEXT NOT NULL, businessId TEXT NOT NULL,
                type TEXT NOT NULL, customerId TEXT, supplierId TEXT, partyName TEXT NOT NULL,
                accountId TEXT, accountName TEXT NOT NULL, toAccountId TEXT, toAccountName TEXT NOT NULL,
                referenceId TEXT, categoryId TEXT, categoryName TEXT NOT NULL,
                subtotalPaisa INTEGER NOT NULL, discountPaisa INTEGER NOT NULL, taxPaisa INTEGER NOT NULL,
                totalAmountPaisa INTEGER NOT NULL, paidAmountPaisa INTEGER NOT NULL, dueDeltaPaisa INTEGER NOT NULL,
                cogsPaisa INTEGER NOT NULL, hasEstimatedCost INTEGER NOT NULL,
                cashFlowDeltaPaisa INTEGER NOT NULL, accountBalanceAfterPaisa INTEGER NOT NULL,
                isReversed INTEGER NOT NULL, reversedTransactionId TEXT, notes TEXT NOT NULL,
                attachmentUri TEXT, occurredAt INTEGER NOT NULL, dueDateMillis INTEGER,
                createdBy TEXT NOT NULL, createdAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_transactions_businessId ON accounting_transactions(businessId)")
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_transactions_customerId ON accounting_transactions(customerId)")
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_transactions_supplierId ON accounting_transactions(supplierId)")
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_transactions_accountId ON accounting_transactions(accountId)")
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_accounting_transactions_occurredAt ON accounting_transactions(occurredAt)")
        rawDb.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_accounting_transactions_idempotencyKey ON accounting_transactions(idempotencyKey)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS invoices (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, invoiceNumber TEXT NOT NULL,
                invoiceType TEXT NOT NULL, partyId TEXT, partyName TEXT NOT NULL,
                subtotalPaisa INTEGER NOT NULL, discountPaisa INTEGER NOT NULL, taxRateBps INTEGER NOT NULL,
                taxPaisa INTEGER NOT NULL, totalPaisa INTEGER NOT NULL, paidPaisa INTEGER NOT NULL,
                duePaisa INTEGER NOT NULL, cogsPaisa INTEGER NOT NULL, accountId TEXT,
                notes TEXT NOT NULL, occurredAt INTEGER NOT NULL, createdBy TEXT NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_invoices_businessId ON invoices(businessId)")
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_invoices_occurredAt ON invoices(occurredAt)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS invoice_items (
                id TEXT NOT NULL PRIMARY KEY, invoiceId TEXT NOT NULL, productId TEXT,
                itemName TEXT NOT NULL, unit TEXT NOT NULL, quantityMilliUnits INTEGER NOT NULL,
                unitPricePaisa INTEGER NOT NULL, costPricePaisa INTEGER NOT NULL,
                lineTotalPaisa INTEGER NOT NULL, returnedMilliUnits INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_invoice_items_invoiceId ON invoice_items(invoiceId)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS employees (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, name TEXT NOT NULL,
                phone TEXT NOT NULL, role TEXT NOT NULL, canViewReports INTEGER NOT NULL,
                canDeleteOrReverse INTEGER NOT NULL, canManageEmployees INTEGER NOT NULL,
                canManageSettings INTEGER NOT NULL, isActive INTEGER NOT NULL, createdAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_employees_businessId ON employees(businessId)")
        rawDb.execSQL(
            """
            CREATE TABLE IF NOT EXISTS app_notifications (
                id TEXT NOT NULL PRIMARY KEY, businessId TEXT NOT NULL, type TEXT NOT NULL,
                title TEXT NOT NULL, message TEXT NOT NULL, isRead INTEGER NOT NULL, createdAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_app_notifications_businessId ON app_notifications(businessId)")
        rawDb.execSQL("CREATE INDEX IF NOT EXISTS index_app_notifications_createdAt ON app_notifications(createdAt)")

        // Seed existing v1 records
        val now = 1760000000000L
        rawDb.execSQL(
            "INSERT INTO businesses VALUES ('biz-1', 'Bismillah Store', 'Grocery Shop', '01711111111', 'Dhaka', NULL, 'bn', 100000, 1, 0, 0, 0, $now, $now)"
        )
        rawDb.execSQL(
            "INSERT INTO accounts VALUES ('acc-1', 'biz-1', 'Cash', 'CASH', '', 100000, 350000, 1, 0, $now)"
        )
        rawDb.execSQL(
            "INSERT INTO customers VALUES ('cust-1', 'biz-1', 'CUST-0001', 'Rahim Uddin', '01811111111', 'Mirpur', NULL, 'Regular', 0, 50000, 150000, 100000, NULL, 0, $now, $now)"
        )
        rawDb.execSQL(
            "INSERT INTO products VALUES ('prod-1', 'biz-1', 'Miniket Rice', 'SKU-1', '8901234567890', 'Staples', 7500, 9000, 25000, 'KG', 5000, NULL, 0, $now, $now)"
        )
        rawDb.execSQL(
            "INSERT INTO employees VALUES ('emp-1', 'biz-1', 'Jamal Owner', '01711111111', 'OWNER', 1, 1, 1, 1, 1, $now)"
        )
        rawDb.execSQL(
            "INSERT INTO accounting_transactions VALUES ('tx-1', 'idem-1', 'biz-1', 'SALE', 'cust-1', NULL, 'Rahim Uddin', 'acc-1', 'Cash', NULL, '', NULL, NULL, 'INV-00001', 250000, 0, 0, 250000, 250000, 0, 180000, 0, 250000, 350000, 0, NULL, 'Legacy sale', NULL, $now, NULL, 'Owner', $now)"
        )
        rawDb.version = 1
        rawDb.close()

        val migratedDb = Room.databaseBuilder(context, HisabDatabase::class.java, dbFile.absolutePath)
            .addMigrations(HisabDatabase.MIGRATION_1_2, HisabDatabase.MIGRATION_2_3)
            .allowMainThreadQueries()
            .build()

        try {
            val migratedBiz = migratedDb.businessDao().getById("biz-1")
            assertNotNull(migratedBiz)
            assertEquals("Bismillah Store", migratedBiz?.name)
            assertEquals(1L, migratedBiz?.syncVersion)

            val migratedCust = migratedDb.customerDao().getById("cust-1")
            assertEquals(50000L, migratedCust?.currentDuePaisa)

            val migratedProd = migratedDb.productDao().getById("prod-1")
            assertEquals(25000L, migratedProd?.stockMilliUnits)

            val migratedTx = migratedDb.transactionDao().getById("tx-1")
            assertEquals(250000L, migratedTx?.totalAmountPaisa)

            val migratedEmp = migratedDb.employeeDao().getById("emp-1")
            assertEquals("OWNER", migratedEmp?.role)
            assertTrue(migratedEmp?.canRecordSales == true)

            // Verify new v2 & v3 tables operate cleanly on the migrated database
            val migratedRepo = AccountingRepository(migratedDb)
            migratedRepo.ensureRolePermissionsSeeded("biz-1")
            val roles = migratedDb.rolePermissionDao().getRolePermissionsSync("biz-1")
            assertTrue(roles.size >= 4)

            migratedRepo.recordAttendance("biz-1", "emp-1", "2026-11-25", AttendanceStatuses.PRESENT, "On time")
            val att = migratedDb.attendanceDao().getForDate("biz-1", "2026-11-25")
            assertEquals(1, att.size)

            migratedRepo.recordDueLedgerEntry(
                businessId = "biz-1",
                customerId = "cust-1",
                type = TxTypes.CREDIT_SALE,
                amountPaisa = 20000L,
                accountId = "acc-1",
                affectAccountBalance = false,
                notes = "Post-migration baki",
                dueDateMillis = now + 86_400_000L * 7
            )
            val bakiEntries = migratedDb.bakiKhataDao().getEntriesForBusinessSync("biz-1")
            assertTrue(bakiEntries.any { it.customerId == "cust-1" && it.promisedRepaymentDateMillis != null })
        } finally {
            migratedDb.close()
            dbFile.delete()
        }
    }

    @Test
    fun `voice accounting parser supports bangla commands ambiguity and duplicate warning`() {
        val customers = listOf(
            CustomerEntity(id = "c1", businessId = "b1", customerCode = "C-1", name = "Rahim Mia"),
            CustomerEntity(id = "c2", businessId = "b1", customerCode = "C-2", name = "Rahim Sheikh"),
            CustomerEntity(id = "c3", businessId = "b1", customerCode = "C-3", name = "Karim Ali")
        )
        val products = listOf(
            ProductEntity(id = "p1", businessId = "b1", name = "চাল", sellingPricePaisa = 8_000L, unit = "Kg")
        )
        val now = 1764000000000L

        // 1. Ambiguous customer ("রহিম" matches Rahim Mia & Rahim Sheikh)
        val cmd1 = VoiceAccountingParser.parse("রহিমের কাছ থেকে ২০০০ টাকা পেলাম", customers, products, emptyList(), now)
        assertEquals(VoiceIntentType.CUSTOMER_PAYMENT, cmd1.intentType)
        assertEquals(200_000L, cmd1.amountPaisa)
        assertEquals(2, cmd1.ambiguousCustomers.size)
        assertNull(cmd1.customerId)

        // 2. Exact Bangla credit sale ("করিমকে ৫০০০ টাকা বাকিতে দিলাম")
        val cmd2 = VoiceAccountingParser.parse("করিমকে ৫০০০ টাকা বাকিতে দিলাম", customers, products, emptyList(), now)
        assertEquals(VoiceIntentType.CREDIT_SALE, cmd2.intentType)
        assertEquals(500_000L, cmd2.amountPaisa)
        assertEquals("c3", cmd2.customerId)

        // 3. Bangla expense ("দোকানের ভাড়া ৩০০০ টাকা দিলাম")
        val cmd3 = VoiceAccountingParser.parse("দোকানের ভাড়া ৩০০০ টাকা দিলাম", customers, products, emptyList(), now)
        assertEquals(VoiceIntentType.EXPENSE, cmd3.intentType)
        assertEquals(300_000L, cmd3.amountPaisa)
        assertEquals("Rent", cmd3.categoryName)

        // 4. Quantity + Product sale ("১০ কেজি চাল বিক্রি করলাম") -> uses 10 * ৳80 = ৳800
        val cmd4 = VoiceAccountingParser.parse("১০ কেজি চাল বিক্রি করলাম", customers, products, emptyList(), now)
        assertEquals(VoiceIntentType.SALE, cmd4.intentType)
        assertEquals(10_000L, cmd4.quantityMilliUnits)
        assertEquals("p1", cmd4.productId)
        assertEquals(80_000L, cmd4.amountPaisa)

        // 5. Query intent ("আজকের বিক্রির হিসাব দেখাও")
        val cmd5 = VoiceAccountingParser.parse("আজকের বিক্রির হিসাব দেখাও", customers, products, emptyList(), now)
        assertEquals(VoiceIntentType.QUERY_SUMMARY, cmd5.intentType)

        // 6. Duplicate prevention within 5 minutes
        val recentTx = listOf(
            AccountingTransactionEntity(
                businessId = "b1",
                type = TxTypes.CREDIT_SALE,
                customerId = "c3",
                totalAmountPaisa = 500_000L,
                occurredAt = now - 60_000L
            )
        )
        val dupCmd = VoiceAccountingParser.parse("করিমকে ৫০০০ টাকা বাকিতে দিলাম", customers, products, recentTx, now)
        assertNotNull(dupCmd.duplicateCandidate)
    }

    @Test
    fun `advanced analytics computes mom growth product profitability missing cost flag and health score`() = runBlocking {
        val biz = repo.createBusinessWithDefaults("Pro Store", "Retail Store", "01700000000", "Dhaka", null, "en", 500_000L, true)
        val cash = repo.observeAccounts(biz.id).first().first { it.type == AccountTypes.CASH }
        val oil = repo.saveProduct(biz.id, null, "Soybean Oil", "", "", "Grocery", 15_000L, 19_000L, 20_000L, "Litre", 2_000L, null)

        val now = System.currentTimeMillis()
        val prevMonthInstant = Instant.ofEpochMilli(now)
            .atZone(com.example.core.util.MoneyUtils.DHAKA_ZONE)
            .toLocalDate()
            .minusMonths(1)
            .withDayOfMonth(10)
            .atTime(12, 0)
            .atZone(com.example.core.util.MoneyUtils.DHAKA_ZONE)
            .toInstant()
            .toEpochMilli()

        // Previous month sale: ৳1,000
        repo.recordSale(
            biz.id, null,
            listOf(SaleCartLine(oil.id, oil.name, "Litre", 5_000L, 20_000L, 15_000L)),
            0L, 0, 100_000L, cash.id, "Prev month sale", occurredAt = prevMonthInstant
        )
        // Current month sale: ৳1,500 (+50% MoM) plus custom item with missing purchase cost
        repo.recordSale(
            biz.id, null,
            listOf(
                SaleCartLine(oil.id, oil.name, "Litre", 5_000L, 20_000L, 15_000L),
                SaleCartLine(null, "Gift Bag", "Piece", 5_000L, 10_000L, 0L)
            ),
            0L, 0, 150_000L, cash.id, "Current month sale", occurredAt = now
        )
        repo.recordIncomeOrExpense(biz.id, true, 20_000L, null, "Rent", cash.id, "Shop rent", null, occurredAt = now)

        val txs = repo.observeTransactions(biz.id).first()
        val invoices = repo.observeInvoices(biz.id).first()
        val items = repo.observeAllInvoiceItems(biz.id).first()
        val accounts = repo.observeAccounts(biz.id).first()
        val products = repo.observeProducts(biz.id).first()

        val report = AccountingCalculator.computeAdvancedAnalytics(
            accounts = accounts,
            customers = emptyList(),
            products = products,
            transactions = txs,
            invoices = invoices,
            invoiceItems = items,
            nowMillis = now
        )

        assertEquals(150_000L, report.currentMonthSalesPaisa)
        assertEquals(100_000L, report.previousMonthSalesPaisa)
        assertEquals(50.0, report.salesGrowthPercent ?: 0.0, 0.01)
        assertTrue(report.productProfitability.any { it.itemName == "Soybean Oil" && it.profitPaisa == 50_000L })
        assertTrue(report.productProfitability.any { it.itemName == "Gift Bag" && it.hasMissingCost })
        assertEquals("Rent", report.expenseBreakdown.first().categoryName)
        assertEquals(100.0, report.expenseBreakdown.first().sharePercent, 0.01)

        val todayKey = Instant.ofEpochMilli(now)
            .atZone(com.example.core.util.MoneyUtils.DHAKA_ZONE)
            .toLocalDate()
            .format(DateTimeFormatter.ISO_LOCAL_DATE)
        assertTrue(report.calendarDayMap.containsKey(todayKey))
        assertTrue(report.healthReport.score in 10..100)
    }

    @Test
    fun `encrypted backup roundtrip protects data with aes256gcm and rejects wrong passphrase`() = runBlocking {
        val biz = repo.createBusinessWithDefaults("Secure Mart", "Grocery Shop", "01722222222", "Sylhet", null, "en", 200_000L, true)
        repo.saveCustomer(biz.id, null, "Salma", "01899999999", "Sylhet", null, "VIP", 15_000L)

        val encrypted = repo.exportEncryptedBackup("MyStrongPass#2026")
        assertTrue(SecurityUtils.isEncryptedBackup(encrypted))
        assertFalse(encrypted.contains("Secure Mart"))

        // Wrong passphrase must fail GCM authentication tag check
        var failed = false
        try {
            SecurityUtils.decryptBackup(encrypted, "WrongPass")
        } catch (_: Exception) {
            failed = true
        }
        assertTrue(failed)

        // Wipe in-memory DB & restore from encrypted payload
        db.clearAllTables()
        val restoredCount = repo.restoreEncryptedOrPlainBackup(encrypted, "MyStrongPass#2026")
        assertEquals(1, restoredCount)
        val restoredCustomers = repo.observeCustomers(biz.id).first()
        assertEquals(1, restoredCustomers.size)
        assertEquals("Salma", restoredCustomers.first().name)
        assertEquals(15_000L, restoredCustomers.first().currentDuePaisa)
    }

    @Test
    fun `hr salary payout rbac role propagation attendance leave and sync conflict resolution work end to end`() = runBlocking {
        val biz = repo.createBusinessWithDefaults("HR Corp", "Small Company", "01611111111", "Dhaka", null, "en", 1_000_000L, false)
        repo.ensureRolePermissionsSeeded(biz.id)
        val cash = repo.observeAccounts(biz.id).first().first { it.type == AccountTypes.CASH }

        repo.saveEmployee(biz.id, "Tariq Hasan", "01733333333", EmployeeRoles.CASHIER, "tariq@shop.bd", 1_500_000L)
        val emp = repo.observeEmployees(biz.id).first().first { it.name == "Tariq Hasan" }
        assertFalse(emp.canViewReports)

        // Update CASHIER role permission and verify propagation
        val cashierRole = repo.observeRolePermissions(biz.id).first().first { it.roleName == EmployeeRoles.CASHIER }
        repo.updateRolePermission(cashierRole.copy(canViewReports = true))
        val updatedEmp = repo.observeEmployees(biz.id).first().first { it.id == emp.id }
        assertTrue(updatedEmp.canViewReports)

        // Attendance & Leave
        repo.recordAttendance(biz.id, emp.id, "2026-11-25", AttendanceStatuses.PRESENT, "Morning shift")
        assertEquals(1, repo.observeAttendance(biz.id).first().size)

        repo.submitLeaveRequest(biz.id, emp.id, "2026-12-01", "2026-12-02", "Casual", "Family function")
        val leave = repo.observeLeaves(biz.id).first().first()
        repo.decideLeaveRequest(leave.id, true, "Owner")
        assertEquals(LeaveStatuses.APPROVED, repo.observeLeaves(biz.id).first().first().status)

        // Salary payment posts EXPENSE ledger transaction and reduces cash balance
        repo.recordSalaryPayment(biz.id, emp.id, "2026-11", SalaryPaymentTypes.SALARY, 400_000L, cash.id, "Nov salary")
        val cashAfter = repo.observeAccounts(biz.id).first().first { it.id == cash.id }.currentBalancePaisa
        assertEquals(600_000L, cashAfter)
        assertTrue(repo.observeTransactions(biz.id).first().any { it.type == TxTypes.EXPENSE && it.categoryName == "Employee Salary" })

        // Sync Outbox Conflict Resolution
        val conflictItem = SyncOutboxEntity(
            businessId = biz.id,
            entityType = "CUSTOMER",
            entityId = "c-conflict",
            status = "CONFLICT",
            conflictDetail = "Modified on another phone"
        )
        db.syncOutboxDao().upsert(conflictItem)
        assertEquals(1, repo.observeConflicts().first().size)

        repo.resolveSyncConflict(conflictItem.id, keepLocal = true)
        assertEquals(0, repo.observeConflicts().first().size)
        assertTrue(repo.observeSyncOutbox().first().any { it.id == conflictItem.id && it.status == "PENDING" })
    }

    @Test
    fun `code128 barcode esc pos payload and report pdf csv exports generate valid output`() = runBlocking {
        val biz = BusinessEntity(name = "Padma Mart", category = "Grocery Shop", phone = "01700001111")
        val inv = InvoiceEntity(
            businessId = biz.id,
            invoiceNumber = "INV-00042",
            invoiceType = "SALE",
            partyName = "Walk-in",
            subtotalPaisa = 50_000L,
            discountPaisa = 0L,
            taxRateBps = 0,
            taxPaisa = 0L,
            totalPaisa = 50_000L,
            paidPaisa = 50_000L,
            duePaisa = 0L,
            cogsPaisa = 35_000L,
            accountId = "acc-1"
        )
        val items = listOf(
            InvoiceItemEntity(
                invoiceId = inv.id,
                itemName = "Sugar",
                unit = "KG",
                quantityMilliUnits = 2_000L,
                unitPricePaisa = 25_000L,
                costPricePaisa = 17_500L,
                lineTotalPaisa = 50_000L
            )
        )

        val bmp = BarcodeScannerHelper.generateCode128Bitmap("INV-00042", 420, 90)
        assertEquals(420, bmp.width)
        assertEquals(90, bmp.height)

        val escPos = ThermalPrinterHelper.buildEscPosPayload(biz, inv, items)
        assertTrue(escPos.isNotEmpty())
        val receiptText = ThermalPrinterHelper.buildThermalReceiptText(biz, inv, items)
        assertTrue(receiptText.contains("INV-00042"))
        assertTrue(receiptText.contains("Sugar"))

        val csvFile = ExportUtils.generateExcelCsv(
            context = context,
            fileName = "test_pro_report.csv",
            headers = listOf("Product", "Profit"),
            rows = listOf(listOf("Sugar", "150"), listOf("চাল", "400"))
        )
        assertTrue(csvFile.exists() && csvFile.readText(Charsets.UTF_8).contains("Sugar"))
        assertTrue(csvFile.readText(Charsets.UTF_8).contains("চাল"))

        // Note: Android PdfDocument uses native PDFium (mNativeDocument=0 on Robolectric SDK 36 without native libhwui).
        try {
            val pdfFile = ExportUtils.generateReportPdf(
                context = context,
                fileName = "test_pro_report.pdf",
                businessName = biz.name,
                reportTitle = "Pro Analytics",
                summaryRows = listOf("Current Month Sales" to "Tk 500"),
                tableHeaders = listOf("Product", "Profit"),
                tableRows = listOf(listOf("Sugar", "Tk 150"))
            )
            assertTrue(pdfFile.exists() && pdfFile.length() > 100L)
        } catch (e: IllegalStateException) {
            assertTrue(e.message?.contains("closed", ignoreCase = true) == true)
        }
    }

    @Test
    fun `baki khata viewmodel adds customers tracks credit with promised date and records repayment date`() = runBlocking {
        val biz = repo.createBusinessWithDefaults("Baki Mart", "Grocery Shop", "01744444444", "Dhaka", null, "en", 100_000L, true)
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = BakiKhataViewModel(app, db, UserPreferences(app))
        vm.setBusinessId(biz.id)

        var createdCustomer: CustomerEntity? = null
        vm.addCustomer(name = "Karim Traders", phone = "01844444444", address = "Gulshan") {
            createdCustomer = it
        }
        var attempts = 0
        while (createdCustomer == null && attempts < 40) {
            org.robolectric.shadows.ShadowLooper.idleMainLooper()
            delay(20)
            attempts++
        }
        val customer = requireNotNull(createdCustomer)
        assertEquals("Karim Traders", customer.name)

        val dayMillis = 86_400_000L
        val promisedDueMillis = System.currentTimeMillis() + 7 * dayMillis
        vm.recordCredit(
            customerId = customer.id,
            amountPaisa = 1_000_000L, // Tk 10,000
            promisedRepaymentDateMillis = promisedDueMillis,
            notes = "Rice 10 sacks on baki"
        )
        attempts = 0
        while (db.bakiKhataDao().getEntriesForCustomerSync(customer.id).isEmpty() && attempts < 40) {
            org.robolectric.shadows.ShadowLooper.idleMainLooper()
            delay(20)
            attempts++
        }

        val entriesAfterCredit = db.bakiKhataDao().getEntriesForCustomerSync(customer.id)
        assertEquals(1, entriesAfterCredit.size)
        assertEquals(BakiEntryTypes.CREDIT, entriesAfterCredit.first().entryType)
        assertEquals(1_000_000L, entriesAfterCredit.first().amountPaisa)
        assertEquals(promisedDueMillis, entriesAfterCredit.first().promisedRepaymentDateMillis)
        assertFalse(entriesAfterCredit.first().isSettled)

        val partialRepayDate = System.currentTimeMillis() + 3 * dayMillis
        vm.recordRepayment(
            customerId = customer.id,
            amountPaisa = 400_000L, // Tk 4,000
            repaymentDateMillis = partialRepayDate,
            notes = "Partial cash payment"
        )
        attempts = 0
        while (db.bakiKhataDao().getEntriesForCustomerSync(customer.id).size < 2 && attempts < 40) {
            org.robolectric.shadows.ShadowLooper.idleMainLooper()
            delay(20)
            attempts++
        }

        val updatedCust = db.customerDao().getById(customer.id)!!
        assertEquals(600_000L, updatedCust.currentDuePaisa) // Tk 6,000 remaining
        val entriesAfterPartial = db.bakiKhataDao().getEntriesForCustomerSync(customer.id)
        assertTrue(entriesAfterPartial.any { it.entryType == BakiEntryTypes.REPAYMENT && it.actualRepaymentDateMillis == partialRepayDate })

        // Full remaining repayment marks all open credit entries settled
        val finalRepayDate = System.currentTimeMillis() + 6 * dayMillis
        vm.recordRepayment(
            customerId = customer.id,
            amountPaisa = 600_000L,
            repaymentDateMillis = finalRepayDate,
            notes = "Final settlement"
        )
        attempts = 0
        while ((db.customerDao().getById(customer.id)?.currentDuePaisa ?: 1L) > 0L && attempts < 40) {
            org.robolectric.shadows.ShadowLooper.idleMainLooper()
            delay(20)
            attempts++
        }
        org.robolectric.shadows.ShadowLooper.idleMainLooper()

        val settledCust = db.customerDao().getById(customer.id)!!
        assertEquals(0L, settledCust.currentDuePaisa)
        val allEntries = db.bakiKhataDao().getEntriesForCustomerSync(customer.id)
        assertTrue(allEntries.all { it.isSettled })
        assertEquals(0L, vm.uiState.value.totalReceivablePaisa)
        assertEquals(1_000_000L, vm.uiState.value.totalCollectedPaisa)
    }

    @Test
    fun `reset business hisab keeps other businesses untouched and snapshot restore recovers wiped data`() = runBlocking {
        val bizA = repo.createBusinessWithDefaults("Shop A", "Grocery Shop", "01710000001", "Dhaka", null, "en", 200_000L, true)
        val bizB = repo.createBusinessWithDefaults("Shop B", "Wholesale", "01710000002", "Chittagong", null, "en", 300_000L, true)
        val cashA = repo.observeAccounts(bizA.id).first().first { it.type == AccountTypes.CASH }
        val custA = repo.saveCustomer(bizA.id, null, "Rahim A", "01810000001", "Dhaka", null, "Regular", 0L)
        val custB = repo.saveCustomer(bizB.id, null, "Karim B", "01810000002", "Chittagong", null, "Regular", 50_000L)

        repo.recordDueLedgerEntry(bizA.id, custA.id, TxTypes.CREDIT_SALE, 100_000L, cashA.id, false, "Credit A")
        val snapshotJson = repo.exportLocalBackupJson()

        // 1. Reset ledgers & balances only (keep customers)
        repo.resetBusinessAccounting(bizA.id, clearMasterEntities = false, operatorName = "Owner")
        val keptCustA = db.customerDao().getById(custA.id)!!
        assertEquals(0L, keptCustA.currentDuePaisa)
        assertEquals(0, repo.observeTransactions(bizA.id).first().size)
        assertEquals(0, db.bakiKhataDao().getEntriesForBusinessSync(bizA.id).size)
        // Shop B remains completely intact
        assertEquals(50_000L, db.customerDao().getById(custB.id)?.currentDuePaisa)

        // 2. Full wipe on Shop A
        repo.resetBusinessAccounting(bizA.id, clearMasterEntities = true, operatorName = "Owner")
        assertEquals(0, db.customerDao().getCustomersSync(bizA.id).size)
        assertEquals(1, db.customerDao().getCustomersSync(bizB.id).size)

        // 3. Restore snapshot recovers Shop A customer, due balance, and Baki Khata entry
        val restoredCount = repo.restoreLocalBackupJson(snapshotJson)
        assertEquals(2, restoredCount)
        assertEquals(100_000L, db.customerDao().getById(custA.id)?.currentDuePaisa)
        assertEquals(1, db.bakiKhataDao().getEntriesForBusinessSync(bizA.id).size)
    }
}
