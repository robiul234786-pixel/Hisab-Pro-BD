package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.local.AccountEntity
import com.example.data.local.AccountingTransactionEntity
import com.example.data.local.BusinessEntity
import com.example.data.local.CustomerEntity
import com.example.data.local.HisabDatabase
import com.example.data.local.ProductEntity
import com.example.data.local.SupplierEntity
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

data class CloudSyncSummary(
    val businessesSynced: Int,
    val recordsSynced: Int,
    val syncedAtMillis: Long
)

class CloudSyncRepository(
    private val db: FirebaseFirestore,
    private val localDb: HisabDatabase,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context, localDb: HisabDatabase) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        localDb = localDb
    )

    private fun requireUserId(): String {
        val uid = auth.currentUser?.uid
        check(!uid.isNullOrBlank()) { "User must be signed in with Google before accessing Firestore." }
        return uid
    }

    private fun sanitizeFirestoreId(raw: String): String {
        return raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(128).ifBlank { "doc_0" }
    }

    suspend fun syncLocalToCloud(currentUserId: String): Result<CloudSyncSummary> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != currentUserId) {
            return Result.failure(IllegalStateException("Signed-in user changed; aborting sync."))
        }

        val now = System.currentTimeMillis()
        val userDocRef = db.collection("users").document(uid)
        val businesses = localDb.businessDao().getAllBusinessesSync()

        return try {
            val profileSnap = userDocRef.get().await()
            val displayName = (auth.currentUser?.displayName ?: auth.currentUser?.email ?: "Hisab User")
                .take(100)
                .ifBlank { "Hisab User" }
            val email = auth.currentUser?.email?.take(160)

            if (!profileSnap.exists()) {
                val createProfile = mutableMapOf<String, Any>(
                    "userId" to uid,
                    "displayName" to displayName,
                    "businessCount" to businesses.size.toLong(),
                    "lastSyncAtMillis" to now,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!email.isNullOrBlank()) createProfile["email"] = email
                userDocRef.set(createProfile).await()
            } else {
                val updateProfile = mutableMapOf<String, Any>(
                    "displayName" to displayName,
                    "businessCount" to businesses.size.toLong(),
                    "lastSyncAtMillis" to now,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!email.isNullOrBlank()) updateProfile["email"] = email
                userDocRef.update(updateProfile).await()
            }

            var totalRecords = 0
            for (biz in businesses) {
                val bizDocId = sanitizeFirestoreId(biz.id)
                val bizRef = userDocRef.collection("businesses").document(bizDocId)
                val cloudBiz = CloudBusiness(
                    userId = uid,
                    name = biz.name,
                    category = biz.category,
                    phone = biz.phone.ifBlank { null },
                    address = biz.address.ifBlank { null },
                    languageCode = biz.languageCode,
                    openingCashPaisa = biz.openingCashPaisa,
                    inventoryEnabled = biz.inventoryEnabled,
                    taxEnabled = biz.taxEnabled,
                    defaultTaxRateBps = biz.defaultTaxRateBps.toLong(),
                    archived = biz.archived
                )
                val existingBiz = bizRef.get().await()
                if (!existingBiz.exists()) {
                    bizRef.set(cloudBiz.toCreateMap(uid)).await()
                } else {
                    bizRef.update(cloudBiz.toUpdateMap()).await()
                }

                val records = buildLedgerRecordsForBusiness(uid, bizDocId, biz.id)
                for (rec in records) {
                    val recId = sanitizeFirestoreId(rec.first)
                    val recRef = userDocRef.collection("ledger_records").document(recId)
                    val existingRec = recRef.get().await()
                    if (!existingRec.exists()) {
                        recRef.set(rec.second.toCreateMap(uid)).await()
                    } else {
                        recRef.update(rec.second.toUpdateMap()).await()
                    }
                    totalRecords++
                }
            }

            Result.success(
                CloudSyncSummary(
                    businessesSynced = businesses.size,
                    recordsSynced = totalRecords,
                    syncedAtMillis = now
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/$uid")
            Result.failure(e)
        }
    }

    suspend fun restoreCloudToLocal(currentUserId: String): Result<CloudSyncSummary> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != currentUserId) {
            return Result.failure(IllegalStateException("Signed-in user changed; aborting restore."))
        }

        val userDocRef = db.collection("users").document(uid)
        return try {
            val bizSnap = userDocRef.collection("businesses").get().await()
            val businesses = bizSnap.toObjects(
                CloudBusiness::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            val recSnap = userDocRef.collection("ledger_records").get().await()
            val records = recSnap.toObjects(
                CloudLedgerRecord::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )

            businesses.forEach { cb ->
                val localBiz = BusinessEntity(
                    id = cb.id,
                    name = cb.name,
                    category = cb.category,
                    phone = cb.phone ?: "",
                    address = cb.address ?: "",
                    languageCode = cb.languageCode,
                    openingCashPaisa = cb.openingCashPaisa,
                    inventoryEnabled = cb.inventoryEnabled,
                    taxEnabled = cb.taxEnabled,
                    defaultTaxRateBps = cb.defaultTaxRateBps.toInt(),
                    archived = cb.archived,
                    createdAt = cb.createdAt?.toDate()?.time ?: System.currentTimeMillis(),
                    updatedAt = cb.updatedAt?.toDate()?.time ?: System.currentTimeMillis()
                )
                localDb.businessDao().upsert(localBiz)
            }

            records.forEach { rec ->
                when (rec.entityType) {
                    "ACCOUNT" -> {
                        val existing = localDb.accountDao().getById(rec.id)
                        if (existing == null) {
                            localDb.accountDao().upsert(
                                AccountEntity(
                                    id = rec.id,
                                    businessId = rec.businessId,
                                    name = rec.title,
                                    type = rec.status,
                                    accountNumber = rec.subtitle ?: "",
                                    openingBalancePaisa = rec.amountPaisa,
                                    currentBalancePaisa = rec.balancePaisa,
                                    isDefault = rec.status == "CASH",
                                    archived = rec.archived,
                                    createdAt = rec.occurredAtMillis
                                )
                            )
                        }
                    }
                    "CUSTOMER" -> {
                        localDb.customerDao().upsert(
                            CustomerEntity(
                                id = rec.id,
                                businessId = rec.businessId,
                                customerCode = rec.status,
                                name = rec.title,
                                phone = rec.phone ?: "",
                                address = rec.notes ?: "",
                                category = rec.category ?: "Regular",
                                currentDuePaisa = rec.balancePaisa,
                                totalPurchasesPaisa = rec.amountPaisa,
                                archived = rec.archived,
                                createdAt = rec.occurredAtMillis
                            )
                        )
                    }
                    "SUPPLIER" -> {
                        localDb.supplierDao().upsert(
                            SupplierEntity(
                                id = rec.id,
                                businessId = rec.businessId,
                                supplierCode = rec.status,
                                name = rec.title,
                                phone = rec.phone ?: "",
                                address = rec.notes ?: "",
                                currentPayablePaisa = rec.balancePaisa,
                                totalPurchasesPaisa = rec.amountPaisa,
                                archived = rec.archived,
                                createdAt = rec.occurredAtMillis
                            )
                        )
                    }
                    "PRODUCT" -> {
                        localDb.productDao().upsert(
                            ProductEntity(
                                id = rec.id,
                                businessId = rec.businessId,
                                name = rec.title,
                                sku = rec.subtitle ?: "",
                                category = rec.category ?: "General",
                                sellingPricePaisa = rec.amountPaisa,
                                stockMilliUnits = rec.balancePaisa,
                                unit = rec.status,
                                archived = rec.archived,
                                createdAt = rec.occurredAtMillis
                            )
                        )
                    }
                }
            }

            Result.success(
                CloudSyncSummary(
                    businessesSynced = businesses.size,
                    recordsSynced = records.size,
                    syncedAtMillis = System.currentTimeMillis()
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "users/$uid/businesses")
            Result.failure(e)
        }
    }

    private suspend fun buildLedgerRecordsForBusiness(
        uid: String,
        bizDocId: String,
        localBizId: String
    ): List<Pair<String, CloudLedgerRecord>> {
        val out = mutableListOf<Pair<String, CloudLedgerRecord>>()

        localDb.accountDao().getAccountsSync(localBizId).forEach { acc ->
            out.add(
                acc.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "ACCOUNT",
                    title = acc.name,
                    subtitle = acc.accountNumber.ifBlank { null },
                    amountPaisa = acc.openingBalancePaisa,
                    balancePaisa = acc.currentBalancePaisa,
                    status = acc.type,
                    occurredAtMillis = acc.createdAt,
                    archived = acc.archived
                )
            )
        }

        localDb.customerDao().getCustomersSync(localBizId).forEach { cust ->
            out.add(
                cust.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "CUSTOMER",
                    title = cust.name,
                    subtitle = cust.category,
                    amountPaisa = cust.totalPurchasesPaisa,
                    balancePaisa = cust.currentDuePaisa,
                    status = cust.customerCode,
                    category = cust.category,
                    phone = cust.phone.ifBlank { null },
                    notes = cust.address.ifBlank { null },
                    occurredAtMillis = cust.createdAt,
                    archived = cust.archived
                )
            )
        }

        localDb.supplierDao().getSuppliersSync(localBizId).forEach { sup ->
            out.add(
                sup.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "SUPPLIER",
                    title = sup.name,
                    amountPaisa = sup.totalPurchasesPaisa,
                    balancePaisa = sup.currentPayablePaisa,
                    status = sup.supplierCode,
                    phone = sup.phone.ifBlank { null },
                    notes = sup.address.ifBlank { null },
                    occurredAtMillis = sup.createdAt,
                    archived = sup.archived
                )
            )
        }

        localDb.productDao().getProductsSync(localBizId).forEach { prod ->
            out.add(
                prod.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "PRODUCT",
                    title = prod.name,
                    subtitle = prod.sku.ifBlank { null },
                    amountPaisa = prod.sellingPricePaisa,
                    balancePaisa = prod.stockMilliUnits,
                    status = prod.unit,
                    category = prod.category,
                    occurredAtMillis = prod.createdAt,
                    archived = prod.archived
                )
            )
        }

        localDb.transactionDao().getTransactionsSync(localBizId).take(150).forEach { tx: AccountingTransactionEntity ->
            out.add(
                tx.id to CloudLedgerRecord(
                    userId = uid,
                    businessId = bizDocId,
                    entityType = "TRANSACTION",
                    title = tx.partyName.ifBlank { tx.categoryName.ifBlank { tx.type } },
                    subtitle = tx.accountName.ifBlank { null },
                    amountPaisa = tx.totalAmountPaisa,
                    balancePaisa = tx.paidAmountPaisa,
                    status = tx.type,
                    category = tx.categoryName.ifBlank { null },
                    notes = tx.notes.ifBlank { null },
                    occurredAtMillis = tx.occurredAt,
                    archived = tx.isReversed
                )
            )
        }

        return out
    }
}
