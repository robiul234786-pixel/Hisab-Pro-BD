package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.*
import com.example.data.repository.AccountingRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class BakiKhataUiState(
    val activeBusinessId: String = "",
    val customers: List<CustomerEntity> = emptyList(),
    val filteredCustomers: List<CustomerEntity> = emptyList(),
    val selectedCustomerId: String? = null,
    val entries: List<BakiKhataEntryEntity> = emptyList(),
    val selectedCustomerEntries: List<BakiKhataEntryEntity> = emptyList(),
    val upcomingOrOverdueEntries: List<BakiKhataEntryEntity> = emptyList(),
    val accounts: List<AccountEntity> = emptyList(),
    val searchQuery: String = "",
    val totalReceivablePaisa: Long = 0L,
    val totalCollectedPaisa: Long = 0L,
    val overdueCount: Int = 0,
    val isLoading: Boolean = false,
    val statusMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class BakiKhataViewModel(
    application: Application,
    private val db: HisabDatabase,
    private val prefs: UserPreferences
) : AndroidViewModel(application) {

    constructor(application: Application) : this(
        application = application,
        db = HisabDatabase.getInstance(application),
        prefs = UserPreferences(application)
    )

    val repo = AccountingRepository(db)

    private val _explicitBusinessId = MutableStateFlow<String?>(null)
    private val _selectedCustomerId = MutableStateFlow<String?>(null)
    private val _searchQuery = MutableStateFlow("")
    private val _isLoading = MutableStateFlow(false)
    private val _statusMessage = MutableStateFlow<String?>(null)

    private val activeBusinessIdFlow: Flow<String> = combine(
        _explicitBusinessId,
        prefs.settingsFlow,
        repo.observeBusinesses()
    ) { explicitId, settings, businesses ->
        explicitId?.takeIf { it.isNotBlank() }
            ?: businesses.firstOrNull { it.id == settings.activeBusinessId }?.id
            ?: businesses.firstOrNull()?.id.orEmpty()
    }.distinctUntilChanged()

    private val businessDataFlow: Flow<BakiBusinessBundle> = activeBusinessIdFlow.flatMapLatest { bizId ->
        if (bizId.isBlank()) {
            flowOf(BakiBusinessBundle())
        } else {
            combine(
                repo.observeCustomers(bizId),
                repo.observeBakiEntries(bizId),
                repo.observeUpcomingBakiDues(bizId),
                repo.observeAccounts(bizId)
            ) { customers, entries, upcoming, accounts ->
                BakiBusinessBundle(
                    businessId = bizId,
                    customers = customers,
                    entries = entries,
                    upcomingOrOverdue = upcoming,
                    accounts = accounts
                )
            }
        }
    }

    val uiState: StateFlow<BakiKhataUiState> = combine(
        businessDataFlow,
        _selectedCustomerId,
        _searchQuery,
        _isLoading,
        _statusMessage
    ) { data, selectedCustId, query, loading, message ->
        val cleanQuery = query.trim()
        val filteredCustomers = if (cleanQuery.isBlank()) {
            data.customers
        } else {
            data.customers.filter { c ->
                c.name.contains(cleanQuery, ignoreCase = true) ||
                    c.phone.contains(cleanQuery, ignoreCase = true) ||
                    c.customerCode.contains(cleanQuery, ignoreCase = true)
            }
        }
        val selectedEntries = if (selectedCustId.isNullOrBlank()) {
            data.entries
        } else {
            data.entries.filter { it.customerId == selectedCustId }
        }
        val now = System.currentTimeMillis()
        val overdueCount = data.upcomingOrOverdue.count { entry ->
            !entry.isSettled && (entry.promisedRepaymentDateMillis ?: Long.MAX_VALUE) < now
        }
        val totalReceivable = data.customers.sumOf { it.currentDuePaisa.coerceAtLeast(0L) }
        val totalCollected = data.entries
            .filter { it.entryType == BakiEntryTypes.REPAYMENT }
            .sumOf { it.amountPaisa }

        BakiKhataUiState(
            activeBusinessId = data.businessId,
            customers = data.customers,
            filteredCustomers = filteredCustomers,
            selectedCustomerId = selectedCustId,
            entries = data.entries,
            selectedCustomerEntries = selectedEntries,
            upcomingOrOverdueEntries = data.upcomingOrOverdue,
            accounts = data.accounts,
            searchQuery = query,
            totalReceivablePaisa = totalReceivable,
            totalCollectedPaisa = totalCollected,
            overdueCount = overdueCount,
            isLoading = loading,
            statusMessage = message
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, BakiKhataUiState())

    fun setBusinessId(businessId: String) {
        _explicitBusinessId.value = businessId
    }

    private suspend fun resolveBusinessId(): String {
        val current = uiState.value.activeBusinessId.ifBlank { _explicitBusinessId.value.orEmpty() }
        if (current.isNotBlank()) return current
        return db.businessDao().getAllBusinessesSync().firstOrNull()?.id.orEmpty()
    }

    fun selectCustomer(customerId: String?) {
        _selectedCustomerId.value = customerId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun addCustomer(
        name: String,
        phone: String,
        address: String = "",
        category: String = "Regular",
        openingDuePaisa: Long = 0L,
        onCreated: (CustomerEntity) -> Unit = {}
    ) {
        val cleanName = name.trim()
        if (cleanName.isBlank()) {
            _statusMessage.value = "Customer name is required"
            return
        }
        viewModelScope.launch {
            val bizId = resolveBusinessId()
            if (bizId.isBlank()) {
                _statusMessage.value = "No active business selected"
                return@launch
            }
            _isLoading.value = true
            try {
                val created = repo.saveCustomer(
                    businessId = bizId,
                    existingId = null,
                    name = cleanName,
                    phone = phone.trim(),
                    address = address.trim(),
                    photoUri = null,
                    category = category,
                    openingDuePaisa = openingDuePaisa.coerceAtLeast(0L)
                )
                _statusMessage.value = "Customer ${created.name} added"
                onCreated(created)
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Failed to add customer"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun recordCredit(
        customerId: String,
        amountPaisa: Long,
        promisedRepaymentDateMillis: Long? = null,
        accountId: String? = null,
        entryDateMillis: Long = System.currentTimeMillis(),
        notes: String = "",
        isCashAdvance: Boolean = false
    ) {
        if (amountPaisa <= 0L) {
            _statusMessage.value = "Credit amount must be greater than zero"
            return
        }
        viewModelScope.launch {
            val bizId = resolveBusinessId()
            val accId = accountId?.takeIf { it.isNotBlank() }
                ?: uiState.value.accounts.firstOrNull()?.id
                ?: db.accountDao().getAccountsSync(bizId).firstOrNull()?.id.orEmpty()
            if (bizId.isBlank() || accId.isBlank()) {
                _statusMessage.value = "Business or account not initialized"
                return@launch
            }
            _isLoading.value = true
            try {
                val txType = if (isCashAdvance) TxTypes.CUSTOMER_CREDIT_ADVANCE else TxTypes.CREDIT_SALE
                repo.recordDueLedgerEntry(
                    businessId = bizId,
                    customerId = customerId,
                    type = txType,
                    amountPaisa = amountPaisa,
                    accountId = accId,
                    affectAccountBalance = isCashAdvance,
                    notes = notes,
                    occurredAt = entryDateMillis,
                    dueDateMillis = promisedRepaymentDateMillis
                )
                _statusMessage.value = "Credit entry recorded"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Could not record credit"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun recordRepayment(
        customerId: String,
        amountPaisa: Long,
        repaymentDateMillis: Long = System.currentTimeMillis(),
        accountId: String? = null,
        notes: String = "",
        settledEntryId: String? = null
    ) {
        if (amountPaisa <= 0L) {
            _statusMessage.value = "Repayment amount must be greater than zero"
            return
        }
        viewModelScope.launch {
            val bizId = resolveBusinessId()
            val accId = accountId?.takeIf { it.isNotBlank() }
                ?: uiState.value.accounts.firstOrNull()?.id
                ?: db.accountDao().getAccountsSync(bizId).firstOrNull()?.id.orEmpty()
            if (bizId.isBlank() || accId.isBlank()) {
                _statusMessage.value = "Business or account not initialized"
                return@launch
            }
            _isLoading.value = true
            try {
                repo.recordDueLedgerEntry(
                    businessId = bizId,
                    customerId = customerId,
                    type = TxTypes.CUSTOMER_PAYMENT,
                    amountPaisa = amountPaisa,
                    accountId = accId,
                    affectAccountBalance = true,
                    notes = notes,
                    occurredAt = repaymentDateMillis,
                    dueDateMillis = null
                )
                if (!settledEntryId.isNullOrBlank()) {
                    repo.markBakiEntryRepaid(settledEntryId, repaymentDateMillis)
                }
                _statusMessage.value = "Repayment recorded"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Could not record repayment"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun markEntrySettled(
        entryId: String,
        repaymentDateMillis: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            try {
                repo.markBakiEntryRepaid(entryId, repaymentDateMillis)
                _statusMessage.value = "Repayment date recorded"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Failed to update entry"
            }
        }
    }

    private data class BakiBusinessBundle(
        val businessId: String = "",
        val customers: List<CustomerEntity> = emptyList(),
        val entries: List<BakiKhataEntryEntity> = emptyList(),
        val upcomingOrOverdue: List<BakiKhataEntryEntity> = emptyList(),
        val accounts: List<AccountEntity> = emptyList()
    )
}
