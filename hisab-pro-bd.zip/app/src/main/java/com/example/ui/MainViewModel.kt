package com.example.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.core.util.ParsedVoiceCommand
import com.example.core.util.SecurityUtils
import com.example.core.util.VoiceAccountingParser
import com.example.core.util.VoiceIntentType
import com.example.data.local.*
import com.example.data.remote.AiBusinessAssistant
import com.example.data.remote.AiChatMessage
import com.example.data.remote.AiUiState
import com.example.data.remote.CloudSyncRepository
import com.example.data.remote.CloudSyncSummary
import com.example.data.remote.GitHubReleaseUpdater
import com.example.data.remote.UpdateUiState
import com.example.data.repository.AccountingCalculator
import com.example.data.repository.AccountingRepository
import com.example.data.repository.AdvancedAnalyticsReport
import com.example.data.repository.DashboardMetrics
import com.example.data.repository.MonthlyChartPoint
import com.example.data.repository.SaleCartLine
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

data class BusinessWorkspaceState(
    val settings: AppSettingsState = AppSettingsState(),
    val businesses: List<BusinessEntity> = emptyList(),
    val activeBusiness: BusinessEntity? = null,
    val accounts: List<AccountEntity> = emptyList(),
    val customers: List<CustomerEntity> = emptyList(),
    val archivedCustomers: List<CustomerEntity> = emptyList(),
    val suppliers: List<SupplierEntity> = emptyList(),
    val products: List<ProductEntity> = emptyList(),
    val stockMovements: List<StockMovementEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val transactions: List<AccountingTransactionEntity> = emptyList(),
    val invoices: List<InvoiceEntity> = emptyList(),
    val allInvoiceItems: List<InvoiceItemEntity> = emptyList(),
    val employees: List<EmployeeEntity> = emptyList(),
    val activeEmployee: EmployeeEntity? = null,
    val notifications: List<AppNotificationEntity> = emptyList(),
    val unreadNotifications: Int = 0,
    val dashboard: DashboardMetrics = DashboardMetrics(),
    val monthlyChart: List<MonthlyChartPoint> = emptyList(),
    val advancedAnalytics: AdvancedAnalyticsReport = AdvancedAnalyticsReport(),
    val attendance: List<AttendanceEntity> = emptyList(),
    val leaves: List<LeaveRequestEntity> = emptyList(),
    val salaryPayments: List<SalaryPaymentEntity> = emptyList(),
    val activityLogs: List<ActivityLogEntity> = emptyList(),
    val rolePermissions: List<RolePermissionEntity> = emptyList(),
    val syncOutbox: List<SyncOutboxEntity> = emptyList(),
    val conflicts: List<SyncOutboxEntity> = emptyList(),
    val pendingSyncCount: Int = 0,
    val authorizedDevices: List<AuthorizedDeviceEntity> = emptyList(),
    val deviceId: String = ""
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = HisabDatabase.getInstance(application)
    val repo = AccountingRepository(db)
    val prefs = UserPreferences(application)
    val cloudSyncRepo = CloudSyncRepository(application, db)

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _updateState = MutableStateFlow<UpdateUiState>(UpdateUiState.Idle)
    val updateState: StateFlow<UpdateUiState> = _updateState.asStateFlow()

    private val _deviceId = MutableStateFlow("")
    val deviceId: StateFlow<String> = _deviceId.asStateFlow()

    private val _aiUiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val aiUiState: StateFlow<AiUiState> = _aiUiState.asStateFlow()

    private val _aiMessages = MutableStateFlow<List<AiChatMessage>>(emptyList())
    val aiMessages: StateFlow<List<AiChatMessage>> = _aiMessages.asStateFlow()

    private val _pendingEncryptedRestoreUri = MutableStateFlow<Uri?>(null)
    val pendingEncryptedRestoreUri: StateFlow<Uri?> = _pendingEncryptedRestoreUri.asStateFlow()

    private var lockCheckedOnLaunch = false
    private var aiStreamJob: Job? = null
    private var connectivityCallback: ConnectivityManager.NetworkCallback? = null

    val settingsState: StateFlow<AppSettingsState> = prefs.settingsFlow
        .onEach { settings ->
            if (!lockCheckedOnLaunch && settings.onboardingCompleted && settings.hasPin) {
                _isLocked.value = true
                lockCheckedOnLaunch = true
            } else if (!lockCheckedOnLaunch && settings.onboardingCompleted) {
                lockCheckedOnLaunch = true
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettingsState())

    private val activeBusinessIdFlow: Flow<String> = combine(
        prefs.settingsFlow,
        repo.observeBusinesses()
    ) { settings, businesses ->
        val valid = businesses.firstOrNull { it.id == settings.activeBusinessId }
        valid?.id ?: businesses.firstOrNull()?.id.orEmpty()
    }.distinctUntilChanged()

    private val coreBundleFlow: Flow<CoreBusinessBundle> = activeBusinessIdFlow.flatMapLatest { bizId ->
        if (bizId.isBlank()) {
            flowOf(EmptyCoreBundle)
        } else {
            combine(
                repo.observeAccounts(bizId),
                repo.observeCustomers(bizId),
                repo.observeArchivedCustomers(bizId),
                repo.observeSuppliers(bizId),
                repo.observeProducts(bizId),
                repo.observeStockMovements(bizId),
                repo.observeCategories(bizId),
                repo.observeTransactions(bizId),
                repo.observeInvoices(bizId),
                repo.observeAllInvoiceItems(bizId),
                repo.observeEmployees(bizId),
                repo.observeNotifications(bizId),
                repo.observeUnreadNotificationCount(bizId)
            ) { arr ->
                @Suppress("UNCHECKED_CAST")
                CoreBusinessBundle(
                    accounts = arr[0] as List<AccountEntity>,
                    customers = arr[1] as List<CustomerEntity>,
                    archivedCustomers = arr[2] as List<CustomerEntity>,
                    suppliers = arr[3] as List<SupplierEntity>,
                    products = arr[4] as List<ProductEntity>,
                    stockMovements = arr[5] as List<StockMovementEntity>,
                    categories = arr[6] as List<CategoryEntity>,
                    transactions = arr[7] as List<AccountingTransactionEntity>,
                    invoices = arr[8] as List<InvoiceEntity>,
                    invoiceItems = arr[9] as List<InvoiceItemEntity>,
                    employees = arr[10] as List<EmployeeEntity>,
                    notifications = arr[11] as List<AppNotificationEntity>,
                    unreadCount = arr[12] as Int
                )
            }
        }
    }

    private val proBundleFlow: Flow<ProBusinessBundle> = activeBusinessIdFlow.flatMapLatest { bizId ->
        if (bizId.isBlank()) {
            flowOf(EmptyProBundle)
        } else {
            val uid = Firebase.auth.currentUser?.uid.orEmpty()
            val devicesFlow = if (uid.isNotBlank()) repo.observeAuthorizedDevices(uid) else flowOf(emptyList())
            combine(
                repo.observeAttendance(bizId),
                repo.observeLeaves(bizId),
                repo.observeSalaryPayments(bizId),
                repo.observeActivityLogs(bizId),
                repo.observeRolePermissions(bizId),
                repo.observeSyncOutbox(),
                repo.observeConflicts(),
                repo.observePendingSyncCount(),
                devicesFlow
            ) { arr ->
                @Suppress("UNCHECKED_CAST")
                ProBusinessBundle(
                    attendance = arr[0] as List<AttendanceEntity>,
                    leaves = arr[1] as List<LeaveRequestEntity>,
                    salaryPayments = arr[2] as List<SalaryPaymentEntity>,
                    activityLogs = arr[3] as List<ActivityLogEntity>,
                    rolePermissions = arr[4] as List<RolePermissionEntity>,
                    syncOutbox = arr[5] as List<SyncOutboxEntity>,
                    conflicts = arr[6] as List<SyncOutboxEntity>,
                    pendingSyncCount = arr[7] as Int,
                    authorizedDevices = arr[8] as List<AuthorizedDeviceEntity>
                )
            }
        }
    }

    val workspaceState: StateFlow<BusinessWorkspaceState> = combine(
        prefs.settingsFlow,
        repo.observeBusinesses(),
        coreBundleFlow,
        proBundleFlow,
        _deviceId
    ) { settings, businesses, core, pro, devId ->
        val activeBiz = businesses.firstOrNull { it.id == settings.activeBusinessId } ?: businesses.firstOrNull()
        val activeEmp = core.employees.firstOrNull { it.id == settings.activeEmployeeId }
            ?: core.employees.firstOrNull { it.role == EmployeeRoles.OWNER }
            ?: core.employees.firstOrNull()
        val dashboard = AccountingCalculator.computeDashboard(
            accounts = core.accounts,
            customers = core.customers,
            suppliers = core.suppliers,
            transactions = core.transactions
        )
        val chart = AccountingCalculator.computeLast6MonthsChart(core.transactions)
        val analytics = AccountingCalculator.computeAdvancedAnalytics(
            accounts = core.accounts,
            customers = core.customers,
            products = core.products,
            transactions = core.transactions,
            invoices = core.invoices,
            invoiceItems = core.invoiceItems
        )
        BusinessWorkspaceState(
            settings = settings,
            businesses = businesses,
            activeBusiness = activeBiz,
            accounts = core.accounts,
            customers = core.customers,
            archivedCustomers = core.archivedCustomers,
            suppliers = core.suppliers,
            products = core.products,
            stockMovements = core.stockMovements,
            categories = core.categories,
            transactions = core.transactions,
            invoices = core.invoices,
            allInvoiceItems = core.invoiceItems,
            employees = core.employees,
            activeEmployee = activeEmp,
            notifications = core.notifications,
            unreadNotifications = core.unreadCount,
            dashboard = dashboard,
            monthlyChart = chart,
            advancedAnalytics = analytics,
            attendance = pro.attendance,
            leaves = pro.leaves,
            salaryPayments = pro.salaryPayments,
            activityLogs = pro.activityLogs,
            rolePermissions = pro.rolePermissions,
            syncOutbox = pro.syncOutbox,
            conflicts = pro.conflicts,
            pendingSyncCount = pro.pendingSyncCount,
            authorizedDevices = pro.authorizedDevices,
            deviceId = devId
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), BusinessWorkspaceState())

    init {
        viewModelScope.launch {
            _deviceId.value = prefs.getOrCreateDeviceId()
        }
        viewModelScope.launch {
            activeBusinessIdFlow.collect { bizId ->
                if (bizId.isNotBlank()) {
                    repo.ensureRolePermissionsSeeded(bizId)
                }
            }
        }
        registerConnectivityAutoSync()
    }

    private fun registerConnectivityAutoSync() {
        try {
            val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                ?: return
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val caps = cm.getNetworkCapabilities(network) ?: return
                    if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return
                    val uid = Firebase.auth.currentUser?.uid
                    val autoEnabled = settingsState.value.autoCloudSyncEnabled
                    val pending = workspaceState.value.pendingSyncCount
                    if (!uid.isNullOrBlank() && autoEnabled && pending > 0 && !_isSyncing.value) {
                        syncToCloud(uid)
                    }
                }
            }
            connectivityCallback = callback
            cm.registerDefaultNetworkCallback(callback)
        } catch (_: Exception) {
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            connectivityCallback?.let { cm?.unregisterNetworkCallback(it) }
        } catch (_: Exception) {
        }
        aiStreamJob?.cancel()
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun unlockWithPin(pin: String): Boolean {
        val s = settingsState.value
        val ok = SecurityUtils.verifyPin(pin, s.pinSalt, s.pinHash)
        if (ok) _isLocked.value = false
        return ok
    }

    fun unlockBiometric() {
        _isLocked.value = false
    }

    fun lockNow() {
        if (settingsState.value.hasPin) {
            _isLocked.value = true
        }
    }

    fun setPin(pin: String) {
        viewModelScope.launch {
            val salt = SecurityUtils.generateSalt()
            val hash = SecurityUtils.hashPin(pin, salt)
            prefs.setPin(hash, salt)
            _statusMessage.value = "Security PIN enabled"
        }
    }

    fun removePin() {
        viewModelScope.launch {
            prefs.clearPin()
            _isLocked.value = false
            _statusMessage.value = "Security PIN removed"
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setBiometricEnabled(enabled) }
    }

    fun completeOnboarding(
        name: String,
        category: String,
        phone: String,
        address: String,
        logoUri: String?,
        languageCode: String,
        openingCashPaisa: Long,
        inventoryEnabled: Boolean,
        pin: String
    ) {
        viewModelScope.launch {
            val biz = repo.createBusinessWithDefaults(
                name = name,
                category = category,
                phone = phone,
                address = address,
                logoUri = logoUri,
                languageCode = languageCode,
                openingCashPaisa = openingCashPaisa,
                inventoryEnabled = inventoryEnabled
            )
            if (pin.length in 4..6) {
                val salt = SecurityUtils.generateSalt()
                val hash = SecurityUtils.hashPin(pin, salt)
                prefs.setPin(hash, salt)
            }
            prefs.completeOnboarding(biz.id, languageCode)
        }
    }

    fun createAdditionalBusiness(
        name: String,
        category: String,
        phone: String,
        address: String,
        logoUri: String?,
        openingCashPaisa: Long,
        inventoryEnabled: Boolean
    ) {
        viewModelScope.launch {
            val biz = repo.createBusinessWithDefaults(
                name = name,
                category = category,
                phone = phone,
                address = address,
                logoUri = logoUri,
                languageCode = settingsState.value.languageCode,
                openingCashPaisa = openingCashPaisa,
                inventoryEnabled = inventoryEnabled
            )
            prefs.setActiveBusinessId(biz.id)
            _statusMessage.value = "Switched to ${biz.name}"
        }
    }

    fun switchBusiness(businessId: String) {
        viewModelScope.launch { prefs.setActiveBusinessId(businessId) }
    }

    fun updateBusiness(business: BusinessEntity) {
        viewModelScope.launch {
            repo.updateBusiness(business)
            _statusMessage.value = "Business profile updated"
        }
    }

    fun setLanguage(code: String) {
        viewModelScope.launch { prefs.setLanguage(code) }
    }

    fun setBanglaDigits(enabled: Boolean) {
        viewModelScope.launch { prefs.setBanglaDigits(enabled) }
    }

    fun setDarkMode(mode: String) {
        viewModelScope.launch { prefs.setDarkMode(mode) }
    }

    fun setActiveEmployee(employeeId: String) {
        viewModelScope.launch { prefs.setActiveEmployeeId(employeeId) }
    }

    fun updateNotificationPrefs(due: Boolean, stock: Boolean, daily: Boolean, backup: Boolean) {
        viewModelScope.launch { prefs.updateNotificationSettings(due, stock, daily, backup) }
    }

    fun setAutoCloudSync(enabled: Boolean) {
        viewModelScope.launch { prefs.setAutoCloudSync(enabled) }
    }

    fun markNotificationsRead() {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch { repo.markNotificationsRead(bizId) }
    }

    private fun operatorName(): String =
        workspaceState.value.activeEmployee?.let { "${it.name} (${it.role})" } ?: "Owner"

    fun saveCustomer(
        existingId: String?,
        name: String,
        phone: String,
        address: String,
        photoUri: String?,
        category: String,
        openingDuePaisa: Long
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveCustomer(bizId, existingId, name, phone, address, photoUri, category, openingDuePaisa)
            _statusMessage.value = "Customer saved"
        }
    }

    fun archiveCustomer(customerId: String, archived: Boolean) {
        viewModelScope.launch { repo.setCustomerArchived(customerId, archived) }
    }

    fun saveSupplier(
        existingId: String?,
        name: String,
        phone: String,
        address: String,
        openingPayablePaisa: Long
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveSupplier(bizId, existingId, name, phone, address, openingPayablePaisa)
            _statusMessage.value = "Supplier saved"
        }
    }

    fun saveProduct(
        existingId: String?,
        name: String,
        sku: String,
        barcode: String,
        category: String,
        purchasePricePaisa: Long,
        sellingPricePaisa: Long,
        initialStockMilliUnits: Long,
        unit: String,
        lowStockThresholdMilliUnits: Long,
        imageUri: String?
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveProduct(
                bizId, existingId, name, sku, barcode, category,
                purchasePricePaisa, sellingPricePaisa, initialStockMilliUnits,
                unit, lowStockThresholdMilliUnits, imageUri, operatorName()
            )
            _statusMessage.value = "Product saved"
        }
    }

    fun adjustStock(productId: String, type: String, deltaMilliUnits: Long, notes: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.adjustStock(bizId, productId, type, deltaMilliUnits, notes, operatorName())
            _statusMessage.value = "Stock updated"
        }
    }

    fun recordSale(
        customerId: String?,
        lines: List<SaleCartLine>,
        discountPaisa: Long,
        taxRateBps: Int,
        paidPaisa: Long,
        accountId: String,
        notes: String,
        onComplete: (InvoiceEntity) -> Unit = {}
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                val inv = repo.recordSale(
                    bizId, customerId, lines, discountPaisa, taxRateBps,
                    paidPaisa, accountId, notes, createdBy = operatorName()
                )
                _statusMessage.value = "Invoice ${inv.invoiceNumber} saved"
                onComplete(inv)
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Could not save sale"
            }
        }
    }

    fun recordDueEntry(
        customerId: String,
        type: String,
        amountPaisa: Long,
        accountId: String,
        affectAccount: Boolean,
        notes: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                repo.recordDueLedgerEntry(
                    bizId, customerId, type, amountPaisa, accountId,
                    affectAccount, notes, createdBy = operatorName()
                )
                _statusMessage.value = "Due ledger updated"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Failed to update due ledger"
            }
        }
    }

    fun recordPurchase(
        supplierId: String?,
        lines: List<SaleCartLine>,
        paidPaisa: Long,
        accountId: String,
        notes: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                val inv = repo.recordPurchase(
                    bizId, supplierId, lines, paidPaisa, accountId, notes, createdBy = operatorName()
                )
                _statusMessage.value = "Purchase ${inv.invoiceNumber} recorded"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Purchase failed"
            }
        }
    }

    fun recordSupplierPayment(supplierId: String, amountPaisa: Long, accountId: String, notes: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.recordSupplierPayment(bizId, supplierId, amountPaisa, accountId, notes, createdBy = operatorName())
            _statusMessage.value = "Supplier payment recorded"
        }
    }

    fun recordIncomeOrExpense(
        isExpense: Boolean,
        amountPaisa: Long,
        categoryId: String?,
        categoryName: String,
        accountId: String,
        notes: String,
        attachmentUri: String?
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.recordIncomeOrExpense(
                bizId, isExpense, amountPaisa, categoryId, categoryName,
                accountId, notes, attachmentUri, createdBy = operatorName()
            )
            _statusMessage.value = if (isExpense) "Expense recorded" else "Income recorded"
        }
    }

    fun createCategory(name: String, type: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch { repo.createCustomCategory(bizId, name, type) }
    }

    fun saveAccount(name: String, type: String, number: String, openingBalancePaisa: Long) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveAccount(bizId, name, type, number, openingBalancePaisa)
            _statusMessage.value = "Account added"
        }
    }

    fun transferAccounts(fromId: String, toId: String, amountPaisa: Long, notes: String) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                repo.recordAccountTransfer(bizId, fromId, toId, amountPaisa, notes, createdBy = operatorName())
                _statusMessage.value = "Account transfer completed"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Transfer failed"
            }
        }
    }

    fun recordReturnOrCorrection(
        type: String,
        customerId: String?,
        supplierId: String?,
        productId: String?,
        quantityMilliUnits: Long,
        amountPaisa: Long,
        refundCash: Boolean,
        accountId: String,
        notes: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.recordReturnOrCorrection(
                bizId, type, customerId, supplierId, productId,
                quantityMilliUnits, amountPaisa, refundCash, accountId, notes, operatorName()
            )
            _statusMessage.value = "Adjustment recorded"
        }
    }

    fun reverseTransaction(txId: String, reason: String) {
        val emp = workspaceState.value.activeEmployee
        if (emp != null && !emp.canDeleteOrReverse) {
            _statusMessage.value = "Permission denied: ${emp.role} cannot reverse transactions"
            return
        }
        viewModelScope.launch {
            repo.reverseTransaction(txId, reason, operatorName())
            _statusMessage.value = "Reversal audit entry recorded"
        }
    }

    // --- Employees, HR, Attendance, Leave, Payroll & RBAC ---

    fun saveEmployee(name: String, phone: String, role: String) {
        saveEmployeeExtended(name, phone, "", role, 0L, null)
    }

    fun saveEmployeeExtended(
        name: String,
        phone: String,
        email: String,
        role: String,
        salaryPaisa: Long,
        existingId: String? = null
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.saveEmployee(bizId, name, phone, role, email, salaryPaisa, existingId)
            _statusMessage.value = if (existingId == null) "Employee added" else "Employee updated"
        }
    }

    fun removeEmployee(id: String) {
        viewModelScope.launch { repo.removeEmployee(id) }
    }

    fun updateRolePermission(permission: RolePermissionEntity) {
        viewModelScope.launch {
            repo.updateRolePermission(permission)
            _statusMessage.value = "Permissions updated for ${permission.roleName}"
        }
    }

    fun recordAttendance(employeeId: String, dateKey: String, status: String, notes: String = "") {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.recordAttendance(bizId, employeeId, dateKey, status, notes, operatorName())
            _statusMessage.value = "Attendance recorded ($status)"
        }
    }

    fun submitLeaveRequest(
        employeeId: String,
        startDateKey: String,
        endDateKey: String,
        leaveType: String,
        reason: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            repo.submitLeaveRequest(bizId, employeeId, startDateKey, endDateKey, leaveType, reason)
            _statusMessage.value = "Leave request submitted"
        }
    }

    fun decideLeaveRequest(requestId: String, approved: Boolean) {
        val emp = workspaceState.value.activeEmployee
        if (emp != null && !emp.canManageEmployees) {
            _statusMessage.value = "Only Owner/Administrator can approve leave requests"
            return
        }
        viewModelScope.launch {
            repo.decideLeaveRequest(requestId, approved, operatorName())
            _statusMessage.value = if (approved) "Leave approved" else "Leave rejected"
        }
    }

    fun recordSalaryPayment(
        employeeId: String,
        monthKey: String,
        paymentType: String,
        amountPaisa: Long,
        accountId: String,
        notes: String
    ) {
        val bizId = workspaceState.value.activeBusiness?.id ?: return
        viewModelScope.launch {
            try {
                repo.recordSalaryPayment(bizId, employeeId, monthKey, paymentType, amountPaisa, accountId, notes, operatorName())
                _statusMessage.value = "Salary payment recorded & posted to ledger"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Salary payment failed"
            }
        }
    }

    // --- AI Business Assistant (Firebase AI Logic + Live Ledger Context) ---

    fun askAiAssistant(question: String) {
        val clean = question.trim()
        if (clean.isBlank()) return
        val ws = workspaceState.value
        val biz = ws.activeBusiness ?: run {
            _aiUiState.value = AiUiState.Error("Create a business profile first.")
            return
        }

        aiStreamJob?.cancel()
        val userMsg = AiChatMessage(isUser = true, text = clean)
        val assistantMsgId = java.util.UUID.randomUUID().toString()
        val (contextBlock, dateRangeLabel) = AiBusinessAssistant.buildDatabaseContext(
            business = biz,
            accounts = ws.accounts,
            customers = ws.customers,
            suppliers = ws.suppliers,
            products = ws.products,
            transactions = ws.transactions,
            invoices = ws.invoices,
            invoiceItems = ws.allInvoiceItems
        )
        val priorHistory = _aiMessages.value
        _aiMessages.value = priorHistory + userMsg + AiChatMessage(
            id = assistantMsgId,
            isUser = false,
            text = "...",
            dateRangeLabel = dateRangeLabel
        )
        _aiUiState.value = AiUiState.Loading

        aiStreamJob = viewModelScope.launch {
            try {
                var latest = ""
                AiBusinessAssistant.streamQuery(clean, priorHistory, contextBlock).collect { partial ->
                    latest = partial
                    val (cleanDisplay, _) = AiBusinessAssistant.extractProposedAction(partial)
                    _aiUiState.value = AiUiState.Streaming(cleanDisplay)
                    _aiMessages.value = _aiMessages.value.map { msg ->
                        if (msg.id == assistantMsgId) msg.copy(text = cleanDisplay) else msg
                    }
                }
                val (finalText, proposed) = AiBusinessAssistant.extractProposedAction(latest)
                _aiMessages.value = _aiMessages.value.map { msg ->
                    if (msg.id == assistantMsgId) {
                        msg.copy(text = finalText, proposedAction = proposed, dateRangeLabel = dateRangeLabel)
                    } else msg
                }
                _aiUiState.value = AiUiState.Success(finalText)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val errText = e.message ?: "Unable to reach AI Business Assistant."
                _aiUiState.value = AiUiState.Error(errText)
                _aiMessages.value = _aiMessages.value.map { msg ->
                    if (msg.id == assistantMsgId) msg.copy(text = "Error: $errText") else msg
                }
            }
        }
    }

    fun confirmAiProposedAction(msgId: String) {
        val msg = _aiMessages.value.firstOrNull { it.id == msgId } ?: return
        val action = msg.proposedAction ?: return
        if (msg.actionExecuted) return
        val ws = workspaceState.value
        val bizId = ws.activeBusiness?.id ?: return
        val defaultAccId = ws.accounts.firstOrNull()?.id ?: return

        viewModelScope.launch {
            try {
                when (action.actionType) {
                    "ADD_EXPENSE" -> {
                        repo.recordIncomeOrExpense(
                            bizId, true, action.amountPaisa, null,
                            action.partyOrCategory.ifBlank { "Other Expenses" },
                            defaultAccId, action.notes.ifBlank { "AI Assistant confirmed entry" },
                            null, createdBy = operatorName()
                        )
                    }
                    "RECEIVE_PAYMENT", "CREDIT_SALE" -> {
                        val existingCust = ws.customers.firstOrNull {
                            it.name.equals(action.partyOrCategory, ignoreCase = true) ||
                                it.name.contains(action.partyOrCategory, ignoreCase = true)
                        } ?: repo.saveCustomer(
                            bizId, null, action.partyOrCategory.ifBlank { "Customer" },
                            "", "", null, "Regular", 0L
                        )
                        val txType = if (action.actionType == "RECEIVE_PAYMENT") TxTypes.CUSTOMER_PAYMENT else TxTypes.CREDIT_SALE
                        repo.recordDueLedgerEntry(
                            bizId, existingCust.id, txType, action.amountPaisa,
                            defaultAccId, true, action.notes.ifBlank { "AI Assistant confirmed" },
                            createdBy = operatorName()
                        )
                    }
                    "ADD_SALE" -> {
                        repo.recordSale(
                            bizId, null,
                            listOf(
                                SaleCartLine(
                                    itemName = action.partyOrCategory.ifBlank { "Cash Sale" },
                                    quantityMilliUnits = 1000L,
                                    unitPricePaisa = action.amountPaisa
                                )
                            ),
                            0L, 0, action.amountPaisa, defaultAccId,
                            action.notes.ifBlank { "AI Assistant confirmed sale" },
                            createdBy = operatorName()
                        )
                    }
                }
                _aiMessages.value = _aiMessages.value.map {
                    if (it.id == msgId) it.copy(actionExecuted = true) else it
                }
                _statusMessage.value = "Confirmed & saved to ledger"
            } catch (e: Exception) {
                _statusMessage.value = e.message ?: "Action failed"
            }
        }
    }

    fun clearAiChat() {
        aiStreamJob?.cancel()
        _aiMessages.value = emptyList()
        _aiUiState.value = AiUiState.Idle
    }

    // --- Bangla & English Voice Accounting ---

    fun parseVoiceCommand(rawText: String): ParsedVoiceCommand {
        val ws = workspaceState.value
        return VoiceAccountingParser.parse(
            rawText = rawText,
            customers = ws.customers,
            products = ws.products,
            recentTransactions = ws.transactions
        )
    }

    fun executeVoiceCommand(cmd: ParsedVoiceCommand, accountId: String, onDone: (Boolean, String) -> Unit = { _, _ -> }) {
        val ws = workspaceState.value
        val bizId = ws.activeBusiness?.id ?: run {
            onDone(false, "No active business")
            return
        }
        val accId = accountId.ifBlank { ws.accounts.firstOrNull()?.id.orEmpty() }
        if (accId.isBlank()) {
            onDone(false, "No payment account available")
            return
        }
        if (cmd.amountPaisa <= 0L) {
            onDone(false, "Please enter an amount greater than 0")
            return
        }

        viewModelScope.launch {
            try {
                when (cmd.intentType) {
                    VoiceIntentType.CUSTOMER_PAYMENT, VoiceIntentType.CREDIT_SALE -> {
                        val custId = cmd.customerId ?: run {
                            val name = cmd.customerName.ifBlank { "Voice Customer" }
                            repo.saveCustomer(bizId, null, name, "", "", null, "Regular", 0L).id
                        }
                        val txType = if (cmd.intentType == VoiceIntentType.CUSTOMER_PAYMENT) {
                            TxTypes.CUSTOMER_PAYMENT
                        } else {
                            TxTypes.CREDIT_SALE
                        }
                        repo.recordDueLedgerEntry(
                            businessId = bizId,
                            customerId = custId,
                            type = txType,
                            amountPaisa = cmd.amountPaisa,
                            accountId = accId,
                            affectAccountBalance = cmd.intentType == VoiceIntentType.CUSTOMER_PAYMENT,
                            notes = cmd.notes,
                            occurredAt = cmd.occurredAtMillis,
                            createdBy = operatorName()
                        )
                    }
                    VoiceIntentType.EXPENSE, VoiceIntentType.INCOME -> {
                        repo.recordIncomeOrExpense(
                            businessId = bizId,
                            isExpense = cmd.intentType == VoiceIntentType.EXPENSE,
                            amountPaisa = cmd.amountPaisa,
                            categoryId = null,
                            categoryName = cmd.categoryName.ifBlank {
                                if (cmd.intentType == VoiceIntentType.EXPENSE) "Other Expenses" else "Other Income"
                            },
                            accountId = accId,
                            notes = cmd.notes,
                            attachmentUri = null,
                            occurredAt = cmd.occurredAtMillis,
                            createdBy = operatorName()
                        )
                    }
                    VoiceIntentType.SALE -> {
                        val prod = cmd.productId?.let { id -> ws.products.firstOrNull { it.id == id } }
                        val qtyMilli = cmd.quantityMilliUnits.coerceAtLeast(1L)
                        val unitPricePaisa = (cmd.amountPaisa * 1000L) / qtyMilli
                        val line = SaleCartLine(
                            productId = prod?.id,
                            itemName = cmd.productName.ifBlank { prod?.name ?: "Voice Sale" },
                            unit = cmd.unit.ifBlank { prod?.unit ?: "Piece" },
                            quantityMilliUnits = qtyMilli,
                            unitPricePaisa = unitPricePaisa.coerceAtLeast(1L),
                            costPricePaisa = prod?.purchasePricePaisa ?: 0L
                        )
                        repo.recordSale(
                            businessId = bizId,
                            customerId = cmd.customerId,
                            lines = listOf(line),
                            discountPaisa = 0L,
                            taxRateBps = 0,
                            paidPaisa = cmd.amountPaisa,
                            accountId = accId,
                            notes = cmd.notes,
                            occurredAt = cmd.occurredAtMillis,
                            createdBy = operatorName()
                        )
                    }
                    VoiceIntentType.QUERY_SUMMARY -> {
                        askAiAssistant(cmd.queryPrompt ?: cmd.rawText)
                    }
                }
                _statusMessage.value = "Voice transaction saved"
                onDone(true, "Saved")
            } catch (e: Exception) {
                val msg = e.message ?: "Could not save voice entry"
                _statusMessage.value = msg
                onDone(false, msg)
            }
        }
    }

    // --- Backup (Plain JSON & AES-256 Encrypted) ---

    fun exportBackupToUri(uri: Uri) {
        exportBackupToUri(uri, null)
    }

    fun exportBackupToUri(uri: Uri, passphrase: String?) {
        viewModelScope.launch {
            try {
                val payload = if (!passphrase.isNullOrBlank()) {
                    repo.exportEncryptedBackup(passphrase)
                } else {
                    repo.exportLocalBackupJson()
                }
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                    it.write(payload.toByteArray(Charsets.UTF_8))
                }
                prefs.updateLastLocalBackup(System.currentTimeMillis())
                _statusMessage.value = if (!passphrase.isNullOrBlank()) {
                    "Encrypted backup exported successfully"
                } else {
                    "Local backup exported successfully"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Export failed: ${e.message}"
            }
        }
    }

    fun restoreBackupFromUri(uri: Uri) {
        restoreBackupFromUri(uri, null)
    }

    fun restoreBackupFromUri(uri: Uri, passphrase: String?) {
        viewModelScope.launch {
            try {
                val payload = getApplication<Application>().contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                } ?: return@launch
                if (SecurityUtils.isEncryptedBackup(payload) && passphrase.isNullOrBlank()) {
                    _pendingEncryptedRestoreUri.value = uri
                    return@launch
                }
                val count = repo.restoreEncryptedOrPlainBackup(payload, passphrase)
                _pendingEncryptedRestoreUri.value = null
                if (count > 0) {
                    val businesses = db.businessDao().getAllBusinessesSync()
                    businesses.firstOrNull()?.let { prefs.completeOnboarding(it.id, it.languageCode) }
                    _statusMessage.value = "Restored $count business(es) from backup"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Restore failed: ${e.message}"
            }
        }
    }

    fun dismissPendingEncryptedRestore() {
        _pendingEncryptedRestoreUri.value = null
    }

    // --- Cloud Multi-Device Sync & Conflicts ---

    fun syncToCloud(currentUserId: String) {
        if (_isSyncing.value) return
        viewModelScope.launch {
            _isSyncing.value = true
            val devId = _deviceId.value.ifBlank { prefs.getOrCreateDeviceId().also { _deviceId.value = it } }
            val result: Result<CloudSyncSummary> = cloudSyncRepo.syncLocalToCloud(currentUserId, devId)
            _isSyncing.value = false
            result.onSuccess { summary ->
                prefs.updateLastCloudSync(summary.syncedAtMillis)
                val conflictSuffix = if (summary.conflictsDetected > 0) {
                    " (${summary.conflictsDetected} conflict(s) flagged)"
                } else ""
                _statusMessage.value = "Synced ${summary.businessesSynced} business(es), ${summary.recordsSynced} records$conflictSuffix"
            }.onFailure { err ->
                _statusMessage.value = "Cloud sync failed: ${err.message}"
            }
        }
    }

    fun restoreFromCloud(currentUserId: String) {
        if (_isSyncing.value) return
        viewModelScope.launch {
            _isSyncing.value = true
            val result = cloudSyncRepo.restoreCloudToLocal(currentUserId)
            _isSyncing.value = false
            result.onSuccess { summary ->
                prefs.updateLastCloudSync(summary.syncedAtMillis)
                val businesses = db.businessDao().getAllBusinessesSync()
                businesses.firstOrNull()?.let { prefs.completeOnboarding(it.id, it.languageCode) }
                _statusMessage.value = "Restored ${summary.businessesSynced} business(es) from cloud"
            }.onFailure { err ->
                _statusMessage.value = "Cloud restore failed: ${err.message}"
            }
        }
    }

    fun resolveSyncConflict(outboxId: String, keepLocal: Boolean) {
        viewModelScope.launch {
            repo.resolveSyncConflict(outboxId, keepLocal)
            _statusMessage.value = if (keepLocal) "Conflict marked to push local version" else "Local conflict cleared"
        }
    }

    fun revokeCloudDevice(currentUserId: String, targetDeviceId: String, revoke: Boolean) {
        viewModelScope.launch {
            val res = cloudSyncRepo.revokeCloudDevice(currentUserId, targetDeviceId, revoke)
            res.onSuccess {
                _statusMessage.value = if (revoke) "Device access revoked" else "Device access restored"
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "Failed to update device status"
            }
        }
    }

    // --- GitHub Releases Updater ---

    fun checkForAppUpdate(repoInput: String) {
        if (_updateState.value is UpdateUiState.Checking || _updateState.value is UpdateUiState.Downloading) return
        val normalized = GitHubReleaseUpdater.normalizeRepoSlug(repoInput)
        if (normalized == null) {
            _updateState.value = UpdateUiState.Error("Enter a valid GitHub repo (e.g. username/hisab-pro-bd)")
            return
        }
        viewModelScope.launch {
            prefs.setGithubUpdateRepo(normalized)
            _updateState.value = UpdateUiState.Checking
            val currentVer = BuildConfig.VERSION_NAME
            val result = GitHubReleaseUpdater.fetchLatestRelease(normalized)
            result.onSuccess { release ->
                if (GitHubReleaseUpdater.isRemoteVersionNewer(release.tagName, currentVer)) {
                    _updateState.value = UpdateUiState.UpdateAvailable(currentVer, release)
                } else {
                    _updateState.value = UpdateUiState.UpToDate(currentVer, release.tagName)
                }
            }.onFailure { err ->
                _updateState.value = UpdateUiState.Error(err.message ?: "Unable to check GitHub Releases")
            }
        }
    }

    fun downloadAvailableUpdate() {
        val current = _updateState.value
        val release = when (current) {
            is UpdateUiState.UpdateAvailable -> current.release
            is UpdateUiState.Error -> return
            else -> return
        }
        val apkUrl = release.apkDownloadUrl
        if (apkUrl.isNullOrBlank()) {
            _updateState.value = UpdateUiState.Error("No .apk asset found in release ${release.tagName}. Open the release page instead.")
            return
        }
        viewModelScope.launch {
            val destDir = File(getApplication<Application>().cacheDir, "updates")
            _updateState.value = UpdateUiState.Downloading(release, 0, 0L, release.apkSizeBytes)
            val result = GitHubReleaseUpdater.downloadApk(
                apkUrl = apkUrl,
                destDir = destDir,
                fileName = release.apkAssetName ?: "hisab_pro_${release.tagName}.apk",
                expectedSizeBytes = release.apkSizeBytes
            ) { pct, downloaded, total ->
                _updateState.value = UpdateUiState.Downloading(release, pct, downloaded, total)
            }
            result.onSuccess { file ->
                _updateState.value = UpdateUiState.ReadyToInstall(release, file.absolutePath)
                _statusMessage.value = "Update downloaded. Ready to install ${release.tagName}"
            }.onFailure { err ->
                _updateState.value = UpdateUiState.Error(err.message ?: "APK download failed")
            }
        }
    }

    fun resetUpdateState() {
        _updateState.value = UpdateUiState.Idle
    }

    private data class CoreBusinessBundle(
        val accounts: List<AccountEntity>,
        val customers: List<CustomerEntity>,
        val archivedCustomers: List<CustomerEntity>,
        val suppliers: List<SupplierEntity>,
        val products: List<ProductEntity>,
        val stockMovements: List<StockMovementEntity>,
        val categories: List<CategoryEntity>,
        val transactions: List<AccountingTransactionEntity>,
        val invoices: List<InvoiceEntity>,
        val invoiceItems: List<InvoiceItemEntity>,
        val employees: List<EmployeeEntity>,
        val notifications: List<AppNotificationEntity>,
        val unreadCount: Int
    )

    private data class ProBusinessBundle(
        val attendance: List<AttendanceEntity>,
        val leaves: List<LeaveRequestEntity>,
        val salaryPayments: List<SalaryPaymentEntity>,
        val activityLogs: List<ActivityLogEntity>,
        val rolePermissions: List<RolePermissionEntity>,
        val syncOutbox: List<SyncOutboxEntity>,
        val conflicts: List<SyncOutboxEntity>,
        val pendingSyncCount: Int,
        val authorizedDevices: List<AuthorizedDeviceEntity>
    )

    private val EmptyCoreBundle = CoreBusinessBundle(
        emptyList(), emptyList(), emptyList(), emptyList(), emptyList(),
        emptyList(), emptyList(), emptyList(), emptyList(), emptyList(),
        emptyList(), emptyList(), 0
    )

    private val EmptyProBundle = ProBusinessBundle(
        emptyList(), emptyList(), emptyList(), emptyList(), emptyList(),
        emptyList(), emptyList(), 0, emptyList()
    )
}
