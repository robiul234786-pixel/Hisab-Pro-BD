package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BusinessDao {
    @Query("SELECT * FROM businesses WHERE archived = 0 ORDER BY createdAt ASC")
    fun observeBusinesses(): Flow<List<BusinessEntity>>

    @Query("SELECT * FROM businesses WHERE archived = 0 ORDER BY createdAt ASC")
    suspend fun getAllBusinessesSync(): List<BusinessEntity>

    @Query("SELECT * FROM businesses WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): BusinessEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(business: BusinessEntity)
}

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts WHERE businessId = :businessId AND archived = 0 ORDER BY isDefault DESC, createdAt ASC")
    fun observeAccounts(businessId: String): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE businessId = :businessId AND archived = 0")
    suspend fun getAccountsSync(businessId: String): List<AccountEntity>

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(account: AccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(accounts: List<AccountEntity>)

    @Query("UPDATE accounts SET currentBalancePaisa = :newBalance WHERE id = :accountId")
    suspend fun updateBalance(accountId: String, newBalance: Long)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE businessId = :businessId AND archived = 0 ORDER BY name ASC")
    fun observeCustomers(businessId: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE businessId = :businessId AND archived = 1 ORDER BY name ASC")
    fun observeArchivedCustomers(businessId: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE businessId = :businessId")
    suspend fun getCustomersSync(businessId: String): List<CustomerEntity>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CustomerEntity?

    @Query("SELECT COUNT(*) FROM customers WHERE businessId = :businessId")
    suspend fun countForBusiness(businessId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(customer: CustomerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(customers: List<CustomerEntity>)

    @Update
    suspend fun update(customer: CustomerEntity)
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE businessId = :businessId AND archived = 0 ORDER BY name ASC")
    fun observeSuppliers(businessId: String): Flow<List<SupplierEntity>>

    @Query("SELECT * FROM suppliers WHERE businessId = :businessId")
    suspend fun getSuppliersSync(businessId: String): List<SupplierEntity>

    @Query("SELECT * FROM suppliers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): SupplierEntity?

    @Query("SELECT COUNT(*) FROM suppliers WHERE businessId = :businessId")
    suspend fun countForBusiness(businessId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(supplier: SupplierEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(suppliers: List<SupplierEntity>)

    @Update
    suspend fun update(supplier: SupplierEntity)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE businessId = :businessId AND archived = 0 ORDER BY name ASC")
    fun observeProducts(businessId: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE businessId = :businessId")
    suspend fun getProductsSync(businessId: String): List<ProductEntity>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProductEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(products: List<ProductEntity>)

    @Query("UPDATE products SET stockMilliUnits = :newStock, updatedAt = :updatedAt WHERE id = :productId")
    suspend fun updateStock(productId: String, newStock: Long, updatedAt: Long)
}

@Dao
interface StockMovementDao {
    @Query("SELECT * FROM stock_movements WHERE businessId = :businessId ORDER BY occurredAt DESC LIMIT 200")
    fun observeMovements(businessId: String): Flow<List<StockMovementEntity>>

    @Query("SELECT * FROM stock_movements WHERE businessId = :businessId")
    suspend fun getMovementsSync(businessId: String): List<StockMovementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(movement: StockMovementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(movements: List<StockMovementEntity>)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE businessId = :businessId ORDER BY isSystem DESC, name ASC")
    fun observeCategories(businessId: String): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE businessId = :businessId")
    suspend fun getCategoriesSync(businessId: String): List<CategoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: CategoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(categories: List<CategoryEntity>)
}

@Dao
interface AccountingTransactionDao {
    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId ORDER BY occurredAt DESC, createdAt DESC")
    fun observeTransactions(businessId: String): Flow<List<AccountingTransactionEntity>>

    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId AND customerId = :customerId ORDER BY occurredAt DESC")
    fun observeCustomerTransactions(businessId: String, customerId: String): Flow<List<AccountingTransactionEntity>>

    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId AND supplierId = :supplierId ORDER BY occurredAt DESC")
    fun observeSupplierTransactions(businessId: String, supplierId: String): Flow<List<AccountingTransactionEntity>>

    @Query("SELECT * FROM accounting_transactions WHERE businessId = :businessId")
    suspend fun getTransactionsSync(businessId: String): List<AccountingTransactionEntity>

    @Query("SELECT * FROM accounting_transactions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AccountingTransactionEntity?

    @Query("SELECT * FROM accounting_transactions WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getByIdempotencyKey(key: String): AccountingTransactionEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(tx: AccountingTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(txs: List<AccountingTransactionEntity>)

    @Query("UPDATE accounting_transactions SET isReversed = 1 WHERE id = :txId")
    suspend fun markReversed(txId: String)
}

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices WHERE businessId = :businessId ORDER BY occurredAt DESC")
    fun observeInvoices(businessId: String): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE businessId = :businessId")
    suspend fun getInvoicesSync(businessId: String): List<InvoiceEntity>

    @Query("SELECT * FROM invoices WHERE id = :invoiceId LIMIT 1")
    suspend fun getInvoiceById(invoiceId: String): InvoiceEntity?

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId")
    suspend fun getItemsForInvoice(invoiceId: String): List<InvoiceItemEntity>

    @Query("SELECT * FROM invoice_items WHERE invoiceId IN (SELECT id FROM invoices WHERE businessId = :businessId)")
    suspend fun getAllInvoiceItemsSync(businessId: String): List<InvoiceItemEntity>

    @Query("SELECT COUNT(*) FROM invoices WHERE businessId = :businessId AND invoiceType = :type")
    suspend fun countInvoices(businessId: String, type: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<InvoiceItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoices(invoices: List<InvoiceEntity>)

    @Query("UPDATE invoice_items SET returnedMilliUnits = returnedMilliUnits + :qty WHERE id = :itemId")
    suspend fun incrementReturnedQty(itemId: String, qty: Long)
}

@Dao
interface EmployeeDao {
    @Query("SELECT * FROM employees WHERE businessId = :businessId ORDER BY createdAt ASC")
    fun observeEmployees(businessId: String): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM employees WHERE businessId = :businessId")
    suspend fun getEmployeesSync(businessId: String): List<EmployeeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(employee: EmployeeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(employees: List<EmployeeEntity>)

    @Query("DELETE FROM employees WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface AppNotificationDao {
    @Query("SELECT * FROM app_notifications WHERE businessId = :businessId ORDER BY createdAt DESC LIMIT 100")
    fun observeNotifications(businessId: String): Flow<List<AppNotificationEntity>>

    @Query("SELECT COUNT(*) FROM app_notifications WHERE businessId = :businessId AND isRead = 0")
    fun observeUnreadCount(businessId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: AppNotificationEntity)

    @Query("UPDATE app_notifications SET isRead = 1 WHERE businessId = :businessId")
    suspend fun markAllRead(businessId: String)
}
