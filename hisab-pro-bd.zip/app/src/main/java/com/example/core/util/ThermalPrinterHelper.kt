package com.example.core.util

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.data.local.BusinessEntity
import com.example.data.local.InvoiceEntity
import com.example.data.local.InvoiceItemEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

data class PairedPrinterDevice(
    val name: String,
    val address: String
)

object ThermalPrinterHelper {
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun hasBluetoothPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    @Suppress("MissingPermission")
    fun listPairedPrinters(context: Context): Result<List<PairedPrinterDevice>> {
        if (!hasBluetoothPermission(context)) {
            return Result.failure(SecurityException("Bluetooth permission is required"))
        }
        val mgr = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter: BluetoothAdapter? = mgr?.adapter
        if (adapter == null) {
            return Result.failure(IllegalStateException("Bluetooth is not supported on this device"))
        }
        if (!adapter.isEnabled) {
            return Result.failure(IllegalStateException("Please turn on Bluetooth first"))
        }
        val devices = adapter.bondedDevices.orEmpty().map { d: BluetoothDevice ->
            PairedPrinterDevice(
                name = d.name?.ifBlank { d.address } ?: d.address,
                address = d.address
            )
        }.sortedBy { it.name }
        return Result.success(devices)
    }

    fun buildThermalReceiptText(
        business: BusinessEntity,
        invoice: InvoiceEntity,
        items: List<InvoiceItemEntity>
    ): String {
        val sb = StringBuilder()
        val divider = "--------------------------------"
        sb.appendLine(centerLine(business.name, 32))
        if (business.phone.isNotBlank()) sb.appendLine(centerLine(business.phone, 32))
        if (business.address.isNotBlank()) sb.appendLine(centerLine(business.address.take(32), 32))
        sb.appendLine(divider)
        sb.appendLine("Bill: ${invoice.invoiceNumber}")
        sb.appendLine("Date: ${MoneyUtils.formatDhakaDateTime(invoice.occurredAt, false)}")
        sb.appendLine("Party: ${invoice.partyName.take(24)}")
        sb.appendLine(divider)
        sb.appendLine(padColumns("Item", "Qty   Total", 32))
        sb.appendLine(divider)
        items.forEach { item ->
            val qtyStr = MoneyUtils.milliUnitsToString(item.quantityMilliUnits, false)
            val totalStr = asciiTaka(item.lineTotalPaisa)
            sb.appendLine(padColumns(item.itemName.take(15), "$qtyStr  $totalStr", 32))
        }
        sb.appendLine(divider)
        sb.appendLine(padColumns("Subtotal:", asciiTaka(invoice.subtotalPaisa), 32))
        if (invoice.discountPaisa > 0L) {
            sb.appendLine(padColumns("Discount:", "-${asciiTaka(invoice.discountPaisa)}", 32))
        }
        if (invoice.taxPaisa > 0L) {
            sb.appendLine(padColumns("VAT/Tax:", asciiTaka(invoice.taxPaisa), 32))
        }
        sb.appendLine(padColumns("TOTAL:", asciiTaka(invoice.totalPaisa), 32))
        sb.appendLine(padColumns("Paid:", asciiTaka(invoice.paidPaisa), 32))
        if (invoice.duePaisa > 0L) {
            sb.appendLine(padColumns("DUE:", asciiTaka(invoice.duePaisa), 32))
        }
        sb.appendLine(divider)
        sb.appendLine(centerLine("Thank you! Hisab Pro BD", 32))
        return sb.toString()
    }

    fun buildEscPosPayload(
        business: BusinessEntity,
        invoice: InvoiceEntity,
        items: List<InvoiceItemEntity>
    ): ByteArray {
        val out = ByteArrayOutputStream()
        // ESC @ Initialize printer
        out.write(byteArrayOf(0x1B, 0x40))
        // Center align + double emphasis header
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        out.write(byteArrayOf(0x1B, 0x45, 0x01))
        out.write("${business.name}\n".toByteArray(Charsets.US_ASCII))
        out.write(byteArrayOf(0x1B, 0x45, 0x00))
        if (business.phone.isNotBlank()) out.write("${business.phone}\n".toByteArray(Charsets.US_ASCII))
        // Left align body
        out.write(byteArrayOf(0x1B, 0x61, 0x00))
        out.write(buildThermalReceiptText(business, invoice, items).toByteArray(Charsets.US_ASCII))
        // Feed 3 lines & partial cut (GS V 1)
        out.write("\n\n\n".toByteArray(Charsets.US_ASCII))
        out.write(byteArrayOf(0x1D, 0x56, 0x01))
        return out.toByteArray()
    }

    @Suppress("MissingPermission")
    suspend fun printEscPosOverBluetooth(
        context: Context,
        deviceAddress: String,
        payload: ByteArray
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!hasBluetoothPermission(context)) {
            return@withContext Result.failure(SecurityException("Bluetooth permission required"))
        }
        val mgr = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = mgr?.adapter
            ?: return@withContext Result.failure(IllegalStateException("Bluetooth adapter unavailable"))
        try {
            val device = adapter.getRemoteDevice(deviceAddress)
            adapter.cancelDiscovery()
            val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.use { s ->
                s.connect()
                s.outputStream.use { os ->
                    os.write(payload)
                    os.flush()
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun asciiTaka(paisa: Long): String {
        val whole = paisa / 100L
        val frac = kotlin.math.abs(paisa % 100L)
        return if (frac == 0L) "Tk $whole" else "Tk $whole.${frac.toString().padStart(2, '0')}"
    }

    private fun centerLine(text: String, width: Int): String {
        val t = text.take(width)
        val pad = ((width - t.length) / 2).coerceAtLeast(0)
        return " ".repeat(pad) + t
    }

    private fun padColumns(left: String, right: String, width: Int): String {
        val space = (width - left.length - right.length).coerceAtLeast(1)
        return left + " ".repeat(space) + right
    }
}
