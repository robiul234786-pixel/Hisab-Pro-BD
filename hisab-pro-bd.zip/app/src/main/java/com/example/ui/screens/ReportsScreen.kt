package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.util.ExportUtils
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.TxTypes
import com.example.data.repository.AccountingCalculator
import com.example.data.repository.CalendarDaySummary
import com.example.ui.BusinessWorkspaceState
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricCard
import com.example.ui.components.TransactionRowCard
import com.example.ui.theme.*
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class ReportType(val title: String) {
    PROFIT_LOSS("Profit & Loss"),
    PRO_ANALYTICS("Pro Analytics"),
    FINANCIAL_CALENDAR("Calendar"),
    BUSINESS_HEALTH("Health Score"),
    DAILY("Daily Report"),
    WEEKLY("Weekly Report"),
    MONTHLY("Monthly Report"),
    YEARLY("Yearly Report"),
    SALES("Sales Report"),
    PURCHASE("Purchase Report"),
    CUSTOMER_DUE("Customer Due"),
    SUPPLIER_PAYABLE("Supplier Payable"),
    INCOME("Income Report"),
    EXPENSE("Expense Report"),
    INVENTORY("Inventory Report"),
    CASHBOOK("Cashbook Report"),
    ACTIVITY_LOG("Audit Log")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(state: BusinessWorkspaceState) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val context = LocalContext.current

    val canViewReports = state.activeEmployee?.canViewReports ?: true
    if (!canViewReports) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            EmptyStateCard(
                icon = Icons.Default.Lock,
                title = "Restricted Access",
                subtitle = "Current role (${state.activeEmployee?.role}) does not have permission to view financial reports."
            )
        }
        return
    }

    var selectedReport by remember { mutableStateOf(ReportType.PROFIT_LOSS) }
    var useCustomDateRange by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var customStartMillis by remember { mutableLongStateOf(MoneyUtils.dhakaMonthBounds().first) }
    var customEndMillis by remember { mutableLongStateOf(MoneyUtils.dhakaMonthBounds().second) }

    val (startMillis, endMillis) = remember(selectedReport, useCustomDateRange, customStartMillis, customEndMillis) {
        if (useCustomDateRange) {
            customStartMillis to customEndMillis
        } else {
            when (selectedReport) {
                ReportType.DAILY -> MoneyUtils.dhakaTodayBounds()
                ReportType.WEEKLY -> MoneyUtils.dhakaWeekBounds()
                ReportType.MONTHLY -> MoneyUtils.dhakaMonthBounds()
                ReportType.YEARLY -> MoneyUtils.dhakaYearBounds()
                else -> 0L to Long.MAX_VALUE
            }
        }
    }

    val pnl = remember(state.transactions, startMillis, endMillis) {
        AccountingCalculator.computeProfitAndLoss(state.transactions, startMillis, endMillis)
    }

    val filteredTransactions = remember(state.transactions, selectedReport, startMillis, endMillis) {
        val inRange = state.transactions.filter { it.occurredAt in startMillis..endMillis }
        when (selectedReport) {
            ReportType.SALES -> inRange.filter { it.type == TxTypes.SALE || it.type == TxTypes.CREDIT_SALE || it.type == TxTypes.SALE_RETURN }
            ReportType.PURCHASE -> inRange.filter { it.type == TxTypes.PURCHASE || it.type == TxTypes.PURCHASE_RETURN }
            ReportType.INCOME -> inRange.filter { it.type == TxTypes.INCOME || it.type == TxTypes.SALE || it.type == TxTypes.CREDIT_SALE }
            ReportType.EXPENSE -> inRange.filter { it.type == TxTypes.EXPENSE }
            ReportType.CASHBOOK -> inRange.filter { it.cashFlowDeltaPaisa != 0L || it.type == TxTypes.ACCOUNT_TRANSFER }
            else -> inRange
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.tabReports, style = MaterialTheme.typography.headlineSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { showDatePicker = true },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (useCustomDateRange) "Custom" else "Filter")
                    }
                    if (useCustomDateRange) {
                        IconButton(onClick = { useCustomDateRange = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Reset filter")
                        }
                    }
                }
            }
        }

        // Report Selector Chips (All 17 reports including Pro Analytics, Calendar, Health Score, Audit Log)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ReportType.entries) { rt ->
                    FilterChip(
                        selected = selectedReport == rt,
                        onClick = { selectedReport = rt },
                        label = { Text(rt.title) },
                        modifier = Modifier.testTag("report_chip_${rt.name.lowercase()}")
                    )
                }
            }
        }

        // Export Buttons
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        val bizName = state.activeBusiness?.name ?: "Hisab Pro BD"
                        val (summary, headers, rows) = buildExportPayload(selectedReport, state, pnl, filteredTransactions, useBn)
                        val pdf = ExportUtils.generateReportPdf(
                            context = context,
                            fileName = "hisab_${selectedReport.name.lowercase()}.pdf",
                            businessName = bizName,
                            reportTitle = selectedReport.title,
                            summaryRows = summary,
                            tableHeaders = headers,
                            tableRows = rows
                        )
                        ExportUtils.shareFile(context, pdf, "application/pdf", strings.exportPdf)
                    },
                    modifier = Modifier.weight(1f).testTag("export_pdf_button")
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.exportPdf)
                }
                OutlinedButton(
                    onClick = {
                        val (_, headers, rows) = buildExportPayload(selectedReport, state, pnl, filteredTransactions, useBn)
                        val csv = ExportUtils.generateExcelCsv(
                            context = context,
                            fileName = "hisab_${selectedReport.name.lowercase()}.csv",
                            headers = headers,
                            rows = rows
                        )
                        ExportUtils.shareFile(context, csv, "text/csv", strings.exportExcel)
                    },
                    modifier = Modifier.weight(1f).testTag("export_excel_button")
                ) {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.exportExcel)
                }
            }
        }

        when (selectedReport) {
            ReportType.PRO_ANALYTICS -> {
                val adv = state.advancedAnalytics
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("This Month Sales", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    MoneyUtils.formatTaka(adv.currentMonthSalesPaisa, useBn),
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                    color = EmeraldPrimary
                                )
                                Text(
                                    text = adv.salesGrowthPercent?.let {
                                        val sign = if (it >= 0) "+" else ""
                                        "$sign${"%.1f".format(it)}% vs last month"
                                    } ?: "No prior month sales baseline",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if ((adv.salesGrowthPercent ?: 0.0) >= 0.0) EmeraldPrimary else ExpenseRed
                                )
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("This Month Profit", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    MoneyUtils.formatTaka(adv.currentMonthProfitPaisa, useBn),
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                    color = if (adv.currentMonthProfitPaisa >= 0) EmeraldPrimary else ExpenseRed
                                )
                                Text(
                                    text = adv.profitGrowthPercent?.let {
                                        val sign = if (it >= 0) "+" else ""
                                        "$sign${"%.1f".format(it)}% vs last month"
                                    } ?: "Prior month profit unavailable",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Expense Breakdown Canvas Donut + Legend
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(strings.expenseBreakdown, style = MaterialTheme.typography.titleMedium)
                            if (adv.expenseBreakdown.isEmpty()) {
                                Text("No expense entries recorded yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                val palette = listOf(EmeraldPrimary, ExpenseRed, WarningAmber, InfoBlue, Color(0xFF8B5CF6), Color(0xFFEC4899))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Canvas(modifier = Modifier.size(110.dp)) {
                                        var startAngle = -90f
                                        adv.expenseBreakdown.take(6).forEachIndexed { idx, share ->
                                            val sweep = (share.sharePercent.toFloat() / 100f) * 360f
                                            drawArc(
                                                color = palette[idx % palette.size],
                                                startAngle = startAngle,
                                                sweepAngle = sweep.coerceAtLeast(2f),
                                                useCenter = false,
                                                style = Stroke(width = 24f, cap = StrokeCap.Butt)
                                            )
                                            startAngle += sweep
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        adv.expenseBreakdown.take(6).forEachIndexed { idx, share ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                                                    Box(Modifier.size(8.dp).clip(CircleShape).background(palette[idx % palette.size]))
                                                    Text(share.categoryName, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                                Text(
                                                    "${"%.0f".format(share.sharePercent)}% (${MoneyUtils.formatTaka(share.amountPaisa, useBn)})",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontFamily = MonoFontFamily
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Product Profitability & Best Sellers
                item {
                    Text(strings.productProfitability, style = MaterialTheme.typography.titleMedium)
                }
                if (adv.productProfitability.isEmpty()) {
                    item {
                        EmptyStateCard(Icons.Default.Inventory, "No product sales yet", "Create itemized POS sales to analyze top sellers and margins.")
                    }
                } else {
                    items(adv.productProfitability.take(12), key = { it.productId ?: it.itemName }) { row ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(row.itemName, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "Sold: ${MoneyUtils.milliUnitsToString(row.quantitySoldMilliUnits, useBn)} ${row.unit} • Rev: ${MoneyUtils.formatTaka(row.revenuePaisa, useBn)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (row.hasMissingCost) {
                                        Text("Purchase cost unavailable for some units", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                                    }
                                }
                                Text(
                                    MoneyUtils.formatTaka(row.profitPaisa, useBn),
                                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                    color = if (row.profitPaisa >= 0) EmeraldPrimary else ExpenseRed
                                )
                            }
                        }
                    }
                }
            }

            ReportType.FINANCIAL_CALENDAR -> {
                item {
                    FinancialCalendarSection(
                        calendarMap = state.advancedAnalytics.calendarDayMap,
                        transactions = state.transactions,
                        useBn = useBn
                    )
                }
            }

            ReportType.BUSINESS_HEALTH -> {
                val health = state.advancedAnalytics.healthReport
                item {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(strings.businessHealthScore, style = MaterialTheme.typography.titleLarge)
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(160.dp)) {
                                val scoreColor = when {
                                    health.score >= 80 -> EmeraldPrimary
                                    health.score >= 60 -> InfoBlue
                                    health.score >= 45 -> WarningAmber
                                    else -> ExpenseRed
                                }
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawArc(
                                        color = Color.Gray.copy(alpha = 0.2f),
                                        startAngle = 135f,
                                        sweepAngle = 270f,
                                        useCenter = false,
                                        style = Stroke(width = 24f, cap = StrokeCap.Round)
                                    )
                                    drawArc(
                                        color = scoreColor,
                                        startAngle = 135f,
                                        sweepAngle = (health.score / 100f) * 270f,
                                        useCenter = false,
                                        style = Stroke(width = 24f, cap = StrokeCap.Round)
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        "${health.score}",
                                        style = MaterialTheme.typography.displayMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                        color = scoreColor
                                    )
                                    Text(health.grade, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            HorizontalDivider()
                            ReportLine("Profit Margin", "${"%.1f".format(health.profitMarginPercent)}%", highlight = true)
                            ReportLine("Liquid Cash / Bank / MFS", MoneyUtils.formatTaka(health.totalLiquidPaisa, useBn))
                            ReportLine("Receivable-to-Sales Ratio", "${"%.1f".format(health.receivableToSalesPercent)}%")
                            ReportLine("Low Stock Products", "${health.lowStockCount}")
                        }
                    }
                }
            }

            ReportType.ACTIVITY_LOG -> {
                if (state.activityLogs.isEmpty()) {
                    item { EmptyStateCard(Icons.Default.VerifiedUser, "No audit activity yet", "Financial and HR operations appear in this tamper-evident log.") }
                } else {
                    items(state.activityLogs.take(80), key = { it.id }) { log ->
                        ListItem(
                            headlineContent = { Text(log.summary) },
                            supportingContent = { Text("${log.actorName} • ${log.actionType} • ${MoneyUtils.formatDhakaDateTime(log.occurredAt, useBn)}") },
                            leadingContent = { Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = EmeraldPrimary) }
                        )
                    }
                }
            }

            ReportType.CUSTOMER_DUE -> {
                val dueList = state.customers.filter { it.currentDuePaisa > 0L }.sortedByDescending { it.currentDuePaisa }
                item {
                    MetricCard(strings.totalReceivable, state.dashboard.totalReceivablesPaisa, useBn, Icons.Default.MenuBook, WarningAmber)
                }
                items(dueList, key = { it.id }) { c ->
                    ListItem(
                        headlineContent = { Text(c.name) },
                        supportingContent = { Text("${c.customerCode} • ${c.phone}") },
                        trailingContent = {
                            Text(MoneyUtils.formatTaka(c.currentDuePaisa, useBn), fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold, color = WarningAmber)
                        }
                    )
                }
            }

            ReportType.SUPPLIER_PAYABLE -> {
                val payList = state.suppliers.filter { it.currentPayablePaisa > 0L }.sortedByDescending { it.currentPayablePaisa }
                item {
                    MetricCard(strings.supplierPayables, state.dashboard.totalPayablesPaisa, useBn, Icons.Default.LocalShipping, ExpenseRed)
                }
                items(payList, key = { it.id }) { s ->
                    ListItem(
                        headlineContent = { Text(s.name) },
                        supportingContent = { Text("${s.supplierCode} • ${s.phone}") },
                        trailingContent = {
                            Text(MoneyUtils.formatTaka(s.currentPayablePaisa, useBn), fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold, color = ExpenseRed)
                        }
                    )
                }
            }

            ReportType.INVENTORY -> {
                val totalStockVal = state.products.sumOf {
                    MoneyUtils.calculateLineTotalPaisa(it.stockMilliUnits, it.purchasePricePaisa)
                }
                item {
                    MetricCard("Stock Valuation (Cost)", totalStockVal, useBn, Icons.Default.Inventory2, EmeraldPrimary)
                }
                items(state.products, key = { it.id }) { p ->
                    val low = p.stockMilliUnits <= p.lowStockThresholdMilliUnits
                    ListItem(
                        headlineContent = { Text(p.name) },
                        supportingContent = { Text("Buy: ${MoneyUtils.formatTaka(p.purchasePricePaisa, useBn)} | Sell: ${MoneyUtils.formatTaka(p.sellingPricePaisa, useBn)}") },
                        trailingContent = {
                            Text(
                                "${MoneyUtils.milliUnitsToString(p.stockMilliUnits, useBn)} ${p.unit}",
                                color = if (low) ExpenseRed else EmeraldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                }
            }

            else -> {
                // Financial P&L + Cashflow Summary Card
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedReport.title, style = MaterialTheme.typography.titleMedium)
                                Surface(
                                    color = if (pnl.isEstimated) WarningSoftAmber else SoftGreenAccent,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = if (pnl.isEstimated) strings.estimatedProfit else strings.finalizedProfit,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (pnl.isEstimated) WarningAmber else EmeraldPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            ReportLine("Net Sales", MoneyUtils.formatTaka(pnl.netSalesPaisa, useBn))
                            ReportLine(strings.cogsLabel, MoneyUtils.formatTaka(pnl.cogsPaisa, useBn))
                            ReportLine(strings.grossProfit, MoneyUtils.formatTaka(pnl.grossProfitPaisa, useBn), highlight = true)
                            ReportLine("Other Income", MoneyUtils.formatTaka(pnl.otherIncomePaisa, useBn))
                            ReportLine("Operating Expenses", MoneyUtils.formatTaka(pnl.operatingExpensesPaisa, useBn))
                            HorizontalDivider()
                            ReportLine(
                                strings.netProfit,
                                MoneyUtils.formatTaka(pnl.netProfitPaisa, useBn),
                                highlight = true
                            )
                            HorizontalDivider()
                            ReportLine("Cash Inflow (Collected)", MoneyUtils.formatTaka(pnl.totalCashInPaisa, useBn))
                            ReportLine("Cash Outflow", MoneyUtils.formatTaka(pnl.totalCashOutPaisa, useBn))
                        }
                    }
                }

                items(filteredTransactions.take(60), key = { it.id }) { tx ->
                    TransactionRowCard(tx = tx, useBanglaDigits = useBn, onClick = {})
                }
            }
        }
    }

    if (showDatePicker) {
        val dateRangeState = rememberDateRangePickerState(
            initialSelectedStartDateMillis = customStartMillis,
            initialSelectedEndDateMillis = customEndMillis
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    val s = dateRangeState.selectedStartDateMillis
                    val e = dateRangeState.selectedEndDateMillis
                    if (s != null && e != null) {
                        customStartMillis = s
                        customEndMillis = e + (24L * 60L * 60L * 1000L - 1L)
                        useCustomDateRange = true
                    }
                    showDatePicker = false
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancel") } }
        ) {
            DateRangePicker(state = dateRangeState, modifier = Modifier.height(420.dp))
        }
    }
}

@Composable
private fun FinancialCalendarSection(
    calendarMap: Map<String, CalendarDaySummary>,
    transactions: List<com.example.data.local.AccountingTransactionEntity>,
    useBn: Boolean
) {
    val today = remember { LocalDate.now(MoneyUtils.DHAKA_ZONE) }
    var currentMonth by remember { mutableStateOf(YearMonth.from(today)) }
    var selectedDate by remember { mutableStateOf(today) }
    val monthFmt = remember { DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH) }
    val isoFmt = DateTimeFormatter.ISO_LOCAL_DATE

    val firstDay = currentMonth.atDay(1)
    val daysInMonth = currentMonth.lengthOfMonth()
    val leadingBlanks = (firstDay.dayOfWeek.value - 1).coerceAtLeast(0)
    val selectedKey = selectedDate.format(isoFmt)
    val daySummary = calendarMap[selectedKey]
    val dayTxs = remember(transactions, selectedKey) {
        transactions.filter {
            Instant.ofEpochMilli(it.occurredAt).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate().format(isoFmt) == selectedKey
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { currentMonth = currentMonth.minusMonths(1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                    }
                    Text(currentMonth.format(monthFmt), style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = { currentMonth = currentMonth.plusMonths(1) }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next month")
                    }
                }

                Row(modifier = Modifier.fillMaxWidth()) {
                    listOf("M", "T", "W", "T", "F", "S", "S").forEach { d ->
                        Text(
                            d,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                val totalCells = leadingBlanks + daysInMonth
                val rows = (totalCells + 6) / 7
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (r in 0 until rows) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            for (c in 0 until 7) {
                                val cellIndex = r * 7 + c
                                val dayNum = cellIndex - leadingBlanks + 1
                                if (dayNum !in 1..daysInMonth) {
                                    Spacer(Modifier.weight(1f).height(44.dp))
                                } else {
                                    val date = currentMonth.atDay(dayNum)
                                    val key = date.format(isoFmt)
                                    val summary = calendarMap[key]
                                    val isSelected = date == selectedDate
                                    Surface(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp)
                                            .clickable { selectedDate = date },
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) EmeraldPrimary else Color.Transparent,
                                        border = if (date == today && !isSelected) BorderStroke(1.dp, EmeraldPrimary) else null
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize(),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                dayNum.toString(),
                                                style = MaterialTheme.typography.labelMedium,
                                                color = if (isSelected) PureWhite else MaterialTheme.colorScheme.onSurface
                                            )
                                            if (summary != null) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                    if (summary.salesPaisa > 0L) {
                                                        Box(Modifier.size(5.dp).clip(CircleShape).background(if (isSelected) PureWhite else EmeraldPrimary))
                                                    }
                                                    if (summary.expensePaisa > 0L) {
                                                        Box(Modifier.size(5.dp).clip(CircleShape).background(if (isSelected) PureWhite else ExpenseRed))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Daily Summary • $selectedKey", style = MaterialTheme.typography.titleMedium)
                if (daySummary == null) {
                    Text("No financial transactions recorded on $selectedKey.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    ReportLine("Sales", MoneyUtils.formatTaka(daySummary.salesPaisa, useBn), highlight = true)
                    ReportLine("Expenses", MoneyUtils.formatTaka(daySummary.expensePaisa, useBn))
                    ReportLine("Cash Collected", MoneyUtils.formatTaka(daySummary.cashInPaisa, useBn))
                    ReportLine("Credit Added", MoneyUtils.formatTaka(daySummary.dueAddedPaisa, useBn))
                    ReportLine("Transactions", "${daySummary.transactionCount}")
                }
            }
        }

        dayTxs.take(20).forEach { tx ->
            TransactionRowCard(tx = tx, useBanglaDigits = useBn, onClick = {})
        }
    }
}

@Composable
private fun ReportLine(label: String, value: String, highlight: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
            label,
            style = if (highlight) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
            color = if (highlight) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value,
            style = if (highlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontFamily = MonoFontFamily,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
            color = if (highlight) EmeraldPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}

private fun buildExportPayload(
    reportType: ReportType,
    state: BusinessWorkspaceState,
    pnl: com.example.data.repository.ProfitAndLossReport,
    txs: List<com.example.data.local.AccountingTransactionEntity>,
    useBn: Boolean
): Triple<List<Pair<String, String>>, List<String>, List<List<String>>> {
    val summary = listOf(
        "Net Sales" to MoneyUtils.formatTaka(pnl.netSalesPaisa, useBn),
        "COGS" to MoneyUtils.formatTaka(pnl.cogsPaisa, useBn),
        "Gross Profit" to MoneyUtils.formatTaka(pnl.grossProfitPaisa, useBn),
        "Operating Expenses" to MoneyUtils.formatTaka(pnl.operatingExpensesPaisa, useBn),
        "Net Profit" to MoneyUtils.formatTaka(pnl.netProfitPaisa, useBn),
        "Total Receivables" to MoneyUtils.formatTaka(state.dashboard.totalReceivablesPaisa, useBn),
        "Total Payables" to MoneyUtils.formatTaka(state.dashboard.totalPayablesPaisa, useBn)
    )
    return when (reportType) {
        ReportType.PRO_ANALYTICS -> Triple(
            summary + ("Business Health Score" to "${state.advancedAnalytics.healthReport.score}/100 (${state.advancedAnalytics.healthReport.grade})"),
            listOf("Product", "Qty Sold", "Revenue", "Cost", "Profit", "Cost Note"),
            state.advancedAnalytics.productProfitability.map {
                listOf(
                    it.itemName,
                    "${MoneyUtils.milliUnitsToString(it.quantitySoldMilliUnits, useBn)} ${it.unit}",
                    MoneyUtils.formatTaka(it.revenuePaisa, useBn),
                    MoneyUtils.formatTaka(it.costPaisa, useBn),
                    MoneyUtils.formatTaka(it.profitPaisa, useBn),
                    if (it.hasMissingCost) "Cost unavailable for some units" else "Exact"
                )
            }
        )
        ReportType.ACTIVITY_LOG -> Triple(
            summary,
            listOf("Date", "Actor", "Action", "Summary"),
            state.activityLogs.map {
                listOf(MoneyUtils.formatDhakaDateTime(it.occurredAt, useBn), it.actorName, it.actionType, it.summary)
            }
        )
        ReportType.CUSTOMER_DUE -> Triple(
            summary,
            listOf("Code", "Customer", "Phone", "Current Due"),
            state.customers.filter { it.currentDuePaisa > 0 }.map {
                listOf(it.customerCode, it.name, it.phone, MoneyUtils.formatTaka(it.currentDuePaisa, useBn))
            }
        )
        ReportType.SUPPLIER_PAYABLE -> Triple(
            summary,
            listOf("Code", "Supplier", "Phone", "Payable"),
            state.suppliers.filter { it.currentPayablePaisa > 0 }.map {
                listOf(it.supplierCode, it.name, it.phone, MoneyUtils.formatTaka(it.currentPayablePaisa, useBn))
            }
        )
        ReportType.INVENTORY -> Triple(
            summary,
            listOf("Product", "SKU", "Stock", "Buy Price", "Sell Price"),
            state.products.map {
                listOf(
                    it.name,
                    it.sku,
                    "${MoneyUtils.milliUnitsToString(it.stockMilliUnits, useBn)} ${it.unit}",
                    MoneyUtils.formatTaka(it.purchasePricePaisa, useBn),
                    MoneyUtils.formatTaka(it.sellingPricePaisa, useBn)
                )
            }
        )
        else -> Triple(
            summary,
            listOf("Date", "Type", "Party/Category", "Amount", "Cash Flow"),
            txs.map {
                listOf(
                    MoneyUtils.formatDhakaDate(it.occurredAt, useBn),
                    it.type,
                    it.partyName.ifBlank { it.categoryName },
                    MoneyUtils.formatTaka(it.totalAmountPaisa, useBn),
                    MoneyUtils.formatTaka(it.cashFlowDeltaPaisa, useBn)
                )
            }
        )
    }
}
