# HISAB PRO BD

**HISAB PRO BD** is an offline-first Native Android business accounting, POS, inventory, HR/payroll, and AI-assisted financial management application built with Kotlin, Jetpack Compose, Material 3, Room, WorkManager, Firebase AI Logic, App Check, Firebase Authentication, and Cloud Firestore for businesses in Bangladesh.

## Core & Pro Features

- **Offline-First Accounting Engine (Room v2 + `MIGRATION_1_2`)**: Full accounting workflows run offline with atomic `withTransaction` writes and integer Paisa (`1 BDT = 100 Paisa`) + `BigDecimal` arithmetic. Non-destructive schema migration (`MIGRATION_1_2`) preserves all v1 businesses, accounts, customers, suppliers, products, employees, and ledger transactions.
- **AI Business Assistant (Firebase AI Logic + App Check)**: Natural Bangla and English financial assistant powered by `Firebase.ai.generativeModel("gemini-3.8-flash")` with App Check protection. Reads live ledger context, quotes exact date ranges, distinguishes zero vs unavailable data, and gates any transaction proposal behind explicit user confirmation.
- **Bangla & English Voice Accounting**: On-device `SpeechRecognizer` (`bn-BD` / `en-US`) plus manual text fallback and NLP parser (`VoiceAccountingParser`) supporting Bangla numbers, units, dates, ambiguous customer disambiguation, 5-minute duplicate warnings, and editable transaction previews before saving.
- **Multi-Device Cloud Synchronization & Conflict Resolution**: Optional Google Sign-In (`CredentialManager`) + Cloud Firestore sync (`SyncOutboxEntity`, optimistic `syncVersion` concurrency, automatic `ConnectivityManager` flush on reconnect, `Keep Local` / `Use Cloud` conflict resolution UI, and authorized device revocation).
- **Financial Dashboard & Pro Analytics**: Live database-backed KPIs, Business Health Score (`0–100` arc gauge), Month-over-Month Sales & Profit growth %, Compose `Canvas` Expense Category Donut chart, Product Profitability & Best Sellers (flagging items with missing purchase cost), Customer Purchase Trends, and interactive Financial Calendar.
- **Enhanced POS, Barcode & ESC/POS Thermal Printing**: Category filter chips, `-`/`+` cart steppers, CameraX `PreviewView` + `ImageAnalysis` EAN-13/Code-128 barcode scanning (`BarcodeScannerHelper`), scannable Code-128 invoice barcodes, PDF invoices, and Bluetooth SPP ESC/POS thermal receipt printing (`ThermalPrinterHelper`).
- **HR, Attendance, Leave, Payroll & RBAC**: Employee management, daily attendance tracking, leave submission & owner approval, salary/advance/bonus payouts that automatically post `EXPENSE` ledger transactions, customizable per-role permissions (`RolePermissionEntity`) propagated to matching staff, and immutable `ActivityLogEntity` audit trails.
- **Security & AES-256-GCM Encrypted Backups**: Optional PIN + Biometric lock, PBKDF2-HMAC-SHA256 + AES-256-GCM passphrase-encrypted `.hisabenc` backup export & restore alongside plain JSON backups and WorkManager daily backups.
- **In-App GitHub Releases Updater**: Check GitHub Releases, download `.apk` assets with live progress, and trigger Android's package installer via `FileProvider`.

## Architecture

- `app/src/main/java/com/example/data/local/`: Room v2 entities, DAOs, `HisabDatabase` (`MIGRATION_1_2`), and DataStore `UserPreferences`.
- `app/src/main/java/com/example/data/repository/`: `AccountingRepository` (transactional ledger, HR/RBAC, outbox queueing, encrypted/plain JSON backups) and `AccountingCalculator` (KPIs, P&L, 6-month chart, Pro Analytics, Financial Calendar, Business Health Score).
- `app/src/main/java/com/example/data/remote/`: `AppCheckInit`, `AiBusinessAssistant`, `FirebaseAuthHelper`, `CloudSyncRepository`, `CloudSyncModels`, `FirestoreErrorHandler`, and `GitHubReleaseUpdater`.
- `app/src/main/java/com/example/core/util/`: `MoneyUtils`, `AppStrings` (EN/BN), `SecurityUtils` (PIN + AES-256-GCM), `VoiceAccountingParser`, `VoiceSpeechHelper`, `BarcodeScannerHelper`, `ThermalPrinterHelper`, and `ExportUtils`.
- `app/src/main/java/com/example/ui/`: `MainViewModel`, adaptive Material 3 screens (`HomeDashboardScreen`, `CustomersAndDuesScreen`, `TransactionsHubScreen`, `ReportsScreen`, `SettingsScreen`), and Pro components (`AiAssistantSheet`, `VoiceAccountingDialog`, `BarcodeScannerDialog`, `HrManagementSheet`, `SyncAndDevicesSheet`).

## Firebase & App Check Configuration

- **Offline Core**: All core accounting, POS, voice parsing, barcode, thermal printing, and HR features work offline.
- **Firebase Integration**:
  - `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml` configure Firebase Auth, named Cloud Firestore (`firestore_database_id`), App Check (`PlayIntegrity` / `DebugAppCheckProviderFactory`), and Firebase AI Logic (`Firebase.ai`).
  - `firestore.rules` enforces strict owner-only isolation (`request.auth.uid == userId`) and non-revoked device checks across `/users/{userId}` and `/users/{userId}/businesses/{businessId}/**`.

## Build & Test Instructions

### Run Unit & Robolectric Tests
```bash
gradle :app:testDebugUnitTest
```

### Build Debug APK
```bash
gradle :app:assembleDebug
```
The generated debug APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`
