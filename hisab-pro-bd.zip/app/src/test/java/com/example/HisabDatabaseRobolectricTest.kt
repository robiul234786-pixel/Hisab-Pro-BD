package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.util.MoneyUtils
import com.example.data.local.AccountTypes
import com.example.data.local.HisabDatabase
import com.example.data.local.TxTypes
import com.example.data.repository.AccountingCalculator
import com.example.data.repository.AccountingRepository
import com.example.data.repository.SaleCartLine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class HisabDatabaseRobolectricTest {

    private lateinit var db: HisabDatabase
    private lateinit var repo: AccountingRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, HisabDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = AccountingRepository(db)
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `baki khata credit and partial payment calculate exact remaining due and cash received`() = runBlocking {
        val biz = repo.createBusinessWithDefaults(
            name = "Dhaka Grocery",
            category = "Grocery Shop",
            phone = "01711223344",
            address = "Mirpur 10, Dhaka",
            logoUri = null,
            languageCode = "en",
            openingCashPaisa = 0L,
            inventoryEnabled = true
        )
        val accounts = repo.observeAccounts(biz.id).first()
        val cashAccount = accounts.first { it.type == AccountTypes.CASH }

        val rahim = repo.saveCustomer(
            businessId = biz.id,
            existingId = null,
            name = "Rahim",
            phone = "01811000111",
            address = "Mirpur",
            photoUri = null,
            category = "Regular",
            openingDuePaisa = 0L
        )

        // New Credit: ৳10,000
        repo.recordDueLedgerEntry(
            businessId = biz.id,
            customerId = rahim.id,
            type = TxTypes.CREDIT_SALE,
            amountPaisa = MoneyUtils.parseTakaToPaisa("10000"),
            accountId = cashAccount.id,
            notes = "Monthly credit groceries"
        )

        // Partial Payment: ৳4,000
        repo.recordDueLedgerEntry(
            businessId = biz.id,
            customerId = rahim.id,
            type = TxTypes.CUSTOMER_PAYMENT,
            amountPaisa = MoneyUtils.parseTakaToPaisa("4000"),
            accountId = cashAccount.id,
            notes = "Partial payment received"
        )

        val updatedCustomers = repo.observeCustomers(biz.id).first()
        val updatedRahim = updatedCustomers.first { it.id == rahim.id }
        val updatedAccounts = repo.observeAccounts(biz.id).first()
        val txs = repo.observeTransactions(biz.id).first()

        // Remaining Due must be ৳6,000 (600_000 paisa)
        assertEquals(600_000L, updatedRahim.currentDuePaisa)
        // Cash Balance must ONLY include the ৳4,000 payment (not unpaid ৳6,000 credit)
        assertEquals(400_000L, updatedAccounts.first { it.id == cashAccount.id }.currentBalancePaisa)

        val metrics = AccountingCalculator.computeDashboard(
            accounts = updatedAccounts,
            customers = updatedCustomers,
            suppliers = emptyList(),
            transactions = txs
        )
        assertEquals(1_000_000L, metrics.totalSalesPaisa)
        assertEquals(400_000L, metrics.totalCashReceivedPaisa)
        assertEquals(600_000L, metrics.totalReceivablesPaisa)
        assertEquals(400_000L, metrics.totalCollectedDuesPaisa)
    }

    @Test
    fun `pos sale updates stock cogs profit and excludes account transfers from profit`() = runBlocking {
        val biz = repo.createBusinessWithDefaults(
            name = "Padma Traders",
            category = "Retail Store",
            phone = "01900000000",
            address = "Chattogram",
            logoUri = null,
            languageCode = "en",
            openingCashPaisa = 500_000L, // ৳5,000 opening cash
            inventoryEnabled = true
        )
        val accounts = repo.observeAccounts(biz.id).first()
        val cashAcc = accounts.first { it.type == AccountTypes.CASH }
        val bkashAcc = accounts.first { it.type == AccountTypes.BKASH }

        val rice = repo.saveProduct(
            businessId = biz.id,
            existingId = null,
            name = "Miniket Rice",
            sku = "RICE-01",
            barcode = "",
            category = "Staples",
            purchasePricePaisa = 8_000L, // ৳80/kg
            sellingPricePaisa = 12_000L, // ৳120/kg
            initialStockMilliUnits = 10_000L, // 10 kg
            unit = "KG",
            lowStockThresholdMilliUnits = 2_000L,
            imageUri = null
        )

        val karim = repo.saveCustomer(
            businessId = biz.id,
            existingId = null,
            name = "Karim",
            phone = "01799999999",
            address = "Halishahar",
            photoUri = null,
            category = "Regular",
            openingDuePaisa = 0L
        )

        // Sell 2 kg for ৳240, receive ৳100 cash, ৳140 due
        repo.recordSale(
            businessId = biz.id,
            customerId = karim.id,
            lines = listOf(
                SaleCartLine(
                    productId = rice.id,
                    itemName = rice.name,
                    unit = rice.unit,
                    quantityMilliUnits = 2_000L,
                    unitPricePaisa = 12_000L,
                    costPricePaisa = 8_000L
                )
            ),
            discountPaisa = 0L,
            taxRateBps = 0,
            paidPaisa = 10_000L,
            accountId = cashAcc.id,
            notes = "POS Test Sale"
        )

        // Transfer ৳2,000 from Cash to bKash (must NOT affect profit)
        repo.recordAccountTransfer(
            businessId = biz.id,
            fromAccountId = cashAcc.id,
            toAccountId = bkashAcc.id,
            amountPaisa = 200_000L,
            notes = "Cash deposit to bKash"
        )

        val updatedProduct = repo.observeProducts(biz.id).first().first { it.id == rice.id }
        assertEquals(8_000L, updatedProduct.stockMilliUnits) // 8 kg remaining

        val updatedAccounts = repo.observeAccounts(biz.id).first()
        val finalCash = updatedAccounts.first { it.id == cashAcc.id }.currentBalancePaisa
        val finalBkash = updatedAccounts.first { it.id == bkashAcc.id }.currentBalancePaisa
        // 5,000 + 100 - 2,000 = 3,100 (310_000 paisa)
        assertEquals(310_000L, finalCash)
        assertEquals(200_000L, finalBkash)

        val txs = repo.observeTransactions(biz.id).first()
        val pnl = AccountingCalculator.computeProfitAndLoss(txs, 0L, Long.MAX_VALUE)
        assertEquals(24_000L, pnl.netSalesPaisa) // ৳240
        assertEquals(16_000L, pnl.cogsPaisa) // 2 * ৳80 = ৳160
        assertEquals(8_000L, pnl.netProfitPaisa) // ৳80 profit; transfer excluded
    }

    @Test
    fun `reversing transaction preserves audit history and restores balances`() = runBlocking {
        val biz = repo.createBusinessWithDefaults(
            name = "Audit Mart",
            category = "Retail Store",
            phone = "01611111111",
            address = "Sylhet",
            logoUri = null,
            languageCode = "en",
            openingCashPaisa = 100_000L, // ৳1,000
            inventoryEnabled = false
        )
        val cashAcc = repo.observeAccounts(biz.id).first().first { it.type == AccountTypes.CASH }

        repo.recordIncomeOrExpense(
            businessId = biz.id,
            isExpense = true,
            amountPaisa = 30_000L, // ৳300 expense
            categoryId = null,
            categoryName = "Transport",
            accountId = cashAcc.id,
            notes = "Rickshaw fare",
            attachmentUri = null
        )

        val txsBefore = repo.observeTransactions(biz.id).first()
        val expenseTx = txsBefore.first { it.type == TxTypes.EXPENSE }
        assertEquals(70_000L, repo.observeAccounts(biz.id).first().first { it.id == cashAcc.id }.currentBalancePaisa)

        repo.reverseTransaction(expenseTx.id, "Entered in wrong business")

        val txsAfter = repo.observeTransactions(biz.id).first()
        assertTrue(txsAfter.any { it.id == expenseTx.id && it.isReversed })
        assertTrue(txsAfter.any { it.type == TxTypes.REVERSAL && it.reversedTransactionId == expenseTx.id })
        assertEquals(100_000L, repo.observeAccounts(biz.id).first().first { it.id == cashAcc.id }.currentBalancePaisa)

        val pnl = AccountingCalculator.computeProfitAndLoss(txsAfter, 0L, Long.MAX_VALUE)
        assertEquals(0L, pnl.operatingExpensesPaisa)
    }

    @Test
    fun `multi business records remain completely isolated`() = runBlocking {
        val biz1 = repo.createBusinessWithDefaults("Shop One", "Grocery Shop", "01711111111", "Dhaka", null, "en", 100_000L, true)
        val biz2 = repo.createBusinessWithDefaults("Shop Two", "Service Business", "01822222222", "Khulna", null, "bn", 250_000L, false)

        repo.saveCustomer(biz1.id, null, "Customer A", "01700000001", "", null, "Regular", 50_000L)

        assertEquals(1, repo.observeCustomers(biz1.id).first().size)
        assertEquals(0, repo.observeCustomers(biz2.id).first().size)
        assertEquals(100_000L, repo.observeAccounts(biz1.id).first().first { it.type == AccountTypes.CASH }.currentBalancePaisa)
        assertEquals(250_000L, repo.observeAccounts(biz2.id).first().first { it.type == AccountTypes.CASH }.currentBalancePaisa)
    }
}
