package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.util.BarcodeScannerHelper
import com.example.core.util.ExportUtils
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.core.util.PairedPrinterDevice
import com.example.core.util.ThermalPrinterHelper
import com.example.data.local.*
import com.example.data.repository.SaleCartLine
import com.example.ui.BusinessWorkspaceState
import com.example.ui.components.BarcodeScannerDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.TransactionRowCard
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun TransactionsHubScreen(
    state: BusinessWorkspaceState,
    initialSubTab: Int = 0,
    onRecordSale: (
        customerId: String?,
        lines: List<SaleCartLine>,
        discountPaisa: Long,
        taxRateBps: Int,
        paidPaisa: Long,
        accountId: String,
        notes: String,
        onComplete: (InvoiceEntity) -> Unit
    ) -> Unit,
    onRecordPurchase: (supplierId: String?, lines: List<SaleCartLine>, paidPaisa: Long, accountId: String, notes: String) -> Unit,
    onRecordIncomeOrExpense: (isExpense: Boolean, amountPaisa: Long, categoryId: String?, categoryName: String, accountId: String, notes: String, attachmentUri: String?) -> Unit,
    onCreateCategory: (name: String, type: String) -> Unit,
    onSaveAccount: (name: String, type: String, number: String, openingBalancePaisa: Long) -> Unit,
    onTransferAccounts: (fromId: String, toId: String, amountPaisa: Long, notes: String) -> Unit,
    onRecordReturnOrCorrection: (type: String, customerId: String?, supplierId: String?, productId: String?, qtyMilli: Long, amountPaisa: Long, refundCash: Boolean, accountId: String, notes: String) -> Unit,
    onReverseTransaction: (txId: String, reason: String) -> Unit,
    onLoadInvoiceItems: suspend (String) -> List<InvoiceItemEntity>,
    onOpenVoiceEntry: () -> Unit = {}
) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    var subTab by remember(initialSubTab) { mutableIntStateOf(initialSubTab) } // 0 POS, 1 Purchase, 2 Income/Exp, 3 Cashbook, 4 History/Returns

    var generatedInvoice by remember { mutableStateOf<InvoiceEntity?>(null) }
    var reverseTarget by remember { mutableStateOf<AccountingTransactionEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = subTab, edgePadding = 12.dp) {
            listOf(
                strings.posBilling,
                strings.purchases,
                strings.incomeExpense,
                strings.cashbook,
                strings.ledgerHistory
            ).forEachIndexed { idx, label ->
                Tab(
                    selected = subTab == idx,
                    onClick = { subTab = idx },
                    text = { Text(label, maxLines = 1) },
                    modifier = Modifier.testTag("tx_subtab_$idx")
                )
            }
        }

        when (subTab) {
            0 -> PosBillingTab(
                state = state,
                useBn = useBn,
                onOpenVoiceEntry = onOpenVoiceEntry,
                onSubmitSale = { custId, lines, disc, taxBps, paid, accId, notes ->
                    onRecordSale(custId, lines, disc, taxBps, paid, accId, notes) { inv ->
                        generatedInvoice = inv
                    }
                }
            )
            1 -> PurchaseTab(state = state, useBn = useBn, onRecordPurchase = onRecordPurchase)
            2 -> IncomeExpenseTab(
                state = state,
                useBn = useBn,
                onSubmit = onRecordIncomeOrExpense,
                onCreateCategory = onCreateCategory
            )
            3 -> CashbookTab(
                state = state,
                useBn = useBn,
                onSaveAccount = onSaveAccount,
                onTransfer = onTransferAccounts
            )
            else -> LedgerHistoryAndReturnsTab(
                state = state,
                useBn = useBn,
                onRecordReturn = onRecordReturnOrCorrection,
                onRequestReverse = { reverseTarget = it }
            )
        }
    }

    generatedInvoice?.let { inv ->
        InvoicePreviewDialog(
            invoice = inv,
            business = state.activeBusiness,
            useBanglaDigits = useBn,
            onLoadItems = onLoadInvoiceItems,
            onDismiss = { generatedInvoice = null }
        )
    }

    reverseTarget?.let { tx ->
        var reason by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { reverseTarget = null },
            title = { Text("Reverse Transaction?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Original records are never deleted. A compensating audit reversal entry will be created.")
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Reason for reversal") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onReverseTransaction(tx.id, reason)
                    reverseTarget = null
                }) { Text("Confirm Reversal") }
            },
            dismissButton = { TextButton(onClick = { reverseTarget = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PosBillingTab(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    onOpenVoiceEntry: () -> Unit,
    onSubmitSale: (String?, List<SaleCartLine>, Long, Int, Long, String, String) -> Unit
) {
    val strings = LocalAppStrings.current
    var selectedCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    var cart by remember { mutableStateOf<List<SaleCartLine>>(emptyList()) }
    var customItemName by remember { mutableStateOf("") }
    var customQtyText by remember { mutableStateOf("1") }
    var customPriceText by remember { mutableStateOf("") }
    var discountText by remember { mutableStateOf("") }
    var taxPercentText by remember(state.activeBusiness) {
        val bps = state.activeBusiness?.defaultTaxRateBps ?: 0
        mutableStateOf(if (state.activeBusiness?.taxEnabled == true && bps > 0) (bps / 100.0).toString() else "0")
    }
    var paidText by remember { mutableStateOf("") }
    var paidEditedManually by remember { mutableStateOf(false) }
    var selectedAccount by remember(state.accounts) { mutableStateOf(state.accounts.firstOrNull()) }
    var notes by remember { mutableStateOf("") }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var productSearch by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var showBarcodeScanner by remember { mutableStateOf(false) }

    val subtotalPaisa = remember(cart) {
        cart.sumOf { MoneyUtils.calculateLineTotalPaisa(it.quantityMilliUnits, it.unitPricePaisa) }
    }
    val discountPaisa = MoneyUtils.parseTakaToPaisa(discountText).coerceIn(0L, subtotalPaisa)
    val taxRateBps = ((taxPercentText.toDoubleOrNull() ?: 0.0) * 100).toInt().coerceIn(0, 10000)
    val taxPaisa = MoneyUtils.calculateTaxPaisa((subtotalPaisa - discountPaisa).coerceAtLeast(0L), taxRateBps)
    val grandTotalPaisa = (subtotalPaisa - discountPaisa + taxPaisa).coerceAtLeast(0L)

    LaunchedEffect(grandTotalPaisa, paidEditedManually) {
        if (!paidEditedManually) {
            paidText = if (grandTotalPaisa > 0L) MoneyUtils.paisaToInputString(grandTotalPaisa) else ""
        }
    }

    val paidPaisa = MoneyUtils.parseTakaToPaisa(paidText).coerceIn(0L, grandTotalPaisa)
    val duePaisa = grandTotalPaisa - paidPaisa

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Customer selector
        item {
            Surface(
                modifier = Modifier.fillMaxWidth().clickable { showCustomerPicker = true },
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldPrimary)
                        Column {
                            Text(selectedCustomer?.name ?: strings.walkInCustomer, style = MaterialTheme.typography.titleMedium)
                            Text(
                                selectedCustomer?.phone?.ifBlank { selectedCustomer?.customerCode ?: "" }
                                    ?: "Cash sale without customer",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    TextButton(onClick = { showCustomerPicker = true }) { Text("Change") }
                }
            }
        }

        // Inventory quick picker (if enabled and products exist)
        if (state.activeBusiness?.inventoryEnabled == true && state.products.isNotEmpty()) {
            item {
                val categories = remember(state.products) {
                    listOf("All") + state.products.map { it.category.ifBlank { "General" } }.distinct().sorted()
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = productSearch,
                            onValueChange = { productSearch = it },
                            label = { Text("Search product, SKU or barcode") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        FilledTonalIconButton(
                            onClick = { showBarcodeScanner = true },
                            modifier = Modifier.size(52.dp).testTag("pos_scan_barcode_button")
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = strings.scanBarcode)
                        }
                        FilledTonalIconButton(
                            onClick = onOpenVoiceEntry,
                            modifier = Modifier.size(52.dp).testTag("pos_voice_add_button")
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = strings.voiceAccountingTitle, tint = EmeraldPrimary)
                        }
                    }

                    if (categories.size > 2) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(categories) { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }

                    val filtered = state.products.filter { prod ->
                        val matchesCat = selectedCategory == "All" || prod.category.equals(selectedCategory, ignoreCase = true)
                        val matchesQuery = productSearch.isBlank() ||
                            prod.name.contains(productSearch, true) ||
                            prod.barcode.contains(productSearch, true) ||
                            prod.sku.contains(productSearch, true)
                        matchesCat && matchesQuery
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered.take(24), key = { it.id }) { prod ->
                            Surface(
                                modifier = Modifier.clickable {
                                    val existingIdx = cart.indexOfFirst { it.productId == prod.id }
                                    cart = if (existingIdx >= 0) {
                                        cart.mapIndexed { i, line ->
                                            if (i == existingIdx) line.copy(quantityMilliUnits = line.quantityMilliUnits + 1000L) else line
                                        }
                                    } else {
                                        cart + SaleCartLine(
                                            productId = prod.id,
                                            itemName = prod.name,
                                            unit = prod.unit,
                                            quantityMilliUnits = 1000L,
                                            unitPricePaisa = prod.sellingPricePaisa,
                                            costPricePaisa = prod.purchasePricePaisa
                                        )
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                color = SoftGreenAccent,
                                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(10.dp).widthIn(min = 116.dp)) {
                                    Text(prod.name, style = MaterialTheme.typography.titleSmall, color = DarkNavy, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        "${MoneyUtils.formatTaka(prod.sellingPricePaisa, useBn)} / ${prod.unit}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EmeraldPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Custom / Service line adder
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Add Item / Service Line", style = MaterialTheme.typography.titleSmall)
                    OutlinedTextField(
                        value = customItemName,
                        onValueChange = { customItemName = it },
                        label = { Text("Item or Service Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("pos_custom_item_name")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customQtyText,
                            onValueChange = { customQtyText = it },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("pos_custom_qty")
                        )
                        OutlinedTextField(
                            value = customPriceText,
                            onValueChange = { customPriceText = it },
                            label = { Text("Rate (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("pos_custom_price")
                        )
                    }
                    FilledTonalButton(
                        onClick = {
                            val qty = MoneyUtils.parseQtyToMilliUnits(customQtyText)
                            val price = MoneyUtils.parseTakaToPaisa(customPriceText)
                            if (customItemName.isNotBlank() && qty > 0L && price > 0L) {
                                cart = cart + SaleCartLine(
                                    itemName = customItemName.trim(),
                                    quantityMilliUnits = qty,
                                    unitPricePaisa = price
                                )
                                customItemName = ""
                                customQtyText = "1"
                                customPriceText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("pos_add_line_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Add to Bill")
                    }
                }
            }
        }

        // Cart lines with +/- steppers
        if (cart.isNotEmpty()) {
            items(cart.indices.toList()) { idx ->
                val line = cart[idx]
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(line.itemName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${MoneyUtils.milliUnitsToString(line.quantityMilliUnits, useBn)} ${line.unit} × ${MoneyUtils.formatTaka(line.unitPricePaisa, useBn)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    val nextQty = line.quantityMilliUnits - 1000L
                                    cart = if (nextQty <= 0L) {
                                        cart.filterIndexed { i, _ -> i != idx }
                                    } else {
                                        cart.mapIndexed { i, item -> if (i == idx) item.copy(quantityMilliUnits = nextQty) else item }
                                    }
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease qty")
                            }
                            Text(
                                MoneyUtils.formatTaka(MoneyUtils.calculateLineTotalPaisa(line.quantityMilliUnits, line.unitPricePaisa), useBn),
                                style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold)
                            )
                            IconButton(
                                onClick = {
                                    cart = cart.mapIndexed { i, item ->
                                        if (i == idx) item.copy(quantityMilliUnits = item.quantityMilliUnits + 1000L) else item
                                    }
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase qty", tint = EmeraldPrimary)
                            }
                            IconButton(
                                onClick = { cart = cart.filterIndexed { i, _ -> i != idx } },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = ExpenseRed)
                            }
                        }
                    }
                }
            }

            // Summary, Discount, Tax, Payment
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = discountText,
                                onValueChange = { discountText = it },
                                label = { Text("${strings.discount} (৳)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = taxPercentText,
                                onValueChange = { taxPercentText = it },
                                label = { Text("${strings.taxVat} (%)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(strings.subtotal, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(MoneyUtils.formatTaka(subtotalPaisa, useBn), fontFamily = MonoFontFamily)
                        }
                        if (taxPaisa > 0L) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(strings.taxVat, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(MoneyUtils.formatTaka(taxPaisa, useBn), fontFamily = MonoFontFamily)
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(strings.grandTotal, style = MaterialTheme.typography.titleMedium)
                            Text(
                                MoneyUtils.formatTaka(grandTotalPaisa, useBn),
                                style = MaterialTheme.typography.titleLarge.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                color = EmeraldPrimary
                            )
                        }

                        OutlinedTextField(
                            value = paidText,
                            onValueChange = { paidText = it; paidEditedManually = true },
                            label = { Text("${strings.paidAmount} (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("pos_paid_input")
                        )

                        if (duePaisa > 0L) {
                            Text(
                                text = "${strings.dueAmount}: ${MoneyUtils.formatTaka(duePaisa, useBn)}" +
                                    if (selectedCustomer == null) " (Select a customer for credit sale!)" else "",
                                color = if (selectedCustomer == null) ExpenseRed else WarningAmber,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(state.accounts) { acc ->
                                FilterChip(
                                    selected = selectedAccount?.id == acc.id,
                                    onClick = { selectedAccount = acc },
                                    label = { Text(acc.name) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Invoice Notes") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                val accId = selectedAccount?.id ?: state.accounts.firstOrNull()?.id.orEmpty()
                                if (cart.isNotEmpty() && accId.isNotBlank() && !(duePaisa > 0L && selectedCustomer == null)) {
                                    onSubmitSale(selectedCustomer?.id, cart, discountPaisa, taxRateBps, paidPaisa, accId, notes)
                                    cart = emptyList()
                                    discountText = ""
                                    paidText = ""
                                    paidEditedManually = false
                                    notes = ""
                                }
                            },
                            enabled = cart.isNotEmpty() && !(duePaisa > 0L && selectedCustomer == null),
                            modifier = Modifier.fillMaxWidth().height(52.dp).testTag("pos_complete_sale"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.Receipt, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(strings.completeSale)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showCustomerPicker) {
        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("Select Customer") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                    item {
                        ListItem(
                            headlineContent = { Text(strings.walkInCustomer) },
                            modifier = Modifier.clickable { selectedCustomer = null; showCustomerPicker = false }
                        )
                    }
                    items(state.customers, key = { it.id }) { c ->
                        ListItem(
                            headlineContent = { Text(c.name) },
                            supportingContent = { Text("${c.customerCode} • ${c.phone}") },
                            modifier = Modifier.clickable { selectedCustomer = c; showCustomerPicker = false }
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCustomerPicker = false }) { Text("Close") } }
        )
    }

    if (showBarcodeScanner) {
        BarcodeScannerDialog(
            products = state.products,
            onBarcodeDetected = { code ->
                showBarcodeScanner = false
                val match = state.products.firstOrNull {
                    it.barcode.equals(code, ignoreCase = true) || it.sku.equals(code, ignoreCase = true)
                }
                if (match != null) {
                    val existingIdx = cart.indexOfFirst { it.productId == match.id }
                    cart = if (existingIdx >= 0) {
                        cart.mapIndexed { i, line ->
                            if (i == existingIdx) line.copy(quantityMilliUnits = line.quantityMilliUnits + 1000L) else line
                        }
                    } else {
                        cart + SaleCartLine(
                            productId = match.id,
                            itemName = match.name,
                            unit = match.unit,
                            quantityMilliUnits = 1000L,
                            unitPricePaisa = match.sellingPricePaisa,
                            costPricePaisa = match.purchasePricePaisa
                        )
                    }
                } else {
                    productSearch = code
                }
            },
            onDismiss = { showBarcodeScanner = false }
        )
    }
}

@Composable
private fun PurchaseTab(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    onRecordPurchase: (String?, List<SaleCartLine>, Long, String, String) -> Unit
) {
    var selectedSupplier by remember { mutableStateOf<SupplierEntity?>(null) }
    var itemName by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("1") }
    var priceText by remember { mutableStateOf("") }
    var selectedProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var cart by remember { mutableStateOf<List<SaleCartLine>>(emptyList()) }
    var paidText by remember { mutableStateOf("") }
    var selectedAccount by remember(state.accounts) { mutableStateOf(state.accounts.firstOrNull()) }
    var notes by remember { mutableStateOf("") }

    val total = cart.sumOf { MoneyUtils.calculateLineTotalPaisa(it.quantityMilliUnits, it.unitPricePaisa) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text("Supplier", style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    FilterChip(selected = selectedSupplier == null, onClick = { selectedSupplier = null }, label = { Text("Cash Supplier") })
                }
                items(state.suppliers, key = { it.id }) { s ->
                    FilterChip(selected = selectedSupplier?.id == s.id, onClick = { selectedSupplier = s }, label = { Text(s.name) })
                }
            }
        }

        if (state.products.isNotEmpty()) {
            item {
                Text("Select Inventory Product (Optional)", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(state.products, key = { it.id }) { p ->
                        FilterChip(
                            selected = selectedProduct?.id == p.id,
                            onClick = {
                                selectedProduct = p
                                itemName = p.name
                                priceText = MoneyUtils.paisaToInputString(p.purchasePricePaisa)
                            },
                            label = { Text(p.name) }
                        )
                    }
                }
            }
        }

        item {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = itemName, onValueChange = { itemName = it }, label = { Text("Purchased Item") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = priceText, onValueChange = { priceText = it }, label = { Text("Unit Cost (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                    FilledTonalButton(
                        onClick = {
                            val qty = MoneyUtils.parseQtyToMilliUnits(qtyText)
                            val cost = MoneyUtils.parseTakaToPaisa(priceText)
                            if (itemName.isNotBlank() && qty > 0L && cost > 0L) {
                                cart = cart + SaleCartLine(
                                    productId = selectedProduct?.id,
                                    itemName = itemName.trim(),
                                    unit = selectedProduct?.unit ?: "Piece",
                                    quantityMilliUnits = qty,
                                    unitPricePaisa = cost,
                                    costPricePaisa = cost
                                )
                                selectedProduct = null; itemName = ""; qtyText = "1"; priceText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Add Purchase Item") }
                }
            }
        }

        items(cart.indices.toList()) { idx ->
            val l = cart[idx]
            ListItem(
                headlineContent = { Text(l.itemName) },
                supportingContent = { Text("${MoneyUtils.milliUnitsToString(l.quantityMilliUnits, useBn)} × ${MoneyUtils.formatTaka(l.unitPricePaisa, useBn)}") },
                trailingContent = {
                    Text(MoneyUtils.formatTaka(MoneyUtils.calculateLineTotalPaisa(l.quantityMilliUnits, l.unitPricePaisa), useBn))
                }
            )
        }

        if (cart.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Total Purchase: ${MoneyUtils.formatTaka(total, useBn)}", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = paidText, onValueChange = { paidText = it }, label = { Text("Paid Amount (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(state.accounts) { acc ->
                            FilterChip(selected = selectedAccount?.id == acc.id, onClick = { selectedAccount = acc }, label = { Text(acc.name) })
                        }
                    }
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            val accId = selectedAccount?.id ?: state.accounts.firstOrNull()?.id.orEmpty()
                            if (accId.isNotBlank()) {
                                onRecordPurchase(selectedSupplier?.id, cart, MoneyUtils.parseTakaToPaisa(paidText), accId, notes)
                                cart = emptyList(); paidText = ""; notes = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) { Text("Save Purchase Entry") }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun IncomeExpenseTab(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    onSubmit: (Boolean, Long, String?, String, String, String, String?) -> Unit,
    onCreateCategory: (String, String) -> Unit
) {
    val strings = LocalAppStrings.current
    var isExpense by remember { mutableStateOf(true) }
    val typeFilter = if (isExpense) "EXPENSE" else "INCOME"
    val cats = remember(state.categories, typeFilter) { state.categories.filter { it.type == typeFilter } }
    var selectedCat by remember(cats) { mutableStateOf(cats.firstOrNull()) }
    var amountText by remember { mutableStateOf("") }
    var selectedAccount by remember(state.accounts) { mutableStateOf(state.accounts.firstOrNull()) }
    var notes by remember { mutableStateOf("") }
    var attachmentUri by remember { mutableStateOf<String?>(null) }
    var showNewCatDialog by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) attachmentUri = uri.toString()
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(selected = isExpense, onClick = { isExpense = true }, shape = SegmentedButtonDefaults.itemShape(0, 2)) {
                    Text(if (strings.isBangla) "ব্যয় (Expense)" else "Expense")
                }
                SegmentedButton(selected = !isExpense, onClick = { isExpense = false }, shape = SegmentedButtonDefaults.itemShape(1, 2)) {
                    Text(if (strings.isBangla) "আয় (Income)" else "Income")
                }
            }
        }

        item {
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text("Amount (৳)") },
                prefix = { Text("৳ ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("inc_exp_amount")
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Category", style = MaterialTheme.typography.titleSmall)
                TextButton(onClick = { showNewCatDialog = true }) { Text("+ Custom Category") }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                cats.forEach { cat ->
                    FilterChip(
                        selected = selectedCat?.id == cat.id,
                        onClick = { selectedCat = cat },
                        label = { Text(if (strings.isBangla) cat.nameBn else cat.name) }
                    )
                }
            }
        }

        item {
            Text("Payment Account", style = MaterialTheme.typography.titleSmall)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.accounts) { acc ->
                    FilterChip(selected = selectedAccount?.id == acc.id, onClick = { selectedAccount = acc }, label = { Text(acc.name) })
                }
            }
        }

        item {
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Description / Notes") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedButton(
                onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.AttachFile, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (attachmentUri == null) "Attach Receipt Photo (Optional)" else "Receipt Attached")
            }
        }

        item {
            Button(
                onClick = {
                    val paisa = MoneyUtils.parseTakaToPaisa(amountText)
                    val accId = selectedAccount?.id ?: state.accounts.firstOrNull()?.id.orEmpty()
                    val catName = selectedCat?.name ?: if (isExpense) "Other Expenses" else "Other Income"
                    if (paisa > 0L && accId.isNotBlank()) {
                        onSubmit(isExpense, paisa, selectedCat?.id, catName, accId, notes, attachmentUri)
                        amountText = ""
                        notes = ""
                        attachmentUri = null
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("inc_exp_submit")
            ) {
                Text(if (isExpense) strings.addExpense else "Record Income")
            }
        }
    }

    if (showNewCatDialog) {
        var newCat by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNewCatDialog = false },
            title = { Text("Custom Category") },
            text = { OutlinedTextField(value = newCat, onValueChange = { newCat = it }, label = { Text("Category Name") }) },
            confirmButton = {
                Button(onClick = {
                    if (newCat.isNotBlank()) {
                        onCreateCategory(newCat, typeFilter)
                        showNewCatDialog = false
                    }
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showNewCatDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun CashbookTab(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    onSaveAccount: (String, String, String, Long) -> Unit,
    onTransfer: (String, String, Long, String) -> Unit
) {
    val strings = LocalAppStrings.current
    var showTransferDialog by remember { mutableStateOf(false) }
    var showAddAccountDialog by remember { mutableStateOf(false) }
    var selectedAccountFilter by remember { mutableStateOf<String?>(null) }

    val cashbookTxs = remember(state.transactions, selectedAccountFilter) {
        state.transactions.filter { tx ->
            val matchesAcc = selectedAccountFilter == null || tx.accountId == selectedAccountFilter || tx.toAccountId == selectedAccountFilter
            matchesAcc && (tx.cashFlowDeltaPaisa != 0L || tx.type == TxTypes.ACCOUNT_TRANSFER)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { showTransferDialog = true },
                    modifier = Modifier.weight(1f).testTag("cashbook_transfer_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Transfer")
                }
                OutlinedButton(
                    onClick = { showAddAccountDialog = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.AddCard, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add Account")
                }
            }
        }

        items(state.accounts, key = { it.id }) { acc ->
            val selected = selectedAccountFilter == acc.id
            Surface(
                modifier = Modifier.fillMaxWidth().clickable {
                    selectedAccountFilter = if (selected) null else acc.id
                },
                shape = RoundedCornerShape(14.dp),
                color = if (selected) SoftGreenAccent else MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) EmeraldPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(acc.name, style = MaterialTheme.typography.titleMedium, color = if (selected) DarkNavy else MaterialTheme.colorScheme.onSurface)
                        Text("${acc.type} ${if (acc.accountNumber.isNotBlank()) "• ${acc.accountNumber}" else ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        MoneyUtils.formatTaka(acc.currentBalancePaisa, useBn),
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                        color = if (acc.currentBalancePaisa >= 0) EmeraldPrimary else ExpenseRed
                    )
                }
            }
        }

        item {
            Text(
                text = if (selectedAccountFilter == null) "All Cashbook Entries" else "Filtered Account Entries",
                style = MaterialTheme.typography.titleMedium
            )
        }

        if (cashbookTxs.isEmpty()) {
            item { EmptyStateCard(Icons.Default.AccountBalanceWallet, strings.noDataYet, "Cash, Bank, bKash, Nagad movements appear here.") }
        } else {
            items(cashbookTxs.take(50), key = { it.id }) { tx ->
                TransactionRowCard(tx = tx, useBanglaDigits = useBn, onClick = {})
            }
        }
    }

    if (showTransferDialog && state.accounts.size >= 2) {
        var fromAcc by remember { mutableStateOf(state.accounts.first()) }
        var toAcc by remember { mutableStateOf(state.accounts[1]) }
        var amtText by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showTransferDialog = false },
            title = { Text(strings.accountTransfer) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("From Account", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(state.accounts) { a ->
                            FilterChip(selected = fromAcc.id == a.id, onClick = { fromAcc = a }, label = { Text(a.name) })
                        }
                    }
                    Text("To Account", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(state.accounts) { a ->
                            FilterChip(selected = toAcc.id == a.id, onClick = { toAcc = a }, label = { Text(a.name) })
                        }
                    }
                    OutlinedTextField(value = amtText, onValueChange = { amtText = it }, label = { Text("Amount (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    val p = MoneyUtils.parseTakaToPaisa(amtText)
                    if (p > 0L && fromAcc.id != toAcc.id) {
                        onTransfer(fromAcc.id, toAcc.id, p, notes)
                        showTransferDialog = false
                    }
                }) { Text("Transfer") }
            },
            dismissButton = { TextButton(onClick = { showTransferDialog = false }) { Text("Cancel") } }
        )
    }

    if (showAddAccountDialog) {
        var name by remember { mutableStateOf("") }
        var type by remember { mutableStateOf(AccountTypes.BANK) }
        var number by remember { mutableStateOf("") }
        var openBal by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddAccountDialog = false },
            title = { Text("Add Financial Account") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Account Name") })
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf(AccountTypes.CASH, AccountTypes.BANK, AccountTypes.BKASH, AccountTypes.NAGAD, AccountTypes.ROCKET, AccountTypes.CUSTOM)) { t ->
                            FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) })
                        }
                    }
                    OutlinedTextField(value = number, onValueChange = { number = it }, label = { Text("Account / Wallet No.") })
                    OutlinedTextField(value = openBal, onValueChange = { openBal = it }, label = { Text("Opening Balance (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        onSaveAccount(name, type, number, MoneyUtils.parseTakaToPaisa(openBal))
                        showAddAccountDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddAccountDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun LedgerHistoryAndReturnsTab(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    onRecordReturn: (String, String?, String?, String?, Long, Long, Boolean, String, String) -> Unit,
    onRequestReverse: (AccountingTransactionEntity) -> Unit
) {
    var showReturnDialog by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            FilledTonalButton(
                onClick = { showReturnDialog = true },
                modifier = Modifier.fillMaxWidth().testTag("open_return_adjustment_button")
            ) {
                Icon(Icons.Default.AssignmentReturn, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Record Sale/Purchase Return or Correction")
            }
        }

        if (state.transactions.isEmpty()) {
            item { EmptyStateCard(Icons.Default.History, "No ledger entries", "Every financial transaction has a traceable audit entry here.") }
        } else {
            items(state.transactions, key = { it.id }) { tx ->
                TransactionRowCard(
                    tx = tx,
                    useBanglaDigits = useBn,
                    onClick = {
                        if (!tx.isReversed && tx.type != TxTypes.REVERSAL) {
                            onRequestReverse(tx)
                        }
                    }
                )
            }
        }
    }

    if (showReturnDialog) {
        var retType by remember { mutableStateOf(TxTypes.SALE_RETURN) }
        var selectedCust by remember { mutableStateOf<CustomerEntity?>(null) }
        var selectedSup by remember { mutableStateOf<SupplierEntity?>(null) }
        var selectedProd by remember { mutableStateOf<ProductEntity?>(null) }
        var qtyText by remember { mutableStateOf("1") }
        var amountText by remember { mutableStateOf("") }
        var refundCash by remember { mutableStateOf(true) }
        var selectedAcc by remember { mutableStateOf(state.accounts.firstOrNull()) }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showReturnDialog = false },
            title = { Text("Return / Payment Correction") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(
                            listOf(
                                TxTypes.SALE_RETURN to "Sale Return",
                                TxTypes.PURCHASE_RETURN to "Purchase Return",
                                TxTypes.PAYMENT_CORRECTION to "Pay Correction"
                            )
                        ) { (t, lbl) ->
                            FilterChip(selected = retType == t, onClick = { retType = t }, label = { Text(lbl) })
                        }
                    }
                    if (retType == TxTypes.SALE_RETURN && state.customers.isNotEmpty()) {
                        Text("Customer (Optional)", style = MaterialTheme.typography.labelMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(state.customers) { c ->
                                FilterChip(selected = selectedCust?.id == c.id, onClick = { selectedCust = c }, label = { Text(c.name) })
                            }
                        }
                    }
                    if (retType == TxTypes.PURCHASE_RETURN && state.suppliers.isNotEmpty()) {
                        Text("Supplier (Optional)", style = MaterialTheme.typography.labelMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(state.suppliers) { s ->
                                FilterChip(selected = selectedSup?.id == s.id, onClick = { selectedSup = s }, label = { Text(s.name) })
                            }
                        }
                    }
                    if (retType != TxTypes.PAYMENT_CORRECTION && state.products.isNotEmpty()) {
                        Text("Product (Optional)", style = MaterialTheme.typography.labelMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(state.products) { p ->
                                FilterChip(selected = selectedProd?.id == p.id, onClick = { selectedProd = p }, label = { Text(p.name) })
                            }
                        }
                        OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Returned Qty") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    }
                    OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Cash Refund / Payout?", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = refundCash, onCheckedChange = { refundCash = it })
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(state.accounts) { a ->
                            FilterChip(selected = selectedAcc?.id == a.id, onClick = { selectedAcc = a }, label = { Text(a.name) })
                        }
                    }
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amt = MoneyUtils.parseTakaToPaisa(amountText)
                    val qty = MoneyUtils.parseQtyToMilliUnits(qtyText)
                    val accId = selectedAcc?.id ?: state.accounts.firstOrNull()?.id.orEmpty()
                    if (amt > 0L && accId.isNotBlank()) {
                        onRecordReturn(retType, selectedCust?.id, selectedSup?.id, selectedProd?.id, qty, amt, refundCash, accId, notes)
                        showReturnDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showReturnDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun InvoicePreviewDialog(
    invoice: InvoiceEntity,
    business: BusinessEntity?,
    useBanglaDigits: Boolean,
    onLoadItems: suspend (String) -> List<InvoiceItemEntity>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalAppStrings.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<InvoiceItemEntity>>(emptyList()) }
    LaunchedEffect(invoice.id) {
        items = onLoadItems(invoice.id)
    }

    val barcodeBmp = remember(invoice.invoiceNumber) {
        BarcodeScannerHelper.generateCode128Bitmap(invoice.invoiceNumber, 480, 96)
    }

    var showThermalDialog by remember { mutableStateOf(false) }
    var printers by remember { mutableStateOf<List<PairedPrinterDevice>>(emptyList()) }
    var thermalMessage by remember { mutableStateOf<String?>(null) }
    var isThermalPrinting by remember { mutableStateOf(false) }

    fun loadPrinters() {
        ThermalPrinterHelper.listPairedPrinters(context)
            .onSuccess {
                printers = it
                thermalMessage = if (it.isEmpty()) "No paired Bluetooth thermal printers found. Pair printer in Android Bluetooth settings." else null
            }
            .onFailure {
                printers = emptyList()
                thermalMessage = it.message
            }
    }

    val btPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            loadPrinters()
            showThermalDialog = true
        } else {
            thermalMessage = "Bluetooth permission is required for thermal printing."
            showThermalDialog = true
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Invoice ${invoice.invoiceNumber}") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Party: ${invoice.partyName}", style = MaterialTheme.typography.titleSmall)
                Text("Date: ${MoneyUtils.formatDhakaDateTime(invoice.occurredAt, useBanglaDigits)}", style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                items.forEach { item ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${item.itemName} (${MoneyUtils.milliUnitsToString(item.quantityMilliUnits, useBanglaDigits)})", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(MoneyUtils.formatTaka(item.lineTotalPaisa, useBanglaDigits), fontFamily = MonoFontFamily)
                    }
                }
                HorizontalDivider()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Grand Total", fontWeight = FontWeight.Bold)
                    Text(MoneyUtils.formatTaka(invoice.totalPaisa, useBanglaDigits), fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Paid")
                    Text(MoneyUtils.formatTaka(invoice.paidPaisa, useBanglaDigits), fontFamily = MonoFontFamily)
                }
                if (invoice.duePaisa > 0L) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Due", color = WarningAmber)
                        Text(MoneyUtils.formatTaka(invoice.duePaisa, useBanglaDigits), fontFamily = MonoFontFamily, color = WarningAmber)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Image(
                    bitmap = barcodeBmp.asImageBitmap(),
                    contentDescription = "Invoice barcode ${invoice.invoiceNumber}",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                )
            }
        },
        confirmButton = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val biz = business ?: return@OutlinedButton
                        val pdf = ExportUtils.generateInvoicePdf(context, biz, invoice, items, useBanglaDigits)
                        ExportUtils.printPdfDocument(context, pdf, invoice.invoiceNumber)
                    }) { Text("Print PDF") }
                    Button(onClick = {
                        val biz = business ?: return@Button
                        val pdf = ExportUtils.generateInvoicePdf(context, biz, invoice, items, useBanglaDigits)
                        ExportUtils.shareFile(context, pdf, "application/pdf", "Share Invoice ${invoice.invoiceNumber}")
                    }) { Text("Share PDF") }
                }
                FilledTonalButton(
                    onClick = {
                        if (ThermalPrinterHelper.hasBluetoothPermission(context)) {
                            loadPrinters()
                            showThermalDialog = true
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            btPermLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("invoice_thermal_print_button")
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.thermalPrint)
                }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )

    if (showThermalDialog && business != null) {
        val receiptPreview = remember(invoice.id, items) {
            ThermalPrinterHelper.buildThermalReceiptText(business, invoice, items)
        }
        AlertDialog(
            onDismissRequest = { showThermalDialog = false },
            title = { Text(strings.bluetoothPrinters) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    thermalMessage?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = WarningAmber)
                    }
                    printers.forEach { dev ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isThermalPrinting) {
                                    isThermalPrinting = true
                                    scope.launch {
                                        val payload = ThermalPrinterHelper.buildEscPosPayload(business, invoice, items)
                                        val res = ThermalPrinterHelper.printEscPosOverBluetooth(context, dev.address, payload)
                                        isThermalPrinting = false
                                        thermalMessage = res.fold(
                                            onSuccess = { "Printed cleanly to ${dev.name}!" },
                                            onFailure = { err -> "Print failed: ${err.message}" }
                                        )
                                    }
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = SoftGreenAccent
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(dev.name, style = MaterialTheme.typography.titleSmall, color = DarkNavy)
                                    Text(dev.address, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                                }
                                Icon(Icons.Default.Print, contentDescription = "Print to ${dev.name}", tint = EmeraldPrimary)
                            }
                        }
                    }
                    HorizontalDivider()
                    Text("58mm Receipt Preview", style = MaterialTheme.typography.labelMedium)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Text(
                            receiptPreview,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = MonoFontFamily,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThermalDialog = false }) { Text("Done") }
            }
        )
    }
}
