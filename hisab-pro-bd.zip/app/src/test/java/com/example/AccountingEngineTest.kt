package com.example

import com.example.core.util.MoneyUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class AccountingEngineTest {

    @Test
    fun `taka to paisa parsing and bangla formatting are exact`() {
        assertEquals(12500050L, MoneyUtils.parseTakaToPaisa("1,25,000.50"))
        assertEquals(1000000L, MoneyUtils.parseTakaToPaisa("৳১০,০০০"))
        assertEquals("৳1,25,000", MoneyUtils.formatTaka(12500000L, useBanglaDigits = false))
        assertEquals("৳১০,০০০", MoneyUtils.formatTaka(1000000L, useBanglaDigits = true))
        assertEquals("-৳500", MoneyUtils.formatTaka(-50000L, useBanglaDigits = false))
    }

    @Test
    fun `decimal safe line total and tax calculations use HALF_UP rounding`() {
        // 2.5 kg * ৳125.50 = ৳313.75 -> 31375 paisa
        val qtyMilli = MoneyUtils.parseQtyToMilliUnits("2.5")
        val unitPaisa = MoneyUtils.parseTakaToPaisa("125.50")
        assertEquals(2500L, qtyMilli)
        assertEquals(12550L, unitPaisa)
        assertEquals(31375L, MoneyUtils.calculateLineTotalPaisa(qtyMilli, unitPaisa))

        // 15% VAT (1500 bps) on ৳10,000 = ৳1,500
        assertEquals(150000L, MoneyUtils.calculateTaxPaisa(1_000_000L, 1500))
    }

    @Test
    fun `bangladesh phone formatting handles 01x and 880x and bangla digits`() {
        assertEquals("+880 1712-345678", MoneyUtils.formatBdPhone("01712345678"))
        assertEquals("+880 1811-223344", MoneyUtils.formatBdPhone("০১৮১১২২৩৩৪৪"))
        assertEquals("+880 1911-000111", MoneyUtils.formatBdPhone("+8801911000111"))
    }

    @Test
    fun `dhaka utc+6 today bounds span exact 24h minus 1ms in Asia Dhaka`() {
        val sampleMillis = 1764000000000L
        val (start, end) = MoneyUtils.dhakaTodayBounds(sampleMillis)
        assertTrue(sampleMillis in start..end)
        assertEquals(86_399_999L, end - start)
        val startDate = Instant.ofEpochMilli(start).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate()
        val endDate = Instant.ofEpochMilli(end).atZone(MoneyUtils.DHAKA_ZONE).toLocalDate()
        assertEquals(startDate, endDate)
    }
}
