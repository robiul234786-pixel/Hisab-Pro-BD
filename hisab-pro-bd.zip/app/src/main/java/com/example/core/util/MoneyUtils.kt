package com.example.core.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

object MoneyUtils {
    val DHAKA_ZONE: ZoneId = ZoneId.of("Asia/Dhaka")
    private val HUNDRED = BigDecimal(100)
    private val TEN_THOUSAND = BigDecimal(10000)
    private val THOUSAND = BigDecimal(1000)

    fun parseTakaToPaisa(input: String): Long {
        val normalized = normalizeDigits(input).replace(",", "").replace("৳", "").trim()
        if (normalized.isBlank()) return 0L
        return try {
            BigDecimal(normalized)
                .multiply(HUNDRED)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
        } catch (_: Exception) {
            0L
        }
    }

    fun paisaToInputString(paisa: Long): String {
        if (paisa == 0L) return ""
        val bd = BigDecimal(paisa).divide(HUNDRED, 2, RoundingMode.HALF_UP).stripTrailingZeros()
        return bd.toPlainString()
    }

    fun parseQtyToMilliUnits(input: String): Long {
        val normalized = normalizeDigits(input).replace(",", "").trim()
        if (normalized.isBlank()) return 0L
        return try {
            BigDecimal(normalized)
                .multiply(THOUSAND)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
        } catch (_: Exception) {
            0L
        }
    }

    fun milliUnitsToString(milliUnits: Long, useBanglaDigits: Boolean = false): String {
        val bd = BigDecimal(milliUnits).divide(THOUSAND, 3, RoundingMode.HALF_UP).stripTrailingZeros()
        val raw = bd.toPlainString()
        return if (useBanglaDigits) toBanglaDigits(raw) else raw
    }

    /**
     * Exact decimal-safe line total calculation:
     * (quantityMilliUnits / 1000) * unitPricePaisa, rounded HALF_UP to nearest Paisa.
     */
    fun calculateLineTotalPaisa(quantityMilliUnits: Long, unitPricePaisa: Long): Long {
        if (quantityMilliUnits == 0L || unitPricePaisa == 0L) return 0L
        return BigDecimal(quantityMilliUnits)
            .multiply(BigDecimal(unitPricePaisa))
            .divide(THOUSAND, 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    /**
     * Exact decimal-safe tax calculation:
     * taxablePaisa * (taxRateBps / 10000), rounded HALF_UP.
     */
    fun calculateTaxPaisa(taxablePaisa: Long, taxRateBps: Int): Long {
        if (taxablePaisa <= 0L || taxRateBps <= 0) return 0L
        return BigDecimal(taxablePaisa)
            .multiply(BigDecimal(taxRateBps))
            .divide(TEN_THOUSAND, 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    fun calculatePercentageAmountPaisa(basePaisa: Long, percentBps: Int): Long {
        if (basePaisa <= 0L || percentBps <= 0) return 0L
        return BigDecimal(basePaisa)
            .multiply(BigDecimal(percentBps))
            .divide(TEN_THOUSAND, 0, RoundingMode.HALF_UP)
            .longValueExact()
    }

    fun formatTaka(
        paisa: Long,
        useBanglaDigits: Boolean = false,
        showSign: Boolean = false
    ): String {
        val sign = when {
            paisa < 0L -> "-"
            showSign && paisa > 0L -> "+"
            else -> ""
        }
        val absPaisa = abs(paisa)
        val whole = absPaisa / 100L
        val frac = (absPaisa % 100L).toInt()
        val grouped = formatIndianSubcontinentGrouping(whole)
        val formatted = if (frac == 0) {
            "${sign}৳$grouped"
        } else {
            val fracStr = frac.toString().padStart(2, '0')
            "${sign}৳$grouped.$fracStr"
        }
        return if (useBanglaDigits) toBanglaDigits(formatted) else formatted
    }

    private fun formatIndianSubcontinentGrouping(number: Long): String {
        val s = number.toString()
        if (s.length <= 3) return s
        val lastThree = s.takeLast(3)
        val rest = s.dropLast(3)
        val sb = StringBuilder()
        var idx = rest.length
        val chunks = mutableListOf<String>()
        while (idx > 0) {
            val start = maxOf(0, idx - 2)
            chunks.add(rest.substring(start, idx))
            idx = start
        }
        chunks.reversed().forEach {
            sb.append(it).append(',')
        }
        sb.append(lastThree)
        return sb.toString()
    }

    fun normalizeDigits(input: String): String {
        val bn = "০১২৩৪৫৬৭৮৯"
        val sb = StringBuilder(input.length)
        for (ch in input) {
            val idx = bn.indexOf(ch)
            if (idx >= 0) sb.append(('0'.code + idx).toChar()) else sb.append(ch)
        }
        return sb.toString()
    }

    fun toBanglaDigits(input: String): String {
        val bn = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val sb = StringBuilder(input.length)
        for (ch in input) {
            if (ch in '0'..'9') sb.append(bn[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    fun formatBdPhone(raw: String): String {
        val digits = normalizeDigits(raw).filter { it.isDigit() }
        return when {
            digits.startsWith("880") && digits.length == 13 -> "+880 ${digits.substring(3, 7)}-${digits.substring(7)}"
            digits.startsWith("01") && digits.length == 11 -> "+880 ${digits.substring(1, 5)}-${digits.substring(5)}"
            else -> raw.trim()
        }
    }

    fun formatDhakaDate(epochMillis: Long, isBangla: Boolean = false): String {
        val zdt = Instant.ofEpochMilli(epochMillis).atZone(DHAKA_ZONE)
        val formatted = zdt.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH))
        return if (isBangla) toBanglaDigits(formatted) else formatted
    }

    fun formatDhakaDateTime(epochMillis: Long, isBangla: Boolean = false): String {
        val zdt = Instant.ofEpochMilli(epochMillis).atZone(DHAKA_ZONE)
        val formatted = zdt.format(DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.ENGLISH))
        return if (isBangla) toBanglaDigits(formatted) else formatted
    }

    fun dhakaTodayBounds(nowMillis: Long = System.currentTimeMillis()): Pair<Long, Long> {
        val date = Instant.ofEpochMilli(nowMillis).atZone(DHAKA_ZONE).toLocalDate()
        val start = date.atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli()
        val end = date.plusDays(1).atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli() - 1L
        return start to end
    }

    fun dhakaWeekBounds(nowMillis: Long = System.currentTimeMillis()): Pair<Long, Long> {
        val date = Instant.ofEpochMilli(nowMillis).atZone(DHAKA_ZONE).toLocalDate()
        val start = date.minusDays(6).atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli()
        val end = date.plusDays(1).atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli() - 1L
        return start to end
    }

    fun dhakaMonthBounds(nowMillis: Long = System.currentTimeMillis()): Pair<Long, Long> {
        val date = Instant.ofEpochMilli(nowMillis).atZone(DHAKA_ZONE).toLocalDate()
        val firstDay = date.withDayOfMonth(1)
        val start = firstDay.atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli()
        val end = firstDay.plusMonths(1).atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli() - 1L
        return start to end
    }

    fun dhakaYearBounds(nowMillis: Long = System.currentTimeMillis()): Pair<Long, Long> {
        val date = Instant.ofEpochMilli(nowMillis).atZone(DHAKA_ZONE).toLocalDate()
        val firstDay = LocalDate.of(date.year, 1, 1)
        val start = firstDay.atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli()
        val end = firstDay.plusYears(1).atStartOfDay(DHAKA_ZONE).toInstant().toEpochMilli() - 1L
        return start to end
    }
}
