package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.BuildConfig
import com.example.core.util.AppLanguage
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.*
import com.example.data.remote.FirebaseAuthHelper
import com.example.data.remote.GitHubReleaseUpdater
import com.example.data.remote.UpdateUiState
import com.example.ui.BusinessWorkspaceState
import com.example.ui.components.*
import com.example.ui.theme.*
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    state: BusinessWorkspaceState,
    isSyncing: Boolean,
    updateState: UpdateUiState,
    onUpdateBusiness: (BusinessEntity) -> Unit,
    onSaveProduct: (
        existingId: String?,
        name: String,
        sku: String,
        barcode: String,
        category: String,
        buyPaisa: Long,
        sellPaisa: Long,
        stockMilli: Long,
        unit: String,
        lowStockMilli: Long,
        imageUri: String?
    ) -> Unit,
    onAdjustStock: (productId: String, type: String, deltaMilli: Long, notes: String) -> Unit,
    onSaveEmployee: (name: String, phone: String, role: String) -> Unit,
    onSaveEmployeeExtended: (name: String, phone: String, email: String, role: String, salaryPaisa: Long, existingId: String?) -> Unit,
    onRemoveEmployee: (String) -> Unit,
    onSetActiveEmployee: (String) -> Unit,
    onRecordAttendance: (employeeId: String, dateKey: String, status: String, notes: String) -> Unit,
    onSubmitLeave: (employeeId: String, startDateKey: String, endDateKey: String, leaveType: String, reason: String) -> Unit,
    onDecideLeave: (requestId: String, approved: Boolean) -> Unit,
    onRecordSalary: (employeeId: String, monthKey: String, paymentType: String, amountPaisa: Long, accountId: String, notes: String) -> Unit,
    onUpdateRolePermission: (RolePermissionEntity) -> Unit,
    onSetPin: (String) -> Unit,
    onRemovePin: () -> Unit,
    onSetBiometric: (Boolean) -> Unit,
    onSetLanguage: (String) -> Unit,
    onSetBanglaDigits: (Boolean) -> Unit,
    onSetDarkMode: (String) -> Unit,
    onUpdateNotifications: (Boolean, Boolean, Boolean, Boolean) -> Unit,
    onExportBackupUri: (Uri) -> Unit,
    onExportBackupWithPassphrase: (Uri, String?) -> Unit,
    onRestoreBackupUri: (Uri) -> Unit,
    onSyncToCloud: (String) -> Unit,
    onRestoreFromCloud: (String) -> Unit,
    onOpenSyncDevices: () -> Unit,
    onCheckForUpdate: (String) -> Unit,
    onDownloadUpdate: () -> Unit,
    onResetUpdateState: () -> Unit
) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { currentUser = it.currentUser }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }
    var authError by remember { mutableStateOf<String?>(null) }
    var authLoading by remember { mutableStateOf(false) }

    var showInventorySheet by remember { mutableStateOf(false) }
    var showEmployeesSheet by remember { mutableStateOf(false) }
    var showBusinessEditDialog by remember { mutableStateOf(false) }
    var showSetPinDialog by remember { mutableStateOf(false) }
    var showEncryptedExportDialog by remember { mutableStateOf(false) }
    var pendingExportPassphrase by remember { mutableStateOf<String?>(null) }

    val createBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) onExportBackupUri(uri) }

    val createEncryptedBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val pass = pendingExportPassphrase
        pendingExportPassphrase = null
        if (uri != null && !pass.isNullOrBlank()) {
            onExportBackupWithPassphrase(uri, pass)
        }
    }

    val openBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) onRestoreBackupUri(uri) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    var pendingInstallApkPath by remember { mutableStateOf<String?>(null) }
    val unknownSourcesLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        val path = pendingInstallApkPath
        if (path != null && GitHubReleaseUpdater.canInstallPackages(context)) {
            GitHubReleaseUpdater.launchApkInstaller(context, File(path))
            pendingInstallApkPath = null
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(strings.tabSettings, style = MaterialTheme.typography.headlineSmall)
        }

        // 1. Business Profile & Inventory Toggle
        item {
            val biz = state.activeBusiness
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(biz?.name ?: strings.appTitle, style = MaterialTheme.typography.titleMedium)
                            Text("${biz?.category ?: ""} • ${biz?.phone ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { showBusinessEditDialog = true }) { Text("Edit") }
                    }
                    if (biz != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(strings.enableInventory, style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = biz.inventoryEnabled,
                                onCheckedChange = { onUpdateBusiness(biz.copy(inventoryEnabled = it)) }
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Enable VAT / Tax Billing", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = biz.taxEnabled,
                                onCheckedChange = { onUpdateBusiness(biz.copy(taxEnabled = it)) }
                            )
                        }
                    }
                }
            }
        }

        // 2. Products & Inventory Hub
        if (state.activeBusiness?.inventoryEnabled == true) {
            item {
                SettingsActionTile(
                    icon = Icons.Default.Inventory2,
                    title = strings.inventoryProducts,
                    subtitle = "${state.products.size} products • Stock adjustments & movement log",
                    onClick = { showInventorySheet = true },
                    modifier = Modifier.testTag("settings_inventory_button")
                )
            }
        }

        // 3. Employees & Access Management
        item {
            SettingsActionTile(
                icon = Icons.Default.Badge,
                title = strings.employeesAccess,
                subtitle = "Active: ${state.activeEmployee?.name ?: "Owner"} (${state.activeEmployee?.role ?: "OWNER"})",
                onClick = { showEmployeesSheet = true },
                modifier = Modifier.testTag("settings_employees_button")
            )
        }

        // 4. Optional Google Account & Firebase Cloud Sync (Strictly auth-gated with Credential Manager)
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.cloudSyncAccount, style = MaterialTheme.typography.titleMedium)
                    val user = currentUser
                    if (user == null) {
                        Text(
                            "Optional: Sign in with Google to sync businesses and ledgers securely to Firebase Firestore.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = {
                                authLoading = true
                                authError = null
                                FirebaseAuthHelper.onGoogleSignInClicked(
                                    context = context,
                                    credentialManager = credentialManager,
                                    onAuthSuccess = { authLoading = false },
                                    onAuthError = { msg -> authLoading = false; authError = msg },
                                    scope = scope,
                                    onAuthCancelled = { authLoading = false }
                                )
                            },
                            enabled = !authLoading,
                            modifier = Modifier.fillMaxWidth().testTag("google_signin_button")
                        ) {
                            if (authLoading) {
                                CircularProgressIndicator(Modifier.size(20.dp), color = PureWhite, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(strings.signInWithGoogle)
                            }
                        }
                        authError?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = ExpenseRed)
                        }
                    } else {
                        key(user.uid) {
                            Text("Signed in: ${user.displayName ?: user.email ?: user.uid}", style = MaterialTheme.typography.bodyMedium, color = EmeraldPrimary)
                            if (state.settings.lastCloudSyncMillis > 0L) {
                                Text(
                                    "Last synced: ${MoneyUtils.formatDhakaDateTime(state.settings.lastCloudSyncMillis, useBn)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onSyncToCloud(user.uid) },
                                    enabled = !isSyncing,
                                    modifier = Modifier.weight(1f).testTag("cloud_sync_now_button")
                                ) {
                                    Text(if (isSyncing) "Syncing..." else strings.syncNow)
                                }
                                OutlinedButton(
                                    onClick = { onRestoreFromCloud(user.uid) },
                                    enabled = !isSyncing,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Pull Cloud")
                                }
                            }
                            TextButton(
                                onClick = { FirebaseAuthHelper.signOut(credentialManager, scope) },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text(strings.signOut, color = ExpenseRed)
                            }
                        }
                    }
                    HorizontalDivider()
                    OutlinedButton(
                        onClick = onOpenSyncDevices,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("open_sync_devices_button")
                    ) {
                        Icon(Icons.Default.Devices, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "${strings.syncConflictsDevices} (${state.pendingSyncCount} pending" +
                                if (state.conflicts.isNotEmpty()) ", ${state.conflicts.size} conflict" else "" + ")"
                        )
                    }
                }
            }
        }

        // 5. Security & Local Backup
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.securityBackup, style = MaterialTheme.typography.titleMedium)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (state.settings.hasPin) "PIN Lock Active" else "Set Security PIN", style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { showSetPinDialog = true }) {
                                Text(if (state.settings.hasPin) "Change" else "Set PIN")
                            }
                            if (state.settings.hasPin) {
                                TextButton(onClick = onRemovePin) { Text("Remove", color = ExpenseRed) }
                            }
                        }
                    }
                    if (state.settings.hasPin) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Biometric Fingerprint Unlock", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = state.settings.biometricEnabled, onCheckedChange = onSetBiometric)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { createBackupLauncher.launch("hisab_pro_backup_${System.currentTimeMillis()}.json") },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) { Text(strings.exportLocalBackup) }
                        OutlinedButton(
                            onClick = { openBackupLauncher.launch(arrayOf("application/json", "application/octet-stream", "*/*")) },
                            modifier = Modifier.weight(1f).heightIn(min = 48.dp)
                        ) { Text(strings.restoreLocalBackup) }
                    }
                    OutlinedButton(
                        onClick = { showEncryptedExportDialog = true },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("export_encrypted_backup_button")
                    ) {
                        Icon(Icons.Default.EnhancedEncryption, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(strings.encryptedBackupLabel)
                    }
                }
            }
        }

        // 6. Notifications Preferences
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(strings.notificationsTitle, style = MaterialTheme.typography.titleMedium)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            TextButton(onClick = { notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                                Text("Enable Alerts")
                            }
                        }
                    }
                    ToggleRow("Customer & Supplier Reminders", state.settings.dueReminderEnabled) {
                        onUpdateNotifications(it, state.settings.lowStockAlertEnabled, state.settings.dailySummaryEnabled, state.settings.autoBackupEnabled)
                    }
                    ToggleRow("Low Stock Alerts", state.settings.lowStockAlertEnabled) {
                        onUpdateNotifications(state.settings.dueReminderEnabled, it, state.settings.dailySummaryEnabled, state.settings.autoBackupEnabled)
                    }
                    ToggleRow("Daily & Monthly Summary", state.settings.dailySummaryEnabled) {
                        onUpdateNotifications(state.settings.dueReminderEnabled, state.settings.lowStockAlertEnabled, it, state.settings.autoBackupEnabled)
                    }
                    ToggleRow("Automatic Scheduled Backup", state.settings.autoBackupEnabled) {
                        onUpdateNotifications(state.settings.dueReminderEnabled, state.settings.lowStockAlertEnabled, state.settings.dailySummaryEnabled, it)
                    }
                }
            }
        }

        // 7. Language & Appearance
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.appearanceLanguage, style = MaterialTheme.typography.titleMedium)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        listOf(AppLanguage.ENGLISH, AppLanguage.BANGLA).forEachIndexed { i, lang ->
                            SegmentedButton(
                                selected = state.settings.languageCode == lang.code,
                                onClick = { onSetLanguage(lang.code) },
                                shape = SegmentedButtonDefaults.itemShape(i, 2),
                                modifier = Modifier.testTag("lang_button_${lang.code}")
                            ) { Text(lang.displayName) }
                        }
                    }
                    ToggleRow("Bangla Numerals (১২৩)", state.settings.useBanglaDigits, onSetBanglaDigits)
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        listOf("SYSTEM", "LIGHT", "DARK").forEachIndexed { i, mode ->
                            SegmentedButton(
                                selected = state.settings.darkModePreference == mode,
                                onClick = { onSetDarkMode(mode) },
                                shape = SegmentedButtonDefaults.itemShape(i, 3)
                            ) { Text(mode) }
                        }
                    }
                }
            }
        }

        // 8. App Updates via GitHub Releases
        item {
            var repoInput by remember(state.settings.githubUpdateRepo) {
                mutableStateOf(state.settings.githubUpdateRepo)
            }
            var showPermissionHint by remember { mutableStateOf(false) }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.SystemUpdate, contentDescription = null, tint = EmeraldPrimary)
                            Text(strings.appUpdatesTitle, style = MaterialTheme.typography.titleMedium)
                        }
                        AssistChip(
                            onClick = {},
                            label = { Text("v${BuildConfig.VERSION_NAME}") }
                        )
                    }

                    Text(
                        text = "${strings.currentVersionLabel}: v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = repoInput,
                        onValueChange = {
                            repoInput = it
                            if (updateState !is UpdateUiState.Checking && updateState !is UpdateUiState.Downloading) {
                                onResetUpdateState()
                            }
                        },
                        label = { Text(strings.githubRepoLabel) },
                        placeholder = { Text("username/hisab-pro-bd") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("github_repo_input")
                    )

                    when (updateState) {
                        is UpdateUiState.Idle -> {
                            Button(
                                onClick = { onCheckForUpdate(repoInput) },
                                enabled = repoInput.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("check_update_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(strings.checkUpdates)
                            }
                        }

                        is UpdateUiState.Checking -> {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Text(strings.checkingUpdates, style = MaterialTheme.typography.bodyMedium)
                            }
                        }

                        is UpdateUiState.UpToDate -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = SoftGreenAccent
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary)
                                    Text(
                                        text = "${strings.upToDateLabel} (${updateState.latestTag})",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = DarkNavy,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = { onCheckForUpdate(repoInput) },
                                modifier = Modifier.fillMaxWidth().testTag("check_update_button")
                            ) {
                                Text(strings.checkUpdates)
                            }
                        }

                        is UpdateUiState.UpdateAvailable -> {
                            val rel = updateState.release
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "${strings.updateAvailableLabel}: ${rel.tagName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = EmeraldPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (rel.apkAssetName != null) {
                                        val mbText = if (rel.apkSizeBytes > 0L) {
                                            " (${String.format("%.1f", rel.apkSizeBytes / (1024.0 * 1024.0))} MB)"
                                        } else ""
                                        Text("${rel.apkAssetName}$mbText", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (rel.releaseNotes.isNotBlank()) {
                                        Text(
                                            text = rel.releaseNotes.take(280),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!rel.apkDownloadUrl.isNullOrBlank()) {
                                    Button(
                                        onClick = onDownloadUpdate,
                                        modifier = Modifier.weight(1f).testTag("download_update_button")
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.downloadAndInstall)
                                    }
                                }
                                if (rel.htmlUrl.isNotBlank()) {
                                    OutlinedButton(
                                        onClick = {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(rel.htmlUrl)))
                                        },
                                        modifier = if (rel.apkDownloadUrl.isNullOrBlank()) Modifier.fillMaxWidth() else Modifier.weight(1f)
                                    ) {
                                        Text(strings.openReleasePage)
                                    }
                                }
                            }
                        }

                        is UpdateUiState.Downloading -> {
                            val pct = updateState.progressPercent
                            val dlMb = updateState.downloadedBytes / (1024.0 * 1024.0)
                            val totalMb = updateState.totalBytes / (1024.0 * 1024.0)
                            Text(
                                text = if (updateState.totalBytes > 0L) {
                                    String.format("Downloading %s: %d%% (%.1f / %.1f MB)", updateState.release.tagName, pct, dlMb, totalMb)
                                } else {
                                    String.format("Downloading %s: %.1f MB", updateState.release.tagName, dlMb)
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (updateState.totalBytes > 0L) {
                                LinearProgressIndicator(
                                    progress = { pct / 100f },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }
                        }

                        is UpdateUiState.ReadyToInstall -> {
                            val apkFile = File(updateState.apkFilePath)
                            if (showPermissionHint) {
                                Text(
                                    text = strings.allowUnknownAppsPrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Button(
                                onClick = {
                                    if (GitHubReleaseUpdater.canInstallPackages(context)) {
                                        showPermissionHint = false
                                        GitHubReleaseUpdater.launchApkInstaller(context, apkFile)
                                    } else {
                                        showPermissionHint = true
                                        pendingInstallApkPath = apkFile.absolutePath
                                        unknownSourcesLauncher.launch(
                                            GitHubReleaseUpdater.createUnknownSourcesSettingsIntent(context)
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().testTag("install_update_button")
                            ) {
                                Icon(Icons.Default.InstallMobile, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("${strings.installUpdateNow} (${updateState.release.tagName})")
                            }
                        }

                        is UpdateUiState.Error -> {
                            Text(
                                text = updateState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = ExpenseRed
                            )
                            Button(
                                onClick = { onCheckForUpdate(repoInput) },
                                enabled = repoInput.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().testTag("check_update_button")
                            ) {
                                Text(strings.checkUpdates)
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }

    // Inventory & Product Management Sheet
    if (showInventorySheet) {
        InventoryManagementSheet(
            state = state,
            useBn = useBn,
            onDismiss = { showInventorySheet = false },
            onSaveProduct = onSaveProduct,
            onAdjustStock = onAdjustStock
        )
    }

    // Employees, HR, Payroll & RBAC Management Sheet
    if (showEmployeesSheet) {
        HrManagementSheet(
            state = state,
            onDismiss = { showEmployeesSheet = false },
            onSaveEmployee = onSaveEmployeeExtended,
            onRemoveEmployee = onRemoveEmployee,
            onSetActiveEmployee = onSetActiveEmployee,
            onRecordAttendance = onRecordAttendance,
            onSubmitLeave = onSubmitLeave,
            onDecideLeave = onDecideLeave,
            onRecordSalary = onRecordSalary,
            onUpdateRolePermission = onUpdateRolePermission
        )
    }

    // Business Profile Edit Dialog
    if (showBusinessEditDialog && state.activeBusiness != null) {
        val biz = state.activeBusiness
        var name by remember { mutableStateOf(biz.name) }
        var phone by remember { mutableStateOf(biz.phone) }
        var address by remember { mutableStateOf(biz.address) }
        var taxRate by remember { mutableStateOf((biz.defaultTaxRateBps / 100.0).toString()) }
        var logoUri by remember { mutableStateOf(biz.logoUri) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) logoUri = uri.toString()
        }

        AlertDialog(
            onDismissRequest = { showBusinessEditDialog = false },
            title = { Text("Edit Business Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text("Update Logo") }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Business Name") })
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") })
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") })
                    OutlinedTextField(value = taxRate, onValueChange = { taxRate = it }, label = { Text("Default VAT/Tax (%)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
            },
            confirmButton = {
                Button(onClick = {
                    val bps = ((taxRate.toDoubleOrNull() ?: 0.0) * 100).toInt().coerceIn(0, 10000)
                    onUpdateBusiness(
                        biz.copy(
                            name = name.trim().ifBlank { biz.name },
                            phone = MoneyUtils.formatBdPhone(phone),
                            address = address.trim(),
                            logoUri = logoUri,
                            defaultTaxRateBps = bps
                        )
                    )
                    showBusinessEditDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showBusinessEditDialog = false }) { Text("Cancel") } }
        )
    }

    if (showSetPinDialog) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSetPinDialog = false },
            title = { Text("Set Security PIN (4-6 digits)") },
            text = {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pin = it },
                    label = { Text("New PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (pin.length in 4..6) {
                        onSetPin(pin)
                        showSetPinDialog = false
                    }
                }) { Text("Save PIN") }
            },
            dismissButton = { TextButton(onClick = { showSetPinDialog = false }) { Text("Cancel") } }
        )
    }

    if (showEncryptedExportDialog) {
        var pass by remember { mutableStateOf("") }
        var confirmPass by remember { mutableStateOf("") }
        val mismatch = confirmPass.isNotEmpty() && pass != confirmPass
        AlertDialog(
            onDismissRequest = { showEncryptedExportDialog = false },
            title = { Text(strings.encryptedBackupLabel) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Protect your full accounting backup with AES-256-GCM encryption. Remember this passphrase to restore later.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        label = { Text(strings.passphraseLabel) },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("encrypted_backup_passphrase_input")
                    )
                    OutlinedTextField(
                        value = confirmPass,
                        onValueChange = { confirmPass = it },
                        label = { Text("Confirm Passphrase") },
                        visualTransformation = PasswordVisualTransformation(),
                        isError = mismatch,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingExportPassphrase = pass
                        showEncryptedExportDialog = false
                        createEncryptedBackupLauncher.launch("hisab_pro_encrypted_${System.currentTimeMillis()}.hisabenc")
                    },
                    enabled = pass.length >= 4 && pass == confirmPass
                ) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showEncryptedExportDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
private fun SettingsActionTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, contentDescription = title, tint = EmeraldPrimary)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null)
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun InventoryManagementSheet(
    state: BusinessWorkspaceState,
    useBn: Boolean,
    onDismiss: () -> Unit,
    onSaveProduct: (String?, String, String, String, String, Long, Long, Long, String, Long, String?) -> Unit,
    onAdjustStock: (String, String, Long, String) -> Unit
) {
    var showAddProduct by remember { mutableStateOf(false) }
    var adjustTarget by remember { mutableStateOf<ProductEntity?>(null) }
    var showMovements by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Products & Inventory", style = MaterialTheme.typography.titleLarge)
                Row {
                    TextButton(onClick = { showMovements = !showMovements }) {
                        Text(if (showMovements) "Products" else "Movements")
                    }
                    Button(onClick = { showAddProduct = true }) { Text("+ Add") }
                }
            }

            if (showMovements) {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.stockMovements, key = { it.id }) { m ->
                        ListItem(
                            headlineContent = { Text("${m.productName} (${m.movementType})") },
                            supportingContent = { Text("${MoneyUtils.formatDhakaDateTime(m.occurredAt, useBn)} • ${m.notes}") },
                            trailingContent = {
                                val sign = if (m.deltaMilliUnits >= 0) "+" else ""
                                Text("$sign${MoneyUtils.milliUnitsToString(m.deltaMilliUnits, useBn)}")
                            }
                        )
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.products, key = { it.id }) { p ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(p.name, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "Buy ${MoneyUtils.formatTaka(p.purchasePricePaisa, useBn)} • Sell ${MoneyUtils.formatTaka(p.sellingPricePaisa, useBn)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${MoneyUtils.milliUnitsToString(p.stockMilliUnits, useBn)} ${p.unit}", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                    TextButton(onClick = { adjustTarget = p }) { Text("Adjust") }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    if (showAddProduct) {
        var name by remember { mutableStateOf("") }
        var sku by remember { mutableStateOf("") }
        var barcode by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("General") }
        var buyPrice by remember { mutableStateOf("") }
        var sellPrice by remember { mutableStateOf("") }
        var stock by remember { mutableStateOf("") }
        var unit by remember { mutableStateOf("Piece") }
        var lowThreshold by remember { mutableStateOf("5") }
        var imgUri by remember { mutableStateOf<String?>(null) }
        var showProductBarcodeScanner by remember { mutableStateOf(false) }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) imgUri = uri.toString()
        }

        AlertDialog(
            onDismissRequest = { showAddProduct = false },
            title = { Text("Add Product") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text(if (imgUri == null) "Product Image (Optional)" else "Image Selected") }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name *") })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = barcode, onValueChange = { barcode = it }, label = { Text("Barcode") }, modifier = Modifier.weight(1f))
                        IconButton(
                            onClick = { showProductBarcodeScanner = true },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                Icons.Default.QrCodeScanner,
                                contentDescription = LocalAppStrings.current.scanBarcode,
                                tint = EmeraldPrimary
                            )
                        }
                    }
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = buyPrice, onValueChange = { buyPrice = it }, label = { Text("Buy Price (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = sellPrice, onValueChange = { sellPrice = it }, label = { Text("Sell Price (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Initial Stock") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = lowThreshold, onValueChange = { lowThreshold = it }, label = { Text("Low Alert") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                    Text("Unit", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Piece", "KG", "Gram", "Liter", "Meter", "Box", "Packet").forEach { u ->
                            FilterChip(selected = unit == u, onClick = { unit = u }, label = { Text(u) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        onSaveProduct(
                            null, name, sku, barcode, category,
                            MoneyUtils.parseTakaToPaisa(buyPrice),
                            MoneyUtils.parseTakaToPaisa(sellPrice),
                            MoneyUtils.parseQtyToMilliUnits(stock),
                            unit,
                            MoneyUtils.parseQtyToMilliUnits(lowThreshold).coerceAtLeast(1000L),
                            imgUri
                        )
                        showAddProduct = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddProduct = false }) { Text("Cancel") } }
        )

        if (showProductBarcodeScanner) {
            BarcodeScannerDialog(
                products = state.products,
                onBarcodeDetected = { code ->
                    barcode = code
                    showProductBarcodeScanner = false
                },
                onDismiss = { showProductBarcodeScanner = false }
            )
        }
    }

    adjustTarget?.let { prod ->
        var adjType by remember { mutableStateOf("ADJUSTMENT") }
        var qty by remember { mutableStateOf("") }
        var isDecrease by remember { mutableStateOf(true) }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adjustTarget = null },
            title = { Text("Adjust ${prod.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf("ADJUSTMENT", "DAMAGE")) { t ->
                            FilterChip(selected = adjType == t, onClick = { adjType = t; if (t == "DAMAGE") isDecrease = true }, label = { Text(t) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Decrease Stock (Out/Damage)")
                        Switch(checked = isDecrease, onCheckedChange = { isDecrease = it })
                    }
                    OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Quantity (${prod.unit})") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Reason / Notes") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    val m = MoneyUtils.parseQtyToMilliUnits(qty)
                    if (m > 0L) {
                        onAdjustStock(prod.id, adjType, if (isDecrease) -m else m, notes)
                        adjustTarget = null
                    }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { adjustTarget = null }) { Text("Cancel") } }
        )
    }
}


