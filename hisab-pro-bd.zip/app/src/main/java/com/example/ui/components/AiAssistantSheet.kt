package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.remote.AiChatMessage
import com.example.data.remote.AiUiState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantSheet(
    messages: List<AiChatMessage>,
    aiUiState: AiUiState,
    useBanglaDigits: Boolean,
    onAskQuestion: (String) -> Unit,
    onConfirmAction: (String) -> Unit,
    onClearChat: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val suggestions = remember(strings.isBangla) {
        if (strings.isBangla) {
            listOf(
                "আজকে আমার কত টাকা বিক্রি হয়েছে?",
                "এই মাসে কত লাভ হয়েছে?",
                "সবচেয়ে বেশি বাকি কার কাছে?",
                "কোন পণ্য সবচেয়ে বেশি বিক্রি হয়েছে?",
                "গত মাসের তুলনায় এই মাসে বিক্রি কত বেড়েছে?"
            )
        } else {
            listOf(
                "আজকে আমার কত টাকা বিক্রি হয়েছে?",
                "What is my net profit this month?",
                "Who has the highest customer due?",
                "Which product sold the most?",
                "Compare this month sales vs last month"
            )
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .padding(horizontal = 16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = EmeraldPrimary.copy(alpha = 0.14f)
                    ) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = strings.aiAssistantTitle,
                            tint = EmeraldPrimary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Column {
                        Text(strings.aiAssistantTitle, style = MaterialTheme.typography.titleLarge)
                        Text(
                            strings.aiAssistantSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (messages.isNotEmpty()) {
                    IconButton(onClick = onClearChat) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear AI conversation")
                    }
                }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(suggestions) { prompt ->
                    SuggestionChip(
                        onClick = { onAskQuestion(prompt) },
                        label = { Text(prompt, maxLines = 1) }
                    )
                }
            }

            if (aiUiState is AiUiState.Error) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ExpenseRed.copy(alpha = 0.10f),
                    border = BorderStroke(1.dp, ExpenseRed.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = aiUiState.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = ExpenseRed,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Default.Psychology,
                            title = if (strings.isBangla) "আপনার ব্যবসার যেকোনো হিসাব জিজ্ঞাসা করুন" else "Ask anything about your live accounts",
                            subtitle = if (strings.isBangla)
                                "বিক্রয়, লাভ-ক্ষতি, বকেয়া, পণ্য বিশ্লেষণ ও ব্যবসার উন্নতির পরামর্শ পান সরাসরি আপনার খাতা থেকে।"
                            else
                                "Get accurate Bangla & English answers grounded in your actual ledger with explicit date ranges."
                        )
                    }
                } else {
                    items(messages, key = { it.id }) { msg ->
                        AiMessageBubble(
                            msg = msg,
                            useBanglaDigits = useBanglaDigits,
                            onConfirmAction = { onConfirmAction(msg.id) }
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text(strings.aiAskHint, maxLines = 1) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_chat_input"),
                    maxLines = 3,
                    shape = RoundedCornerShape(16.dp)
                )
                FilledIconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            onAskQuestion(inputText)
                            inputText = ""
                        }
                    },
                    enabled = inputText.isNotBlank() && aiUiState !is AiUiState.Loading && aiUiState !is AiUiState.Streaming,
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("ai_send_button")
                ) {
                    if (aiUiState is AiUiState.Loading || aiUiState is AiUiState.Streaming) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = PureWhite,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
                    }
                }
            }
        }
    }
}

@Composable
private fun AiMessageBubble(
    msg: AiChatMessage,
    useBanglaDigits: Boolean,
    onConfirmAction: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (msg.isUser) 16.dp else 4.dp,
                bottomEnd = if (msg.isUser) 4.dp else 16.dp
            ),
            color = if (msg.isUser) DarkNavy else MaterialTheme.colorScheme.surface,
            border = if (msg.isUser) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!msg.isUser && !msg.dateRangeLabel.isNullOrBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .background(EmeraldPrimary.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(12.dp))
                        Text(
                            msg.dateRangeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary
                        )
                    }
                }

                Text(
                    text = msg.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (msg.isUser) PureWhite else MaterialTheme.colorScheme.onSurface
                )

                msg.proposedAction?.let { action ->
                    HorizontalDivider()
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SoftGreenAccent,
                        border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "Proposed Entry (${action.actionType})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkNavy
                            )
                            Text(
                                "${action.partyOrCategory} • ${MoneyUtils.formatTaka(action.amountPaisa, useBanglaDigits)}",
                                style = MaterialTheme.typography.titleSmall,
                                color = EmeraldPrimary
                            )
                            if (action.notes.isNotBlank()) {
                                Text(action.notes, style = MaterialTheme.typography.bodySmall, color = DarkNavy)
                            }
                            if (msg.actionExecuted) {
                                Text("Confirmed & Saved ✓", style = MaterialTheme.typography.labelMedium, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                            } else {
                                Button(
                                    onClick = onConfirmAction,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 48.dp)
                                        .testTag("ai_confirm_action_button")
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Confirm & Save")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
