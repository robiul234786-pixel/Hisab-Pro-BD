package com.example.core.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.camera.core.ImageProxy

/**
 * Pure-Kotlin 1D Barcode helper (Zero external uncached binaries):
 * - Generates scannable Code-128B Bitmaps for POS invoices & product labels.
 * - Decodes EAN-13 / Code-128 horizontal scanlines from CameraX Y-plane frames.
 */
object BarcodeScannerHelper {

    private val EAN13_L = arrayOf(
        "0001101", "0011001", "0010011", "0111101", "0100011",
        "0110001", "0101111", "0111011", "0110111", "0001011"
    )
    private val EAN13_G = arrayOf(
        "0100111", "0110011", "0011011", "0100001", "0011101",
        "0111001", "0000101", "0010001", "0001001", "0010111"
    )
    private val EAN13_R = arrayOf(
        "1110010", "1100110", "1101100", "1000010", "1011100",
        "1001110", "1010000", "1000100", "1001000", "1110100"
    )
    private val EAN13_PARITY = arrayOf(
        "LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG",
        "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL"
    )

    // Code-128 widths (107 patterns)
    private val CODE128_PATTERNS = arrayOf(
        "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213",
        "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132",
        "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211",
        "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
        "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331",
        "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111",
        "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214",
        "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
        "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141",
        "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141",
        "114131", "311141", "411131", "211412", "211214", "211232", "2331112"
    )

    fun generateCode128Bitmap(content: String, widthPx: Int = 520, heightPx: Int = 110): Bitmap {
        val clean = content.filter { it.code in 32..126 }.ifBlank { "HISAB" }
        val codes = mutableListOf(104) // Start B
        var checksum = 104
        clean.forEachIndexed { idx, ch ->
            val v = ch.code - 32
            codes.add(v)
            checksum += v * (idx + 1)
        }
        codes.add(checksum % 103)
        codes.add(106) // Stop

        val modules = buildString {
            codes.forEach { code ->
                val pattern = CODE128_PATTERNS[code]
                pattern.forEachIndexed { i, w ->
                    val bit = if (i % 2 == 0) '1' else '0'
                    repeat(w.digitToInt()) { append(bit) }
                }
            }
        }

        val bmp = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val paint = Paint().apply { color = Color.BLACK; isAntiAlias = false }

        val quiet = 20f
        val barAreaWidth = widthPx - quiet * 2f
        val moduleWidth = barAreaWidth / modules.length.coerceAtLeast(1)
        val barBottom = heightPx - 24f

        modules.forEachIndexed { idx, bit ->
            if (bit == '1') {
                val left = quiet + idx * moduleWidth
                canvas.drawRect(left, 8f, left + moduleWidth, barBottom, paint)
            }
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(clean, widthPx / 2f, heightPx - 4f, textPaint)
        return bmp
    }

    /**
     * Attempts to decode an EAN-13 barcode from the middle horizontal scanlines of a CameraX YUV_420_888 frame.
     */
    fun decodeEan13FromImage(image: ImageProxy): String? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        if (width < 120 || height < 40) return null

        val sampleRows = listOf(height / 2, height * 2 / 5, height * 3 / 5)
        val rowBytes = ByteArray(width)
        for (y in sampleRows) {
            val offset = y * rowStride
            if (offset + width > buffer.limit()) continue
            buffer.position(offset)
            buffer.get(rowBytes, 0, width)
            decodeEan13Row(rowBytes)?.let { return it }
        }
        return null
    }

    private fun decodeEan13Row(luma: ByteArray): String? {
        val w = luma.size
        var minL = 255
        var maxL = 0
        for (b in luma) {
            val v = b.toInt() and 0xFF
            if (v < minL) minL = v
            if (v > maxL) maxL = v
        }
        if (maxL - minL < 35) return null
        val threshold = (minL + maxL) / 2

        // Run-length encode black/white transitions
        val runs = mutableListOf<Pair<Boolean, Int>>() // isBlack to length
        var curBlack = (luma[0].toInt() and 0xFF) < threshold
        var curLen = 1
        for (i in 1 until w) {
            val b = (luma[i].toInt() and 0xFF) < threshold
            if (b == curBlack) {
                curLen++
            } else {
                runs.add(curBlack to curLen)
                curBlack = b
                curLen = 1
            }
        }
        runs.add(curBlack to curLen)
        if (runs.size < 59) return null

        // Scan for Start Guard: B-W-B roughly 1:1:1
        for (start in 0..(runs.size - 59)) {
            if (!runs[start].first || runs[start + 1].first || !runs[start + 2].first) continue
            val g1 = runs[start].second.toFloat()
            val g2 = runs[start + 1].second.toFloat()
            val g3 = runs[start + 2].second.toFloat()
            val mod = (g1 + g2 + g3) / 3f
            if (mod < 1f) continue
            if (kotlin.math.abs(g1 - mod) > mod * 0.55f ||
                kotlin.math.abs(g2 - mod) > mod * 0.55f ||
                kotlin.math.abs(g3 - mod) > mod * 0.55f
            ) continue

            val digits = StringBuilder()
            val parity = StringBuilder()
            var idx = start + 3
            var valid = true

            // Left 6 digits (24 runs)
            for (d in 0 until 6) {
                val pattern = quantize4Runs(runs, idx, mod * 7f) ?: run { valid = false; break }
                val lIdx = EAN13_L.indexOf(pattern)
                val gIdx = EAN13_G.indexOf(pattern)
                when {
                    lIdx >= 0 -> {
                        digits.append(lIdx)
                        parity.append('L')
                    }
                    gIdx >= 0 -> {
                        digits.append(gIdx)
                        parity.append('G')
                    }
                    else -> {
                        valid = false
                        break
                    }
                }
                idx += 4
            }
            if (!valid) continue

            val firstDigit = EAN13_PARITY.indexOf(parity.toString())
            if (firstDigit < 0) continue

            // Center guard (5 runs)
            idx += 5
            if (idx + 24 >= runs.size) continue

            // Right 6 digits (24 runs)
            for (d in 0 until 6) {
                val pattern = quantize4Runs(runs, idx, mod * 7f) ?: run { valid = false; break }
                val rIdx = EAN13_R.indexOf(pattern)
                if (rIdx < 0) {
                    valid = false
                    break
                }
                digits.append(rIdx)
                idx += 4
            }
            if (!valid) continue

            val full = "$firstDigit$digits"
            if (full.length == 13 && isValidEan13Checksum(full)) {
                return full
            }
        }
        return null
    }

    private fun quantize4Runs(runs: List<Pair<Boolean, Int>>, offset: Int, digitWidth: Float): String? {
        if (offset + 3 >= runs.size) return null
        val total = (0..3).sumOf { runs[offset + it].second }.toFloat()
        if (total < digitWidth * 0.5f || total > digitWidth * 1.8f) return null
        val unit = total / 7f
        val sb = StringBuilder(7)
        for (i in 0..3) {
            val count = kotlin.math.round(runs[offset + i].second / unit).toInt().coerceIn(1, 4)
            val bit = if (runs[offset + i].first) '1' else '0'
            repeat(count) { sb.append(bit) }
        }
        return if (sb.length == 7) sb.toString() else null
    }

    fun isValidEan13Checksum(code: String): Boolean {
        if (code.length != 13 || !code.all { it.isDigit() }) return false
        var sum = 0
        for (i in 0 until 12) {
            val d = code[i] - '0'
            sum += if (i % 2 == 0) d else d * 3
        }
        val check = (10 - (sum % 10)) % 10
        return check == (code[12] - '0')
    }
}
