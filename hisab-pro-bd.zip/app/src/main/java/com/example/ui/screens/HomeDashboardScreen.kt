package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.data.local.AccountingTransactionEntity
import com.example.data.local.BusinessCategories
import com.example.ui.BusinessWorkspaceState
import com.example.ui.components.*
import com.example.ui.theme.*

enum class QuickActionType {
    ADD_SALE, ADD_CUSTOMER, ADD_DUE, RECEIVE_PAYMENT, ADD_EXPENSE, ADD_PURCHASE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeDashboardScreen(
    state: BusinessWorkspaceState,
    onSwitchBusiness: (String) -> Unit,
    onCreateBusiness: (name: String, category: String, phone: String, address: String, openingCash: Long, inv: Boolean) -> Unit,
    onQuickAction: (QuickActionType) -> Unit,
    onMarkNotificationsRead: () -> Unit,
    onOpenTransactionDetail: (AccountingTransactionEntity) -> Unit,
    onOpenCustomerDetail: (String) -> Unit,
    onLockApp: () -> Unit,
    onOpenAiAssistant: () -> Unit = {},
    onOpenVoiceEntry: () -> Unit = {},
    onOpenSyncDevices: () -> Unit = {},
    hasSavedSnapshot: Boolean = false,
    onSaveAllAccounts: () -> Unit = {},
    onRestoreLastSnapshot: () -> Unit = {},
    onResetAccounts: (clearMasterEntities: Boolean, backupBeforeReset: Boolean) -> Unit = { _, _ -> }
) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val biz = state.activeBusiness
    val dash = state.dashboard

    var showBusinessSwitcher by remember { mutableStateOf(false) }
    var showCreateBusinessDialog by remember { mutableStateOf(false) }
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }

    val lowStockProducts = remember(state.products, biz) {
        if (biz?.inventoryEnabled == true) {
            state.products.filter { it.stockMilliUnits <= it.lowStockThresholdMilliUnits }
        } else emptyList()
    }
    val topCustomers = remember(state.customers) {
        state.customers.sortedByDescending { it.totalPurchasesPaisa }.take(4)
    }
    val outstandingDueCustomers = remember(state.customers) {
        state.customers.filter { it.currentDuePaisa > 0L }.sortedByDescending { it.currentDuePaisa }.take(5)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header: Business Switcher + Lock + Notifications
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showBusinessSwitcher = true }
                        .padding(vertical = 4.dp)
                        .testTag("business_switcher_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(EmeraldPrimary.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!biz?.logoUri.isNullOrBlank()) {
                            AsyncImage(
                                model = biz?.logoUri,
                                contentDescription = biz?.name ?: "Logo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(Icons.Default.Storefront, contentDescription = "Business", tint = EmeraldPrimary)
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = biz?.name ?: strings.appTitle,
                                style = MaterialTheme.typography.titleLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Switch business")
                        }
                        Text(
                            text = "${biz?.category ?: ""} • ${state.activeEmployee?.role ?: "OWNER"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (state.settings.hasPin) {
                        IconButton(onClick = onLockApp) {
                            Icon(Icons.Default.Lock, contentDescription = "Lock app")
                        }
                    }
                    BadgedBox(
                        badge = {
                            if (state.unreadNotifications > 0) {
                                Badge { Text(state.unreadNotifications.toString()) }
                            }
                        }
                    ) {
                        IconButton(
                            onClick = {
                                showNotificationsSheet = true
                                onMarkNotificationsRead()
                            },
                            modifier = Modifier.testTag("notifications_button")
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = strings.notificationsTitle)
                        }
                    }
                }
            }
        }

        // Hero Card: Net Profit + Today's Summary + Liquid Balances
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = Color.Transparent
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(DarkNavy, Color(0xFF12363A))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (dash.isEstimatedProfit) "${strings.netProfit} (${strings.estimatedProfit})" else strings.netProfit,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = PureWhite.copy(alpha = 0.78f)
                                )
                                Text(
                                    text = MoneyUtils.formatTaka(dash.netProfitPaisa, useBn),
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontFamily = MonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = if (dash.netProfitPaisa >= 0) EmeraldLight else ExpenseSoftRed
                                )
                            }
                            Surface(
                                color = EmeraldPrimary.copy(alpha = 0.22f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text(
                                        text = MoneyUtils.formatDhakaDate(System.currentTimeMillis(), useBn),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EmeraldLight
                                    )
                                    Text(
                                        text = "Health ${state.advancedAnalytics.healthReport.score}/100",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = PureWhite
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            HeroPill(
                                label = strings.todaysSales,
                                value = MoneyUtils.formatTaka(dash.todaysSalesPaisa, useBn),
                                valueColor = EmeraldLight,
                                modifier = Modifier.weight(1f)
                            )
                            HeroPill(
                                label = strings.todaysExpenses,
                                value = MoneyUtils.formatTaka(dash.todaysExpensesPaisa, useBn),
                                valueColor = ExpenseSoftRed,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        HorizontalDivider(color = PureWhite.copy(alpha = 0.12f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MiniBalanceColumn(strings.cashBalance, MoneyUtils.formatTaka(dash.cashBalancePaisa, useBn))
                            MiniBalanceColumn(strings.bankBalance, MoneyUtils.formatTaka(dash.bankBalancePaisa, useBn))
                            MiniBalanceColumn(strings.mfsBalance, MoneyUtils.formatTaka(dash.mfsBalancePaisa, useBn))
                        }
                    }
                }
            }
        }

        // Pro AI Business Assistant + Bangla Voice Entry + Sync Alert
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpenAiAssistant,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("open_ai_assistant_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = strings.aiAssistantTitle, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.aiAssistantTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    FilledTonalButton(
                        onClick = onOpenVoiceEntry,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("open_voice_entry_button")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = strings.voiceAccountingTitle, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            if (strings.isBangla) "ভয়েস হিসাব" else "Voice Entry",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (state.conflicts.isNotEmpty() || state.pendingSyncCount > 0) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onOpenSyncDevices),
                        shape = RoundedCornerShape(12.dp),
                        color = if (state.conflicts.isNotEmpty()) WarningSoftAmber else SoftGreenAccent,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (state.conflicts.isNotEmpty()) WarningAmber else EmeraldPrimary.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    if (state.conflicts.isNotEmpty()) Icons.Default.SyncProblem else Icons.Default.CloudQueue,
                                    contentDescription = null,
                                    tint = if (state.conflicts.isNotEmpty()) WarningAmber else EmeraldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = if (state.conflicts.isNotEmpty())
                                        "${state.conflicts.size} sync conflict(s) need attention"
                                    else
                                        "${state.pendingSyncCount} local change(s) queued for cloud sync",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DarkNavy
                                )
                            }
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = DarkNavy)
                        }
                    }
                }
            }
        }

        // Quick Actions Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(strings.quickActions, style = MaterialTheme.typography.titleMedium)
                val actions = listOf(
                    Triple(QuickActionType.ADD_SALE, strings.addSale, Icons.Default.PointOfSale),
                    Triple(QuickActionType.ADD_DUE, strings.addDue, Icons.Default.MenuBook),
                    Triple(QuickActionType.RECEIVE_PAYMENT, strings.receivePayment, Icons.Default.Payments),
                    Triple(QuickActionType.ADD_CUSTOMER, strings.addCustomer, Icons.Default.PersonAdd),
                    Triple(QuickActionType.ADD_EXPENSE, strings.addExpense, Icons.Default.ReceiptLong),
                    Triple(QuickActionType.ADD_PURCHASE, strings.addPurchase, Icons.Default.ShoppingCart)
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    actions.chunked(3).forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowItems.forEach { (type, label, icon) ->
                                QuickActionTile(
                                    icon = icon,
                                    label = label,
                                    onClick = { onQuickAction(type) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("quick_action_${type.name.lowercase()}")
                                )
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = onSaveAllAccounts,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("home_save_all_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = strings.saveAllHisab, modifier = Modifier.size(18.dp), tint = EmeraldPrimary)
                            Spacer(Modifier.width(6.dp))
                            Text(strings.saveAllHisab, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        OutlinedButton(
                            onClick = { showResetDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ExpenseRed.copy(alpha = 0.45f)),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("home_reset_hisab_button")
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = strings.resetHisab, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.resetHisab, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (hasSavedSnapshot) {
                        TextButton(
                            onClick = onRestoreLastSnapshot,
                            modifier = Modifier
                                .align(Alignment.End)
                                .testTag("home_restore_snapshot_button")
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.restoreLastSnapshot)
                        }
                    }
                }
            }
        }

        // Core Financial KPI Grid (Adaptive 2-column phone / 3-column tablet)
        item {
            val kpiSpecs = listOf(
                Triple(strings.totalSales, dash.totalSalesPaisa, Icons.Default.TrendingUp to EmeraldPrimary),
                Triple(strings.cashReceived, dash.totalCashReceivedPaisa, Icons.Default.AccountBalanceWallet to InfoBlue),
                Triple(strings.customerReceivables, dash.totalReceivablesPaisa, Icons.Default.CallReceived to WarningAmber),
                Triple(strings.supplierPayables, dash.totalPayablesPaisa, Icons.Default.CallMade to ExpenseRed),
                Triple(strings.totalIncome, dash.totalIncomePaisa, Icons.Default.AddChart to EmeraldPrimary),
                Triple(strings.totalExpenses, dash.totalExpensesPaisa, Icons.Default.MoneyOff to ExpenseRed)
            )
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val cols = if (maxWidth >= 600.dp) 3 else 2
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    kpiSpecs.chunked(cols).forEach { rowSpecs ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            rowSpecs.forEach { (title, amount, iconTint) ->
                                MetricCard(
                                    title = title,
                                    amountPaisa = amount,
                                    useBanglaDigits = useBn,
                                    icon = iconTint.first,
                                    accentColor = iconTint.second,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Charts
        item {
            MonthlySalesBarChart(points = state.monthlyChart, useBanglaDigits = useBn)
        }
        item {
            IncomeVsExpenseChart(points = state.monthlyChart, useBanglaDigits = useBn)
        }

        // Low Stock Alerts
        if (lowStockProducts.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.lowStockAlerts, style = MaterialTheme.typography.titleMedium, color = WarningAmber)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(lowStockProducts, key = { it.id }) { prod ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = WarningSoftAmber,
                                border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(prod.name, style = MaterialTheme.typography.titleSmall, color = DarkNavy)
                                    Text(
                                        text = "${MoneyUtils.milliUnitsToString(prod.stockMilliUnits, useBn)} ${prod.unit} left",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = WarningAmber
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Outstanding Customer Dues
        if (outstandingDueCustomers.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.outstandingDues, style = MaterialTheme.typography.titleMedium)
                    outstandingDueCustomers.forEach { cust ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenCustomerDetail(cust.id) },
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(cust.name, style = MaterialTheme.typography.titleSmall)
                                    Text(cust.phone.ifBlank { cust.customerCode }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(
                                    text = MoneyUtils.formatTaka(cust.currentDuePaisa, useBn),
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                    color = WarningAmber
                                )
                            }
                        }
                    }
                }
            }
        }

        // Top Customers
        if (topCustomers.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.topCustomers, style = MaterialTheme.typography.titleMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(topCustomers, key = { it.id }) { cust ->
                            Surface(
                                modifier = Modifier.clickable { onOpenCustomerDetail(cust.id) },
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp).widthIn(min = 130.dp)) {
                                    Text(cust.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        text = MoneyUtils.formatTaka(cust.totalPurchasesPaisa, useBn),
                                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                                        color = EmeraldPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Recent Transactions
        item {
            Text(strings.recentTransactions, style = MaterialTheme.typography.titleMedium)
        }

        if (state.transactions.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Default.ReceiptLong,
                    title = strings.noDataYet,
                    subtitle = if (strings.isBangla) "উপরের দ্রুত বাটন থেকে প্রথম বিক্রয় বা লেনদেন যোগ করুন" else "Use Quick Actions above to record your first sale or entry."
                )
            }
        } else {
            items(state.transactions.take(8), key = { it.id }) { tx ->
                TransactionRowCard(
                    tx = tx,
                    useBanglaDigits = useBn,
                    onClick = { onOpenTransactionDetail(tx) }
                )
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }

    // Business Switcher Sheet
    if (showBusinessSwitcher) {
        ModalBottomSheet(onDismissRequest = { showBusinessSwitcher = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = if (strings.isBangla) "ব্যবসা নির্বাচন / নতুন ব্যবসা" else "Switch or Add Business",
                    style = MaterialTheme.typography.titleLarge
                )
                state.businesses.forEach { b ->
                    val active = b.id == biz?.id
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSwitchBusiness(b.id)
                                showBusinessSwitcher = false
                            },
                        shape = RoundedCornerShape(14.dp),
                        color = if (active) SoftGreenAccent else MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (active) EmeraldPrimary else MaterialTheme.colorScheme.outline
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(b.name, style = MaterialTheme.typography.titleMedium, color = DarkNavy)
                                Text(b.category, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                            }
                            if (active) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Active", tint = EmeraldPrimary)
                            }
                        }
                    }
                }
                Button(
                    onClick = {
                        showBusinessSwitcher = false
                        showCreateBusinessDialog = true
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.AddBusiness, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (strings.isBangla) "নতুন ব্যবসা যোগ করুন" else "Add New Business")
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showCreateBusinessDialog) {
        CreateBusinessDialog(
            onDismiss = { showCreateBusinessDialog = false },
            onConfirm = { name, cat, phone, addr, cash, inv ->
                onCreateBusiness(name, cat, phone, addr, cash, inv)
                showCreateBusinessDialog = false
            }
        )
    }

    if (showNotificationsSheet) {
        ModalBottomSheet(onDismissRequest = { showNotificationsSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(strings.notificationsTitle, style = MaterialTheme.typography.titleLarge)
                if (state.notifications.isEmpty()) {
                    Text(strings.noDataYet, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    state.notifications.take(20).forEach { n ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                                Text(n.title, style = MaterialTheme.typography.titleSmall)
                                Text(n.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(MoneyUtils.formatDhakaDateTime(n.createdAt, useBn), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }

    if (showResetDialog) {
        ResetHisabConfirmDialog(
            businessName = biz?.name ?: strings.appTitle,
            onConfirmReset = onResetAccounts,
            onDismiss = { showResetDialog = false }
        )
    }
}

@Composable
private fun HeroPill(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = PureWhite.copy(alpha = 0.08f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = PureWhite.copy(alpha = 0.72f))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.Bold),
                color = valueColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MiniBalanceColumn(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = PureWhite.copy(alpha = 0.68f), maxLines = 1)
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily, fontWeight = FontWeight.SemiBold),
            color = PureWhite
        )
    }
}

@Composable
private fun QuickActionTile(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(82.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(EmeraldPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = label, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun CreateBusinessDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, category: String, phone: String, address: String, openingCash: Long, inv: Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(BusinessCategories.ALL.first()) }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var cash by remember { mutableStateOf("") }
    var inv by remember { mutableStateOf(true) }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Business Profile") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Business Name") }, singleLine = true)
                Box {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = { IconButton(onClick = { expanded = true }) { Icon(Icons.Default.ArrowDropDown, null) } },
                        modifier = Modifier.fillMaxWidth().clickable { expanded = true }
                    )
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        BusinessCategories.ALL.forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false })
                        }
                    }
                }
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, singleLine = true)
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, singleLine = true)
                OutlinedTextField(value = cash, onValueChange = { cash = it }, label = { Text("Opening Cash (৳)") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Enable Inventory", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = inv, onCheckedChange = { inv = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onConfirm(name, category, MoneyUtils.formatBdPhone(phone), address, MoneyUtils.parseTakaToPaisa(cash), inv)
                    }
                }
            ) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
