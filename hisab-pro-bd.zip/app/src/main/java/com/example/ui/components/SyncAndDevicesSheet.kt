package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.ui.BusinessWorkspaceState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyncAndDevicesSheet(
    state: BusinessWorkspaceState,
    currentUserId: String?,
    isSyncing: Boolean,
    onToggleAutoSync: (Boolean) -> Unit,
    onSyncNow: (String) -> Unit,
    onResolveConflict: (outboxId: String, keepLocal: Boolean) -> Unit,
    onRevokeDevice: (userId: String, deviceId: String, revoke: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val useBn = state.settings.useBanglaDigits
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.84f)
                .padding(horizontal = 16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            item {
                Text(strings.syncConflictsDevices, style = MaterialTheme.typography.titleLarge)
            }

            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Auto-sync when internet reconnects", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = state.settings.autoCloudSyncEnabled,
                                onCheckedChange = onToggleAutoSync
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Pending Outbox Queue: ${state.pendingSyncCount}", style = MaterialTheme.typography.labelMedium, color = EmeraldPrimary)
                            if (!currentUserId.isNullOrBlank()) {
                                Button(
                                    onClick = { onSyncNow(currentUserId) },
                                    enabled = !isSyncing
                                ) {
                                    Text(if (isSyncing) "Syncing..." else strings.syncNow)
                                }
                            }
                        }
                    }
                }
            }

            if (state.conflicts.isNotEmpty()) {
                item {
                    Text(
                        "Sync Conflicts (${state.conflicts.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = WarningAmber
                    )
                }
                items(state.conflicts, key = { it.id }) { conflict ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = WarningSoftAmber,
                        border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("${conflict.entityType} Conflict", style = MaterialTheme.typography.titleSmall, color = DarkNavy)
                            Text(conflict.conflictDetail, style = MaterialTheme.typography.bodySmall, color = DarkNavy)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onResolveConflict(conflict.id, true) },
                                    modifier = Modifier.weight(1f).testTag("conflict_keep_local_${conflict.id}")
                                ) { Text("Keep Local") }
                                OutlinedButton(
                                    onClick = { onResolveConflict(conflict.id, false) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Use Cloud") }
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "Authorized Devices (${state.authorizedDevices.size})",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            if (state.authorizedDevices.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.Devices,
                        title = "No synced devices recorded",
                        subtitle = "Sign in with Google and tap Sync to register this device."
                    )
                }
            } else {
                items(state.authorizedDevices, key = { it.id }) { dev ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(dev.deviceName, style = MaterialTheme.typography.titleSmall)
                                    if (dev.isCurrentDevice || dev.id == state.deviceId) {
                                        Text("(This Device)", style = MaterialTheme.typography.labelSmall, color = EmeraldPrimary)
                                    }
                                }
                                Text(
                                    "v${dev.appVersion} • Last Sync: ${MoneyUtils.formatDhakaDateTime(dev.lastSyncAtMillis, useBn)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (dev.revoked) {
                                    Text("REVOKED", style = MaterialTheme.typography.labelSmall, color = ExpenseRed)
                                }
                            }
                            if (!currentUserId.isNullOrBlank() && !dev.isCurrentDevice && dev.id != state.deviceId) {
                                TextButton(
                                    onClick = { onRevokeDevice(currentUserId, dev.id, !dev.revoked) }
                                ) {
                                    Text(
                                        if (dev.revoked) "Restore" else "Revoke",
                                        color = if (dev.revoked) EmeraldPrimary else ExpenseRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
