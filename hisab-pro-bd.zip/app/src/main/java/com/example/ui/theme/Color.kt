package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Palette - HISAB PRO BD
val EmeraldPrimary = Color(0xFF10A36C)
val EmeraldDark = Color(0xFF0B7D52)
val EmeraldLight = Color(0xFF34D399)
val SoftGreenAccent = Color(0xFFE6F7F0)
val SoftGreenContainer = Color(0xFFD1FAE5)

val DarkNavy = Color(0xFF101C2C)
val DarkNavyLight = Color(0xFF1E2D42)
val DarkNavySurface = Color(0xFF132133)
val DarkBackground = Color(0xFF0B131E)
val DarkCard = Color(0xFF172538)

val PureWhite = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF4F6F8)
val LightSurfaceVariant = Color(0xFFEAEFF4)
val BorderLight = Color(0xFFE2E8F0)
val BorderDark = Color(0xFF26384F)

// Semantic Financial Colors
val IncomeGreen = Color(0xFF10A36C)
val ExpenseRed = Color(0xFFDC2626)
val ExpenseSoftRed = Color(0xFFFEE2E2)
val ExpenseDarkRed = Color(0xFFF87171)
val WarningAmber = Color(0xFFD97706)
val WarningSoftAmber = Color(0xFFFEF3C7)
val InfoBlue = Color(0xFF2563EB)
val InfoSoftBlue = Color(0xFFDBEAFE)
val BkashPink = Color(0xFFE2136E)
val NagadOrange = Color(0xFFF26522)
val RocketPurple = Color(0xFF8C3494)

val TextPrimaryLight = Color(0xFF101C2C)
val TextSecondaryLight = Color(0xFF52637A)
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
