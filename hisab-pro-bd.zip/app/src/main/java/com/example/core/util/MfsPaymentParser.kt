package com.example.core.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.AccountTypes
import com.example.data.local.OnlinePaymentMethods
import java.math.BigDecimal
import java.math.RoundingMode

data class BdMfsProviderSpec(
    val paymentMethod: String,
    val accountType: String,
    val labelEn: String,
    val labelBn: String,
    val ussdCode: String,
    val appPackage: String,
    val defaultAccountName: String
)

data class ParsedMfsReceipt(
    val providerMethod: String? = null,
    val amountPaisa: Long? = null,
    val senderPhone: String = "",
    val trxId: String = ""
)

/**
 * Helper for Bangladesh Mobile Financial Services (bKash, Nagad, Rocket, Upay):
 * - Zero-permission USSD & App launchers (*247#, *167#, *322#, *268#)
 * - Smart confirmation SMS parser (extracts provider, Tk amount, sender mobile, and TrxID)
 */
object MfsPaymentParser {

    val PROVIDERS = listOf(
        BdMfsProviderSpec(
            paymentMethod = OnlinePaymentMethods.BKASH,
            accountType = AccountTypes.BKASH,
            labelEn = "bKash",
            labelBn = "বিকাশ",
            ussdCode = "*247#",
            appPackage = "com.bKash.customerapp",
            defaultAccountName = "bKash"
        ),
        BdMfsProviderSpec(
            paymentMethod = OnlinePaymentMethods.NAGAD,
            accountType = AccountTypes.NAGAD,
            labelEn = "Nagad",
            labelBn = "নগদ",
            ussdCode = "*167#",
            appPackage = "com.konasl.nagad",
            defaultAccountName = "Nagad"
        ),
        BdMfsProviderSpec(
            paymentMethod = OnlinePaymentMethods.ROCKET,
            accountType = AccountTypes.ROCKET,
            labelEn = "Rocket",
            labelBn = "রকেট",
            ussdCode = "*322#",
            appPackage = "com.dbbl.mbs.apps.main",
            defaultAccountName = "Rocket"
        ),
        BdMfsProviderSpec(
            paymentMethod = OnlinePaymentMethods.UPAY,
            accountType = AccountTypes.UPAY,
            labelEn = "Upay",
            labelBn = "উপায়",
            ussdCode = "*268#",
            appPackage = "com.ucb.upay",
            defaultAccountName = "Upay"
        )
    )

    fun specFor(methodOrAccountType: String): BdMfsProviderSpec? =
        PROVIDERS.firstOrNull {
            it.paymentMethod.equals(methodOrAccountType, ignoreCase = true) ||
                it.accountType.equals(methodOrAccountType, ignoreCase = true)
        }

    fun isMfsMethod(method: String): Boolean = specFor(method) != null

    /**
     * Opens the official MFS app if installed, otherwise opens the Android dialer with the USSD code.
     */
    fun openMfsAppOrUssd(context: Context, methodOrType: String) {
        val spec = specFor(methodOrType) ?: return
        val launchIntent = try {
            context.packageManager.getLaunchIntentForPackage(spec.appPackage)
        } catch (_: Exception) {
            null
        }
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            dialUssd(context, spec.ussdCode)
        }
    }

    fun dialUssd(context: Context, ussdCode: String) {
        try {
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(ussdCode)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(dialIntent)
        } catch (_: Exception) {
        }
    }

    private val TRX_ID_REGEX = Regex(
        """(?:TrxID|TxnId|Transaction\s*ID|Trx\s*Id|TxID|Ref)\s*[:#\-]?\s*([A-Z0-9]{6,20})""",
        RegexOption.IGNORE_CASE
    )
    private val AMOUNT_REGEX = Regex(
        """(?:Tk|BDT|৳)\s*([\d,]+(?:\.\d{1,2})?)|([\d,]+(?:\.\d{1,2})?)\s*(?:Tk|BDT|টাকা)""",
        RegexOption.IGNORE_CASE
    )
    private val PHONE_REGEX = Regex("""(?:\+?88)?(01[3-9]\d{8})""")

    fun parseReceiptSms(rawText: String): ParsedMfsReceipt {
        if (rawText.isBlank()) return ParsedMfsReceipt()
        val normalized = MoneyUtils.normalizeDigits(rawText.trim())
        val lower = normalized.lowercase()

        val provider = when {
            lower.contains("bkash") || rawText.contains("বিকাশ") || lower.contains("*247#") -> OnlinePaymentMethods.BKASH
            lower.contains("nagad") || rawText.contains("নগদ") || lower.contains("*167#") -> OnlinePaymentMethods.NAGAD
            lower.contains("rocket") || lower.contains("dbbl") || rawText.contains("রকেট") || lower.contains("*322#") -> OnlinePaymentMethods.ROCKET
            lower.contains("upay") || rawText.contains("উপায়") || lower.contains("*268#") -> OnlinePaymentMethods.UPAY
            else -> null
        }

        val trxId = TRX_ID_REGEX.find(normalized)?.groupValues?.getOrNull(1)?.trim()?.uppercase().orEmpty()

        val amountMatch = AMOUNT_REGEX.find(normalized)
        val amountRaw = amountMatch?.groupValues?.getOrNull(1)?.ifBlank {
            amountMatch.groupValues.getOrNull(2).orEmpty()
        }?.replace(",", "").orEmpty()
        val amountPaisa = if (amountRaw.isNotBlank()) {
            try {
                BigDecimal(amountRaw).multiply(BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
            } catch (_: Exception) {
                null
            }
        } else null

        val senderPhone = PHONE_REGEX.find(normalized.replace("-", "").replace(" ", ""))
            ?.groupValues?.getOrNull(1).orEmpty()

        return ParsedMfsReceipt(
            providerMethod = provider,
            amountPaisa = amountPaisa,
            senderPhone = senderPhone,
            trxId = trxId
        )
    }
}
