package com.example.data.repository

import androidx.room.withTransaction
import com.example.core.util.MoneyUtils
import com.example.core.util.SecurityUtils
import com.example.data.local.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class SaleCartLine(
    val productId: String? = null,
    val itemName: String,
    val unit: String = "Piece",
    val quantityMilliUnits: Long,
    val unitPricePaisa: Long,
    val costPricePaisa: Long = 0L
)

class AccountingRepository(private val db: HisabDatabase) {

    fun observeBusinesses(): Flow<List<BusinessEntity>> = db.businessDao().observeBusinesses()
    fun observeAccounts(businessId: String): Flow<List<AccountEntity>> = db.accountDao().observeAccounts(businessId)
    fun observeCustomers(businessId: String): Flow<List<CustomerEntity>> = db.customerDao().observeCustomers(businessId)
    fun observeArchivedCustomers(businessId: String): Flow<List<CustomerEntity>> = db.customerDao().observeArchivedCustomers(businessId)
    fun observeSuppliers(businessId: String): Flow<List<SupplierEntity>> = db.supplierDao().observeSuppliers(businessId)
    fun observeProducts(businessId: String): Flow<List<ProductEntity>> = db.productDao().observeProducts(businessId)
    fun observeStockMovements(businessId: String): Flow<List<StockMovementEntity>> = db.stockMovementDao().observeMovements(businessId)
    fun observeCategories(businessId: String): Flow<List<CategoryEntity>> = db.categoryDao().observeCategories(businessId)
    fun observeTransactions(businessId: String): Flow<List<AccountingTransactionEntity>> = db.transactionDao().observeTransactions(businessId)
    fun observeCustomerTransactions(businessId: String, customerId: String): Flow<List<AccountingTransactionEntity>> =
        db.transactionDao().observeCustomerTransactions(businessId, customerId)
    fun observeSupplierTransactions(businessId: String, supplierId: String): Flow<List<AccountingTransactionEntity>> =
        db.transactionDao().observeSupplierTransactions(businessId, supplierId)
    fun observeInvoices(businessId: String): Flow<List<InvoiceEntity>> = db.invoiceDao().observeInvoices(businessId)
    fun observeEmployees(businessId: String): Flow<List<EmployeeEntity>> = db.employeeDao().observeEmployees(businessId)
    fun observeNotifications(businessId: String): Flow<List<AppNotificationEntity>> = db.notificationDao().observeNotifications(businessId)
    fun observeUnreadNotificationCount(businessId: String): Flow<Int> = db.notificationDao().observeUnreadCount(businessId)
    fun observeAttendance(businessId: String): Flow<List<AttendanceEntity>> = db.attendanceDao().observeAttendance(businessId)
    fun observeLeaves(businessId: String): Flow<List<LeaveRequestEntity>> = db.leaveRequestDao().observeLeaves(businessId)
    fun observeSalaryPayments(businessId: String): Flow<List<SalaryPaymentEntity>> = db.salaryPaymentDao().observeSalaryPayments(businessId)
    fun observeActivityLogs(businessId: String): Flow<List<ActivityLogEntity>> = db.activityLogDao().observeActivityLogs(businessId)
    fun observeRolePermissions(businessId: String): Flow<List<RolePermissionEntity>> = db.rolePermissionDao().observeRolePermissions(businessId)
    fun observeSyncOutbox(): Flow<List<SyncOutboxEntity>> = db.syncOutboxDao().observeAll()
    fun observeConflicts(): Flow<List<SyncOutboxEntity>> = db.syncOutboxDao().observeConflicts()
    fun observePendingSyncCount(): Flow<Int> = db.syncOutboxDao().observePendingCount()
    fun observeAuthorizedDevices(userId: String): Flow<List<AuthorizedDeviceEntity>> = db.authorizedDeviceDao().observeDevices(userId)
    fun observeBakiEntries(businessId: String): Flow<List<BakiKhataEntryEntity>> = db.bakiKhataDao().observeEntriesForBusiness(businessId)
    fun observeBakiEntriesForCustomer(businessId: String, customerId: String): Flow<List<BakiKhataEntryEntity>> =
        db.bakiKhataDao().observeEntriesForCustomer(businessId, customerId)
    fun observeUpcomingBakiDues(businessId: String): Flow<List<BakiKhataEntryEntity>> =
        db.bakiKhataDao().observeUpcomingOrOverdueDues(businessId)

    suspend fun getInvoiceItems(invoiceId: String): List<InvoiceItemEntity> =
        db.invoiceDao().getItemsForInvoice(invoiceId)

    fun observeAllInvoiceItems(businessId: String): Flow<List<InvoiceItemEntity>> =
        db.invoiceDao().observeAllInvoiceItems(businessId)

    suspend fun getAllInvoiceItems(businessId: String): List<InvoiceItemEntity> =
        db.invoiceDao().getAllInvoiceItemsSync(businessId)

    suspend fun markNotificationsRead(businessId: String) {
        db.notificationDao().markAllRead(businessId)
    }

    private suspend fun queueOutbox(
        businessId: String,
        entityType: String,
        entityId: String,
        version: Long = 1L,
        operation: String = "UPSERT"
    ) {
        db.syncOutboxDao().upsert(
            SyncOutboxEntity(
                id = "${entityType}_$entityId",
                businessId = businessId,
                entityType = entityType,
                entityId = entityId,
                operation = operation,
                version = version,
                updatedAtMillis = System.currentTimeMillis(),
                status = "PENDING",
                conflictDetail = ""
            )
        )
    }

    suspend fun logActivity(
        businessId: String,
        actorName: String,
        actorRole: String,
        actionType: String,
        entityType: String,
        entityId: String,
        summary: String
    ) {
        db.activityLogDao().insert(
            ActivityLogEntity(
                businessId = businessId,
                actorName = actorName,
                actorRole = actorRole,
                actionType = actionType,
                entityType = entityType,
                entityId = entityId,
                summary = summary,
                occurredAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun createBusinessWithDefaults(
        name: String,
        category: String,
        phone: String,
        address: String,
        logoUri: String?,
        languageCode: String,
        openingCashPaisa: Long,
        inventoryEnabled: Boolean
    ): BusinessEntity = db.withTransaction {
        val now = System.currentTimeMillis()
        val business = BusinessEntity(
            name = name.trim(),
            category = category,
            phone = phone.trim(),
            address = address.trim(),
            logoUri = logoUri,
            languageCode = languageCode,
            openingCashPaisa = openingCashPaisa.coerceAtLeast(0L),
            inventoryEnabled = inventoryEnabled,
            createdAt = now,
            updatedAt = now
        )
        db.businessDao().upsert(business)

        val cashAccount = AccountEntity(
            businessId = business.id,
            name = "Cash in Hand",
            type = AccountTypes.CASH,
            openingBalancePaisa = openingCashPaisa.coerceAtLeast(0L),
            currentBalancePaisa = openingCashPaisa.coerceAtLeast(0L),
            isDefault = true,
            createdAt = now
        )
        val bkashAccount = AccountEntity(
            businessId = business.id,
            name = "bKash Merchant",
            type = AccountTypes.BKASH,
            createdAt = now + 1
        )
        val nagadAccount = AccountEntity(
            businessId = business.id,
            name = "Nagad",
            type = AccountTypes.NAGAD,
            createdAt = now + 2
        )
        val bankAccount = AccountEntity(
            businessId = business.id,
            name = "Business Bank",
            type = AccountTypes.BANK,
            createdAt = now + 3
        )
        db.accountDao().upsertAll(listOf(cashAccount, bkashAccount, nagadAccount, bankAccount))

        if (openingCashPaisa > 0L) {
            db.transactionDao().insert(
                AccountingTransactionEntity(
                    businessId = business.id,
                    type = TxTypes.OPENING_BALANCE,
                    accountId = cashAccount.id,
                    accountName = cashAccount.name,
                    totalAmountPaisa = openingCashPaisa,
                    paidAmountPaisa = openingCashPaisa,
                    cashFlowDeltaPaisa = openingCashPaisa,
                    accountBalanceAfterPaisa = openingCashPaisa,
                    notes = "Opening cash balance",
                    occurredAt = now,
                    createdBy = "Owner"
                )
            )
        }

        val defaultCategories = listOf(
            CategoryEntity(businessId = business.id, name = "Rent", nameBn = "দোকান / অফিস ভাড়া", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Electricity", nameBn = "বিদ্যুৎ বিল", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Employee Salary", nameBn = "কর্মচারী বেতন", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Transport", nameBn = "যাতায়াত ও পরিবহন", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Food", nameBn = "আপ্যায়ন ও খাবার", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Maintenance", nameBn = "মেরামত ও রক্ষণাবেক্ষণ", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Marketing", nameBn = "মার্কেটিং ও প্রচার", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Other Expenses", nameBn = "অন্যান্য খরচ", type = "EXPENSE", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Product Sales", nameBn = "পণ্য বিক্রয় আয়", type = "INCOME", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Service Income", nameBn = "সেবা থেকে আয়", type = "INCOME", isSystem = true),
            CategoryEntity(businessId = business.id, name = "Other Income", nameBn = "অন্যান্য আয়", type = "INCOME", isSystem = true)
        )
        db.categoryDao().insertAll(defaultCategories)

        db.employeeDao().upsert(
            EmployeeEntity(
                businessId = business.id,
                name = "Business Owner",
                phone = phone.trim(),
                role = EmployeeRoles.OWNER,
                canViewReports = true,
                canDeleteOrReverse = true,
                canManageEmployees = true,
                canManageSettings = true,
                canRecordSales = true,
                canEditCustomers = true,
                canManageInventory = true,
                isActive = true,
                createdAt = now
            )
        )
        seedDefaultRolePermissionsInternal(business.id, now)
        queueOutbox(business.id, "BUSINESS", business.id, business.syncVersion)

        business
    }

    private suspend fun seedDefaultRolePermissionsInternal(businessId: String, now: Long = System.currentTimeMillis()) {
        val existing = db.rolePermissionDao().getRolePermissionsSync(businessId)
        if (existing.isNotEmpty()) return
        val defaults = listOf(
            RolePermissionEntity(
                businessId = businessId, roleName = EmployeeRoles.OWNER,
                canViewDashboard = true, canViewReports = true, canRecordSales = true,
                canEditCustomers = true, canManageInventory = true, canDeleteOrReverse = true,
                canManageEmployees = true, canManageSettings = true, updatedAt = now
            ),
            RolePermissionEntity(
                businessId = businessId, roleName = EmployeeRoles.ADMINISTRATOR,
                canViewDashboard = true, canViewReports = true, canRecordSales = true,
                canEditCustomers = true, canManageInventory = true, canDeleteOrReverse = true,
                canManageEmployees = true, canManageSettings = false, updatedAt = now
            ),
            RolePermissionEntity(
                businessId = businessId, roleName = EmployeeRoles.MANAGER,
                canViewDashboard = true, canViewReports = true, canRecordSales = true,
                canEditCustomers = true, canManageInventory = true, canDeleteOrReverse = true,
                canManageEmployees = false, canManageSettings = false, updatedAt = now
            ),
            RolePermissionEntity(
                businessId = businessId, roleName = EmployeeRoles.ACCOUNTANT,
                canViewDashboard = true, canViewReports = true, canRecordSales = true,
                canEditCustomers = true, canManageInventory = false, canDeleteOrReverse = false,
                canManageEmployees = false, canManageSettings = false, updatedAt = now
            ),
            RolePermissionEntity(
                businessId = businessId, roleName = EmployeeRoles.CASHIER,
                canViewDashboard = true, canViewReports = false, canRecordSales = true,
                canEditCustomers = true, canManageInventory = false, canDeleteOrReverse = false,
                canManageEmployees = false, canManageSettings = false, updatedAt = now
            )
        )
        db.rolePermissionDao().upsertAll(defaults)
    }

    suspend fun ensureRolePermissionsSeeded(businessId: String) {
        seedDefaultRolePermissionsInternal(businessId)
    }

    suspend fun updateBusiness(business: BusinessEntity) {
        db.businessDao().upsert(business.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun saveAccount(
        businessId: String,
        name: String,
        type: String,
        accountNumber: String,
        openingBalancePaisa: Long
    ) = db.withTransaction {
        val now = System.currentTimeMillis()
        val account = AccountEntity(
            businessId = businessId,
            name = name.trim(),
            type = type,
            accountNumber = accountNumber.trim(),
            openingBalancePaisa = openingBalancePaisa,
            currentBalancePaisa = openingBalancePaisa,
            isDefault = false,
            createdAt = now
        )
        db.accountDao().upsert(account)
        if (openingBalancePaisa != 0L) {
            db.transactionDao().insert(
                AccountingTransactionEntity(
                    businessId = businessId,
                    type = TxTypes.OPENING_BALANCE,
                    accountId = account.id,
                    accountName = account.name,
                    totalAmountPaisa = openingBalancePaisa,
                    paidAmountPaisa = openingBalancePaisa,
                    cashFlowDeltaPaisa = openingBalancePaisa,
                    accountBalanceAfterPaisa = openingBalancePaisa,
                    notes = "Opening balance for ${account.name}",
                    occurredAt = now
                )
            )
        }
    }

    suspend fun saveCustomer(
        businessId: String,
        existingId: String?,
        name: String,
        phone: String,
        address: String,
        photoUri: String?,
        category: String,
        openingDuePaisa: Long
    ): CustomerEntity = db.withTransaction {
        val now = System.currentTimeMillis()
        if (existingId != null) {
            val existing = db.customerDao().getById(existingId)
            if (existing != null) {
                val updated = existing.copy(
                    name = name.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    photoUri = photoUri ?: existing.photoUri,
                    category = category,
                    updatedAt = now
                )
                db.customerDao().upsert(updated)
                return@withTransaction updated
            }
        }
        val count = db.customerDao().countForBusiness(businessId) + 1
        val code = "CUST-${count.toString().padStart(4, '0')}"
        val customer = CustomerEntity(
            businessId = businessId,
            customerCode = code,
            name = name.trim(),
            phone = phone.trim(),
            address = address.trim(),
            photoUri = photoUri,
            category = category,
            openingDuePaisa = openingDuePaisa,
            currentDuePaisa = openingDuePaisa,
            overdueSinceMillis = if (openingDuePaisa > 0L) now else null,
            createdAt = now,
            updatedAt = now
        )
        db.customerDao().upsert(customer)
        if (openingDuePaisa != 0L) {
            val openingTx = AccountingTransactionEntity(
                businessId = businessId,
                type = TxTypes.OPENING_BALANCE,
                customerId = customer.id,
                partyName = customer.name,
                totalAmountPaisa = openingDuePaisa,
                dueDeltaPaisa = openingDuePaisa,
                notes = "Opening due balance",
                occurredAt = now
            )
            db.transactionDao().insert(openingTx)
            if (openingDuePaisa > 0L) {
                db.bakiKhataDao().upsert(
                    BakiKhataEntryEntity(
                        businessId = businessId,
                        customerId = customer.id,
                        customerName = customer.name,
                        entryType = BakiEntryTypes.CREDIT,
                        amountPaisa = openingDuePaisa,
                        remainingBalanceAfterPaisa = openingDuePaisa,
                        entryDateMillis = now,
                        notes = "Opening due balance",
                        transactionId = openingTx.id,
                        createdAt = now
                    )
                )
            }
        }
        customer
    }

    suspend fun setCustomerArchived(customerId: String, archived: Boolean) {
        val customer = db.customerDao().getById(customerId) ?: return
        db.customerDao().upsert(customer.copy(archived = archived, updatedAt = System.currentTimeMillis()))
    }

    suspend fun saveSupplier(
        businessId: String,
        existingId: String?,
        name: String,
        phone: String,
        address: String,
        openingPayablePaisa: Long
    ): SupplierEntity = db.withTransaction {
        val now = System.currentTimeMillis()
        if (existingId != null) {
            val existing = db.supplierDao().getById(existingId)
            if (existing != null) {
                val updated = existing.copy(
                    name = name.trim(),
                    phone = phone.trim(),
                    address = address.trim(),
                    updatedAt = now
                )
                db.supplierDao().upsert(updated)
                return@withTransaction updated
            }
        }
        val count = db.supplierDao().countForBusiness(businessId) + 1
        val code = "SUP-${count.toString().padStart(4, '0')}"
        val supplier = SupplierEntity(
            businessId = businessId,
            supplierCode = code,
            name = name.trim(),
            phone = phone.trim(),
            address = address.trim(),
            openingPayablePaisa = openingPayablePaisa,
            currentPayablePaisa = openingPayablePaisa,
            createdAt = now,
            updatedAt = now
        )
        db.supplierDao().upsert(supplier)
        if (openingPayablePaisa != 0L) {
            db.transactionDao().insert(
                AccountingTransactionEntity(
                    businessId = businessId,
                    type = TxTypes.OPENING_BALANCE,
                    supplierId = supplier.id,
                    partyName = supplier.name,
                    totalAmountPaisa = openingPayablePaisa,
                    dueDeltaPaisa = openingPayablePaisa,
                    notes = "Opening supplier payable",
                    occurredAt = now
                )
            )
        }
        supplier
    }

    suspend fun saveProduct(
        businessId: String,
        existingId: String?,
        name: String,
        sku: String,
        barcode: String,
        category: String,
        purchasePricePaisa: Long,
        sellingPricePaisa: Long,
        initialStockMilliUnits: Long,
        unit: String,
        lowStockThresholdMilliUnits: Long,
        imageUri: String?,
        createdBy: String = "Owner"
    ): ProductEntity = db.withTransaction {
        val now = System.currentTimeMillis()
        if (existingId != null) {
            val existing = db.productDao().getById(existingId)
            if (existing != null) {
                val updated = existing.copy(
                    name = name.trim(),
                    sku = sku.trim(),
                    barcode = barcode.trim(),
                    category = category.trim().ifBlank { "General" },
                    purchasePricePaisa = purchasePricePaisa,
                    sellingPricePaisa = sellingPricePaisa,
                    unit = unit.trim().ifBlank { "Piece" },
                    lowStockThresholdMilliUnits = lowStockThresholdMilliUnits,
                    imageUri = imageUri ?: existing.imageUri,
                    updatedAt = now
                )
                db.productDao().upsert(updated)
                return@withTransaction updated
            }
        }

        val product = ProductEntity(
            businessId = businessId,
            name = name.trim(),
            sku = sku.trim(),
            barcode = barcode.trim(),
            category = category.trim().ifBlank { "General" },
            purchasePricePaisa = purchasePricePaisa,
            sellingPricePaisa = sellingPricePaisa,
            stockMilliUnits = initialStockMilliUnits,
            unit = unit.trim().ifBlank { "Piece" },
            lowStockThresholdMilliUnits = lowStockThresholdMilliUnits,
            imageUri = imageUri,
            createdAt = now,
            updatedAt = now
        )
        db.productDao().upsert(product)
        if (initialStockMilliUnits > 0L) {
            db.stockMovementDao().insert(
                StockMovementEntity(
                    businessId = businessId,
                    productId = product.id,
                    productName = product.name,
                    movementType = "OPENING",
                    deltaMilliUnits = initialStockMilliUnits,
                    balanceAfterMilliUnits = initialStockMilliUnits,
                    unitCostPaisa = purchasePricePaisa,
                    notes = "Opening stock",
                    occurredAt = now,
                    createdBy = createdBy
                )
            )
        }
        product
    }

    suspend fun adjustStock(
        businessId: String,
        productId: String,
        movementType: String, // ADJUSTMENT, DAMAGE, SALE_RETURN, PURCHASE_RETURN
        deltaMilliUnits: Long,
        notes: String,
        createdBy: String = "Owner"
    ) = db.withTransaction {
        val product = db.productDao().getById(productId) ?: return@withTransaction
        val now = System.currentTimeMillis()
        val newStock = (product.stockMilliUnits + deltaMilliUnits).coerceAtLeast(0L)
        db.productDao().updateStock(productId, newStock, now)
        db.stockMovementDao().insert(
            StockMovementEntity(
                businessId = businessId,
                productId = productId,
                productName = product.name,
                movementType = movementType,
                deltaMilliUnits = deltaMilliUnits,
                balanceAfterMilliUnits = newStock,
                unitCostPaisa = product.purchasePricePaisa,
                notes = notes.trim(),
                occurredAt = now,
                createdBy = createdBy
            )
        )
        if (newStock <= product.lowStockThresholdMilliUnits) {
            db.notificationDao().insert(
                AppNotificationEntity(
                    businessId = businessId,
                    type = "LOW_STOCK",
                    title = "Low Stock Alert",
                    message = "${product.name} is low on stock (${MoneyUtils.milliUnitsToString(newStock)} ${product.unit} left).",
                    createdAt = now
                )
            )
        }
    }

    /**
     * Atomic POS & Credit Sale engine.
     * - Deducts stock & computes exact COGS.
     * - Updates customer receivable ONLY for unpaid portion.
     * - Credits Cash/Bank/MFS account ONLY with paidAmountPaisa (never unpaid credit!).
     * - Guards against duplicate submission via idempotencyKey.
     */
    suspend fun recordSale(
        businessId: String,
        customerId: String?,
        lines: List<SaleCartLine>,
        discountPaisa: Long,
        taxRateBps: Int,
        paidPaisa: Long,
        accountId: String,
        notes: String,
        occurredAt: Long = System.currentTimeMillis(),
        createdBy: String = "Owner",
        idempotencyKey: String = UUID.randomUUID().toString()
    ): InvoiceEntity = db.withTransaction {
        val existingTx = db.transactionDao().getByIdempotencyKey(idempotencyKey)
        if (existingTx?.referenceId != null) {
            val inv = db.invoiceDao().getInvoiceById(existingTx.referenceId)
            if (inv != null) return@withTransaction inv
        }

        require(lines.isNotEmpty()) { "Sale must contain at least one item" }
        val subtotalPaisa = lines.sumOf {
            MoneyUtils.calculateLineTotalPaisa(it.quantityMilliUnits, it.unitPricePaisa)
        }
        val cleanDiscount = discountPaisa.coerceIn(0L, subtotalPaisa)
        val taxable = (subtotalPaisa - cleanDiscount).coerceAtLeast(0L)
        val taxPaisa = MoneyUtils.calculateTaxPaisa(taxable, taxRateBps)
        val grandTotalPaisa = taxable + taxPaisa
        val cleanPaid = paidPaisa.coerceIn(0L, grandTotalPaisa)
        val duePaisa = grandTotalPaisa - cleanPaid

        if (duePaisa > 0L) {
            require(!customerId.isNullOrBlank()) { "Credit/partial sales require selecting a customer" }
        }

        val customer = customerId?.let { db.customerDao().getById(it) }
        val partyName = customer?.name ?: "Walk-in Customer"
        val account = db.accountDao().getById(accountId)
            ?: throw IllegalStateException("Payment account not found")

        val invoiceCount = db.invoiceDao().countInvoices(businessId, "SALE") + 1
        val invoiceNo = "INV-${invoiceCount.toString().padStart(5, '0')}"

        var totalCogsPaisa = 0L
        var estimatedCost = false
        val invoiceId = UUID.randomUUID().toString()
        val invoiceItems = mutableListOf<InvoiceItemEntity>()

        for (line in lines) {
            val lineTotal = MoneyUtils.calculateLineTotalPaisa(line.quantityMilliUnits, line.unitPricePaisa)
            var unitCost = line.costPricePaisa
            if (line.productId != null) {
                val product = db.productDao().getById(line.productId)
                if (product != null) {
                    if (unitCost <= 0L) unitCost = product.purchasePricePaisa
                    val newStock = (product.stockMilliUnits - line.quantityMilliUnits).coerceAtLeast(0L)
                    db.productDao().updateStock(product.id, newStock, occurredAt)
                    db.stockMovementDao().insert(
                        StockMovementEntity(
                            businessId = businessId,
                            productId = product.id,
                            productName = product.name,
                            movementType = "SALE",
                            deltaMilliUnits = -line.quantityMilliUnits,
                            balanceAfterMilliUnits = newStock,
                            unitCostPaisa = unitCost,
                            referenceId = invoiceId,
                            notes = "Invoice $invoiceNo",
                            occurredAt = occurredAt,
                            createdBy = createdBy
                        )
                    )
                    if (newStock <= product.lowStockThresholdMilliUnits) {
                        db.notificationDao().insert(
                            AppNotificationEntity(
                                businessId = businessId,
                                type = "LOW_STOCK",
                                title = "Low Stock Alert",
                                message = "${product.name} is low (${MoneyUtils.milliUnitsToString(newStock)} ${product.unit} left).",
                                createdAt = occurredAt
                            )
                        )
                    }
                }
            }
            if (unitCost <= 0L) estimatedCost = true
            totalCogsPaisa += MoneyUtils.calculateLineTotalPaisa(line.quantityMilliUnits, unitCost)
            invoiceItems.add(
                InvoiceItemEntity(
                    invoiceId = invoiceId,
                    productId = line.productId,
                    itemName = line.itemName,
                    unit = line.unit,
                    quantityMilliUnits = line.quantityMilliUnits,
                    unitPricePaisa = line.unitPricePaisa,
                    costPricePaisa = unitCost,
                    lineTotalPaisa = lineTotal
                )
            )
        }

        val invoice = InvoiceEntity(
            id = invoiceId,
            businessId = businessId,
            invoiceNumber = invoiceNo,
            invoiceType = "SALE",
            partyId = customer?.id,
            partyName = partyName,
            subtotalPaisa = subtotalPaisa,
            discountPaisa = cleanDiscount,
            taxRateBps = taxRateBps,
            taxPaisa = taxPaisa,
            totalPaisa = grandTotalPaisa,
            paidPaisa = cleanPaid,
            duePaisa = duePaisa,
            cogsPaisa = totalCogsPaisa,
            accountId = account.id,
            notes = notes.trim(),
            occurredAt = occurredAt,
            createdBy = createdBy
        )
        db.invoiceDao().insertInvoice(invoice)
        db.invoiceDao().insertItems(invoiceItems)

        val newAccountBalance = account.currentBalancePaisa + cleanPaid
        if (cleanPaid > 0L) {
            db.accountDao().updateBalance(account.id, newAccountBalance)
        }

        if (customer != null) {
            val newDue = customer.currentDuePaisa + duePaisa
            db.customerDao().upsert(
                customer.copy(
                    currentDuePaisa = newDue,
                    totalPurchasesPaisa = customer.totalPurchasesPaisa + grandTotalPaisa,
                    totalPaymentsPaisa = customer.totalPaymentsPaisa + cleanPaid,
                    overdueSinceMillis = if (newDue > 0L) (customer.overdueSinceMillis ?: occurredAt) else null,
                    updatedAt = occurredAt
                )
            )
        }

        val txType = if (duePaisa > 0L) TxTypes.CREDIT_SALE else TxTypes.SALE
        val tx = AccountingTransactionEntity(
            idempotencyKey = idempotencyKey,
            businessId = businessId,
            type = txType,
            customerId = customer?.id,
            partyName = partyName,
            accountId = account.id,
            accountName = account.name,
            referenceId = invoice.id,
            categoryName = invoiceNo,
            subtotalPaisa = subtotalPaisa,
            discountPaisa = cleanDiscount,
            taxPaisa = taxPaisa,
            totalAmountPaisa = grandTotalPaisa,
            paidAmountPaisa = cleanPaid,
            dueDeltaPaisa = duePaisa,
            cogsPaisa = totalCogsPaisa,
            hasEstimatedCost = estimatedCost,
            cashFlowDeltaPaisa = cleanPaid,
            accountBalanceAfterPaisa = newAccountBalance,
            notes = notes.trim().ifBlank { "Sale $invoiceNo" },
            occurredAt = occurredAt,
            createdBy = createdBy
        )
        db.transactionDao().insert(tx)
        if (customer != null && duePaisa > 0L) {
            val updatedDue = customer.currentDuePaisa + duePaisa
            db.bakiKhataDao().upsert(
                BakiKhataEntryEntity(
                    businessId = businessId,
                    customerId = customer.id,
                    customerName = customer.name,
                    entryType = BakiEntryTypes.CREDIT,
                    amountPaisa = duePaisa,
                    remainingBalanceAfterPaisa = updatedDue,
                    entryDateMillis = occurredAt,
                    notes = notes.trim().ifBlank { "Credit Invoice $invoiceNo" },
                    transactionId = tx.id,
                    createdAt = occurredAt
                )
            )
        }
        queueOutbox(businessId, "TRANSACTION", tx.id, 1L)
        queueOutbox(businessId, "INVOICE", invoice.id, 1L)
        if (customer != null) queueOutbox(businessId, "CUSTOMER", customer.id, customer.syncVersion + 1)
        logActivity(
            businessId, createdBy, "", "SALE", "INVOICE", invoice.id,
            "$invoiceNo ($partyName): ${MoneyUtils.formatTaka(grandTotalPaisa)}"
        )
        invoice
    }

    /**
     * Digital Due Ledger (বাকির খাতা) entry:
     * - CREDIT_SALE (direct credit entry without POS items)
     * - CUSTOMER_CREDIT_ADVANCE (money borrowed/advanced)
     * - CUSTOMER_PAYMENT (partial or full payment)
     * - CUSTOMER_REFUND (refund to customer)
     */
    suspend fun recordDueLedgerEntry(
        businessId: String,
        customerId: String,
        type: String,
        amountPaisa: Long,
        accountId: String,
        affectAccountBalance: Boolean = true,
        notes: String,
        occurredAt: Long = System.currentTimeMillis(),
        dueDateMillis: Long? = null,
        createdBy: String = "Owner",
        idempotencyKey: String = UUID.randomUUID().toString()
    ): AccountingTransactionEntity = db.withTransaction {
        db.transactionDao().getByIdempotencyKey(idempotencyKey)?.let { return@withTransaction it }
        require(amountPaisa > 0L) { "Amount must be greater than zero" }

        val customer = db.customerDao().getById(customerId)
            ?: throw IllegalStateException("Customer not found")
        val account = db.accountDao().getById(accountId)
            ?: throw IllegalStateException("Account not found")

        val dueDelta: Long
        val cashDelta: Long
        val purchaseDelta: Long
        val paymentDelta: Long
        val paidAmount: Long

        when (type) {
            TxTypes.CREDIT_SALE -> {
                dueDelta = amountPaisa
                cashDelta = 0L
                purchaseDelta = amountPaisa
                paymentDelta = 0L
                paidAmount = 0L
            }
            TxTypes.CUSTOMER_CREDIT_ADVANCE -> {
                dueDelta = amountPaisa
                cashDelta = if (affectAccountBalance) -amountPaisa else 0L
                purchaseDelta = 0L
                paymentDelta = 0L
                paidAmount = if (affectAccountBalance) amountPaisa else 0L
            }
            TxTypes.CUSTOMER_PAYMENT -> {
                dueDelta = -amountPaisa
                cashDelta = amountPaisa
                purchaseDelta = 0L
                paymentDelta = amountPaisa
                paidAmount = amountPaisa
            }
            TxTypes.CUSTOMER_REFUND -> {
                dueDelta = amountPaisa
                cashDelta = -amountPaisa
                purchaseDelta = 0L
                paymentDelta = -amountPaisa
                paidAmount = amountPaisa
            }
            else -> throw IllegalArgumentException("Unsupported due ledger type: $type")
        }

        val newAccountBalance = account.currentBalancePaisa + cashDelta
        if (cashDelta != 0L) {
            db.accountDao().updateBalance(account.id, newAccountBalance)
        }

        val newDue = customer.currentDuePaisa + dueDelta
        db.customerDao().upsert(
            customer.copy(
                currentDuePaisa = newDue,
                totalPurchasesPaisa = (customer.totalPurchasesPaisa + purchaseDelta).coerceAtLeast(0L),
                totalPaymentsPaisa = (customer.totalPaymentsPaisa + paymentDelta).coerceAtLeast(0L),
                overdueSinceMillis = when {
                    newDue <= 0L -> null
                    customer.overdueSinceMillis != null -> customer.overdueSinceMillis
                    else -> occurredAt
                },
                updatedAt = occurredAt
            )
        )

        val tx = AccountingTransactionEntity(
            idempotencyKey = idempotencyKey,
            businessId = businessId,
            type = type,
            customerId = customer.id,
            partyName = customer.name,
            accountId = account.id,
            accountName = account.name,
            totalAmountPaisa = amountPaisa,
            paidAmountPaisa = paidAmount,
            dueDeltaPaisa = dueDelta,
            hasEstimatedCost = type == TxTypes.CREDIT_SALE,
            cashFlowDeltaPaisa = cashDelta,
            accountBalanceAfterPaisa = newAccountBalance,
            notes = notes.trim(),
            occurredAt = occurredAt,
            dueDateMillis = dueDateMillis,
            createdBy = createdBy
        )
        db.transactionDao().insert(tx)
        val bakiEntry = if (type == TxTypes.CUSTOMER_PAYMENT) {
            if (newDue <= 0L) {
                db.bakiKhataDao().markOpenCreditsSettledForCustomer(customer.id, occurredAt)
            }
            BakiKhataEntryEntity(
                businessId = businessId,
                customerId = customer.id,
                customerName = customer.name,
                entryType = BakiEntryTypes.REPAYMENT,
                amountPaisa = amountPaisa,
                remainingBalanceAfterPaisa = newDue,
                entryDateMillis = occurredAt,
                actualRepaymentDateMillis = occurredAt,
                isSettled = true,
                notes = notes.trim().ifBlank { "Payment received" },
                transactionId = tx.id,
                createdAt = occurredAt
            )
        } else {
            BakiKhataEntryEntity(
                businessId = businessId,
                customerId = customer.id,
                customerName = customer.name,
                entryType = BakiEntryTypes.CREDIT,
                amountPaisa = amountPaisa,
                remainingBalanceAfterPaisa = newDue,
                entryDateMillis = occurredAt,
                promisedRepaymentDateMillis = dueDateMillis,
                isSettled = newDue <= 0L,
                notes = notes.trim(),
                transactionId = tx.id,
                createdAt = occurredAt
            )
        }
        db.bakiKhataDao().upsert(bakiEntry)
        queueOutbox(businessId, "TRANSACTION", tx.id, 1L)
        queueOutbox(businessId, "CUSTOMER", customer.id, customer.syncVersion + 1)
        logActivity(
            businessId, createdBy, "", type, "CUSTOMER", customer.id,
            "${customer.name}: ${MoneyUtils.formatTaka(amountPaisa)}"
        )
        tx
    }

    suspend fun markBakiEntryRepaid(
        entryId: String,
        repaymentDateMillis: Long = System.currentTimeMillis()
    ) {
        db.bakiKhataDao().markEntrySettled(entryId, repaymentDateMillis)
    }

    suspend fun recordPurchase(
        businessId: String,
        supplierId: String?,
        lines: List<SaleCartLine>,
        paidPaisa: Long,
        accountId: String,
        notes: String,
        occurredAt: Long = System.currentTimeMillis(),
        createdBy: String = "Owner",
        idempotencyKey: String = UUID.randomUUID().toString()
    ): InvoiceEntity = db.withTransaction {
        val existingTx = db.transactionDao().getByIdempotencyKey(idempotencyKey)
        if (existingTx?.referenceId != null) {
            val inv = db.invoiceDao().getInvoiceById(existingTx.referenceId)
            if (inv != null) return@withTransaction inv
        }

        require(lines.isNotEmpty()) { "Purchase must contain at least one item" }
        val totalPaisa = lines.sumOf {
            MoneyUtils.calculateLineTotalPaisa(it.quantityMilliUnits, it.unitPricePaisa)
        }
        val cleanPaid = paidPaisa.coerceIn(0L, totalPaisa)
        val payableDelta = totalPaisa - cleanPaid

        val supplier = supplierId?.let { db.supplierDao().getById(it) }
        val partyName = supplier?.name ?: "Cash Supplier"
        val account = db.accountDao().getById(accountId)
            ?: throw IllegalStateException("Payment account not found")

        val count = db.invoiceDao().countInvoices(businessId, "PURCHASE") + 1
        val purNo = "PUR-${count.toString().padStart(5, '0')}"
        val invoiceId = UUID.randomUUID().toString()
        val items = mutableListOf<InvoiceItemEntity>()

        for (line in lines) {
            val lineTotal = MoneyUtils.calculateLineTotalPaisa(line.quantityMilliUnits, line.unitPricePaisa)
            if (line.productId != null) {
                val product = db.productDao().getById(line.productId)
                if (product != null) {
                    val newStock = product.stockMilliUnits + line.quantityMilliUnits
                    db.productDao().upsert(
                        product.copy(
                            purchasePricePaisa = line.unitPricePaisa,
                            stockMilliUnits = newStock,
                            updatedAt = occurredAt
                        )
                    )
                    db.stockMovementDao().insert(
                        StockMovementEntity(
                            businessId = businessId,
                            productId = product.id,
                            productName = product.name,
                            movementType = "PURCHASE",
                            deltaMilliUnits = line.quantityMilliUnits,
                            balanceAfterMilliUnits = newStock,
                            unitCostPaisa = line.unitPricePaisa,
                            referenceId = invoiceId,
                            notes = "Purchase $purNo",
                            occurredAt = occurredAt,
                            createdBy = createdBy
                        )
                    )
                }
            }
            items.add(
                InvoiceItemEntity(
                    invoiceId = invoiceId,
                    productId = line.productId,
                    itemName = line.itemName,
                    unit = line.unit,
                    quantityMilliUnits = line.quantityMilliUnits,
                    unitPricePaisa = line.unitPricePaisa,
                    costPricePaisa = line.unitPricePaisa,
                    lineTotalPaisa = lineTotal
                )
            )
        }

        val invoice = InvoiceEntity(
            id = invoiceId,
            businessId = businessId,
            invoiceNumber = purNo,
            invoiceType = "PURCHASE",
            partyId = supplier?.id,
            partyName = partyName,
            subtotalPaisa = totalPaisa,
            discountPaisa = 0L,
            taxRateBps = 0,
            taxPaisa = 0L,
            totalPaisa = totalPaisa,
            paidPaisa = cleanPaid,
            duePaisa = payableDelta,
            cogsPaisa = 0L,
            accountId = account.id,
            notes = notes.trim(),
            occurredAt = occurredAt,
            createdBy = createdBy
        )
        db.invoiceDao().insertInvoice(invoice)
        db.invoiceDao().insertItems(items)

        val newAccountBalance = account.currentBalancePaisa - cleanPaid
        if (cleanPaid > 0L) {
            db.accountDao().updateBalance(account.id, newAccountBalance)
        }

        if (supplier != null) {
            db.supplierDao().upsert(
                supplier.copy(
                    currentPayablePaisa = supplier.currentPayablePaisa + payableDelta,
                    totalPurchasesPaisa = supplier.totalPurchasesPaisa + totalPaisa,
                    totalPaymentsPaisa = supplier.totalPaymentsPaisa + cleanPaid,
                    updatedAt = occurredAt
                )
            )
        }

        db.transactionDao().insert(
            AccountingTransactionEntity(
                idempotencyKey = idempotencyKey,
                businessId = businessId,
                type = TxTypes.PURCHASE,
                supplierId = supplier?.id,
                partyName = partyName,
                accountId = account.id,
                accountName = account.name,
                referenceId = invoice.id,
                categoryName = purNo,
                subtotalPaisa = totalPaisa,
                totalAmountPaisa = totalPaisa,
                paidAmountPaisa = cleanPaid,
                dueDeltaPaisa = payableDelta,
                cashFlowDeltaPaisa = -cleanPaid,
                accountBalanceAfterPaisa = newAccountBalance,
                notes = notes.trim().ifBlank { "Purchase $purNo" },
                occurredAt = occurredAt,
                createdBy = createdBy
            )
        )
        invoice
    }

    suspend fun recordSupplierPayment(
        businessId: String,
        supplierId: String,
        amountPaisa: Long,
        accountId: String,
        notes: String,
        occurredAt: Long = System.currentTimeMillis(),
        createdBy: String = "Owner",
        idempotencyKey: String = UUID.randomUUID().toString()
    ) = db.withTransaction {
        if (db.transactionDao().getByIdempotencyKey(idempotencyKey) != null) return@withTransaction
        require(amountPaisa > 0L) { "Payment must be positive" }
        val supplier = db.supplierDao().getById(supplierId) ?: return@withTransaction
        val account = db.accountDao().getById(accountId) ?: return@withTransaction

        val newBalance = account.currentBalancePaisa - amountPaisa
        db.accountDao().updateBalance(account.id, newBalance)
        db.supplierDao().upsert(
            supplier.copy(
                currentPayablePaisa = supplier.currentPayablePaisa - amountPaisa,
                totalPaymentsPaisa = supplier.totalPaymentsPaisa + amountPaisa,
                updatedAt = occurredAt
            )
        )
        db.transactionDao().insert(
            AccountingTransactionEntity(
                idempotencyKey = idempotencyKey,
                businessId = businessId,
                type = TxTypes.SUPPLIER_PAYMENT,
                supplierId = supplier.id,
                partyName = supplier.name,
                accountId = account.id,
                accountName = account.name,
                totalAmountPaisa = amountPaisa,
                paidAmountPaisa = amountPaisa,
                dueDeltaPaisa = -amountPaisa,
                cashFlowDeltaPaisa = -amountPaisa,
                accountBalanceAfterPaisa = newBalance,
                notes = notes.trim().ifBlank { "Supplier payment" },
                occurredAt = occurredAt,
                createdBy = createdBy
            )
        )
    }

    suspend fun recordIncomeOrExpense(
        businessId: String,
        isExpense: Boolean,
        amountPaisa: Long,
        categoryId: String?,
        categoryName: String,
        accountId: String,
        notes: String,
        attachmentUri: String?,
        occurredAt: Long = System.currentTimeMillis(),
        createdBy: String = "Owner",
        idempotencyKey: String = UUID.randomUUID().toString()
    ) = db.withTransaction {
        if (db.transactionDao().getByIdempotencyKey(idempotencyKey) != null) return@withTransaction
        require(amountPaisa > 0L) { "Amount must be positive" }
        val account = db.accountDao().getById(accountId)
            ?: throw IllegalStateException("Account not found")
        val cashDelta = if (isExpense) -amountPaisa else amountPaisa
        val newBalance = account.currentBalancePaisa + cashDelta
        db.accountDao().updateBalance(account.id, newBalance)

        val tx = AccountingTransactionEntity(
            idempotencyKey = idempotencyKey,
            businessId = businessId,
            type = if (isExpense) TxTypes.EXPENSE else TxTypes.INCOME,
            accountId = account.id,
            accountName = account.name,
            categoryId = categoryId,
            categoryName = categoryName,
            totalAmountPaisa = amountPaisa,
            paidAmountPaisa = amountPaisa,
            cashFlowDeltaPaisa = cashDelta,
            accountBalanceAfterPaisa = newBalance,
            notes = notes.trim(),
            attachmentUri = attachmentUri,
            occurredAt = occurredAt,
            createdBy = createdBy
        )
        db.transactionDao().insert(tx)
        queueOutbox(businessId, "TRANSACTION", tx.id, 1L)
        logActivity(
            businessId, createdBy, "", tx.type, "TRANSACTION", tx.id,
            "$categoryName: ${MoneyUtils.formatTaka(amountPaisa)}"
        )
    }

    suspend fun createCustomCategory(businessId: String, name: String, type: String) {
        db.categoryDao().insert(
            CategoryEntity(
                businessId = businessId,
                name = name.trim(),
                nameBn = name.trim(),
                type = type,
                isSystem = false
            )
        )
    }

    /**
     * Transfers funds between Cash/Bank/bKash/Nagad/Rocket accounts.
     * Transfers NEVER count as Income, Sales, or Expenses.
     */
    suspend fun recordAccountTransfer(
        businessId: String,
        fromAccountId: String,
        toAccountId: String,
        amountPaisa: Long,
        notes: String,
        occurredAt: Long = System.currentTimeMillis(),
        createdBy: String = "Owner",
        idempotencyKey: String = UUID.randomUUID().toString()
    ) = db.withTransaction {
        if (db.transactionDao().getByIdempotencyKey(idempotencyKey) != null) return@withTransaction
        require(fromAccountId != toAccountId) { "Source and destination accounts must differ" }
        require(amountPaisa > 0L) { "Transfer amount must be positive" }
        val from = db.accountDao().getById(fromAccountId) ?: return@withTransaction
        val to = db.accountDao().getById(toAccountId) ?: return@withTransaction

        val newFromBal = from.currentBalancePaisa - amountPaisa
        val newToBal = to.currentBalancePaisa + amountPaisa
        db.accountDao().updateBalance(from.id, newFromBal)
        db.accountDao().updateBalance(to.id, newToBal)

        db.transactionDao().insert(
            AccountingTransactionEntity(
                idempotencyKey = idempotencyKey,
                businessId = businessId,
                type = TxTypes.ACCOUNT_TRANSFER,
                accountId = from.id,
                accountName = from.name,
                toAccountId = to.id,
                toAccountName = to.name,
                totalAmountPaisa = amountPaisa,
                paidAmountPaisa = amountPaisa,
                cashFlowDeltaPaisa = 0L,
                accountBalanceAfterPaisa = newFromBal,
                notes = notes.trim().ifBlank { "${from.name} -> ${to.name}" },
                occurredAt = occurredAt,
                createdBy = createdBy
            )
        )
    }

    /**
     * Traceable Sale Return or Purchase Return with stock & cash/due reconciliation.
     */
    suspend fun recordReturnOrCorrection(
        businessId: String,
        type: String, // SALE_RETURN, PURCHASE_RETURN, PAYMENT_CORRECTION
        customerId: String?,
        supplierId: String?,
        productId: String?,
        quantityMilliUnits: Long,
        amountPaisa: Long,
        refundCash: Boolean,
        accountId: String,
        notes: String,
        createdBy: String = "Owner"
    ) = db.withTransaction {
        require(amountPaisa > 0L) { "Amount must be positive" }
        val now = System.currentTimeMillis()
        val account = db.accountDao().getById(accountId) ?: return@withTransaction
        var cashDelta = 0L
        var dueDelta = 0L
        var cogsDelta = 0L
        var partyName = ""

        if (type == TxTypes.SALE_RETURN) {
            if (productId != null && quantityMilliUnits > 0L) {
                val product = db.productDao().getById(productId)
                if (product != null) {
                    val newStock = product.stockMilliUnits + quantityMilliUnits
                    db.productDao().updateStock(product.id, newStock, now)
                    db.stockMovementDao().insert(
                        StockMovementEntity(
                            businessId = businessId,
                            productId = product.id,
                            productName = product.name,
                            movementType = "SALE_RETURN",
                            deltaMilliUnits = quantityMilliUnits,
                            balanceAfterMilliUnits = newStock,
                            unitCostPaisa = product.purchasePricePaisa,
                            notes = notes.ifBlank { "Sales return" },
                            occurredAt = now,
                            createdBy = createdBy
                        )
                    )
                    cogsDelta = -MoneyUtils.calculateLineTotalPaisa(quantityMilliUnits, product.purchasePricePaisa)
                }
            }
            if (refundCash) {
                cashDelta = -amountPaisa
            } else if (customerId != null) {
                dueDelta = -amountPaisa
            }
            customerId?.let { cid ->
                db.customerDao().getById(cid)?.let { c ->
                    partyName = c.name
                    db.customerDao().upsert(
                        c.copy(
                            currentDuePaisa = c.currentDuePaisa + dueDelta,
                            updatedAt = now
                        )
                    )
                }
            }
        } else if (type == TxTypes.PURCHASE_RETURN) {
            if (productId != null && quantityMilliUnits > 0L) {
                val product = db.productDao().getById(productId)
                if (product != null) {
                    val newStock = (product.stockMilliUnits - quantityMilliUnits).coerceAtLeast(0L)
                    db.productDao().updateStock(product.id, newStock, now)
                    db.stockMovementDao().insert(
                        StockMovementEntity(
                            businessId = businessId,
                            productId = product.id,
                            productName = product.name,
                            movementType = "PURCHASE_RETURN",
                            deltaMilliUnits = -quantityMilliUnits,
                            balanceAfterMilliUnits = newStock,
                            unitCostPaisa = product.purchasePricePaisa,
                            notes = notes.ifBlank { "Purchase return" },
                            occurredAt = now,
                            createdBy = createdBy
                        )
                    )
                }
            }
            if (refundCash) {
                cashDelta = amountPaisa
            } else if (supplierId != null) {
                dueDelta = -amountPaisa
            }
            supplierId?.let { sid ->
                db.supplierDao().getById(sid)?.let { s ->
                    partyName = s.name
                    db.supplierDao().upsert(
                        s.copy(
                            currentPayablePaisa = s.currentPayablePaisa + dueDelta,
                            updatedAt = now
                        )
                    )
                }
            }
        } else {
            // PAYMENT_CORRECTION
            cashDelta = if (refundCash) -amountPaisa else amountPaisa
        }

        val newAccBalance = account.currentBalancePaisa + cashDelta
        if (cashDelta != 0L) {
            db.accountDao().updateBalance(account.id, newAccBalance)
        }

        db.transactionDao().insert(
            AccountingTransactionEntity(
                businessId = businessId,
                type = type,
                customerId = customerId,
                supplierId = supplierId,
                partyName = partyName.ifBlank { "Adjustment" },
                accountId = account.id,
                accountName = account.name,
                totalAmountPaisa = amountPaisa,
                paidAmountPaisa = if (refundCash) amountPaisa else 0L,
                dueDeltaPaisa = dueDelta,
                cogsPaisa = cogsDelta,
                cashFlowDeltaPaisa = cashDelta,
                accountBalanceAfterPaisa = newAccBalance,
                notes = notes.trim(),
                occurredAt = now,
                createdBy = createdBy
            )
        )
    }

    /**
     * Never silently deletes or overwrites financial history.
     * Marks original entry as reversed and appends a compensating REVERSAL audit entry.
     */
    suspend fun reverseTransaction(
        txId: String,
        reason: String,
        createdBy: String = "Owner"
    ) = db.withTransaction {
        val orig = db.transactionDao().getById(txId) ?: return@withTransaction
        if (orig.isReversed || orig.type == TxTypes.REVERSAL) return@withTransaction
        val now = System.currentTimeMillis()
        db.transactionDao().markReversed(orig.id)

        var newBalance = orig.accountBalanceAfterPaisa
        if (orig.type == TxTypes.ACCOUNT_TRANSFER) {
            orig.accountId?.let { fromId ->
                db.accountDao().getById(fromId)?.let { acc ->
                    newBalance = acc.currentBalancePaisa + orig.totalAmountPaisa
                    db.accountDao().updateBalance(fromId, newBalance)
                }
            }
            orig.toAccountId?.let { toId ->
                db.accountDao().getById(toId)?.let { acc ->
                    db.accountDao().updateBalance(toId, acc.currentBalancePaisa - orig.totalAmountPaisa)
                }
            }
        } else {
            if (orig.cashFlowDeltaPaisa != 0L && orig.accountId != null) {
                db.accountDao().getById(orig.accountId)?.let { acc ->
                    newBalance = acc.currentBalancePaisa - orig.cashFlowDeltaPaisa
                    db.accountDao().updateBalance(acc.id, newBalance)
                }
            }
            if (orig.dueDeltaPaisa != 0L && orig.customerId != null) {
                db.customerDao().getById(orig.customerId)?.let { cust ->
                    db.customerDao().upsert(
                        cust.copy(
                            currentDuePaisa = cust.currentDuePaisa - orig.dueDeltaPaisa,
                            updatedAt = now
                        )
                    )
                }
            }
            if (orig.dueDeltaPaisa != 0L && orig.supplierId != null) {
                db.supplierDao().getById(orig.supplierId)?.let { sup ->
                    db.supplierDao().upsert(
                        sup.copy(
                            currentPayablePaisa = sup.currentPayablePaisa - orig.dueDeltaPaisa,
                            updatedAt = now
                        )
                    )
                }
            }
        }

        val reversalTx = AccountingTransactionEntity(
            businessId = orig.businessId,
            type = TxTypes.REVERSAL,
            customerId = orig.customerId,
            supplierId = orig.supplierId,
            partyName = orig.partyName,
            accountId = orig.accountId,
            accountName = orig.accountName,
            toAccountId = orig.toAccountId,
            toAccountName = orig.toAccountName,
            referenceId = orig.referenceId,
            categoryName = orig.type,
            totalAmountPaisa = orig.totalAmountPaisa,
            paidAmountPaisa = orig.paidAmountPaisa,
            dueDeltaPaisa = -orig.dueDeltaPaisa,
            cogsPaisa = -orig.cogsPaisa,
            cashFlowDeltaPaisa = -orig.cashFlowDeltaPaisa,
            accountBalanceAfterPaisa = newBalance,
            reversedTransactionId = orig.id,
            notes = "Reversal (${orig.type}): ${reason.trim().ifBlank { "Audit correction" }}",
            occurredAt = now,
            createdBy = createdBy
        )
        db.transactionDao().insert(reversalTx)
        queueOutbox(orig.businessId, "TRANSACTION", orig.id, orig.syncVersion + 1)
        queueOutbox(orig.businessId, "TRANSACTION", reversalTx.id, 1L)
        logActivity(
            businessId = orig.businessId,
            actorName = createdBy,
            actorRole = EmployeeRoles.OWNER,
            actionType = "REVERSE_TX",
            entityType = "TRANSACTION",
            entityId = orig.id,
            summary = "Reversed ${orig.type} (${MoneyUtils.formatTaka(orig.totalAmountPaisa)})"
        )
    }

    suspend fun saveEmployee(
        businessId: String,
        name: String,
        phone: String,
        role: String,
        email: String = "",
        salaryPaisa: Long = 0L,
        existingId: String? = null
    ) {
        val rolePerm = db.rolePermissionDao().getForRole(businessId, role)
        val permList = if (rolePerm != null) {
            listOf(
                rolePerm.canViewReports, rolePerm.canDeleteOrReverse,
                rolePerm.canManageEmployees, rolePerm.canManageSettings,
                rolePerm.canRecordSales, rolePerm.canEditCustomers, rolePerm.canManageInventory
            )
        } else {
            when (role) {
                EmployeeRoles.OWNER -> listOf(true, true, true, true, true, true, true)
                EmployeeRoles.ADMINISTRATOR -> listOf(true, true, true, false, true, true, true)
                EmployeeRoles.MANAGER -> listOf(true, true, false, false, true, true, true)
                EmployeeRoles.ACCOUNTANT -> listOf(true, false, false, false, true, true, false)
                else -> listOf(false, false, false, false, true, true, false) // CASHIER
            }
        }
        val existing = existingId?.let { db.employeeDao().getById(it) }
        val emp = EmployeeEntity(
            id = existing?.id ?: UUID.randomUUID().toString(),
            businessId = businessId,
            name = name.trim(),
            phone = phone.trim(),
            email = email.trim(),
            role = role,
            salaryPaisa = salaryPaisa.coerceAtLeast(0L),
            canViewReports = permList[0],
            canDeleteOrReverse = permList[1],
            canManageEmployees = permList[2],
            canManageSettings = permList[3],
            canRecordSales = permList[4],
            canEditCustomers = permList[5],
            canManageInventory = permList[6],
            isActive = existing?.isActive ?: true,
            createdAt = existing?.createdAt ?: System.currentTimeMillis()
        )
        db.employeeDao().upsert(emp)
        queueOutbox(businessId, "EMPLOYEE", emp.id, 1L)
        logActivity(businessId, "Owner", EmployeeRoles.OWNER, "SAVE_EMPLOYEE", "EMPLOYEE", emp.id, "${emp.name} ($role)")
    }

    suspend fun updateRolePermission(permission: RolePermissionEntity) = db.withTransaction {
        val updated = permission.copy(updatedAt = System.currentTimeMillis())
        db.rolePermissionDao().upsert(updated)
        // Propagate updated role permissions to matching employees in this business
        val employees = db.employeeDao().getEmployeesSync(permission.businessId)
        employees.filter { it.role == permission.roleName }.forEach { emp ->
            db.employeeDao().upsert(
                emp.copy(
                    canViewReports = updated.canViewReports,
                    canDeleteOrReverse = updated.canDeleteOrReverse,
                    canManageEmployees = updated.canManageEmployees,
                    canManageSettings = updated.canManageSettings,
                    canRecordSales = updated.canRecordSales,
                    canEditCustomers = updated.canEditCustomers,
                    canManageInventory = updated.canManageInventory
                )
            )
        }
        queueOutbox(permission.businessId, "ROLE_PERMISSION", updated.id, 1L)
        logActivity(
            permission.businessId,
            "Owner",
            EmployeeRoles.OWNER,
            "UPDATE_RBAC",
            "ROLE_PERMISSION",
            updated.roleName,
            "Updated permissions for ${updated.roleName}"
        )
    }

    suspend fun removeEmployee(id: String) {
        val emp = db.employeeDao().getById(id)
        db.employeeDao().deleteById(id)
        if (emp != null) {
            logActivity(emp.businessId, "Owner", EmployeeRoles.OWNER, "REMOVE_EMPLOYEE", "EMPLOYEE", id, "Removed ${emp.name}")
        }
    }

    suspend fun recordAttendance(
        businessId: String,
        employeeId: String,
        dateKey: String,
        status: String,
        notes: String = "",
        recordedBy: String = "Owner"
    ) = db.withTransaction {
        val emp = db.employeeDao().getById(employeeId) ?: return@withTransaction
        val existing = db.attendanceDao().getForEmployeeDate(businessId, employeeId, dateKey)
        val now = System.currentTimeMillis()
        val record = AttendanceEntity(
            id = existing?.id ?: UUID.randomUUID().toString(),
            businessId = businessId,
            employeeId = emp.id,
            employeeName = emp.name,
            dateKey = dateKey,
            status = status,
            checkInMillis = existing?.checkInMillis ?: if (status == AttendanceStatuses.PRESENT || status == AttendanceStatuses.LATE) now else null,
            checkOutMillis = if (existing?.checkInMillis != null && existing.checkOutMillis == null) now else existing?.checkOutMillis,
            notes = notes.trim(),
            createdAt = existing?.createdAt ?: now
        )
        db.attendanceDao().upsert(record)
        queueOutbox(businessId, "ATTENDANCE", record.id, 1L)
        logActivity(businessId, recordedBy, EmployeeRoles.OWNER, "ATTENDANCE", "ATTENDANCE", record.id, "${emp.name}: $status ($dateKey)")
    }

    suspend fun submitLeaveRequest(
        businessId: String,
        employeeId: String,
        startDateKey: String,
        endDateKey: String,
        leaveType: String,
        reason: String
    ) = db.withTransaction {
        val emp = db.employeeDao().getById(employeeId) ?: return@withTransaction
        val req = LeaveRequestEntity(
            businessId = businessId,
            employeeId = emp.id,
            employeeName = emp.name,
            startDateKey = startDateKey,
            endDateKey = endDateKey,
            leaveType = leaveType,
            reason = reason.trim(),
            status = LeaveStatuses.PENDING
        )
        db.leaveRequestDao().upsert(req)
        queueOutbox(businessId, "LEAVE", req.id, 1L)
        logActivity(businessId, emp.name, emp.role, "LEAVE_REQUEST", "LEAVE", req.id, "${emp.name} requested $leaveType leave ($startDateKey)")
    }

    suspend fun decideLeaveRequest(
        requestId: String,
        approved: Boolean,
        decidedBy: String = "Owner"
    ) = db.withTransaction {
        val req = db.leaveRequestDao().getById(requestId) ?: return@withTransaction
        val newStatus = if (approved) LeaveStatuses.APPROVED else LeaveStatuses.REJECTED
        val updated = req.copy(status = newStatus, approvedBy = decidedBy)
        db.leaveRequestDao().upsert(updated)
        queueOutbox(req.businessId, "LEAVE", updated.id, 2L)
        logActivity(req.businessId, decidedBy, EmployeeRoles.OWNER, "LEAVE_$newStatus", "LEAVE", updated.id, "${req.employeeName} leave $newStatus")
    }

    suspend fun recordSalaryPayment(
        businessId: String,
        employeeId: String,
        monthKey: String,
        paymentType: String,
        amountPaisa: Long,
        accountId: String,
        notes: String,
        createdBy: String = "Owner"
    ) = db.withTransaction {
        require(amountPaisa > 0L) { "Salary amount must be positive" }
        val emp = db.employeeDao().getById(employeeId)
            ?: throw IllegalStateException("Employee not found")
        val account = db.accountDao().getById(accountId)
            ?: throw IllegalStateException("Payment account not found")
        val now = System.currentTimeMillis()
        val newBalance = account.currentBalancePaisa - amountPaisa
        db.accountDao().updateBalance(account.id, newBalance)

        val payment = SalaryPaymentEntity(
            businessId = businessId,
            employeeId = emp.id,
            employeeName = emp.name,
            monthKey = monthKey,
            paymentType = paymentType,
            amountPaisa = amountPaisa,
            accountId = account.id,
            notes = notes.trim(),
            occurredAt = now,
            createdBy = createdBy
        )
        db.salaryPaymentDao().insert(payment)

        val tx = AccountingTransactionEntity(
            businessId = businessId,
            type = TxTypes.EXPENSE,
            partyName = emp.name,
            accountId = account.id,
            accountName = account.name,
            referenceId = payment.id,
            categoryName = "Employee Salary",
            totalAmountPaisa = amountPaisa,
            paidAmountPaisa = amountPaisa,
            cashFlowDeltaPaisa = -amountPaisa,
            accountBalanceAfterPaisa = newBalance,
            notes = "$paymentType ($monthKey) - ${emp.name}: ${notes.trim()}".trimEnd(':', ' '),
            occurredAt = now,
            createdBy = createdBy
        )
        db.transactionDao().insert(tx)
        queueOutbox(businessId, "SALARY", payment.id, 1L)
        queueOutbox(businessId, "TRANSACTION", tx.id, 1L)
        logActivity(
            businessId, createdBy, EmployeeRoles.OWNER, "SALARY_PAYOUT", "SALARY", payment.id,
            "Paid $paymentType ${MoneyUtils.formatTaka(amountPaisa)} to ${emp.name}"
        )
    }

    suspend fun resolveSyncConflict(outboxId: String, keepLocal: Boolean) = db.withTransaction {
        if (keepLocal) {
            db.syncOutboxDao().getByStatusSync("CONFLICT").firstOrNull { it.id == outboxId }?.let { item ->
                db.syncOutboxDao().upsert(item.copy(status = "PENDING", conflictDetail = "", updatedAtMillis = System.currentTimeMillis()))
            }
        } else {
            db.syncOutboxDao().deleteById(outboxId)
        }
    }

    suspend fun registerOrUpdateLocalDevice(
        userId: String,
        deviceId: String,
        deviceName: String,
        appVersion: String
    ) {
        val now = System.currentTimeMillis()
        db.authorizedDeviceDao().upsert(
            AuthorizedDeviceEntity(
                id = deviceId,
                userId = userId,
                deviceName = deviceName,
                platform = "Android",
                appVersion = appVersion,
                lastSyncAtMillis = now,
                revoked = false,
                isCurrentDevice = true,
                createdAt = now
            )
        )
    }

    suspend fun setDeviceRevoked(deviceId: String, revoked: Boolean) {
        db.authorizedDeviceDao().setRevoked(deviceId, revoked)
    }

    suspend fun exportEncryptedBackup(passphrase: String): String {
        val plain = exportLocalBackupJson()
        return SecurityUtils.encryptBackup(plain, passphrase)
    }

    suspend fun restoreEncryptedOrPlainBackup(payload: String, passphrase: String? = null): Int {
        val plainJson = if (SecurityUtils.isEncryptedBackup(payload)) {
            require(!passphrase.isNullOrBlank()) { "Passphrase required for encrypted backup" }
            SecurityUtils.decryptBackup(payload, passphrase)
        } else {
            payload
        }
        return restoreLocalBackupJson(plainJson)
    }

    /**
     * Resets all accounting ledgers, invoices, stock movements, salary payouts, attendance,
     * leaves, outbox items, and account balances for the active business only.
     * When [clearMasterEntities] is false, customer/supplier directories (zeroed balances) and
     * products remain intact; when true, customers, suppliers, and products are also wiped.
     */
    suspend fun resetBusinessAccounting(
        businessId: String,
        clearMasterEntities: Boolean,
        operatorName: String = "Owner"
    ) = db.withTransaction {
        val now = System.currentTimeMillis()
        db.invoiceDao().deleteAllItemsForBusiness(businessId)
        db.invoiceDao().deleteAllForBusiness(businessId)
        db.transactionDao().deleteAllForBusiness(businessId)
        db.stockMovementDao().deleteAllForBusiness(businessId)
        db.salaryPaymentDao().deleteAllForBusiness(businessId)
        db.attendanceDao().deleteAllForBusiness(businessId)
        db.leaveRequestDao().deleteAllForBusiness(businessId)
        db.notificationDao().deleteAllForBusiness(businessId)
        db.syncOutboxDao().deleteAllForBusiness(businessId)
        db.bakiKhataDao().deleteAllForBusiness(businessId)

        db.accountDao().resetBalancesForBusiness(businessId)
        if (clearMasterEntities) {
            db.customerDao().deleteAllForBusiness(businessId)
            db.supplierDao().deleteAllForBusiness(businessId)
            db.productDao().deleteAllForBusiness(businessId)
        } else {
            db.customerDao().resetBalancesForBusiness(businessId, now)
            db.supplierDao().resetBalancesForBusiness(businessId, now)
        }

        logActivity(
            businessId = businessId,
            actorName = operatorName,
            actorRole = EmployeeRoles.OWNER,
            actionType = "RESET_HISAB",
            entityType = "BUSINESS",
            entityId = businessId,
            summary = if (clearMasterEntities) "Full business data reset" else "Ledgers & balances reset (lists kept)"
        )
    }

    suspend fun exportLocalBackupJson(): String {
        val root = JSONObject()
        root.put("version", 2)
        root.put("exportedAt", System.currentTimeMillis())

        val businesses = db.businessDao().getAllBusinessesSync()
        val bizArr = JSONArray()
        val accArr = JSONArray()
        val custArr = JSONArray()
        val supArr = JSONArray()
        val prodArr = JSONArray()
        val txArr = JSONArray()
        val empArr = JSONArray()
        val invArr = JSONArray()
        val invItemArr = JSONArray()
        val attArr = JSONArray()
        val leaveArr = JSONArray()
        val salArr = JSONArray()
        val roleArr = JSONArray()
        val bakiArr = JSONArray()

        for (b in businesses) {
            bizArr.put(JSONObject().apply {
                put("id", b.id); put("name", b.name); put("category", b.category)
                put("phone", b.phone); put("address", b.address); put("languageCode", b.languageCode)
                put("openingCashPaisa", b.openingCashPaisa); put("inventoryEnabled", b.inventoryEnabled)
                put("taxEnabled", b.taxEnabled); put("defaultTaxRateBps", b.defaultTaxRateBps)
                put("createdAt", b.createdAt); put("syncVersion", b.syncVersion)
            })
            db.accountDao().getAccountsSync(b.id).forEach { a ->
                accArr.put(JSONObject().apply {
                    put("id", a.id); put("businessId", a.businessId); put("name", a.name)
                    put("type", a.type); put("accountNumber", a.accountNumber)
                    put("openingBalancePaisa", a.openingBalancePaisa)
                    put("currentBalancePaisa", a.currentBalancePaisa); put("isDefault", a.isDefault)
                })
            }
            db.customerDao().getCustomersSync(b.id).forEach { c ->
                custArr.put(JSONObject().apply {
                    put("id", c.id); put("businessId", c.businessId); put("customerCode", c.customerCode)
                    put("name", c.name); put("phone", c.phone); put("address", c.address)
                    put("category", c.category); put("openingDuePaisa", c.openingDuePaisa)
                    put("currentDuePaisa", c.currentDuePaisa)
                    put("totalPurchasesPaisa", c.totalPurchasesPaisa)
                    put("totalPaymentsPaisa", c.totalPaymentsPaisa); put("archived", c.archived)
                })
            }
            db.supplierDao().getSuppliersSync(b.id).forEach { s ->
                supArr.put(JSONObject().apply {
                    put("id", s.id); put("businessId", s.businessId); put("supplierCode", s.supplierCode)
                    put("name", s.name); put("phone", s.phone); put("address", s.address)
                    put("openingPayablePaisa", s.openingPayablePaisa)
                    put("currentPayablePaisa", s.currentPayablePaisa)
                    put("totalPurchasesPaisa", s.totalPurchasesPaisa)
                    put("totalPaymentsPaisa", s.totalPaymentsPaisa); put("archived", s.archived)
                })
            }
            db.productDao().getProductsSync(b.id).forEach { p ->
                prodArr.put(JSONObject().apply {
                    put("id", p.id); put("businessId", p.businessId); put("name", p.name)
                    put("sku", p.sku); put("barcode", p.barcode); put("category", p.category)
                    put("purchasePricePaisa", p.purchasePricePaisa); put("sellingPricePaisa", p.sellingPricePaisa)
                    put("stockMilliUnits", p.stockMilliUnits); put("unit", p.unit)
                    put("lowStockThresholdMilliUnits", p.lowStockThresholdMilliUnits)
                })
            }
            db.transactionDao().getTransactionsSync(b.id).forEach { t ->
                txArr.put(JSONObject().apply {
                    put("id", t.id); put("idempotencyKey", t.idempotencyKey)
                    put("businessId", t.businessId); put("type", t.type)
                    put("customerId", t.customerId); put("supplierId", t.supplierId)
                    put("partyName", t.partyName); put("accountId", t.accountId)
                    put("accountName", t.accountName); put("toAccountId", t.toAccountId)
                    put("toAccountName", t.toAccountName); put("categoryName", t.categoryName)
                    put("referenceId", t.referenceId)
                    put("subtotalPaisa", t.subtotalPaisa); put("discountPaisa", t.discountPaisa)
                    put("taxPaisa", t.taxPaisa); put("totalAmountPaisa", t.totalAmountPaisa)
                    put("paidAmountPaisa", t.paidAmountPaisa); put("dueDeltaPaisa", t.dueDeltaPaisa)
                    put("cogsPaisa", t.cogsPaisa); put("hasEstimatedCost", t.hasEstimatedCost)
                    put("cashFlowDeltaPaisa", t.cashFlowDeltaPaisa)
                    put("accountBalanceAfterPaisa", t.accountBalanceAfterPaisa)
                    put("isReversed", t.isReversed); put("notes", t.notes); put("occurredAt", t.occurredAt)
                    put("createdBy", t.createdBy)
                })
            }
            db.invoiceDao().getInvoicesSync(b.id).forEach { inv ->
                invArr.put(JSONObject().apply {
                    put("id", inv.id); put("businessId", inv.businessId)
                    put("invoiceNumber", inv.invoiceNumber); put("invoiceType", inv.invoiceType)
                    put("partyId", inv.partyId); put("partyName", inv.partyName)
                    put("subtotalPaisa", inv.subtotalPaisa); put("discountPaisa", inv.discountPaisa)
                    put("taxRateBps", inv.taxRateBps); put("taxPaisa", inv.taxPaisa)
                    put("totalPaisa", inv.totalPaisa); put("paidPaisa", inv.paidPaisa)
                    put("duePaisa", inv.duePaisa); put("cogsPaisa", inv.cogsPaisa)
                    put("accountId", inv.accountId); put("notes", inv.notes)
                    put("occurredAt", inv.occurredAt); put("createdBy", inv.createdBy)
                })
            }
            db.invoiceDao().getAllInvoiceItemsSync(b.id).forEach { ii ->
                invItemArr.put(JSONObject().apply {
                    put("id", ii.id); put("invoiceId", ii.invoiceId); put("productId", ii.productId)
                    put("itemName", ii.itemName); put("unit", ii.unit)
                    put("quantityMilliUnits", ii.quantityMilliUnits); put("unitPricePaisa", ii.unitPricePaisa)
                    put("costPricePaisa", ii.costPricePaisa); put("lineTotalPaisa", ii.lineTotalPaisa)
                    put("returnedMilliUnits", ii.returnedMilliUnits)
                })
            }
            db.employeeDao().getEmployeesSync(b.id).forEach { e ->
                empArr.put(JSONObject().apply {
                    put("id", e.id); put("businessId", e.businessId); put("name", e.name)
                    put("phone", e.phone); put("email", e.email); put("role", e.role)
                    put("salaryPaisa", e.salaryPaisa)
                    put("canViewReports", e.canViewReports); put("canDeleteOrReverse", e.canDeleteOrReverse)
                    put("canManageEmployees", e.canManageEmployees); put("canManageSettings", e.canManageSettings)
                    put("canRecordSales", e.canRecordSales); put("canEditCustomers", e.canEditCustomers)
                    put("canManageInventory", e.canManageInventory)
                })
            }
            db.salaryPaymentDao().getSalaryPaymentsSync(b.id).forEach { sp ->
                salArr.put(JSONObject().apply {
                    put("id", sp.id); put("businessId", sp.businessId); put("employeeId", sp.employeeId)
                    put("employeeName", sp.employeeName); put("monthKey", sp.monthKey)
                    put("paymentType", sp.paymentType); put("amountPaisa", sp.amountPaisa)
                    put("accountId", sp.accountId); put("notes", sp.notes)
                    put("occurredAt", sp.occurredAt); put("createdBy", sp.createdBy)
                })
            }
            db.rolePermissionDao().getRolePermissionsSync(b.id).forEach { rp ->
                roleArr.put(JSONObject().apply {
                    put("id", rp.id); put("businessId", rp.businessId); put("roleName", rp.roleName)
                    put("canViewDashboard", rp.canViewDashboard); put("canViewReports", rp.canViewReports)
                    put("canRecordSales", rp.canRecordSales); put("canEditCustomers", rp.canEditCustomers)
                    put("canManageInventory", rp.canManageInventory); put("canDeleteOrReverse", rp.canDeleteOrReverse)
                    put("canManageEmployees", rp.canManageEmployees); put("canManageSettings", rp.canManageSettings)
                })
            }
            db.bakiKhataDao().getEntriesForBusinessSync(b.id).forEach { bk ->
                bakiArr.put(JSONObject().apply {
                    put("id", bk.id); put("businessId", bk.businessId)
                    put("customerId", bk.customerId); put("customerName", bk.customerName)
                    put("entryType", bk.entryType); put("amountPaisa", bk.amountPaisa)
                    put("remainingBalanceAfterPaisa", bk.remainingBalanceAfterPaisa)
                    put("entryDateMillis", bk.entryDateMillis)
                    if (bk.promisedRepaymentDateMillis != null) put("promisedRepaymentDateMillis", bk.promisedRepaymentDateMillis)
                    if (bk.actualRepaymentDateMillis != null) put("actualRepaymentDateMillis", bk.actualRepaymentDateMillis)
                    put("isSettled", bk.isSettled); put("notes", bk.notes)
                    put("transactionId", bk.transactionId); put("createdAt", bk.createdAt)
                    put("syncVersion", bk.syncVersion)
                })
            }
        }

        root.put("businesses", bizArr)
        root.put("accounts", accArr)
        root.put("customers", custArr)
        root.put("suppliers", supArr)
        root.put("products", prodArr)
        root.put("transactions", txArr)
        root.put("invoices", invArr)
        root.put("invoiceItems", invItemArr)
        root.put("employees", empArr)
        root.put("attendance", attArr)
        root.put("leaves", leaveArr)
        root.put("salaryPayments", salArr)
        root.put("rolePermissions", roleArr)
        root.put("bakiKhataEntries", bakiArr)
        return root.toString()
    }

    suspend fun restoreLocalBackupJson(jsonString: String): Int = db.withTransaction {
        val root = JSONObject(jsonString)
        val bizArr = root.optJSONArray("businesses") ?: return@withTransaction 0
        for (i in 0 until bizArr.length()) {
            val o = bizArr.getJSONObject(i)
            val bizId = o.getString("id")
            db.businessDao().upsert(
                BusinessEntity(
                    id = bizId,
                    name = o.getString("name"),
                    category = o.optString("category", "Retail Store"),
                    phone = o.optString("phone", ""),
                    address = o.optString("address", ""),
                    languageCode = o.optString("languageCode", "en"),
                    openingCashPaisa = o.optLong("openingCashPaisa", 0L),
                    inventoryEnabled = o.optBoolean("inventoryEnabled", true),
                    taxEnabled = o.optBoolean("taxEnabled", false),
                    defaultTaxRateBps = o.optInt("defaultTaxRateBps", 0),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    syncVersion = o.optLong("syncVersion", 1L)
                )
            )
            if (db.categoryDao().getCategoriesSync(bizId).isEmpty()) {
                db.categoryDao().insertAll(
                    listOf(
                        CategoryEntity(businessId = bizId, name = "Rent", nameBn = "দোকান ভাড়া", type = "EXPENSE", isSystem = true),
                        CategoryEntity(businessId = bizId, name = "Electricity", nameBn = "বিদ্যুৎ বিল", type = "EXPENSE", isSystem = true),
                        CategoryEntity(businessId = bizId, name = "Employee Salary", nameBn = "কর্মচারী বেতন", type = "EXPENSE", isSystem = true),
                        CategoryEntity(businessId = bizId, name = "Other Expenses", nameBn = "অন্যান্য খরচ", type = "EXPENSE", isSystem = true),
                        CategoryEntity(businessId = bizId, name = "Service Income", nameBn = "সেবা আয়", type = "INCOME", isSystem = true),
                        CategoryEntity(businessId = bizId, name = "Other Income", nameBn = "অন্যান্য আয়", type = "INCOME", isSystem = true)
                    )
                )
            }
            seedDefaultRolePermissionsInternal(bizId)
        }
        val accArr = root.optJSONArray("accounts")
        if (accArr != null) {
            val list = (0 until accArr.length()).map { i ->
                val o = accArr.getJSONObject(i)
                AccountEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    name = o.getString("name"),
                    type = o.getString("type"),
                    accountNumber = o.optString("accountNumber", ""),
                    openingBalancePaisa = o.optLong("openingBalancePaisa", 0L),
                    currentBalancePaisa = o.optLong("currentBalancePaisa", 0L),
                    isDefault = o.optBoolean("isDefault", false)
                )
            }
            db.accountDao().upsertAll(list)
        }
        val custArr = root.optJSONArray("customers")
        if (custArr != null) {
            val list = (0 until custArr.length()).map { i ->
                val o = custArr.getJSONObject(i)
                CustomerEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    customerCode = o.optString("customerCode", "CUST-0001"),
                    name = o.getString("name"),
                    phone = o.optString("phone", ""),
                    address = o.optString("address", ""),
                    category = o.optString("category", "Regular"),
                    openingDuePaisa = o.optLong("openingDuePaisa", 0L),
                    currentDuePaisa = o.optLong("currentDuePaisa", 0L),
                    totalPurchasesPaisa = o.optLong("totalPurchasesPaisa", 0L),
                    totalPaymentsPaisa = o.optLong("totalPaymentsPaisa", 0L),
                    archived = o.optBoolean("archived", false)
                )
            }
            db.customerDao().upsertAll(list)
        }
        val supArr = root.optJSONArray("suppliers")
        if (supArr != null) {
            val list = (0 until supArr.length()).map { i ->
                val o = supArr.getJSONObject(i)
                SupplierEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    supplierCode = o.optString("supplierCode", "SUP-0001"),
                    name = o.getString("name"),
                    phone = o.optString("phone", ""),
                    address = o.optString("address", ""),
                    openingPayablePaisa = o.optLong("openingPayablePaisa", 0L),
                    currentPayablePaisa = o.optLong("currentPayablePaisa", 0L),
                    totalPurchasesPaisa = o.optLong("totalPurchasesPaisa", 0L),
                    totalPaymentsPaisa = o.optLong("totalPaymentsPaisa", 0L),
                    archived = o.optBoolean("archived", false)
                )
            }
            db.supplierDao().upsertAll(list)
        }
        val prodArr = root.optJSONArray("products")
        if (prodArr != null) {
            val list = (0 until prodArr.length()).map { i ->
                val o = prodArr.getJSONObject(i)
                ProductEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    name = o.getString("name"),
                    sku = o.optString("sku", ""),
                    barcode = o.optString("barcode", ""),
                    category = o.optString("category", "General"),
                    purchasePricePaisa = o.optLong("purchasePricePaisa", 0L),
                    sellingPricePaisa = o.optLong("sellingPricePaisa", 0L),
                    stockMilliUnits = o.optLong("stockMilliUnits", 0L),
                    unit = o.optString("unit", "Piece"),
                    lowStockThresholdMilliUnits = o.optLong("lowStockThresholdMilliUnits", 5000L)
                )
            }
            db.productDao().upsertAll(list)
        }
        val txArr = root.optJSONArray("transactions")
        if (txArr != null) {
            val list = (0 until txArr.length()).map { i ->
                val o = txArr.getJSONObject(i)
                AccountingTransactionEntity(
                    id = o.getString("id"),
                    idempotencyKey = o.optString("idempotencyKey", o.getString("id")),
                    businessId = o.getString("businessId"),
                    type = o.getString("type"),
                    customerId = o.optString("customerId").ifBlank { null },
                    supplierId = o.optString("supplierId").ifBlank { null },
                    partyName = o.optString("partyName", ""),
                    accountId = o.optString("accountId").ifBlank { null },
                    accountName = o.optString("accountName", ""),
                    toAccountId = o.optString("toAccountId").ifBlank { null },
                    toAccountName = o.optString("toAccountName", ""),
                    referenceId = o.optString("referenceId").ifBlank { null },
                    categoryName = o.optString("categoryName", ""),
                    subtotalPaisa = o.optLong("subtotalPaisa", 0L),
                    discountPaisa = o.optLong("discountPaisa", 0L),
                    taxPaisa = o.optLong("taxPaisa", 0L),
                    totalAmountPaisa = o.optLong("totalAmountPaisa", 0L),
                    paidAmountPaisa = o.optLong("paidAmountPaisa", 0L),
                    dueDeltaPaisa = o.optLong("dueDeltaPaisa", 0L),
                    cogsPaisa = o.optLong("cogsPaisa", 0L),
                    hasEstimatedCost = o.optBoolean("hasEstimatedCost", false),
                    cashFlowDeltaPaisa = o.optLong("cashFlowDeltaPaisa", 0L),
                    accountBalanceAfterPaisa = o.optLong("accountBalanceAfterPaisa", 0L),
                    isReversed = o.optBoolean("isReversed", false),
                    notes = o.optString("notes", ""),
                    occurredAt = o.optLong("occurredAt", System.currentTimeMillis()),
                    createdBy = o.optString("createdBy", "Owner")
                )
            }
            db.transactionDao().upsertAll(list)
        }
        val invArr = root.optJSONArray("invoices")
        if (invArr != null) {
            val list = (0 until invArr.length()).map { i ->
                val o = invArr.getJSONObject(i)
                InvoiceEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    invoiceNumber = o.getString("invoiceNumber"),
                    invoiceType = o.getString("invoiceType"),
                    partyId = o.optString("partyId").ifBlank { null },
                    partyName = o.optString("partyName", ""),
                    subtotalPaisa = o.optLong("subtotalPaisa", 0L),
                    discountPaisa = o.optLong("discountPaisa", 0L),
                    taxRateBps = o.optInt("taxRateBps", 0),
                    taxPaisa = o.optLong("taxPaisa", 0L),
                    totalPaisa = o.optLong("totalPaisa", 0L),
                    paidPaisa = o.optLong("paidPaisa", 0L),
                    duePaisa = o.optLong("duePaisa", 0L),
                    cogsPaisa = o.optLong("cogsPaisa", 0L),
                    accountId = o.optString("accountId").ifBlank { null },
                    notes = o.optString("notes", ""),
                    occurredAt = o.optLong("occurredAt", System.currentTimeMillis()),
                    createdBy = o.optString("createdBy", "Owner")
                )
            }
            db.invoiceDao().insertInvoices(list)
        }
        val invItemArr = root.optJSONArray("invoiceItems")
        if (invItemArr != null) {
            val list = (0 until invItemArr.length()).map { i ->
                val o = invItemArr.getJSONObject(i)
                InvoiceItemEntity(
                    id = o.getString("id"),
                    invoiceId = o.getString("invoiceId"),
                    productId = o.optString("productId").ifBlank { null },
                    itemName = o.getString("itemName"),
                    unit = o.optString("unit", "Piece"),
                    quantityMilliUnits = o.optLong("quantityMilliUnits", 1000L),
                    unitPricePaisa = o.optLong("unitPricePaisa", 0L),
                    costPricePaisa = o.optLong("costPricePaisa", 0L),
                    lineTotalPaisa = o.optLong("lineTotalPaisa", 0L),
                    returnedMilliUnits = o.optLong("returnedMilliUnits", 0L)
                )
            }
            db.invoiceDao().insertItems(list)
        }
        val empArr = root.optJSONArray("employees")
        if (empArr != null) {
            val list = (0 until empArr.length()).map { i ->
                val o = empArr.getJSONObject(i)
                EmployeeEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    name = o.getString("name"),
                    phone = o.optString("phone", ""),
                    email = o.optString("email", ""),
                    role = o.optString("role", EmployeeRoles.CASHIER),
                    salaryPaisa = o.optLong("salaryPaisa", 0L),
                    canViewReports = o.optBoolean("canViewReports", false),
                    canDeleteOrReverse = o.optBoolean("canDeleteOrReverse", false),
                    canManageEmployees = o.optBoolean("canManageEmployees", false),
                    canManageSettings = o.optBoolean("canManageSettings", false),
                    canRecordSales = o.optBoolean("canRecordSales", true),
                    canEditCustomers = o.optBoolean("canEditCustomers", true),
                    canManageInventory = o.optBoolean("canManageInventory", false)
                )
            }
            db.employeeDao().upsertAll(list)
        }
        val roleArr = root.optJSONArray("rolePermissions")
        if (roleArr != null) {
            val list = (0 until roleArr.length()).map { i ->
                val o = roleArr.getJSONObject(i)
                RolePermissionEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    roleName = o.getString("roleName"),
                    canViewDashboard = o.optBoolean("canViewDashboard", true),
                    canViewReports = o.optBoolean("canViewReports", false),
                    canRecordSales = o.optBoolean("canRecordSales", true),
                    canEditCustomers = o.optBoolean("canEditCustomers", true),
                    canManageInventory = o.optBoolean("canManageInventory", false),
                    canDeleteOrReverse = o.optBoolean("canDeleteOrReverse", false),
                    canManageEmployees = o.optBoolean("canManageEmployees", false),
                    canManageSettings = o.optBoolean("canManageSettings", false)
                )
            }
            db.rolePermissionDao().upsertAll(list)
        }
        val salArr = root.optJSONArray("salaryPayments")
        if (salArr != null) {
            for (i in 0 until salArr.length()) {
                val o = salArr.getJSONObject(i)
                db.salaryPaymentDao().insert(
                    SalaryPaymentEntity(
                        id = o.getString("id"),
                        businessId = o.getString("businessId"),
                        employeeId = o.getString("employeeId"),
                        employeeName = o.optString("employeeName", ""),
                        monthKey = o.optString("monthKey", ""),
                        paymentType = o.optString("paymentType", SalaryPaymentTypes.SALARY),
                        amountPaisa = o.optLong("amountPaisa", 0L),
                        accountId = o.optString("accountId", ""),
                        notes = o.optString("notes", ""),
                        occurredAt = o.optLong("occurredAt", System.currentTimeMillis()),
                        createdBy = o.optString("createdBy", "Owner")
                    )
                )
            }
        }
        val bakiArr = root.optJSONArray("bakiKhataEntries")
        if (bakiArr != null) {
            val list = (0 until bakiArr.length()).map { i ->
                val o = bakiArr.getJSONObject(i)
                BakiKhataEntryEntity(
                    id = o.getString("id"),
                    businessId = o.getString("businessId"),
                    customerId = o.getString("customerId"),
                    customerName = o.optString("customerName", ""),
                    entryType = o.optString("entryType", BakiEntryTypes.CREDIT),
                    amountPaisa = o.optLong("amountPaisa", 0L),
                    remainingBalanceAfterPaisa = o.optLong("remainingBalanceAfterPaisa", 0L),
                    entryDateMillis = o.optLong("entryDateMillis", System.currentTimeMillis()),
                    promisedRepaymentDateMillis = if (o.has("promisedRepaymentDateMillis") && !o.isNull("promisedRepaymentDateMillis")) {
                        o.optLong("promisedRepaymentDateMillis")
                    } else null,
                    actualRepaymentDateMillis = if (o.has("actualRepaymentDateMillis") && !o.isNull("actualRepaymentDateMillis")) {
                        o.optLong("actualRepaymentDateMillis")
                    } else null,
                    isSettled = o.optBoolean("isSettled", false),
                    notes = o.optString("notes", ""),
                    transactionId = o.optString("transactionId").ifBlank { null },
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    syncVersion = o.optLong("syncVersion", 1L)
                )
            }
            db.bakiKhataDao().upsertAll(list)
        }
        bizArr.length()
    }
}
