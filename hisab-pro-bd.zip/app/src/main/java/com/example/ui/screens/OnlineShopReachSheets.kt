package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.util.*
import com.example.data.local.*
import com.example.data.repository.AccountingRepository
import com.example.ui.OnlineShopUiState
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoAppShopReachBottomSheet(
    state: OnlineShopUiState,
    useBanglaDigits: Boolean,
    onSaveCustomWebShopUrl: (String) -> Unit,
    onPreviewWebShop: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val business = state.activeBusiness
    val businessName = business?.name ?: strings.appTitle
    val targetUrl = state.effectiveCustomerShopUrl.ifBlank {
        WebStorefrontGenerator.resolveCustomerShopEntryUrl(business, state.customWebShopUrl)
    }

    var urlDraft by remember(state.customWebShopUrl) { mutableStateOf(state.customWebShopUrl) }
    var copiedFeedback by remember { mutableStateOf(false) }

    val qrBitmap by produceState<android.graphics.Bitmap?>(initialValue = null, targetUrl) {
        value = withContext(Dispatchers.Default) {
            QrCodeGenerator.generateQrBitmap(targetUrl, sizePx = 560)
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.noAppWebShopTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = strings.noAppWebShopSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = strings.cancel)
                }
            }

            // Live Scannable Shop QR Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, ShopOrange.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = ShopOrangeSoft,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (strings.isBangla) "ক্যামেরা দিয়ে স্ক্যান করলেই শপ খুলবে (কোনো অ্যাপ লাগবে না)"
                            else "Customer scans with phone camera — zero app install needed",
                            style = MaterialTheme.typography.labelSmall,
                            color = ShopOrangeDark,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(196.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(PureWhite)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val bmp = qrBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "$businessName Shop QR Code",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .testTag("shop_qr_code_image"),
                                contentScale = ContentScale.Fit
                            )
                        } else {
                            CircularProgressIndicator(color = ShopOrange, modifier = Modifier.size(32.dp))
                        }
                    }

                    Text(
                        text = targetUrl,
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(targetUrl))
                                copiedFeedback = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("copy_shop_link_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (copiedFeedback) {
                                    if (strings.isBangla) "কপি হয়েছে" else "Copied"
                                } else {
                                    if (strings.isBangla) "লিংক কপি" else "Copy Link"
                                },
                                maxLines = 1
                            )
                        }
                        Button(
                            onClick = {
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)))
                                } catch (_: Exception) {
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("open_customer_link_button")
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (strings.isBangla) "টেস্ট লিংক" else "Open Link", maxLines = 1)
                        }
                    }
                }
            }

            // 4 Zero-App Distribution Channels
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (strings.isBangla) "ক্রেতাদের কাছে শপ পৌঁছে দেওয়ার সহজ উপায়:" else "Zero-Install Customer Sharing Channels:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onPreviewWebShop,
                        colors = ButtonDefaults.buttonColors(containerColor = DarkNavy, contentColor = PureWhite),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("preview_web_shop_button")
                    ) {
                        Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.previewWebShopLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    Button(
                        onClick = {
                            val file = WebStorefrontGenerator.exportWebStorefrontHtmlFile(
                                context = context,
                                business = business,
                                products = state.allProducts,
                                isBanglaDefault = strings.isBangla,
                                accounts = state.accounts
                            )
                            ExportUtils.shareFile(context, file, "text/html", strings.shareWebShopFileLabel)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ShopOrange, contentColor = PureWhite),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("share_html_shop_button")
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.shareWebShopFileLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = {
                            val posterFile = QrCodeGenerator.generateShopQrPosterFile(
                                context = context,
                                businessName = businessName,
                                businessCategory = business?.category ?: "Online Store",
                                phone = business?.phone.orEmpty(),
                                targetOrderUrl = targetUrl
                            )
                            ExportUtils.shareFile(context, posterFile, "image/png", strings.shareQrPosterLabel)
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = ShopOrangeSoft,
                            contentColor = ShopOrangeDark
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("share_qr_poster_button")
                    ) {
                        Icon(Icons.Default.QrCode2, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.shareQrPosterLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    FilledTonalButton(
                        onClick = {
                            val post = WebStorefrontGenerator.buildSocialShopPost(
                                business = business,
                                products = state.allProducts,
                                targetOrderUrl = targetUrl,
                                useBanglaDigits = useBanglaDigits
                            )
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "$businessName Online Shop")
                                putExtra(Intent.EXTRA_TEXT, post)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, strings.shareSocialPostLabel))
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SoftGreenAccent,
                            contentColor = EmeraldDark
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 52.dp)
                            .testTag("share_social_post_button")
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.shareSocialPostLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            // Custom Hosted Web Shop URL Card
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = strings.customShopUrlLabel,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (strings.isBangla) {
                            "টিপস: উপরের HTML ফাইলটি Netlify Drop (app.netlify.com/drop) বা GitHub Pages-এ ফ্রি আপলোড করে লিংকটি নিচে সেভ করুন—তাহলে QR কোড ও শেয়ার পোস্টে আপনার নিজের ওয়েবসাইট লিংক যাবে। ফাঁকা রাখলে সরাসরি WhatsApp অর্ডার লিংক কাজ করবে।"
                        } else {
                            "Tip: Upload the exported HTML file free on Netlify Drop or GitHub Pages and save the https:// link here so your QR Poster opens your website directly. Leave blank to use direct WhatsApp ordering."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = urlDraft,
                            onValueChange = { urlDraft = it },
                            placeholder = { Text("https://myshop.netlify.app") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("custom_web_shop_url_input")
                        )
                        Button(
                            onClick = { onSaveCustomWebShopUrl(urlDraft) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .heightIn(min = 52.dp)
                                .testTag("save_custom_web_shop_url_button")
                        ) {
                            Text(strings.save)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebShopPreviewDialog(
    business: BusinessEntity?,
    products: List<ProductEntity>,
    isBanglaDefault: Boolean,
    accounts: List<AccountEntity> = emptyList(),
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val htmlContent = remember(business, products, isBanglaDefault, accounts) {
        WebStorefrontGenerator.generateWebStorefrontHtml(business, products, isBanglaDefault, accounts)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                Surface(shadowElevation = 2.dp, color = MaterialTheme.colorScheme.surface) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.previewWebShopLabel,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (strings.isBangla) "ক্রেতা ব্রাউজারে ঠিক এইভাবেই দেখবে ও অর্ডার করবে" else "Exact mobile browser experience for customers",
                                style = MaterialTheme.typography.labelSmall,
                                color = ShopOrange
                            )
                        }
                        TextButton(
                            onClick = {
                                val file = WebStorefrontGenerator.exportWebStorefrontHtmlFile(
                                    context, business, products, isBanglaDefault, accounts
                                )
                                ExportUtils.shareFile(context, file, "text/html", strings.shareWebShopFileLabel)
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (strings.isBangla) "শেয়ার" else "Share")
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_web_preview_button")) {
                            Icon(Icons.Default.Close, contentDescription = strings.cancel)
                        }
                    }
                }
            }
        ) { innerPadding ->
            AndroidView(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean {
                                val uri = request?.url ?: return false
                                val host = uri.host.orEmpty()
                                if (host == "hisabprobd.local") return false
                                return try {
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                    true
                                } catch (_: Exception) {
                                    true
                                }
                            }
                        }
                        loadDataWithBaseURL("https://hisabprobd.local/", htmlContent, "text/html", "UTF-8", null)
                    }
                },
                update = { webView ->
                    if (webView.tag != htmlContent.hashCode()) {
                        webView.tag = htmlContent.hashCode()
                        webView.loadDataWithBaseURL("https://hisabprobd.local/", htmlContent, "text/html", "UTF-8", null)
                    }
                }
            )
        }
    }
}

@Composable
fun ImportCustomerOrderDialog(
    state: OnlineShopUiState,
    useBanglaDigits: Boolean,
    onParseOrder: (String) -> ParsedIncomingOrder,
    onConfirmImport: (
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        deliveryDistrict: String,
        deliveryFeePaisa: Long,
        promoCode: String,
        paymentMethod: String,
        accountId: String?,
        notes: String,
        mfsTrxId: String,
        mfsSenderPhone: String,
        lines: List<AccountingRepository.OnlineCheckoutLine>
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val clipboard = LocalClipboardManager.current

    var rawMessage by remember { mutableStateOf("") }
    var parsed by remember { mutableStateOf<ParsedIncomingOrder?>(null) }

    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }
    var deliveryDistrict by remember { mutableStateOf("Dhaka") }
    var deliveryFeeInput by remember { mutableStateOf("60") }
    var promoCode by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf(OnlinePaymentMethods.COD) }
    var mfsTrxId by remember { mutableStateOf("") }
    var mfsSenderPhone by remember { mutableStateOf("") }

    fun applyParsed(result: ParsedIncomingOrder) {
        parsed = result
        if (result.customerName.isNotBlank()) customerName = result.customerName
        if (result.customerPhone.isNotBlank()) customerPhone = result.customerPhone
        if (result.deliveryAddress.isNotBlank()) deliveryAddress = result.deliveryAddress
        deliveryDistrict = result.deliveryDistrict
        deliveryFeeInput = MoneyUtils.paisaToInputString(result.deliveryFeePaisa).ifBlank { "0" }
        promoCode = result.promoCode
        paymentMethod = result.paymentMethod
        mfsTrxId = result.mfsTrxId
        mfsSenderPhone = result.mfsSenderPhone
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (strings.isBangla) "WhatsApp / Web অর্ডার ইমপোর্ট" else "Import WhatsApp / Web Order",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = if (strings.isBangla) {
                        "ক্রেতার WhatsApp, Messenger বা HTML শপ থেকে পাওয়া অর্ডার মেসেজটি এখানে পেস্ট করে Parse চাপুন।"
                    } else {
                        "Paste the customer's WhatsApp, Messenger, SMS, or Web Shop order message below and tap Parse."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = rawMessage,
                    onValueChange = { rawMessage = it },
                    label = { Text(if (strings.isBangla) "অর্ডার মেসেজ" else "Customer Order Message") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("import_order_raw_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            clipboard.getText()?.text?.let { pasted ->
                                rawMessage = pasted
                                applyParsed(onParseOrder(pasted))
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (strings.isBangla) "পেস্ট" else "Paste")
                    }
                    Button(
                        onClick = { applyParsed(onParseOrder(rawMessage)) },
                        enabled = rawMessage.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = ShopOrange),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("parse_order_message_button")
                    ) {
                        Text(if (strings.isBangla) "পণ্য শনাক্ত করুন" else "Parse Order")
                    }
                }

                parsed?.let { result ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (result.items.isNotEmpty()) SoftGreenAccent else WarningSoftAmber,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = if (result.items.isNotEmpty()) {
                                    "${result.items.size} product(s) matched"
                                } else {
                                    "No catalog product matched automatically"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (result.items.isNotEmpty()) EmeraldDark else WarningAmber
                            )
                            result.items.forEach { line ->
                                Text(
                                    "• ${line.product.name} × ${MoneyUtils.milliUnitsToString(line.quantityMilliUnits, useBanglaDigits)} ${line.product.unit}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            if (result.unmatchedLines.isNotEmpty()) {
                                Text(
                                    "Unmatched: ${result.unmatchedLines.joinToString(", ")}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ExpenseRed
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Customer Name *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("Mobile Number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = deliveryAddress,
                        onValueChange = { deliveryAddress = it },
                        label = { Text("Delivery Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = deliveryFeeInput,
                            onValueChange = { deliveryFeeInput = it },
                            label = { Text("Delivery ৳") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = promoCode,
                            onValueChange = { promoCode = it.uppercase() },
                            label = { Text("Promo") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (MfsPaymentParser.isMfsMethod(paymentMethod) || mfsTrxId.isNotBlank()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = mfsTrxId,
                                onValueChange = { mfsTrxId = it.uppercase() },
                                label = { Text("$paymentMethod TrxID") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("import_order_trxid_input")
                            )
                            OutlinedTextField(
                                value = mfsSenderPhone,
                                onValueChange = { mfsSenderPhone = it },
                                label = { Text("Sender No.") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            val matchedLines = parsed?.items.orEmpty()
            Button(
                onClick = {
                    val account = when (paymentMethod) {
                        OnlinePaymentMethods.BKASH -> state.accounts.firstOrNull { it.type == AccountTypes.BKASH }
                        OnlinePaymentMethods.NAGAD -> state.accounts.firstOrNull { it.type == AccountTypes.NAGAD }
                        OnlinePaymentMethods.ROCKET -> state.accounts.firstOrNull { it.type == AccountTypes.ROCKET }
                        OnlinePaymentMethods.UPAY -> state.accounts.firstOrNull { it.type == AccountTypes.UPAY }
                        OnlinePaymentMethods.BANK -> state.accounts.firstOrNull { it.type == AccountTypes.BANK }
                        else -> state.accounts.firstOrNull { it.type == AccountTypes.CASH }
                    } ?: state.accounts.firstOrNull()

                    onConfirmImport(
                        customerName.trim(),
                        customerPhone.trim(),
                        deliveryAddress.trim(),
                        deliveryDistrict,
                        MoneyUtils.parseTakaToPaisa(deliveryFeeInput),
                        promoCode.trim(),
                        paymentMethod,
                        account?.id,
                        "Imported from Web/WhatsApp Order",
                        mfsTrxId.trim().uppercase(),
                        mfsSenderPhone.trim(),
                        matchedLines.map { AccountingRepository.OnlineCheckoutLine(it.product.id, it.quantityMilliUnits) }
                    )
                    onDismiss()
                },
                enabled = matchedLines.isNotEmpty() && customerName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("confirm_import_order_button")
            ) {
                Text(if (strings.isBangla) "অর্ডার তৈরি করুন" else "Create Order")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel)
            }
        }
    )
}
