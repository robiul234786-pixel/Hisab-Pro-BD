package com.example.data.remote

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserSyncProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String? = null,
    val businessCount: Long = 0L,
    val lastSyncAtMillis: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudBusiness(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val category: String = "",
    val phone: String? = null,
    val address: String? = null,
    val languageCode: String = "en",
    val openingCashPaisa: Long = 0L,
    val inventoryEnabled: Boolean = true,
    val taxEnabled: Boolean = false,
    val defaultTaxRateBps: Long = 0L,
    val archived: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> {
        return mapOf(
            "userId" to uid,
            "name" to name.take(120).ifBlank { "Business" },
            "category" to category.take(60).ifBlank { "Retail Store" },
            "phone" to phone?.take(32)?.ifBlank { null },
            "address" to address?.take(240)?.ifBlank { null },
            "languageCode" to if (languageCode == "bn") "bn" else "en",
            "openingCashPaisa" to openingCashPaisa.coerceAtLeast(0L),
            "inventoryEnabled" to inventoryEnabled,
            "taxEnabled" to taxEnabled,
            "defaultTaxRateBps" to defaultTaxRateBps.coerceIn(0L, 10000L),
            "archived" to archived,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }.mapValues { it.value!! }
    }

    fun toUpdateMap(): Map<String, Any> {
        return mapOf(
            "name" to name.take(120).ifBlank { "Business" },
            "category" to category.take(60).ifBlank { "Retail Store" },
            "phone" to phone?.take(32)?.ifBlank { null },
            "address" to address?.take(240)?.ifBlank { null },
            "languageCode" to if (languageCode == "bn") "bn" else "en",
            "openingCashPaisa" to openingCashPaisa.coerceAtLeast(0L),
            "inventoryEnabled" to inventoryEnabled,
            "taxEnabled" to taxEnabled,
            "defaultTaxRateBps" to defaultTaxRateBps.coerceIn(0L, 10000L),
            "archived" to archived,
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }.mapValues { it.value!! }
    }
}

@Keep
@IgnoreExtraProperties
data class CloudLedgerRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val businessId: String = "",
    val entityType: String = "",
    val title: String = "",
    val subtitle: String? = null,
    val amountPaisa: Long = 0L,
    val balancePaisa: Long = 0L,
    val status: String = "ACTIVE",
    val category: String? = null,
    val phone: String? = null,
    val notes: String? = null,
    val occurredAtMillis: Long = 0L,
    val archived: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> {
        return mapOf(
            "userId" to uid,
            "businessId" to businessId,
            "entityType" to entityType,
            "title" to title.take(160).ifBlank { "Record" },
            "subtitle" to subtitle?.take(240)?.ifBlank { null },
            "amountPaisa" to amountPaisa,
            "balancePaisa" to balancePaisa,
            "status" to status.take(40).ifBlank { "ACTIVE" },
            "category" to category?.take(80)?.ifBlank { null },
            "phone" to phone?.take(32)?.ifBlank { null },
            "notes" to notes?.take(500)?.ifBlank { null },
            "occurredAtMillis" to occurredAtMillis.coerceAtLeast(0L),
            "archived" to archived,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }.mapValues { it.value!! }
    }

    fun toUpdateMap(): Map<String, Any> {
        return mapOf(
            "title" to title.take(160).ifBlank { "Record" },
            "subtitle" to subtitle?.take(240)?.ifBlank { null },
            "amountPaisa" to amountPaisa,
            "balancePaisa" to balancePaisa,
            "status" to status.take(40).ifBlank { "ACTIVE" },
            "category" to category?.take(80)?.ifBlank { null },
            "phone" to phone?.take(32)?.ifBlank { null },
            "notes" to notes?.take(500)?.ifBlank { null },
            "occurredAtMillis" to occurredAtMillis.coerceAtLeast(0L),
            "archived" to archived,
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }.mapValues { it.value!! }
    }
}
