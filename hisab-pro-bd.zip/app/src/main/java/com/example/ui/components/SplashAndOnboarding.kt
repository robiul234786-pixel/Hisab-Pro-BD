package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import coil.compose.AsyncImage
import com.example.R
import com.example.core.util.AppLanguage
import com.example.core.util.LocalAppStrings
import com.example.core.util.MoneyUtils
import com.example.core.util.stringsForLanguage
import com.example.data.local.BusinessCategories
import com.example.data.remote.FirebaseAuthHelper
import com.example.ui.theme.*
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay

@Composable
fun BrandedSplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(0.85f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, animationSpec = tween(420))
        scale.animateTo(1f, animationSpec = tween(480))
        delay(850)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DarkNavy, Color(0xFF0A2A28), DarkNavy)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .scale(scale.value)
                .alpha(alpha.value)
                .padding(24.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_hisab_pro_fg),
                contentDescription = "Hisab Pro BD Logo",
                modifier = Modifier
                    .size(104.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .border(2.dp, EmeraldPrimary.copy(alpha = 0.5f), RoundedCornerShape(26.dp)),
                contentScale = ContentScale.Crop
            )
            Text(
                text = "HISAB PRO BD",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = PureWhite
            )
            Text(
                text = "হিসাব প্রো বিডি • Smart Business Accounting",
                style = MaterialTheme.typography.bodyMedium,
                color = EmeraldLight
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun OnboardingWizard(
    initialLanguageCode: String,
    onLanguageSelected: (String) -> Unit,
    onRestoreBackupUri: (Uri) -> Unit,
    onCompleteSetup: (
        name: String,
        category: String,
        phone: String,
        address: String,
        logoUri: String?,
        languageCode: String,
        openingCashPaisa: Long,
        inventoryEnabled: Boolean,
        pin: String
    ) -> Unit,
    onGoogleRestoreSuccess: (String) -> Unit
) {
    var step by remember { mutableIntStateOf(0) } // 0 = Intro, 1 = Business Profile, 2 = Cash/Lang/PIN
    var selectedLang by remember { mutableStateOf(initialLanguageCode) }
    val strings = remember(selectedLang) { stringsForLanguage(selectedLang) }

    var businessName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(BusinessCategories.ALL.first()) }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var logoUri by remember { mutableStateOf<String?>(null) }
    var openingCashText by remember { mutableStateOf("") }
    var inventoryEnabled by remember { mutableStateOf(true) }
    var pinText by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) }
    var authStatus by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) logoUri = uri.toString()
    }

    val backupRestoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onRestoreBackupUri(uri)
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        AnimatedContent(
            targetState = step,
            label = "onboarding_step",
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) { currentStep ->
            when (currentStep) {
                0 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "HISAB PRO BD",
                                style = MaterialTheme.typography.titleLarge,
                                color = EmeraldPrimary
                            )
                            SingleChoiceSegmentedButtonRow {
                                listOf(AppLanguage.ENGLISH, AppLanguage.BANGLA).forEachIndexed { i, lang ->
                                    SegmentedButton(
                                        selected = selectedLang == lang.code,
                                        onClick = {
                                            selectedLang = lang.code
                                            onLanguageSelected(lang.code)
                                        },
                                        shape = SegmentedButtonDefaults.itemShape(i, 2)
                                    ) {
                                        Text(lang.displayName)
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(16.dp))

                        Image(
                            painter = painterResource(id = R.drawable.img_onboarding_hero),
                            contentDescription = "Hisab Pro BD Business Overview",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                                .clip(RoundedCornerShape(22.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(Modifier.height(20.dp))

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = strings.tagline,
                                style = MaterialTheme.typography.headlineMedium,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = if (selectedLang == "bn")
                                    "ইন্টারনেট ছাড়াই দোকানের বিক্রি, বাকি খাতা, ক্রয়, ক্যাশবুক, স্টক ও লাভ-ক্ষতি হিসাব রাখুন।"
                                else
                                    "Offline-first POS billing, Digital Baki Khata, inventory, cashbook, and P&L reports tailored for Bangladesh.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(Modifier.height(20.dp))

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { step = 1 },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("onboarding_get_started"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(strings.getStarted, style = MaterialTheme.typography.labelLarge)
                            }

                            OutlinedButton(
                                onClick = {
                                    FirebaseAuthHelper.onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onAuthSuccess = {
                                            val uid = Firebase.auth.currentUser?.uid
                                            if (!uid.isNullOrBlank()) onGoogleRestoreSuccess(uid)
                                        },
                                        onAuthError = { authStatus = it },
                                        scope = scope,
                                        onAuthCancelled = { authStatus = "Sign-in cancelled" }
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("onboarding_google_signin"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("${strings.signInWithGoogle} / ${strings.restoreFromCloud}")
                            }

                            TextButton(
                                onClick = { backupRestoreLauncher.launch(arrayOf("application/json", "*/*")) },
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Text(strings.restoreLocalBackup)
                            }

                            authStatus?.let {
                                Text(
                                    text = it,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                1 -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { step = 0 }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                            }
                            Text(strings.createBusinessTitle, style = MaterialTheme.typography.headlineSmall)
                        }

                        // Logo Picker
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(SoftGreenAccent)
                                    .border(1.5.dp, EmeraldPrimary.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                                    .clickable {
                                        photoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                    .testTag("pick_business_logo"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (logoUri != null) {
                                    AsyncImage(
                                        model = logoUri,
                                        contentDescription = "Business logo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(Icons.Default.AddAPhoto, contentDescription = strings.uploadLogo, tint = EmeraldPrimary)
                                }
                            }
                            Column {
                                Text(strings.uploadLogo, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = if (selectedLang == "bn") "ঐচ্ছিক • গ্যালারি থেকে লোগো বেছে নিন" else "Optional • Shown on invoices & PDFs",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        OutlinedTextField(
                            value = businessName,
                            onValueChange = {
                                businessName = it
                                nameError = false
                            },
                            label = { Text(strings.businessName) },
                            isError = nameError,
                            supportingText = if (nameError) {
                                { Text(if (selectedLang == "bn") "ব্যবসার নাম লিখুন" else "Business name is required") }
                            } else null,
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_business_name")
                        )

                        Text(strings.businessCategory, style = MaterialTheme.typography.labelLarge)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            BusinessCategories.ALL.forEach { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text(strings.phoneNumber) },
                            placeholder = { Text("017XXXXXXXX") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_phone")
                        )

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text(strings.address) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_address")
                        )

                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (businessName.isBlank()) {
                                    nameError = true
                                } else {
                                    step = 2
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("onboarding_next_step"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(strings.next)
                        }
                    }
                }

                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { step = 1 }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back)
                            }
                            Text(
                                text = if (selectedLang == "bn") "অ্যাকাউন্টিং ও নিরাপত্তা সেটআপ" else "Accounting & Security",
                                style = MaterialTheme.typography.headlineSmall
                            )
                        }

                        OutlinedTextField(
                            value = openingCashText,
                            onValueChange = { openingCashText = it },
                            label = { Text(strings.openingCashBalance) },
                            placeholder = { Text("0") },
                            prefix = { Text("৳ ") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_opening_cash")
                        )

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(strings.enableInventory, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        text = if (selectedLang == "bn")
                                            "সার্ভিস ব্যবসার জন্য এটি বন্ধ রাখা যায়"
                                        else
                                            "Turn off for pure service businesses",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = inventoryEnabled,
                                    onCheckedChange = { inventoryEnabled = it }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = pinText,
                            onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) pinText = it },
                            label = { Text(strings.securityPinOptional) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("onboarding_pin")
                        )

                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                onCompleteSetup(
                                    businessName,
                                    selectedCategory,
                                    MoneyUtils.formatBdPhone(phone),
                                    address,
                                    logoUri,
                                    selectedLang,
                                    MoneyUtils.parseTakaToPaisa(openingCashText),
                                    inventoryEnabled,
                                    pinText
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("onboarding_finish"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(strings.finishSetup, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}
